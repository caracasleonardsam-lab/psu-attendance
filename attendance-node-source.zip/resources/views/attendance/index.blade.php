@extends('layouts.app')

@section('page_title', 'Master Attendance Log')

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Filter Bar -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-body" style="padding: 18px 24px;">
            <form action="{{ route('attendance.index') }}" method="GET" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
                <input 
                    type="text" 
                    name="search" 
                    class="form-control" 
                    placeholder="Search Student ID or Name..." 
                    value="{{ request('search') }}"
                    style="max-width: 240px;"
                >
                <select name="event_id" class="form-select" style="max-width: 220px;" onchange="this.form.submit()">
                    <option value="">All Events</option>
                    @foreach($events as $ev)
                        <option value="{{ $ev->id }}" {{ request('event_id') == $ev->id ? 'selected' : '' }}>
                            {{ $ev->name }}
                        </option>
                    @endforeach
                </select>
                <select name="program_id" class="form-select" style="max-width: 160px;" onchange="this.form.submit()">
                    <option value="">All Programs</option>
                    @foreach($programs as $p)
                        <option value="{{ $p->id }}" {{ request('program_id') == $p->id ? 'selected' : '' }}>
                            {{ $p->name }}
                        </option>
                    @endforeach
                </select>
                <input 
                    type="date" 
                    name="date" 
                    class="form-control" 
                    value="{{ request('date') }}"
                    style="max-width: 160px;"
                    onchange="this.form.submit()"
                >
                <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
                @if(request()->hasAny(['search', 'event_id', 'program_id', 'date']))
                    <a href="{{ route('attendance.index') }}" class="btn btn-sm" style="color: var(--text-muted);">Reset</a>
                @endif
            </form>
        </div>
    </div>

    <!-- Attendance Table -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-clipboard-check" style="color: var(--success);"></i>
                <span>Recorded Attendance Records ({{ number_format($attendances->total()) }})</span>
            </div>
            <a href="{{ route('reports.index') }}" class="btn btn-sm btn-secondary">
                <i class="fa-solid fa-chart-pie"></i> View Reports & Export
            </a>
            <a href="{{ route('attendance.trash') }}" class="btn btn-sm btn-secondary">
                <i class="fa-solid fa-trash-can"></i> Bin
            </a>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student ID</th>
                        <th>Full Name</th>
                        <th>Program</th>
                        <th>Event</th>
                        <th>Check-in Time</th>
                        <th>Status</th>
                        <th>Scanned By</th>
                        <th style="text-align: right;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($attendances as $idx => $att)
                        <tr>
                            <td style="color: var(--text-muted); font-size: 12px;">{{ $attendances->firstItem() + $idx }}</td>
                            <td style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: var(--primary);">
                                {{ $att->student?->student_id }}
                            </td>
                            <td style="font-weight: 700;">{{ $att->student?->full_name }}</td>
                            <td><span class="badge badge-primary">{{ $att->student?->program?->name ?? 'N/A' }}</span></td>
                            <td>{{ $att->event?->name ?? 'Campus Event' }}</td>
                            <td style="font-size: 12px; color: var(--text-muted);">
                                {{ $att->scanned_at?->format('M d, Y h:i A') }}
                            </td>
                            <td>
                                <span class="badge {{ $att->status === 'present' ? 'badge-success' : 'badge-warning' }}">
                                    {{ strtoupper($att->status) }}
                                </span>
                            </td>
                            <td style="font-size: 12px; color: var(--text-muted);">{{ $att->scanned_by ?? 'Barcode Scanner' }}</td>
                            <td style="text-align: right;">
                                <form action="{{ route('attendance.destroy', $att) }}" method="POST" onsubmit="return confirm('Delete this attendance entry?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm" style="color: var(--danger); background: transparent;" title="Delete">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="9" style="text-align: center; color: var(--text-muted); padding: 36px;">
                                No attendance records found for this query.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div style="padding: 16px 24px; border-top: 1px solid var(--card-border-subtle); display: flex; justify-content: space-between; align-items: center;">
            <div style="font-size: 12px; color: var(--text-muted);">
                Showing {{ $attendances->firstItem() ?? 0 }} to {{ $attendances->lastItem() ?? 0 }} of {{ number_format($attendances->total()) }} entries
            </div>
            <div>
                {{ $attendances->links() }}
            </div>
        </div>
    </div>

</div>
@endsection
