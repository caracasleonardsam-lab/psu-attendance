@extends('layouts.app')

@section('page_title', 'Deleted Attendance')

@section('content')
<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
        <div class="card-title"><i class="fa-solid fa-trash-can" style="color:var(--warning)"></i> Deleted attendance records</div>
        <a href="{{ route('attendance.index') }}" class="btn btn-secondary btn-sm">Back to Attendance</a>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr><th>Student ID</th><th>Student</th><th>Event</th><th>Deleted at</th><th></th></tr>
            </thead>
            <tbody>
                @forelse($attendances as $attendance)
                    <tr>
                        <td>{{ $attendance->student?->student_id ?? 'N/A' }}</td>
                        <td>{{ $attendance->student?->full_name ?? 'Deleted student' }}</td>
                        <td>{{ $attendance->event?->name ?? 'Deleted event' }}</td>
                        <td>{{ $attendance->deleted_at?->format('M d, Y h:i A') }}</td>
                        <td style="text-align:right">
                            <form action="{{ route('attendance.restore', $attendance->id) }}" method="POST">
                                @csrf
                                <button type="submit" class="btn btn-primary btn-sm">Restore</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5" style="text-align:center;padding:30px;color:var(--text-muted)">The attendance bin is empty.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="padding:16px 24px">{{ $attendances->links() }}</div>
</div>
@endsection
