@extends('layouts.app')

@section('page_title', 'Live Attendance Scanner & Verification')

@section('content')
<div style="display: flex; flex-direction: column; gap: 20px;">

    <!-- Top Event Header & Live Stats Bar -->
    <div class="card" style="margin-bottom: 0; background: #ffffff; color: var(--text-main); border: 1px solid var(--card-border); box-shadow: var(--shadow-md);">
        <div class="card-body" style="padding: 20px 24px;">
            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
                
                <!-- Event Identity -->
                <div style="display: flex; align-items: center; gap: 16px;">
                    <div style="width: 52px; height: 52px; border-radius: 14px; background: var(--primary-soft); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 24px; border: 1px solid var(--card-border);">
                        <i class="fa-solid fa-barcode"></i>
                    </div>
                    <div>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <h2 style="font-size: 20px; font-weight: 800; color: var(--text-main); margin: 0;">
                                {{ $selectedEvent ? $selectedEvent->name : 'No Active Event Selected' }}
                            </h2>
                            @if($selectedEvent)
                                <span class="badge {{ $canScan ? 'badge-success' : 'badge-warning' }}" style="font-size: 11px; text-transform: uppercase;">
                                    {{ $canScan ? 'SCANNING ON' : 'SCANNING OFF' }}
                                </span>
                            @endif
                        </div>
                        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px; display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                            @if($selectedEvent)
                                <span><i class="fa-regular fa-calendar" style="color: var(--gold);"></i> {{ $selectedEvent->event_date?->format('F d, Y') }}</span>
                                <span><i class="fa-regular fa-clock" style="color: var(--gold);"></i> {{ $selectedEvent->start_time ? \Carbon\Carbon::parse($selectedEvent->start_time)->format('h:i A') : 'All Day' }}</span>
                                <span><i class="fa-solid fa-location-dot" style="color: var(--gold);"></i> {{ $selectedEvent->venue ?? 'Campus Grounds' }}</span>
                                @if($selectedEvent->require_checkout)
                                    <span class="badge badge-primary" style="font-size: 10px;">
                                        <i class="fa-solid fa-right-from-bracket"></i> Requires Check-Out
                                    </span>
                                @endif
                            @else
                                <span>Please select or create an event to begin scanning.</span>
                            @endif
                        </div>
                    </div>
                </div>

                @if($selectedEvent && !$canScan)
                    <div role="status" style="margin-top: 16px; padding: 12px 16px; border-radius: 8px; background: var(--warning-soft); border: 1px solid var(--line); color: var(--text-main); font-size: 13px;">
                        <i class="fa-solid fa-circle-info" style="color: var(--gold-dark);"></i>
                        {{ $selectedEvent->status === 'scheduled' && $selectedEvent->start_time
                            ? 'Scanning starts automatically at '.\Carbon\Carbon::parse($selectedEvent->start_time)->format('h:i A').'. You can also start scanning early.'
                            : ($scanAvailabilityMessage ?? 'Scanning is unavailable for this event.') }}
                        @if(auth()->user()?->isAdmin() && in_array($selectedEvent->status, ['scheduled', 'active'], true) && !$selectedEvent->scanning_enabled)
                            <form action="{{ route('events.scanning.update', $selectedEvent) }}" method="POST" style="display: inline-block; margin-left: 10px;">
                                @csrf
                                <input type="hidden" name="action" value="start">
                                <input type="hidden" name="return_to_scanner" value="1">
                                <button type="submit" class="btn btn-success btn-sm">
                                    <i class="fa-solid fa-play"></i> Start Scanning Now
                                </button>
                            </form>
                        @else
                            <a href="{{ route('events.show', $selectedEvent) }}" style="font-weight: 700; margin-left: 6px;">Event controls</a>
                        @endif
                    </div>
                @endif

                <!-- Event Switcher & Quick Links -->
                <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                    <form action="{{ route('attendance.scanner') }}" method="GET" style="display: flex; gap: 8px; align-items: center;">
                        <select name="event_id" id="event_id" class="form-select" style="min-width: 220px;" onchange="this.form.submit()">
                            @forelse($events as $ev)
                                <option value="{{ $ev->id }}" {{ $selectedEvent && $selectedEvent->id === $ev->id ? 'selected' : '' }} style="color: #0f172a; background: #ffffff;">
                                    {{ $ev->name }} ({{ ucfirst($ev->status) }})
                                </option>
                            @empty
                                <option value="" style="color: #0f172a;">No active events</option>
                            @endforelse
                        </select>
                    </form>
                    
                    <button type="button" id="btnToggleFullscreen" class="btn btn-sm btn-secondary" title="Fullscreen Kiosk Mode">
                        <i class="fa-solid fa-expand"></i>
                    </button>
                    @if($selectedEvent)
                        <a href="{{ route('events.show', $selectedEvent) }}" class="btn btn-sm btn-secondary" title="Event Settings">
                            <i class="fa-solid fa-sliders"></i>
                        </a>
                    @endif
                </div>

            </div>

            <!-- Real-time Event Attendance Counters -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin-top: 18px; padding-top: 16px; border-top: 1px solid var(--line);">
                <div style="background: var(--success-soft); border: 1px solid rgba(16, 185, 129, 0.2); border-radius: 10px; padding: 10px 14px; text-align: center;">
                    <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: var(--success-dark); letter-spacing: 0.5px;">Present</div>
                    <div style="font-size: 22px; font-weight: 900; color: var(--success-dark);" id="statPresent">{{ $stats['total_present'] ?? 0 }}</div>
                </div>

                <div style="background: var(--warning-soft); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: 10px; padding: 10px 14px; text-align: center;">
                    <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: var(--warning-dark); letter-spacing: 0.5px;">Late</div>
                    <div style="font-size: 22px; font-weight: 900; color: var(--gold-dark);" id="statLate">{{ $stats['total_late'] ?? 0 }}</div>
                </div>

                <div style="background: var(--primary-soft); border: 1px solid rgba(18, 89, 195, 0.2); border-radius: 10px; padding: 10px 14px; text-align: center;">
                    <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: var(--primary); letter-spacing: 0.5px;">Checked Out</div>
                    <div style="font-size: 22px; font-weight: 900; color: var(--primary);" id="statCheckout">{{ $stats['total_checkout'] ?? 0 }}</div>
                </div>

                <div style="background: #f5f3ff; border: 1px solid #ddd6fe; border-radius: 10px; padding: 10px 14px; text-align: center;">
                    <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #6d28d9; letter-spacing: 0.5px;">Total Scanned</div>
                    <div style="font-size: 22px; font-weight: 900; color: #6d28d9;" id="statTotal">{{ $stats['total_scanned'] ?? 0 }}</div>
                </div>
            </div>

        </div>
    </div>

    <!-- Scanner Control Bar -->
    <div class="card" style="margin-bottom: 0; padding: 12px 18px;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;">
            
            <!-- Scan Mode Selector -->
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Scan Action:</span>
                <div class="btn-group" role="group" style="display: inline-flex; border-radius: 8px; overflow: hidden; border: 1px solid var(--line);">
                    <button type="button" class="btn btn-sm btn-mode active" data-mode="checkin" id="btnModeIn" style="padding: 6px 14px; font-weight: 700;">
                        <i class="fa-solid fa-right-to-bracket"></i> Check-In Only
                    </button>
                    <button type="button" class="btn btn-sm btn-mode" data-mode="checkout" id="btnModeOut" style="padding: 6px 14px; font-weight: 700;">
                        <i class="fa-solid fa-right-from-bracket"></i> Check-Out Only
                    </button>
                </div>
            </div>

            <!-- Feedback Preferences -->
            <div style="display: flex; align-items: center; gap: 12px;">
                <!-- Audio Beep Toggle -->
                <button type="button" id="btnToggleSound" class="btn btn-sm btn-secondary" style="display: flex; align-items: center; gap: 6px;" title="Toggle Scanner Audio Beep">
                    <i class="fa-solid fa-volume-high" id="soundIcon"></i>
                    <span id="soundText">Sound: ON</span>
                </button>

                <!-- Status indicator -->
                <div style="display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 700; color: {{ $canScan ? 'var(--success)' : 'var(--text-muted)' }}; padding: 4px 10px; background: {{ $canScan ? '#ecfdf5' : '#f1f5f9' }}; border-radius: 20px; border: 1px solid {{ $canScan ? '#a7f3d0' : 'var(--line)' }};">
                    <span style="width: 8px; height: 8px; border-radius: 50%; background: {{ $canScan ? 'var(--success)' : 'var(--text-muted)' }}; {{ $canScan ? 'animation: pulse 1.5s infinite;' : '' }}"></span>
                    <span>{{ $canScan ? 'Scanner Active' : 'Scanner Paused' }}</span>
                </div>
            </div>

        </div>
    </div>

    <!-- Scanner Split Deck -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;" id="scannerGrid">
        
        <!-- Barcode Scanner & Input -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                <div class="card-title">
                    <i class="fa-solid fa-barcode" style="color: var(--primary);"></i>
                    <span>Barcode Scanner</span>
                </div>
            </div>

            <div class="card-body">

                <!-- Hardware Barcode / ID Input Form -->
                <form id="scanForm" action="{{ route('attendance.scan') }}" method="POST">
                    @csrf
                    <input type="hidden" name="event_id" value="{{ $selectedEvent?->id }}">
                    <input type="hidden" name="scan_mode" id="formScanMode" value="checkin">
                    <input type="hidden" name="source" id="scanSource" value="Hardware Scanner">

                    <div class="form-group" style="margin-bottom: 12px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                            <label class="form-label" for="barcodeInput" style="margin-bottom: 0;">
                                Student Number / ID Barcode
                            </label>
                            <span style="font-size: 11px; color: var(--text-muted); font-weight: 600;">
                                <i class="fa-solid fa-keyboard"></i> Global Wedge Active (Gun & Keyboard)
                            </span>
                        </div>

                        <div style="position: relative;">
                            <input 
                                type="text" 
                                name="barcode" 
                                id="barcodeInput" 
                                class="form-control scanner-glowing-input" 
                                placeholder="Scan student ID barcode or type student number..." 
                                autocomplete="off"
                                required
                                autofocus
                                style="font-size: 16px; font-family: 'JetBrains Mono', monospace; font-weight: 700; padding: 12px 14px; padding-right: 120px;"
                                {{ !$canScan ? 'disabled' : '' }}
                            >
                            <button type="submit" class="btn btn-primary" id="btnSubmitScan" style="position: absolute; right: 6px; top: 6px; bottom: 6px; padding: 0 16px; font-weight: 700;" {{ !$canScan ? 'disabled' : '' }}>
                                <i class="fa-solid fa-bolt"></i> Record
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Feedback Banner -->
                <div id="scanFeedback" style="display: none; padding: 12px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; margin-top: 12px; transition: all 0.2s ease;"></div>

                <!-- Instant Manual Student Lookup Dropdown Drawer -->
                <div style="margin-top: 18px; padding-top: 14px; border-top: 1px dashed var(--line);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <span style="font-size: 12px; font-weight: 700; color: var(--text-muted);">
                            <i class="fa-solid fa-magnifying-glass"></i> Can't scan? Manual Search & Instant Check-in:
                        </span>
                    </div>
                    <div style="position: relative;">
                        <input 
                            type="text" 
                            id="manualSearchInput" 
                            class="form-control form-control-sm" 
                            placeholder="Type student name or ID (e.g. Juan, 23-AC-0395)..."
                            autocomplete="off"
                            style="padding: 8px 12px; font-size: 13px;"
                            {{ !$canScan ? 'disabled' : '' }}
                        >
                        <!-- Autocomplete dropdown container -->
                        <div id="manualSearchResults" style="display: none; position: absolute; left: 0; right: 0; top: 100%; background: #ffffff; border: 1px solid var(--line); border-radius: 8px; box-shadow: var(--shadow-lg); max-height: 220px; overflow-y: auto; z-index: 100; margin-top: 4px;"></div>
                    </div>
                </div>

                <!-- Device Guidance Footer -->
                <div style="margin-top: 16px; padding: 10px 14px; background: #f8fafc; border-radius: 8px; border: 1px solid var(--line); font-size: 12px; color: var(--text-muted); display: flex; align-items: center; gap: 10px;">
                    <i class="fa-solid fa-circle-info" style="color: var(--primary); font-size: 16px;"></i>
                    <span>Connect a USB or Bluetooth barcode scanner, then scan into the student ID field. You can also type a student number manually.</span>
                </div>

            </div>
        </div>

        <!-- Right: Real-time Student Pass Verified Card -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header">
                <div class="card-title">
                    <i class="fa-solid fa-id-card" style="color: var(--gold);"></i>
                    <span>Scanned Student Verification</span>
                </div>
                <span id="scanBadgeState" class="badge badge-neutral">STANDBY</span>
            </div>
            
            <div class="card-body" id="verificationResultCard" style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 380px; text-align: center;">
                
                <!-- Standby State -->
                <div id="standbyState">
                    <div class="radar-pulsing-icon">
                        <i class="fa-solid fa-id-badge"></i>
                    </div>
                    <h4 style="font-size: 17px; font-weight: 800; color: var(--text-main); margin-top: 16px;">Awaiting Badge Scan</h4>
                    <p style="color: var(--text-muted); font-size: 13px; max-width: 320px; margin: 8px auto 0;">
                        Present a student ID barcode or type the student number to record immediate attendance.
                    </p>
                </div>

                <!-- Verified Student Card (Populated dynamically on scan) -->
                <div id="verifiedState" style="display: none; width: 100%;">
                    
                    <!-- Avatar with initials & Gold Ring -->
                    <div style="position: relative; width: 88px; height: 88px; margin: 0 auto 12px;">
                        <div style="width: 100%; height: 100%; border-radius: 50%; background: linear-gradient(135deg, #1e3a8a, #0d234a); color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: 900; border: 3px solid var(--gold); box-shadow: 0 8px 20px rgba(0,0,0,0.2);" id="studentAvatar">
                            JD
                        </div>
                        <div id="verifiedCheckIcon" style="position: absolute; bottom: 0; right: 0; width: 28px; height: 28px; border-radius: 50%; background: var(--success); color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 14px; border: 2px solid #ffffff;">
                            <i class="fa-solid fa-check"></i>
                        </div>
                    </div>

                    <!-- Student Names & ID -->
                    <h3 id="studentName" style="font-size: 20px; font-weight: 900; color: var(--text-main); margin-bottom: 2px;">Juan Dela Cruz</h3>
                    <div id="studentIdCode" style="font-family: 'JetBrains Mono', monospace; font-size: 14px; font-weight: 700; color: var(--primary);">
                        23-AC-0395
                    </div>
                    
                    <!-- Student Attributes Badges -->
                    <div style="display: flex; gap: 8px; justify-content: center; margin-top: 12px; flex-wrap: wrap;">
                        <span class="badge badge-primary" id="studentProgram" style="font-weight: 700;">BSIT</span>
                        <span class="badge badge-neutral" id="studentOrg" style="font-weight: 700;">DOIT</span>
                        <span class="badge badge-neutral" id="studentYear" style="font-weight: 700;">4A</span>
                        <span class="badge badge-success" id="studentEligibilityBadge" style="font-weight: 700;">
                            <i class="fa-solid fa-circle-check"></i> Eligible
                        </span>
                    </div>

                    <!-- Attendance Status & Timestamp Board -->
                    <div style="margin-top: 20px; padding: 16px; background: #f8fafc; border-radius: 12px; border: 1px solid var(--line); display: grid; grid-template-columns: 1fr 1fr; gap: 12px; text-align: center;">
                        <div style="padding: 6px; border-right: 1px solid var(--line);">
                            <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase; font-weight: 700;">Status</div>
                            <div style="font-size: 16px; font-weight: 900; color: var(--success); margin-top: 2px;" id="verifiedStatus">PRESENT</div>
                        </div>
                        <div style="padding: 6px;">
                            <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase; font-weight: 700;">Timestamp</div>
                            <div style="font-size: 16px; font-weight: 900; color: var(--text-main); margin-top: 2px;" id="verifiedTime">--:--:--</div>
                        </div>
                    </div>

                    <!-- Override Action Container (Visible only when eligibility warning triggers) -->
                    <div id="overrideContainer" style="display: none; margin-top: 14px; padding: 12px; background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px;">
                        <p style="font-size: 12px; color: #991b1b; margin-bottom: 8px; font-weight: 600;" id="overrideReason">
                            Student is outside designated event eligibility.
                        </p>
                        <button type="button" class="btn btn-sm btn-primary" onclick="forceOverrideCheckin()" style="font-weight: 700;">
                            <i class="fa-solid fa-shield-halved"></i> Authorize Override Check-in
                        </button>
                    </div>

                </div>

            </div>
        </div>

    </div>

    <!-- Live Scans Session Log Table -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div class="card-title">
                <i class="fa-solid fa-list-check" style="color: var(--success);"></i>
                <span>Recent Attendees for this Session (<span id="tableCountBadge">{{ $recentScans->count() }}</span>)</span>
            </div>
            
            <div style="display: flex; gap: 10px; align-items: center;">
                <input 
                    type="text" 
                    id="tableFilterInput" 
                    class="form-control form-control-sm" 
                    placeholder="Filter list..." 
                    style="max-width: 180px; padding: 4px 10px; font-size: 12px;"
                    onkeyup="filterScansTable()"
                >
                @if($selectedEvent)
                    <a href="{{ route('events.export', $selectedEvent) }}" class="btn btn-sm btn-secondary">
                        <i class="fa-solid fa-download"></i> Export Roster CSV
                    </a>
                @endif
            </div>
        </div>

        <div class="table-responsive">
            <table class="table" id="scansTable">
                <thead>
                    <tr>
                        <th style="width: 40px;">#</th>
                        <th>Student ID</th>
                        <th>Full Name</th>
                        <th>Program</th>
                        <th>Organization</th>
                        <th>Status</th>
                        <th>Scanned Time</th>
                        <th>Operator / Method</th>
                        <th style="text-align: right;">Action</th>
                    </tr>
                </thead>
                <tbody id="scansTableBody">
                    @forelse($recentScans as $idx => $att)
                        <tr id="attRow_{{ $att->id }}">
                            <td class="row-index">{{ $idx + 1 }}</td>
                            <td style="font-family: 'JetBrains Mono', monospace; font-weight: 600;">{{ $att->student?->student_id }}</td>
                            <td style="font-weight: 700;">{{ $att->student?->full_name }}</td>
                            <td><span class="badge badge-primary">{{ $att->student?->program?->name ?? 'N/A' }}</span></td>
                            <td><span class="badge badge-neutral">{{ $att->student?->organization?->name ?? 'N/A' }}</span></td>
                            <td>
                                @if(str_contains($att->notes ?? '', 'Checked out') || $att->status === 'checked_out')
                                    <span class="badge" style="background: #dbeafe; color: #1e40af; font-weight: 700;">
                                        CHECKED OUT
                                    </span>
                                @elseif($att->status === 'present')
                                    <span class="badge badge-success" style="font-weight: 700;">PRESENT</span>
                                @else
                                    <span class="badge badge-warning" style="font-weight: 700;">{{ strtoupper($att->status) }}</span>
                                @endif
                            </td>
                            <td style="font-size: 12px; color: var(--text-muted); font-weight: 600;">
                                {{ $att->scanned_at?->format('h:i:s A') }}
                            </td>
                            <td style="font-size: 12px; color: var(--text-muted);">
                                {{ $att->scanned_by ?? 'Barcode Scanner' }}
                            </td>
                            <td style="text-align: right;">
                                <button type="button" class="btn btn-sm btn-danger" onclick="undoScan({{ $att->id }}, '{{ addslashes($att->student?->full_name ?? 'Student') }}')" title="Remove attendance record" style="padding: 4px 8px; font-size: 11px;">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    @empty
                        <tr id="emptyScanRow">
                            <td colspan="9" style="text-align: center; color: var(--text-muted); padding: 32px;">
                                <i class="fa-solid fa-barcode" style="font-size: 32px; opacity: 0.3; margin-bottom: 8px; display: block;"></i>
                                No attendees recorded for this session yet. Ready for scans!
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    <!-- Floating Live Scan Confirmation Toast -->
    <div id="scanLiveToast" class="scan-toast">
        <div id="toastAvatar" style="width: 44px; height: 44px; border-radius: 50%; background: var(--primary); color: #ffffff; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 16px; border: 2px solid var(--gold); flex-shrink: 0;">
            JD
        </div>
        <div style="flex: 1; min-width: 0;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <strong id="toastStudentName" style="font-size: 15px; color: #ffffff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Juan Dela Cruz</strong>
                <span id="toastBadgeStatus" class="badge badge-success" style="font-size: 10px; padding: 2px 6px;">PRESENT</span>
            </div>
            <div id="toastStudentId" style="font-family: 'JetBrains Mono', monospace; font-size: 12px; color: #cbd5e1; margin-top: 2px;">
                23-AC-0395
            </div>
        </div>
        <div id="toastActionIcon" style="width: 32px; height: 32px; border-radius: 50%; background: rgba(16, 185, 129, 0.2); color: #34d399; display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0;">
            <i class="fa-solid fa-check"></i>
        </div>
    </div>

</div>
@endsection

@push('styles')
<style>
    /* Floating Toast Notification */
    .scan-toast {
        position: fixed;
        bottom: 28px;
        left: 50%;
        transform: translateX(-50%) translateY(100px);
        background: #07152d;
        color: #ffffff;
        padding: 14px 20px;
        border-radius: 14px;
        box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
        border: 2px solid var(--gold);
        display: flex;
        align-items: center;
        gap: 14px;
        z-index: 1000;
        opacity: 0;
        transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        min-width: 320px;
        max-width: 90vw;
        pointer-events: none;
    }
    .scan-toast.show {
        transform: translateX(-50%) translateY(0);
        opacity: 1;
        pointer-events: auto;
    }

    /* Flash highlight on newly scanned row */
    @keyframes rowScanFlash {
        0% { background: rgba(16, 185, 129, 0.35); }
        100% { background: transparent; }
    }
    .row-flash {
        animation: rowScanFlash 2s ease-out;
    }

    /* Radar icon pulse */
    .radar-pulsing-icon {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: #f1f5f9;
        color: var(--text-muted);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 32px;
        margin: 0 auto;
        position: relative;
    }

    .radar-pulsing-icon::after {
        content: '';
        position: absolute;
        inset: -6px;
        border-radius: 50%;
        border: 2px solid var(--primary);
        opacity: 0.4;
        animation: radarPulse 2s cubic-bezier(0.25, 0.46, 0.45, 0.94) infinite;
    }

    @keyframes radarPulse {
        0% { transform: scale(0.9); opacity: 0.8; }
        100% { transform: scale(1.3); opacity: 0; }
    }

    /* Glowing focus on barcode input */
    .scanner-glowing-input:focus {
        border-color: var(--primary) !important;
        box-shadow: 0 0 0 4px rgba(18, 89, 195, 0.25) !important;
    }

    /* Mode Button Active Styles */
    .btn-mode {
        background: #f8fafc;
        color: var(--text-main);
        border: none;
        border-right: 1px solid var(--line);
    }
    .btn-mode:last-child {
        border-right: none;
    }
    .btn-mode.active {
        background: var(--primary);
        color: #ffffff;
    }
</style>
@endpush

@push('scripts')
<script>
    // Audio synthesis feedback
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    let soundEnabled = localStorage.getItem('scanner_sound') !== 'false';
    let currentScanMode = 'checkin';
    let lastPendingBarcode = '';

    // Initialize UI Toggles
    const soundText = document.getElementById('soundText');
    const soundIcon = document.getElementById('soundIcon');
    function updateAudioControls() {
        soundText.textContent = soundEnabled ? 'Sound: ON' : 'Sound: OFF';
        soundIcon.className = soundEnabled ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark';
    }
    updateAudioControls();

    document.getElementById('btnToggleSound').addEventListener('click', () => {
        soundEnabled = !soundEnabled;
        localStorage.setItem('scanner_sound', soundEnabled);
        updateAudioControls();
        if (soundEnabled) playBeep('success');
    });

    // Scan Mode Buttons
    document.querySelectorAll('.btn-mode').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.btn-mode').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentScanMode = btn.dataset.mode;
            document.getElementById('formScanMode').value = currentScanMode;
        });
    });

    // Fullscreen Kiosk Mode
    document.getElementById('btnToggleFullscreen').addEventListener('click', () => {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => alert(err.message));
        } else {
            document.exitFullscreen();
        }
    });

    // Sound FX
    function playBeep(type) {
        if (!soundEnabled || !audioCtx) return;
        try {
            if (audioCtx.state === 'suspended') {
                audioCtx.resume();
            }
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);

            if (type === 'success') {
                // Happy chord chime
                osc.type = 'sine';
                osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
                osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.08); // A5
                gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.25);
            } else if (type === 'checkout') {
                // Checkout chime (descending)
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(880, audioCtx.currentTime);
                osc.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.1);
                gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.3);
            } else if (type === 'warning') {
                // Double warning beep
                osc.type = 'square';
                osc.frequency.setValueAtTime(440, audioCtx.currentTime);
                gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.25);
            } else {
                // Low buzz error
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(180, audioCtx.currentTime);
                gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.35);
            }
        } catch (e) {}
    }

    const barcodeInput = document.getElementById('barcodeInput');
    const scanFeedback = document.getElementById('scanFeedback');
    const standbyState = document.getElementById('standbyState');
    const verifiedState = document.getElementById('verifiedState');
    const scanBadgeState = document.getElementById('scanBadgeState');
    const overrideContainer = document.getElementById('overrideContainer');

    // Auto-focus retention
    window.addEventListener('click', (e) => {
        if (!['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON', 'A'].includes(e.target.tagName)) {
            barcodeInput?.focus();
        }
    });

    // Global Hardware Barcode Wedge Listener
    // Handheld USB / Bluetooth laser barcode scanners act as super-fast keyboard input
    let wedgeBuffer = '';
    let lastKeyTime = Date.now();

    window.addEventListener('keydown', (e) => {
        if (e.target.id === 'barcodeInput') {
            return;
        }

        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName) || e.target.isContentEditable) {
            return;
        }

        const currentTime = Date.now();
        const diff = currentTime - lastKeyTime;
        lastKeyTime = currentTime;

        // Rapid key bursts indicate a hardware scanner wedge.
        if (e.key === 'Enter') {
            if (wedgeBuffer.length >= 3) {
                e.preventDefault();
                barcodeInput.value = wedgeBuffer;
                wedgeBuffer = '';
                document.getElementById('scanSource').value = 'Laser Barcode Gun';
                document.getElementById('scanForm').requestSubmit();
            }
            wedgeBuffer = '';
        } else if (e.key.length === 1) {
            if (diff > 120) {
                wedgeBuffer = '';
            }
            wedgeBuffer += e.key;
        }
    });

    // Scan Submit Handler
    let isSubmitting = false;
    let lastScannedCode = '';
    let lastScannedTimestamp = 0;

    barcodeInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            document.getElementById('scanForm').requestSubmit();
        }
    });

    async function handleScanSubmit(e) {
        if (e) e.preventDefault();
        const code = barcodeInput.value.trim();
        if (!code) {
            scanFeedback.style.display = 'block';
            scanFeedback.style.background = '#fef2f2';
            scanFeedback.style.color = '#991b1b';
            scanFeedback.style.border = '1px solid #fecaca';
            scanFeedback.textContent = 'No barcode was received. Scan again or type the student number.';
            barcodeInput.focus();
            return;
        }
        if (isSubmitting) return;

        // Debounce: Ignore exact duplicate scan if under 1.2s
        const now = Date.now();
        if (code === lastScannedCode && (now - lastScannedTimestamp) < 1200) {
            barcodeInput.value = '';
            return;
        }

        lastScannedCode = code;
        lastScannedTimestamp = now;
        lastPendingBarcode = code;
        isSubmitting = true;

        const form = document.getElementById('scanForm');
        const formData = new FormData(form);

        scanFeedback.style.display = 'block';
        scanFeedback.style.background = '#eff6ff';
        scanFeedback.style.color = '#1d4ed8';
        scanFeedback.style.border = '1px solid #bfdbfe';
        scanFeedback.textContent = 'Processing verification for: ' + code + '...';

        try {
            const resp = await fetch(form.action, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: formData
            });

            const data = await resp.json();

            if (data.success) {
                const isOut = data.action === 'checkout';
                playBeep(isOut ? 'checkout' : 'success');

                scanFeedback.style.background = isOut ? '#eff6ff' : '#ecfdf5';
                scanFeedback.style.color = isOut ? '#1e40af' : '#065f46';
                scanFeedback.style.border = isOut ? '1px solid #bfdbfe' : '1px solid #a7f3d0';
                scanFeedback.textContent = data.message;

                // Update Verification Card
                standbyState.style.display = 'none';
                verifiedState.style.display = 'block';
                overrideContainer.style.display = 'none';

                scanBadgeState.className = isOut ? 'badge badge-primary' : 'badge badge-success';
                scanBadgeState.textContent = isOut ? 'CHECKED OUT' : 'VERIFIED';

                document.getElementById('studentName').textContent = data.student.full_name;
                document.getElementById('studentIdCode').textContent = data.student.student_id;
                document.getElementById('studentAvatar').textContent = data.student.full_name.split(' ').map(n=>n[0]).join('').substring(0,2).toUpperCase();
                document.getElementById('studentProgram').textContent = data.student.program || 'N/A';
                document.getElementById('studentOrg').textContent = data.student.organization || 'N/A';
                document.getElementById('studentYear').textContent = `${data.student.year_level || 'N/A'}${data.student.block ? ` / ${data.student.block}` : ''}`;
                document.getElementById('studentEligibilityBadge').style.display = 'inline-block';
                document.getElementById('verifiedStatus').textContent = data.attendance.status.toUpperCase();
                document.getElementById('verifiedStatus').style.color = isOut ? '#2563eb' : 'var(--success)';
                document.getElementById('verifiedTime').textContent = data.attendance.scanned_at;

                // Update stats
                if (data.stats) updateLiveStats(data.stats);

                // Prepend or update live table
                prependToScansTable(data);

            } else if (data.eligibility_warning) {
                // Event eligibility warning
                playBeep('warning');
                scanFeedback.style.background = '#fffbeb';
                scanFeedback.style.color = '#92400e';
                scanFeedback.style.border = '1px solid #fde68a';
                scanFeedback.textContent = data.message;

                standbyState.style.display = 'none';
                verifiedState.style.display = 'block';
                scanBadgeState.className = 'badge badge-warning';
                scanBadgeState.textContent = 'ELIGIBILITY NOTICE';

                document.getElementById('studentName').textContent = data.student.full_name;
                document.getElementById('studentIdCode').textContent = data.student.student_id;
                document.getElementById('studentAvatar').textContent = data.student.full_name.split(' ').map(n=>n[0]).join('').substring(0,2).toUpperCase();
                document.getElementById('studentProgram').textContent = data.student.program || 'N/A';
                document.getElementById('studentOrg').textContent = data.student.organization || 'N/A';
                document.getElementById('studentYear').textContent = `${data.student.year_level || 'N/A'}${data.student.block ? ` / ${data.student.block}` : ''}`;
                document.getElementById('studentEligibilityBadge').style.display = 'none';
                document.getElementById('verifiedStatus').textContent = 'RESTRICTED';
                document.getElementById('verifiedStatus').style.color = 'var(--warning)';

                overrideContainer.style.display = 'block';
                document.getElementById('overrideReason').textContent = data.message;

            } else if (data.already_recorded) {
                playBeep('warning');
                scanFeedback.style.background = '#fffbeb';
                scanFeedback.style.color = '#92400e';
                scanFeedback.style.border = '1px solid #fde68a';
                scanFeedback.textContent = data.message;
                scanBadgeState.className = 'badge badge-warning';
                scanBadgeState.textContent = 'DUPLICATE';

            } else {
                playBeep('error');
                scanFeedback.style.background = '#fef2f2';
                scanFeedback.style.color = '#991b1b';
                scanFeedback.style.border = '1px solid #fecaca';
                scanFeedback.textContent = data.message || 'Student ID not recognized.';
                scanBadgeState.className = 'badge badge-danger';
                scanBadgeState.textContent = 'NOT FOUND';

            }

        } catch (err) {
            playBeep('error');
            scanFeedback.style.background = '#fef2f2';
            scanFeedback.style.color = '#991b1b';
            scanFeedback.textContent = 'Network or server communication error.';
        } finally {
            isSubmitting = false;
            barcodeInput.value = '';
            barcodeInput.focus();
        }
    }

    document.getElementById('scanForm').addEventListener('submit', handleScanSubmit);

    // Force Override Checkin
    function forceOverrideCheckin() {
        if (!lastPendingBarcode) return;
        const form = document.getElementById('scanForm');
        barcodeInput.value = lastPendingBarcode;

        // Temporarily append allow_override
        let overrideInput = document.getElementById('tempOverrideInput');
        if (!overrideInput) {
            overrideInput = document.createElement('input');
            overrideInput.type = 'hidden';
            overrideInput.name = 'allow_override';
            overrideInput.id = 'tempOverrideInput';
            form.appendChild(overrideInput);
        }
        overrideInput.value = '1';

        handleScanSubmit().then(() => {
            overrideInput.value = '0';
        });
    }

    // Prepend to live attendees table
    function prependToScansTable(data) {
        const emptyRow = document.getElementById('emptyScanRow');
        if (emptyRow) emptyRow.remove();

        // Check if row already exists (for checkout update)
        const existingRow = document.getElementById('attRow_' + data.attendance.id);
        if (existingRow) {
            existingRow.style.background = '#eff6ff';
            existingRow.cells[5].innerHTML = `<span class="badge" style="background: #dbeafe; color: #1e40af; font-weight: 700;">CHECKED OUT</span>`;
            existingRow.cells[6].textContent = data.attendance.scanned_at;
            return;
        }

        const tbody = document.getElementById('scansTableBody');
        const row = document.createElement('tr');
        row.id = 'attRow_' + data.attendance.id;
        row.classList.add('row-flash');
        row.style.background = data.action === 'checkout' ? '#eff6ff' : '#f0fdf4';
        row.innerHTML = `
            <td class="row-index">•</td>
            <td style="font-family: 'JetBrains Mono', monospace; font-weight: 600;">${data.student.student_id}</td>
            <td style="font-weight: 700;">${data.student.full_name}</td>
            <td><span class="badge badge-primary">${data.student.program || 'N/A'}</span></td>
            <td><span class="badge badge-neutral">${data.student.organization || 'N/A'}</span></td>
            <td>
                <span class="badge ${data.action === 'checkout' ? 'badge-primary' : 'badge-success'}" style="font-weight: 700;">
                    ${data.attendance.status.toUpperCase()}
                </span>
            </td>
            <td style="font-size: 12px; color: var(--text-muted); font-weight: 600;">${data.attendance.scanned_at}</td>
            <td style="font-size: 12px; color: var(--text-muted);">${document.getElementById('scanSource').value}</td>
            <td style="text-align: right;">
                <button type="button" class="btn btn-sm btn-danger" onclick="undoScan(${data.attendance.id}, '${data.student.full_name.replace("'", "\\'")}')" title="Remove attendance record" style="padding: 4px 8px; font-size: 11px;">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </td>
        `;
        tbody.insertBefore(row, tbody.firstChild);

        // Update count badge
        const countBadge = document.getElementById('tableCountBadge');
        if (countBadge) {
            countBadge.textContent = parseInt(countBadge.textContent || '0') + 1;
        }

        // Show floating toast
        showScanLiveToast(
            data.student.full_name,
            data.student.student_id,
            data.attendance.status.toUpperCase(),
            data.action === 'checkout'
        );
    }

    let toastTimeout = null;
    function showScanLiveToast(name, id, status, isCheckout) {
        const toast = document.getElementById('scanLiveToast');
        if (!toast) return;
        const initials = name.split(' ').map(n=>n[0]).join('').substring(0,2).toUpperCase();
        document.getElementById('toastAvatar').textContent = initials;
        document.getElementById('toastStudentName').textContent = name;
        document.getElementById('toastStudentId').textContent = id;
        
        const badge = document.getElementById('toastBadgeStatus');
        if (badge) {
            badge.textContent = status;
            badge.className = isCheckout ? 'badge badge-primary' : 'badge badge-success';
        }

        const icon = document.getElementById('toastActionIcon');
        if (icon) {
            icon.innerHTML = isCheckout ? '<i class="fa-solid fa-right-from-bracket"></i>' : '<i class="fa-solid fa-check"></i>';
            icon.style.background = isCheckout ? 'rgba(37, 99, 235, 0.2)' : 'rgba(16, 185, 129, 0.2)';
            icon.style.color = isCheckout ? '#60a5fa' : '#34d399';
        }

        toast.classList.add('show');
        if (toastTimeout) clearTimeout(toastTimeout);
        toastTimeout = setTimeout(() => {
            toast.classList.remove('show');
        }, 2500);
    }

    // Live Stats updater
    function updateLiveStats(stats) {
        if (!stats) return;
        if (document.getElementById('statPresent')) document.getElementById('statPresent').textContent = stats.total_present;
        if (document.getElementById('statLate')) document.getElementById('statLate').textContent = stats.total_late;
        if (document.getElementById('statCheckout')) document.getElementById('statCheckout').textContent = stats.total_checkout;
        if (document.getElementById('statTotal')) document.getElementById('statTotal').textContent = stats.total_scanned;
    }

    // Undo Scan Handler
    async function undoScan(id, studentName) {
        if (!confirm(`Are you sure you want to remove the attendance record for ${studentName}?`)) {
            return;
        }

        try {
            const resp = await fetch(`{{ url('/attendance') }}/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                }
            });

            const data = await resp.json();
            if (data.success) {
                const row = document.getElementById('attRow_' + id);
                if (row) {
                    row.style.transition = 'all 0.3s ease';
                    row.style.opacity = '0';
                    setTimeout(() => row.remove(), 300);
                }
                if (data.stats) updateLiveStats(data.stats);
                playBeep('warning');
            }
        } catch (e) {
            alert('Failed to remove attendance record: ' + e.message);
        }
    }

    // Filter Recent Scans Table
    function filterScansTable() {
        const query = document.getElementById('tableFilterInput').value.toLowerCase();
        const rows = document.querySelectorAll('#scansTableBody tr');
        rows.forEach(r => {
            if (r.id === 'emptyScanRow') return;
            const text = r.textContent.toLowerCase();
            r.style.display = text.includes(query) ? '' : 'none';
        });
    }

    // Manual Student Search Dropdown
    const manualSearchInput = document.getElementById('manualSearchInput');
    const manualSearchResults = document.getElementById('manualSearchResults');
    let searchDebounceTimer = null;

    manualSearchInput.addEventListener('input', () => {
        clearTimeout(searchDebounceTimer);
        const q = manualSearchInput.value.trim();
        if (q.length < 2) {
            manualSearchResults.style.display = 'none';
            manualSearchResults.innerHTML = '';
            return;
        }

        searchDebounceTimer = setTimeout(async () => {
            try {
                const resp = await fetch(`{{ route('attendance.search_students') }}?q=${encodeURIComponent(q)}`, {
                    headers: { 'Accept': 'application/json' }
                });
                const students = await resp.json();

                if (students.length === 0) {
                    manualSearchResults.innerHTML = `<div style="padding: 10px 14px; font-size: 12px; color: var(--text-muted);">No matching students found</div>`;
                } else {
                    manualSearchResults.innerHTML = students.map(s => `
                        <div style="padding: 10px 14px; border-bottom: 1px solid var(--line); display: flex; justify-content: space-between; align-items: center; cursor: pointer; transition: background 0.15s;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background=''" onclick="selectManualStudent('${s.student_id}')">
                            <div>
                                <div style="font-weight: 700; font-size: 13px; color: var(--text-main);">${s.full_name}</div>
                                <div style="font-size: 11px; color: var(--text-muted); font-family: 'JetBrains Mono', monospace;">${s.student_id} • ${s.program} (${s.year_level || 'N/A'}${s.block ? ` / ${s.block}` : ''})</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-primary" style="padding: 4px 10px; font-size: 11px; font-weight: 700;">
                                <i class="fa-solid fa-check"></i> Check In
                            </button>
                        </div>
                    `).join('');
                }
                manualSearchResults.style.display = 'block';
            } catch (err) {}
        }, 200);
    });

    function selectManualStudent(studentId) {
        manualSearchResults.style.display = 'none';
        manualSearchInput.value = '';
        barcodeInput.value = studentId;
        document.getElementById('scanSource').value = 'Manual Search';
        document.getElementById('scanForm').requestSubmit();
    }

    document.addEventListener('click', (e) => {
        if (!manualSearchInput.contains(e.target) && !manualSearchResults.contains(e.target)) {
            manualSearchResults.style.display = 'none';
        }
    });

</script>
@if($lifecycleRefreshAt)
<script>
(() => {
    const transitionAt = Number(@json($lifecycleRefreshAt));
    const refreshAtTransition = () => {
        const remaining = transitionAt - Date.now();
        if (remaining <= 0) {
            window.location.reload();
            return;
        }
        window.setTimeout(refreshAtTransition, Math.min(remaining + 250, 30000));
    };
    refreshAtTransition();
})();
</script>
@endif
@endpush
