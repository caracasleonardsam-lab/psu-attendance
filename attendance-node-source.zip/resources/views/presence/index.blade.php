@extends('layouts.app')

@section('page_title', 'Presence Verification & Geofence Perimeter')

@push('styles')
<!-- Leaflet CSS for Interactive Geofencing -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
<style>
    /* Radar Map Styling & Theme */
    #geofenceMap {
        height: 520px;
        width: 100%;
        border-radius: var(--radius-sm);
        z-index: 1;
        background: #0f172a;
    }

    [data-theme="dark"] #geofenceMap {
        box-shadow: inset 0 0 20px rgba(0, 0, 0, 0.6);
    }

    /* Radar Wave Pulse Animation */
    .radar-pulse-container {
        position: relative;
        width: 0;
        height: 0;
        pointer-events: none;
    }
    .radar-ring {
        position: absolute;
        top: -60px;
        left: -60px;
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 2px solid rgba(18, 89, 195, 0.65);
        background: radial-gradient(circle, rgba(18, 89, 195, 0.18) 0%, rgba(18, 89, 195, 0) 70%);
        animation: radarRipple 2.6s cubic-bezier(0.2, 0.6, 0.35, 1) infinite;
        pointer-events: none;
    }
    .radar-ring:nth-child(2) {
        animation-delay: 0.85s;
    }
    .radar-ring:nth-child(3) {
        animation-delay: 1.7s;
    }

    @keyframes radarRipple {
        0% {
            transform: scale(0.1);
            opacity: 0.95;
            border-color: rgba(245, 158, 11, 0.8);
        }
        50% {
            opacity: 0.6;
            border-color: rgba(18, 89, 195, 0.7);
        }
        100% {
            transform: scale(3.4);
            opacity: 0;
            border-color: rgba(18, 89, 195, 0);
        }
    }

    /* Student Pin Markers */
    .student-ping-marker {
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        cursor: pointer;
        transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.2s ease;
    }
    .student-ping-marker:hover {
        transform: scale(1.4) !important;
        z-index: 9999 !important;
    }

    .ping-inside {
        width: 24px;
        height: 24px;
        background: #10b981;
        color: #ffffff;
        border: 2px solid #ffffff;
        box-shadow: 0 0 12px rgba(16, 185, 129, 0.8), 0 2px 4px rgba(0,0,0,0.2);
        font-size: 11px;
    }

    .ping-outside {
        width: 26px;
        height: 26px;
        background: #ef4444;
        color: #ffffff;
        border: 2px solid #ffffff;
        box-shadow: 0 0 14px rgba(239, 68, 68, 0.9), 0 2px 4px rgba(0,0,0,0.3);
        font-size: 11px;
        animation: pingOutsideFlash 1.5s ease-in-out infinite;
    }

    @keyframes pingOutsideFlash {
        0%, 100% {
            transform: scale(1);
            box-shadow: 0 0 10px rgba(239, 68, 68, 0.8);
        }
        50% {
            transform: scale(1.22);
            box-shadow: 0 0 22px rgba(239, 68, 68, 1);
        }
    }

    /* Preset & Tool Buttons */
    .geofence-preset-btn {
        background: var(--bg-body);
        border: 1px solid var(--line);
        color: var(--text-main);
        padding: 6px 12px;
        font-size: 11.5px;
        font-weight: 700;
        border-radius: 6px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.18s ease;
    }
    .geofence-preset-btn:hover, .geofence-preset-btn.active {
        background: var(--primary);
        color: #ffffff;
        border-color: var(--primary);
        box-shadow: 0 2px 6px rgba(18, 89, 195, 0.3);
    }

    /* Filter Pills */
    .map-filter-pill {
        background: var(--bg-body);
        border: 1px solid var(--line);
        color: var(--text-muted);
        padding: 5px 11px;
        font-size: 11px;
        font-weight: 700;
        border-radius: 20px;
        cursor: pointer;
        transition: all 0.15s ease;
    }
    .map-filter-pill:hover, .map-filter-pill.active {
        background: var(--primary);
        color: #ffffff;
        border-color: var(--primary);
    }

    /* Radius Slider */
    .radius-slider {
        -webkit-appearance: none;
        width: 100%;
        height: 6px;
        border-radius: 5px;
        background: var(--line);
        outline: none;
    }
    .radius-slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: var(--primary);
        cursor: pointer;
        border: 2px solid #ffffff;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.35);
        transition: transform 0.1s ease;
    }
    .radius-slider::-webkit-slider-thumb:hover {
        transform: scale(1.15);
    }

    /* Leaflet Popups */
    .leaflet-popup-content-wrapper {
        border-radius: 10px;
        box-shadow: var(--shadow-lg);
        font-family: 'Plus Jakarta Sans', sans-serif;
        background: var(--card-bg);
        color: var(--text-main);
        padding: 0;
        overflow: hidden;
    }
    .leaflet-popup-content {
        margin: 0 !important;
        line-height: 1.4;
    }
    .leaflet-popup-tip {
        background: var(--card-bg);
    }
    .popup-card {
        padding: 14px 16px;
    }
    .popup-card-header {
        display: flex;
        align-items: center;
        gap: 8px;
        padding-bottom: 8px;
        border-bottom: 1px solid var(--line);
        margin-bottom: 10px;
    }
    .popup-row {
        display: flex;
        justify-content: space-between;
        font-size: 11.5px;
        margin-bottom: 5px;
    }
    .popup-row-label {
        color: var(--text-muted);
    }
    .popup-row-val {
        font-weight: 700;
        color: var(--text-main);
    }

    /* Live Telemetry Pulsing Dot */
    .radar-live-badge {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        background: rgba(16, 185, 129, 0.12);
        color: #10b981;
        border: 1px solid rgba(16, 185, 129, 0.3);
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 0.3px;
    }
    .pulse-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #10b981;
        box-shadow: 0 0 8px #10b981;
        animation: dotPulse 1.6s infinite ease-in-out;
    }
    @keyframes dotPulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.4; transform: scale(0.8); }
    }
</style>
@endpush

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Top Event Switcher & KPI Deck -->
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
        <div>
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
                <h2 style="font-size: 22px; font-weight: 800; color: var(--text-main); margin: 0;">
                    Presence Verification &amp; Geofence Perimeter
                </h2>
                <span class="radar-live-badge">
                    <span class="pulse-dot"></span> Radar Engine Active
                </span>
            </div>
            <div style="font-size: 13px; color: var(--text-muted);">
                Calibrate virtual boundary coordinates and radius parameters for campus mobile check-in verification.
            </div>
        </div>

        <form action="{{ route('presence.index') }}" method="GET" style="display: flex; gap: 10px; align-items: center;">
            <label for="eventSelector" style="font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Event:</label>
            <select name="event_id" id="eventSelector" class="form-select" onchange="this.form.submit()" style="min-width: 280px; font-weight: 600;">
                <option value="" {{ $selectedEvent ? '' : 'selected' }} disabled>
                    {{ $events->isEmpty() ? 'No events available' : 'Select an event to view telemetry' }}
                </option>
                @foreach($events as $ev)
                    <option value="{{ $ev->id }}" {{ $selectedEvent && $selectedEvent->id === $ev->id ? 'selected' : '' }}>
                        {{ $ev->name }} ({{ ucfirst($ev->status) }})
                    </option>
                @endforeach
            </select>
        </form>
    </div>

    @if($selectedEvent)
        <!-- KPI Metrics -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 16px;">
            <div class="card" style="margin-bottom: 0; padding: 18px; border-left: 4px solid var(--primary);">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Perimeter Radius</div>
                    <i class="fa-solid fa-circle-notch" style="color: var(--primary); font-size: 16px;"></i>
                </div>
                <div style="font-size: 26px; font-weight: 800; color: var(--primary); margin-top: 4px;" id="kpiRadiusDisplay">
                    {{ $selectedEvent->radius_meters }}m
                </div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                    Venue center boundary
                </div>
            </div>

            <div class="card" style="margin-bottom: 0; padding: 18px; border-left: 4px solid var(--success);">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Inside Perimeter</div>
                    <i class="fa-solid fa-circle-check" style="color: var(--success); font-size: 16px;"></i>
                </div>
                <div style="font-size: 26px; font-weight: 800; color: var(--success); margin-top: 4px;" id="kpiInsideCount">
                    {{ number_format($stats['inside']) }}
                </div>
                <div style="font-size: 12px; color: var(--success); margin-top: 2px;">
                    Verified on-site attendees
                </div>
            </div>

            <div class="card" style="margin-bottom: 0; padding: 18px; border-left: 4px solid var(--danger);">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Outside Perimeter</div>
                    <i class="fa-solid fa-triangle-exclamation" style="color: var(--danger); font-size: 16px;"></i>
                </div>
                <div style="font-size: 26px; font-weight: 800; color: var(--danger); margin-top: 4px;" id="kpiOutsideCount">
                    {{ number_format($stats['outside']) }}
                </div>
                <div style="font-size: 12px; color: var(--danger); margin-top: 2px;">
                    Flagged distance violations
                </div>
            </div>

            <div class="card" style="margin-bottom: 0; padding: 18px; border-left: 4px solid var(--gold);">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Geofence Compliance</div>
                    <i class="fa-solid fa-shield-halved" style="color: var(--gold); font-size: 16px;"></i>
                </div>
                <div style="font-size: 26px; font-weight: 800; color: var(--gold-dark); margin-top: 4px;">
                    {{ $stats['compliance_rate'] }}%
                </div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                    {{ $stats['total'] }} total GPS telemetry pings
                </div>
            </div>
        </div>

        <!-- Security Protocol Banner: Physical Entrance Scan Required for Geofence -->
        <div style="background: linear-gradient(135deg, rgba(7, 21, 45, 0.04) 0%, rgba(18, 89, 195, 0.08) 100%); border: 1px solid rgba(18, 89, 195, 0.2); border-left: 4px solid var(--primary); border-radius: 10px; padding: 14px 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
            <div style="display: flex; align-items: center; gap: 14px;">
                <div style="width: 38px; height: 38px; border-radius: 8px; background: var(--primary); color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0;">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <div>
                    <div style="font-weight: 700; font-size: 13.5px; color: var(--text-main);">
                        Two-Stage Security Policy: Mandatory Entrance Scan Required
                    </div>
                    <div style="font-size: 12.5px; color: var(--text-muted); margin-top: 1px;">
                        Students must be physically scanned at the event entrance first before their mobile app can use Geofence to confirm location or presence.
                    </div>
                </div>
            </div>
            <div style="display: flex; gap: 8px;">
                <span class="badge badge-primary" style="font-size: 11px; padding: 6px 10px;">
                    <i class="fa-solid fa-barcode"></i> Step 1: Entrance Scan
                </span>
                <span class="badge badge-success" style="font-size: 11px; padding: 6px 10px;">
                    <i class="fa-solid fa-location-crosshairs"></i> Step 2: Geofence Confirmed
                </span>
            </div>
        </div>

        <!-- Main Geofence Interactive Deck (Map + Calibration Controls) -->
        <div style="display: grid; grid-template-columns: 1.6fr 1fr; gap: 24px;" id="geofenceEditorDeck">
            
            <!-- Left: Interactive Leaflet Map with Radar Pulses & Pings -->
            <div class="card" style="margin-bottom: 0;">
                <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                    <div class="card-title">
                        <i class="fa-solid fa-radar" style="color: var(--primary);"></i>
                        <span>Live Geofence Radar Map: {{ $selectedEvent->name }}</span>
                    </div>

                    <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                        <!-- Filter Pills -->
                        <div style="display: flex; gap: 4px; background: var(--bg-body); padding: 3px; border-radius: 20px; border: 1px solid var(--line);">
                            <button type="button" class="map-filter-pill active" onclick="filterMapPings('all', this)">All ({{ count($mapPings) }})</button>
                            <button type="button" class="map-filter-pill" onclick="filterMapPings('inside', this)">Inside ({{ $stats['inside'] }})</button>
                            <button type="button" class="map-filter-pill" onclick="filterMapPings('outside', this)">Outside ({{ $stats['outside'] }})</button>
                        </div>

                        <!-- Locate Me & Reset Center -->
                        <button type="button" class="btn btn-sm btn-secondary" onclick="detectUserLocation()" title="Set center to device GPS location">
                            <i class="fa-solid fa-crosshairs"></i> Locate Me
                        </button>
                    </div>
                </div>

                <div class="card-body" style="padding: 16px;">
                    
                    <!-- Campus Preset Quick Buttons -->
                    <div style="margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
                        <div style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                            <span style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">
                                <i class="fa-solid fa-building-columns"></i> Pangasinan State University Presets:
                            </span>
                            <button type="button" class="geofence-preset-btn" onclick="applyCampusLocation(16.115303, 119.967252, 'Pangasinan State University Main Admin Building', this)">
                                Main Admin
                            </button>
                            <button type="button" class="geofence-preset-btn" onclick="applyCampusLocation(16.1490, 119.9845, 'Pangasinan State University Gymnasium', this)">
                                Gymnasium
                            </button>
                            <button type="button" class="geofence-preset-btn" onclick="applyCampusLocation(16.1478, 119.9858, 'Pangasinan State University Quadrangle Plaza', this)">
                                Quadrangle
                            </button>
                            <button type="button" class="geofence-preset-btn" onclick="applyCampusLocation(16.1465, 119.9862, 'Alaminos City Sports Oval', this)">
                                City Sports Oval
                            </button>
                        </div>

                        <div style="display: flex; align-items: center; gap: 6px;">
                            <label style="font-size: 11.5px; font-weight: 600; color: var(--text-muted); cursor: pointer; display: flex; align-items: center; gap: 4px;">
                                <input type="checkbox" id="toggleRadarPulse" checked onchange="toggleRadarAnimation(this.checked)">
                                Radar Pulse
                            </label>
                        </div>
                    </div>

                    <!-- Map Container -->
                    <div id="geofenceMap"></div>

                    <!-- Map Legend and Coords Bar -->
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 14px; font-size: 12px; color: var(--text-muted); flex-wrap: wrap; gap: 10px;">
                        <div style="display: flex; gap: 14px; align-items: center; flex-wrap: wrap;">
                            <span style="display: flex; align-items: center; gap: 6px;">
                                <span style="width: 10px; height: 10px; border-radius: 50%; background: var(--primary); display: inline-block;"></span>
                                <strong>Venue Center</strong>
                            </span>
                            <span style="display: flex; align-items: center; gap: 6px;">
                                <span style="width: 10px; height: 10px; border-radius: 50%; background: #10b981; display: inline-block;"></span>
                                <strong>Student Inside ({{ $stats['inside'] }})</strong>
                            </span>
                            <span style="display: flex; align-items: center; gap: 6px;">
                                <span style="width: 10px; height: 10px; border-radius: 50%; background: #ef4444; display: inline-block;"></span>
                                <strong>Student Outside ({{ $stats['outside'] }})</strong>
                            </span>
                        </div>

                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span id="mapCenterCoords" style="font-family: 'JetBrains Mono', monospace; font-weight: 600;">
                                Lat: {{ number_format($selectedEvent->latitude, 6) }}, Lng: {{ number_format($selectedEvent->longitude, 6) }}
                            </span>
                            <button type="button" class="btn btn-sm btn-secondary" onclick="copyCurrentCoordinates()" title="Copy coordinates to clipboard" style="padding: 3px 8px; font-size: 11px;">
                                <i class="fa-regular fa-copy"></i> Copy
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right: Geofence Calibration & Radius Editor Form -->
            <div class="card" style="margin-bottom: 0;">
                <div class="card-header">
                    <div class="card-title">
                        <i class="fa-solid fa-sliders" style="color: var(--gold);"></i>
                        <span>Calibrate Boundary &amp; Radius</span>
                    </div>
                    <span class="badge {{ $selectedEvent->presence_verification ? 'badge-success' : 'badge-neutral' }}">
                        {{ $selectedEvent->presence_verification ? 'ENFORCED' : 'OPTIONAL' }}
                    </span>
                </div>

                <div class="card-body">
                    <form action="{{ route('presence.update_geofence') }}" method="POST" id="geofenceForm">
                        @csrf
                        <input type="hidden" name="event_id" value="{{ $selectedEvent->id }}">

                        <!-- Radius Range & Direct Value Editor -->
                        <div class="form-group" style="background: var(--bg-body); padding: 16px; border-radius: 8px; border: 1px solid var(--line); margin-bottom: 18px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                <label class="form-label" for="radiusInput" style="margin-bottom: 0; font-size: 13px;">
                                    <i class="fa-solid fa-circle-notch" style="color: var(--primary);"></i> Geofence Radius (Meters)
                                </label>
                                <span style="font-size: 20px; font-weight: 800; color: var(--primary); font-family: 'JetBrains Mono', monospace;" id="radiusBadgeVal">
                                    {{ $selectedEvent->radius_meters }}m
                                </span>
                            </div>

                            <!-- Interactive Slider -->
                            <input 
                                type="range" 
                                id="radiusSlider" 
                                class="radius-slider" 
                                min="10" 
                                max="2500" 
                                step="10" 
                                value="{{ $selectedEvent->radius_meters }}"
                                oninput="onRadiusSliderChange(this.value)"
                            >

                            <!-- Number input for custom precision -->
                            <div style="display: flex; gap: 8px; align-items: center; margin-top: 14px;">
                                <input 
                                    type="number" 
                                    name="radius_meters" 
                                    id="radiusInput" 
                                    class="form-control" 
                                    value="{{ $selectedEvent->radius_meters }}" 
                                    min="10" 
                                    max="10000" 
                                    required 
                                    style="font-family: 'JetBrains Mono', monospace; font-weight: 700; max-width: 140px;"
                                    oninput="onRadiusInputChange(this.value)"
                                >
                                <span style="font-size: 13px; font-weight: 600; color: var(--text-muted);">Meters radius perimeter</span>
                            </div>

                            <!-- Quick Preset Buttons -->
                            <div style="margin-top: 14px;">
                                <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; margin-bottom: 6px;">
                                    Quick Radius Presets:
                                </div>
                                <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                    <button type="button" class="geofence-preset-btn" onclick="applyRadiusPreset(50)">50m (Hall/Gym)</button>
                                    <button type="button" class="geofence-preset-btn" onclick="applyRadiusPreset(100)">100m (Building)</button>
                                    <button type="button" class="geofence-preset-btn" onclick="applyRadiusPreset(200)">200m (Plaza)</button>
                                    <button type="button" class="geofence-preset-btn" onclick="applyRadiusPreset(500)">500m (Main Campus)</button>
                                    <button type="button" class="geofence-preset-btn" onclick="applyRadiusPreset(1000)">1,000m (Campus &amp; Vicinity)</button>
                                </div>
                            </div>
                        </div>

                        <!-- Latitude & Longitude Coordinates -->
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label class="form-label" for="geo_latitude">Latitude</label>
                                <input 
                                    type="number" 
                                    step="0.000001" 
                                    name="latitude" 
                                    id="geo_latitude" 
                                    class="form-control" 
                                    value="{{ $selectedEvent->latitude }}" 
                                    required
                                    onchange="onCoordsInputChange()"
                                    style="font-family: 'JetBrains Mono', monospace;"
                                >
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label class="form-label" for="geo_longitude">Longitude</label>
                                <input 
                                    type="number" 
                                    step="0.000001" 
                                    name="longitude" 
                                    id="geo_longitude" 
                                    class="form-control" 
                                    value="{{ $selectedEvent->longitude }}" 
                                    required
                                    onchange="onCoordsInputChange()"
                                    style="font-family: 'JetBrains Mono', monospace;"
                                >
                            </div>
                        </div>

                        <!-- Verification Interval & Toggles -->
                        <div class="form-group">
                            <label class="form-label" for="geo_interval">Periodic Background Verification Ping</label>
                            <select name="verification_interval_minutes" id="geo_interval" class="form-select">
                                <option value="5" {{ ($selectedEvent->verification_interval_minutes ?? 15) == 5 ? 'selected' : '' }}>Every 5 Minutes (Strict Monitoring)</option>
                                <option value="10" {{ ($selectedEvent->verification_interval_minutes ?? 15) == 10 ? 'selected' : '' }}>Every 10 Minutes</option>
                                <option value="15" {{ ($selectedEvent->verification_interval_minutes ?? 15) == 15 ? 'selected' : '' }}>Every 15 Minutes (Recommended)</option>
                                <option value="30" {{ ($selectedEvent->verification_interval_minutes ?? 15) == 30 ? 'selected' : '' }}>Every 30 Minutes</option>
                                <option value="60" {{ ($selectedEvent->verification_interval_minutes ?? 15) == 60 ? 'selected' : '' }}>Every 1 Hour</option>
                            </select>
                        </div>

                        <div style="margin-bottom: 20px; padding: 14px; background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: 8px;">
                            <div style="display: flex; align-items: flex-start; gap: 10px;">
                                <input 
                                    type="checkbox" 
                                    name="presence_verification" 
                                    id="presence_verification_toggle" 
                                    value="1" 
                                    {{ $selectedEvent->presence_verification ? 'checked' : '' }}
                                    style="margin-top: 3px;"
                                >
                                <label for="presence_verification_toggle" style="font-size: 13px; font-weight: 700; color: var(--text-main); margin-bottom: 2px; cursor: pointer;">
                                    Strict Geofence Enforcement
                                    <span style="display: block; font-size: 12px; font-weight: 400; color: var(--text-muted); margin-top: 2px;">
                                        Require student mobile app users to be physically located within the {{ $selectedEvent->radius_meters }}m perimeter to successfully self check-in.
                                    </span>
                                </label>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 12px; font-size: 14px;">
                            <i class="fa-solid fa-floppy-disk"></i> Save &amp; Apply Geofence Perimeter
                        </button>
                    </form>
                </div>
            </div>

        </div>

        <!-- Real-Time Presence Verifications Log Table -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                <div class="card-title">
                    <i class="fa-solid fa-satellite-dish" style="color: var(--primary);"></i>
                    <span>Real-Time GPS Verification Telemetry Logs ({{ $verifications->total() }})</span>
                </div>
                
                <!-- Quick Search Input for Table -->
                <div style="display: flex; align-items: center; gap: 8px;">
                    <input 
                        type="text" 
                        id="pingSearchInput" 
                        class="form-control" 
                        placeholder="Search student or ID..." 
                        style="max-width: 240px; font-size: 12px; padding: 6px 12px;"
                        onkeyup="filterPingsTable(this.value)"
                    >
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table" id="pingsTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Program</th>
                            <th>Organization</th>
                            <th>Entrance Scan</th>
                            <th>Distance to Venue</th>
                            <th>Geofence Status</th>
                            <th>Timestamp</th>
                            @if(auth()->user()?->isAdmin())
                                <th>Actions</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($verifications as $idx => $v)
                            @php
                                $att = $v->student?->attendances->first();
                            @endphp
                            <tr class="ping-row" data-search="{{ strtolower(($v->student?->student_id ?? '') . ' ' . ($v->student?->full_name ?? '') . ' ' . ($v->student?->program?->name ?? '')) }}">
                                <td style="color: var(--text-muted); font-size: 12px;">{{ $verifications->firstItem() + $idx }}</td>
                                <td style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: var(--primary);">
                                    {{ $v->student?->student_id }}
                                </td>
                                <td style="font-weight: 700;">{{ $v->student?->full_name }}</td>
                                <td><span class="badge badge-primary">{{ $v->student?->program?->name ?? 'N/A' }}</span></td>
                                <td><span class="badge badge-neutral">{{ $v->student?->organization?->name ?? 'N/A' }}</span></td>
                                <td>
                                    @if($att)
                                        <span class="badge badge-success" title="Scanned at entrance: {{ $att->scanned_at?->format('h:i A') }}">
                                            <i class="fa-solid fa-barcode"></i> Scanned ({{ $att->scanned_at?->format('h:i A') }})
                                        </span>
                                    @else
                                        <span class="badge badge-danger">
                                            <i class="fa-solid fa-triangle-exclamation"></i> Not Scanned
                                        </span>
                                    @endif
                                </td>
                                <td style="font-family: 'JetBrains Mono', monospace; font-weight: 700;">
                                    {{ number_format($v->distance_meters, 1) }}m
                                    @if($v->distance_meters > $selectedEvent->radius_meters)
                                        <span style="color: var(--danger); font-size: 11px;">(+{{ number_format($v->distance_meters - $selectedEvent->radius_meters, 1) }}m outside)</span>
                                    @endif
                                </td>
                                <td>
                                    <span class="badge {{ $v->status === 'inside' ? 'badge-success' : 'badge-danger' }}">
                                        <i class="fa-solid {{ $v->status === 'inside' ? 'fa-circle-check' : 'fa-circle-xmark' }}"></i>
                                        {{ $v->status === 'inside' ? 'INSIDE PERIMETER' : 'OUTSIDE PERIMETER' }}
                                    </span>
                                </td>
                                <td style="font-size: 12px; color: var(--text-muted);">
                                    {{ $v->verified_at?->format('M d, Y h:i:s A') }}
                                </td>
                                @if(auth()->user()?->isAdmin())
                                    <td style="white-space: nowrap;">
                                        <button
                                            type="button"
                                            class="btn btn-sm btn-outline-primary"
                                            data-edit-telemetry
                                            data-update-url="{{ route('presence.verifications.update', $v) }}"
                                            data-id="{{ $v->id }}"
                                            data-student="{{ $v->student?->full_name ?? 'Student #' . $v->student_id }}"
                                            data-status="{{ $v->status }}"
                                            data-distance="{{ $v->distance_meters }}"
                                            data-verified-at="{{ $v->verified_at?->format('Y-m-d\TH:i') }}"
                                            data-notes="{{ $v->notes }}"
                                        >
                                            <i class="fa-solid fa-pen-to-square"></i> Edit log
                                        </button>
                                        <form
                                            action="{{ route('presence.verifications.destroy', $v) }}"
                                            method="POST"
                                            style="display: inline;"
                                            onsubmit="return confirm('Delete this GPS verification log? This will not change attendance records.');"
                                        >
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="fa-solid fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                @endif
                            </tr>
                        @empty
                            <tr>
                                <td colspan="{{ auth()->user()?->isAdmin() ? 10 : 9 }}" style="text-align: center; color: var(--text-muted); padding: 40px;">
                                    <i class="fa-solid fa-location-crosshairs" style="font-size: 32px; display: block; margin-bottom: 8px; opacity: 0.5;"></i>
                                    No GPS verification pings logged for this event session yet.
                                    <div style="font-size: 12px; margin-top: 4px;">Pings will register automatically when students confirm location via the Attendance Mobile App after being scanned at the entrance.</div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            @if($verifications->hasPages())
                <div style="padding: 16px 24px; border-top: 1px solid var(--card-border-subtle);">
                    {{ $verifications->links() }}
                </div>
            @endif
        </div>

        @if(auth()->user()?->isAdmin())
            <dialog id="telemetryEditModal" style="width: min(560px, calc(100% - 32px)); border: 0; border-radius: 12px; padding: 0; color: var(--text-main); background: var(--card-bg); box-shadow: var(--shadow-lg);">
                <form id="telemetryEditForm" method="POST" style="padding: 24px;">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="_presence_verification_id" id="telemetryEditId">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; margin-bottom: 20px;">
                        <div>
                            <h3 style="margin: 0; font-size: 18px; font-weight: 800;">Edit GPS Verification Log</h3>
                            <div id="telemetryEditStudent" style="margin-top: 4px; color: var(--text-muted); font-size: 13px;"></div>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-close-telemetry aria-label="Close">Close</button>
                    </div>
                    <div style="display: grid; gap: 14px;">
                        <label style="display: grid; gap: 6px; font-size: 12px; font-weight: 700;">
                            Geofence status
                            <select class="form-select" name="status" id="telemetryEditStatus" required>
                                <option value="inside">Inside perimeter</option>
                                <option value="outside">Outside perimeter</option>
                            </select>
                        </label>
                        <label style="display: grid; gap: 6px; font-size: 12px; font-weight: 700;">
                            Distance to venue (meters)
                            <input class="form-control" type="number" name="distance_meters" id="telemetryEditDistance" min="0" max="20000000" step="0.1" required>
                        </label>
                        <label style="display: grid; gap: 6px; font-size: 12px; font-weight: 700;">
                            Verified at
                            <input class="form-control" type="datetime-local" name="verified_at" id="telemetryEditVerifiedAt" required>
                        </label>
                        <label style="display: grid; gap: 6px; font-size: 12px; font-weight: 700;">
                            Notes / GPS coordinates
                            <textarea class="form-control" name="notes" id="telemetryEditNotes" rows="3" maxlength="5000"></textarea>
                        </label>
                    </div>
                    <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                        <button type="button" class="btn btn-outline-secondary" data-close-telemetry>Cancel</button>
                        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save correction</button>
                    </div>
                </form>
            </dialog>
            @if($errors->hasAny(['status', 'distance_meters', 'verified_at', 'notes']))
                <div role="alert" style="padding: 12px 16px; border-radius: 8px; background: rgba(239, 68, 68, .1); color: var(--danger);">
                    Please correct the GPS log fields and submit again.
                </div>
            @endif
        @endif

    @else
        <div class="card" style="padding: 48px; text-align: center;">
            <i class="fa-regular fa-calendar-xmark" style="font-size: 40px; color: var(--text-muted); margin-bottom: 12px;"></i>
            <h3 style="font-size: 16px; font-weight: 700; color: var(--text-main);">{{ $events->isEmpty() ? 'No Events Available' : 'Select an Event' }}</h3>
            <p style="color: var(--text-muted); font-size: 13px; margin-top: 4px;">
                {{ $events->isEmpty() ? 'Create an event first to view GPS verification telemetry.' : 'Choose an event from the dropdown above to view its GPS verification telemetry logs.' }}
            </p>
        </div>
    @endif

</div>
@endsection

@push('scripts')
@if($selectedEvent)
<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<script>
    const DEFAULT_CAMPUS_LAT = 16.115303;
    const DEFAULT_CAMPUS_LNG = 119.967252;

    let currentLat = parseFloat("{{ $selectedEvent->latitude ?? 16.115303 }}");
    let currentLng = parseFloat("{{ $selectedEvent->longitude ?? 119.967252 }}");
    let currentRadius = parseInt("{{ $selectedEvent->radius_meters ?? 100 }}", 10);
    const eventName = "{{ addslashes($selectedEvent->name) }}";

    // Pings data passed from controller
    const mapPingsData = @json($mapPings ?? []);

    let map = null;
    let centerMarker = null;
    let radarPulseMarker = null;
    let geofenceCircle = null;
    let studentMarkersLayer = null;
    let currentFilter = 'all';

    document.addEventListener('DOMContentLoaded', function () {
        initGeofenceMap();
        initTelemetryEditor();
    });

    function initTelemetryEditor() {
        const modal = document.getElementById('telemetryEditModal');
        const form = document.getElementById('telemetryEditForm');
        if (!modal || !form) return;

        const fields = {
            id: document.getElementById('telemetryEditId'),
            status: document.getElementById('telemetryEditStatus'),
            distance: document.getElementById('telemetryEditDistance'),
            verifiedAt: document.getElementById('telemetryEditVerifiedAt'),
            notes: document.getElementById('telemetryEditNotes'),
            student: document.getElementById('telemetryEditStudent')
        };

        document.querySelectorAll('[data-edit-telemetry]').forEach(button => {
            button.addEventListener('click', function () {
                form.action = this.dataset.updateUrl;
                fields.id.value = this.dataset.id;
                fields.student.textContent = this.dataset.student;
                fields.status.value = this.dataset.status;
                fields.distance.value = this.dataset.distance;
                fields.verifiedAt.value = this.dataset.verifiedAt;
                fields.notes.value = this.dataset.notes || '';
                modal.showModal();
            });
        });

        document.querySelectorAll('[data-close-telemetry]').forEach(button => {
            button.addEventListener('click', () => modal.close());
        });

        @if($errors->hasAny(['status', 'distance_meters', 'verified_at', 'notes']) && old('_presence_verification_id'))
            const oldId = @json(old('_presence_verification_id'));
            const oldButton = document.querySelector(`[data-edit-telemetry][data-id="${oldId}"]`);
            if (oldButton) {
                oldButton.click();
                fields.status.value = @json(old('status'));
                fields.distance.value = @json(old('distance_meters'));
                fields.verifiedAt.value = @json(old('verified_at'));
                fields.notes.value = @json(old('notes'));
            }
        @endif
    }

    function initGeofenceMap() {
        if (!document.getElementById('geofenceMap')) return;

        // Initialize Leaflet Map centered on event coordinates
        map = L.map('geofenceMap', {
            zoomControl: true,
            scrollWheelZoom: true
        }).setView([currentLat, currentLng], 17);

        // OpenStreetMap Layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap contributors | Pangasinan State University'
        }).addTo(map);

        // Layer group for student markers
        studentMarkersLayer = L.layerGroup().addTo(map);

        // Custom Center Pin Icon
        const centerIcon = L.divIcon({
            className: 'custom-center-pin',
            html: `<div style="width: 38px; height: 38px; border-radius: 50%; background: #1259c3; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 17px; border: 3px solid #ffffff; box-shadow: 0 4px 14px rgba(18, 89, 195, 0.6);">
                    <i class="fa-solid fa-building-columns"></i>
                   </div>`,
            iconSize: [38, 38],
            iconAnchor: [19, 19],
            popupAnchor: [0, -22]
        });

        // Add Center Pin Marker (Draggable!)
        centerMarker = L.marker([currentLat, currentLng], {
            draggable: true,
            icon: centerIcon,
            zIndexOffset: 500
        }).addTo(map);

        centerMarker.bindPopup(`
            <div class="popup-card">
                <div class="popup-card-header">
                    <i class="fa-solid fa-location-dot" style="color: var(--primary); font-size: 16px;"></i>
                    <strong style="font-size: 13px;">${eventName}</strong>
                </div>
                <div class="popup-row">
                    <span class="popup-row-label">Location Type:</span>
                    <span class="popup-row-val">Venue Center Origin</span>
                </div>
                <div class="popup-row">
                    <span class="popup-row-label">Perimeter Radius:</span>
                    <span class="popup-row-val" id="popupRadiusLabel">${currentRadius} meters</span>
                </div>
                <div style="font-size: 11px; color: var(--text-muted); margin-top: 8px;">
                    <i class="fa-solid fa-hand-pointer"></i> Drag center pin anywhere to adjust coordinates.
                </div>
            </div>
        `).openPopup();

        // Add Radar Pulse Ring Overlay
        addRadarPulseMarker(currentLat, currentLng);

        // Add Geofence Perimeter Circle
        geofenceCircle = L.circle([currentLat, currentLng], {
            radius: currentRadius,
            color: '#1259c3',
            fillColor: '#2563eb',
            fillOpacity: 0.16,
            weight: 2.5,
            dashArray: '5, 8'
        }).addTo(map);

        // Center marker drag events
        centerMarker.on('drag', function (e) {
            const pos = e.target.getLatLng();
            updateCoordinatesUI(pos.lat, pos.lng);
            geofenceCircle.setLatLng(pos);
            if (radarPulseMarker) radarPulseMarker.setLatLng(pos);
        });

        centerMarker.on('dragend', function (e) {
            const pos = e.target.getLatLng();
            updateCoordinatesUI(pos.lat, pos.lng);
            geofenceCircle.setLatLng(pos);
            if (radarPulseMarker) radarPulseMarker.setLatLng(pos);
            centerMarker.openPopup();
        });

        // Map Click event to move center
        map.on('click', function (e) {
            const lat = e.latlng.lat;
            const lng = e.latlng.lng;
            setMarkerAndCirclePosition(lat, lng);
        });

        // Render Student Markers on Map
        renderStudentMarkers();

        // Update UI displays
        updateCoordinatesUI(currentLat, currentLng);
    }

    // Add animated radar pulse rings at coordinates
    function addRadarPulseMarker(lat, lng) {
        if (radarPulseMarker) {
            map.removeLayer(radarPulseMarker);
        }

        const radarPulseIcon = L.divIcon({
            className: 'radar-pulse-icon',
            html: `
                <div class="radar-pulse-container" id="radarPulseContainer">
                    <div class="radar-ring"></div>
                    <div class="radar-ring"></div>
                    <div class="radar-ring"></div>
                </div>
            `,
            iconSize: [0, 0],
            iconAnchor: [0, 0]
        });

        radarPulseMarker = L.marker([lat, lng], {
            icon: radarPulseIcon,
            interactive: false,
            zIndexOffset: 100
        }).addTo(map);
    }

    // Render Student Verification Markers on Leaflet Map
    function renderStudentMarkers() {
        if (!studentMarkersLayer) return;
        studentMarkersLayer.clearLayers();

        mapPingsData.forEach(ping => {
            if (!ping.lat || !ping.lng) return;

            // Check active filter
            if (currentFilter === 'inside' && ping.status !== 'inside') return;
            if (currentFilter === 'outside' && ping.status !== 'outside') return;

            const isInside = (ping.status === 'inside');
            const iconClass = isInside ? 'ping-inside' : 'ping-outside';
            const iconGlyph = isInside ? '<i class="fa-solid fa-user-check"></i>' : '<i class="fa-solid fa-user-xmark"></i>';

            const pingIcon = L.divIcon({
                className: 'custom-ping-pin',
                html: `<div class="student-ping-marker ${iconClass}" title="${ping.student_name} (${ping.distance_meters}m)">${iconGlyph}</div>`,
                iconSize: [26, 26],
                iconAnchor: [13, 13],
                popupAnchor: [0, -14]
            });

            const marker = L.marker([ping.lat, ping.lng], {
                icon: pingIcon,
                zIndexOffset: isInside ? 300 : 400
            });

            const entranceStatusBadge = ping.has_scanned
                ? `<span class="badge badge-success" style="font-size: 10.5px;"><i class="fa-solid fa-barcode"></i> Scanned (${ping.scanned_time || 'Entrance'})</span>`
                : `<span class="badge badge-danger" style="font-size: 10.5px;"><i class="fa-solid fa-triangle-exclamation"></i> Not Scanned</span>`;

            const statusBadge = isInside
                ? `<span class="badge badge-success" style="font-size: 10.5px;"><i class="fa-solid fa-circle-check"></i> Inside Perimeter</span>`
                : `<span class="badge badge-danger" style="font-size: 10.5px;"><i class="fa-solid fa-circle-xmark"></i> Outside Perimeter (+${Math.max(0, ping.distance_meters - currentRadius).toFixed(1)}m)</span>`;

            marker.bindPopup(`
                <div class="popup-card">
                    <div class="popup-card-header">
                        <i class="fa-solid fa-user-graduate" style="color: var(--primary); font-size: 15px;"></i>
                        <div>
                            <strong style="font-size: 13px; display: block;">${ping.student_name}</strong>
                            <span style="font-size: 11px; color: var(--text-muted); font-family: 'JetBrains Mono', monospace;">${ping.student_id}</span>
                        </div>
                    </div>
                    <div class="popup-row">
                        <span class="popup-row-label">Program:</span>
                        <span class="popup-row-val">${ping.program}</span>
                    </div>
                    <div class="popup-row">
                        <span class="popup-row-label">Distance:</span>
                        <span class="popup-row-val" style="font-family: 'JetBrains Mono', monospace;">${ping.distance_meters} meters</span>
                    </div>
                    <div class="popup-row">
                        <span class="popup-row-label">Entrance Scan:</span>
                        <span>${entranceStatusBadge}</span>
                    </div>
                    <div class="popup-row">
                        <span class="popup-row-label">Geofence Status:</span>
                        <span>${statusBadge}</span>
                    </div>
                    <div class="popup-row" style="margin-bottom: 0; padding-top: 4px; border-top: 1px dashed var(--line);">
                        <span class="popup-row-label">Logged At:</span>
                        <span class="popup-row-val" style="font-size: 11px;">${ping.verified_at}</span>
                    </div>
                </div>
            `);

            studentMarkersLayer.addLayer(marker);
        });
    }

    // Filter student markers on map
    function filterMapPings(filter, btn) {
        currentFilter = filter;
        document.querySelectorAll('.map-filter-pill').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
        renderStudentMarkers();
    }

    // Toggle radar wave animations
    function toggleRadarAnimation(enabled) {
        const rings = document.querySelectorAll('.radar-ring');
        rings.forEach(ring => {
            ring.style.display = enabled ? 'block' : 'none';
        });
    }

    // Move center pin and geofence circle
    function setMarkerAndCirclePosition(lat, lng) {
        currentLat = lat;
        currentLng = lng;
        if (centerMarker) centerMarker.setLatLng([lat, lng]);
        if (geofenceCircle) geofenceCircle.setLatLng([lat, lng]);
        if (radarPulseMarker) radarPulseMarker.setLatLng([lat, lng]);
        updateCoordinatesUI(lat, lng);
    }

    function updateCoordinatesUI(lat, lng) {
        document.getElementById('geo_latitude').value = lat.toFixed(6);
        document.getElementById('geo_longitude').value = lng.toFixed(6);
        document.getElementById('mapCenterCoords').innerText = `Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}`;
    }

    // Radius Slider & Input Handlers
    function onRadiusSliderChange(val) {
        const radius = parseInt(val, 10);
        currentRadius = radius;
        document.getElementById('radiusInput').value = radius;
        document.getElementById('radiusBadgeVal').innerText = radius + 'm';
        document.getElementById('kpiRadiusDisplay').innerText = radius + 'm';
        const pLabel = document.getElementById('popupRadiusLabel');
        if (pLabel) pLabel.innerText = radius + ' meters';

        if (geofenceCircle) {
            geofenceCircle.setRadius(radius);
        }
    }

    function onRadiusInputChange(val) {
        let radius = parseInt(val, 10);
        if (isNaN(radius) || radius < 10) radius = 10;
        currentRadius = radius;
        document.getElementById('radiusSlider').value = Math.min(2500, radius);
        document.getElementById('radiusBadgeVal').innerText = radius + 'm';
        document.getElementById('kpiRadiusDisplay').innerText = radius + 'm';
        const pLabel = document.getElementById('popupRadiusLabel');
        if (pLabel) pLabel.innerText = radius + ' meters';

        if (geofenceCircle) {
            geofenceCircle.setRadius(radius);
        }
    }

    // Quick radius preset buttons
    function applyRadiusPreset(presetMeters) {
        onRadiusSliderChange(presetMeters);
        document.querySelectorAll('.geofence-preset-btn').forEach(btn => {
            if (btn.innerText.includes(presetMeters + 'm')) {
                btn.classList.add('active');
            } else if (!btn.innerText.includes('Pangasinan State University') && !btn.innerText.includes('Oval')) {
                btn.classList.remove('active');
            }
        });
    }

    // Preset Campus Locations
    function applyCampusLocation(lat, lng, name, btn) {
        setMarkerAndCirclePosition(lat, lng);
        map.flyTo([lat, lng], 17, { duration: 1.2 });
        document.querySelectorAll('.geofence-preset-btn').forEach(b => {
            if (b.innerText.includes('Main Admin') || b.innerText.includes('Gymnasium') || b.innerText.includes('Quadrangle') || b.innerText.includes('Oval')) {
                b.classList.remove('active');
            }
        });
        if (btn) btn.classList.add('active');
    }

    // When coords inputs change manually
    function onCoordsInputChange() {
        const lat = parseFloat(document.getElementById('geo_latitude').value);
        const lng = parseFloat(document.getElementById('geo_longitude').value);
        if (!isNaN(lat) && !isNaN(lng)) {
            setMarkerAndCirclePosition(lat, lng);
            map.panTo([lat, lng]);
        }
    }

    // Copy coords to clipboard
    function copyCurrentCoordinates() {
        const text = `${currentLat.toFixed(6)}, ${currentLng.toFixed(6)}`;
        navigator.clipboard.writeText(text).then(() => {
            alert('Coordinates copied: ' + text);
        }).catch(() => {
            prompt('Coordinates:', text);
        });
    }

    // Filter table rows by search text
    function filterPingsTable(query) {
        const term = query.toLowerCase().trim();
        const rows = document.querySelectorAll('#pingsTable tbody tr.ping-row');
        rows.forEach(row => {
            const data = row.getAttribute('data-search') || '';
            row.style.display = data.includes(term) ? '' : 'none';
        });
    }

    // Detect user's current GPS location via HTML5 Geolocation
    function detectUserLocation() {
        if (!navigator.geolocation) {
            alert('HTML5 Geolocation is not supported by your browser.');
            return;
        }

        const btn = event.currentTarget;
        const originalHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Detecting...';
        btn.disabled = true;

        navigator.geolocation.getCurrentPosition(
            function (position) {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                setMarkerAndCirclePosition(lat, lng);
                map.flyTo([lat, lng], 18, { duration: 1.2 });
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            },
            function (err) {
                alert('Could not retrieve GPS location: ' + err.message);
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            },
            { enableHighAccuracy: true, timeout: 10000 }
        );
    }
</script>
@endif
@endpush
