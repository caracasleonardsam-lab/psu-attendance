@extends('layouts.app')

@section('page_title', 'System Settings & Parameters')

@push('styles')
<style>
    /* Settings Tabs */
    .settings-tabs {
        display: flex;
        gap: 8px;
        margin-bottom: 24px;
        border-bottom: 2px solid var(--card-border-subtle);
        padding-bottom: 0;
    }

    .settings-tab-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 20px;
        font-size: 13px;
        font-weight: 700;
        color: var(--text-muted);
        background: transparent;
        border: none;
        border-bottom: 3px solid transparent;
        cursor: pointer;
        transition: all 0.2s ease;
        margin-bottom: -2px;
        text-decoration: none;
    }

    .settings-tab-btn:hover {
        color: var(--primary);
        background: rgba(18, 89, 195, 0.04);
        border-radius: var(--radius-sm) var(--radius-sm) 0 0;
    }

    .settings-tab-btn.active {
        color: var(--primary);
        border-bottom-color: var(--primary);
        background: transparent;
    }

    .settings-tab-pane {
        display: none;
    }

    .settings-tab-pane.active {
        display: block;
        animation: fadeIn 0.2s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(4px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Stats Quick Cards */
    .settings-stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }

    .stat-mini-card {
        background: #ffffff;
        border: 1px solid var(--card-border);
        border-radius: var(--radius-md);
        padding: 16px 18px;
        box-shadow: var(--shadow-sm);
        display: flex;
        align-items: center;
        gap: 14px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .stat-mini-card:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }

    .stat-mini-icon {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        flex-shrink: 0;
    }

    .stat-mini-content h4 {
        font-size: 13px;
        font-weight: 800;
        color: var(--text-main);
        line-height: 1.3;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 170px;
    }

    .stat-mini-content p {
        font-size: 11px;
        color: var(--text-muted);
        margin-top: 2px;
        font-weight: 600;
    }

    /* Helper Notes */
    .settings-help-box {
        background: #f8fafc;
        border: 1px dashed #cbd5e1;
        border-radius: var(--radius-sm);
        padding: 12px 16px;
        font-size: 12px;
        color: var(--text-muted);
        display: flex;
        align-items: flex-start;
        gap: 10px;
        margin-top: 14px;
    }

    .settings-help-box i {
        color: var(--primary);
        font-size: 14px;
        margin-top: 2px;
        flex-shrink: 0;
    }

    /* Role Badges */
    .badge-superadmin {
        background: #fef3c7;
        color: #92400e;
        border: 1px solid rgba(245, 158, 11, 0.4);
    }

    .badge-admin {
        background: #eff6ff;
        color: #1e40af;
        border: 1px solid rgba(37, 99, 235, 0.3);
    }

    .badge-officer {
        background: #ecfdf5;
        color: #065f46;
        border: 1px solid rgba(16, 185, 129, 0.3);
    }

    /* User Row Avatar */
    .user-avatar-circle {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 12px;
        flex-shrink: 0;
    }
</style>
@endpush

@section('content')
<div>

    <!-- Top Statistical Overview Cards -->
    <div class="settings-stats-grid">
        <div class="stat-mini-card">
            <div class="stat-mini-icon" style="background: rgba(18, 89, 195, 0.1); color: var(--primary);">
                <i class="fa-solid fa-building-columns"></i>
            </div>
            <div class="stat-mini-content">
                <h4 title="{{ $settings['campus_name'] ?? 'Pangasinan State University Campus' }}">{{ $settings['campus_name'] ?? 'Pangasinan State University Campus' }}</h4>
                <p><i class="fa-solid fa-user-tie"></i> {{ $settings['campus_head'] ?? 'Campus Head' }}</p>
            </div>
        </div>

        <div class="stat-mini-card">
            <div class="stat-mini-icon" style="background: rgba(245, 158, 11, 0.12); color: var(--gold-dark);">
                <i class="fa-solid fa-calendar-check"></i>
            </div>
            <div class="stat-mini-content">
                <h4>A.Y. {{ $settings['academic_year'] ?? '2025-2026' }}</h4>
                <p><i class="fa-solid fa-bookmark" style="color: var(--gold-dark);"></i> {{ $settings['academic_semester'] ?? '1st Semester' }}</p>
            </div>
        </div>

        @if(Auth::user()?->isSuperAdmin())
        <div class="stat-mini-card">
            <div class="stat-mini-icon" style="background: rgba(99, 102, 241, 0.12); color: #4f46e5;">
                <i class="fa-solid fa-users-gear"></i>
            </div>
            <div class="stat-mini-content">
                <h4>{{ $users->count() }} Staff Accounts</h4>
                <p>{{ $totalAdmins }} Admins • {{ $totalOfficers }} Officers</p>
            </div>
        </div>
        @endif
    </div>

    <!-- Navigation Tabs -->
    <div class="settings-tabs">
        <button type="button" class="settings-tab-btn {{ $activeTab === 'institutional' ? 'active' : '' }}" onclick="switchSettingsTab('institutional')">
            <i class="fa-solid fa-landmark"></i>
            <span>Campus &amp; Academic Term</span>
        </button>
        @if(Auth::user()?->isSuperAdmin())
            <button type="button" class="settings-tab-btn {{ $activeTab === 'users' ? 'active' : '' }}" onclick="switchSettingsTab('users')">
                <i class="fa-solid fa-user-shield"></i>
                <span>Staff &amp; Administrator Accounts</span>
                <span class="badge badge-neutral" style="font-size: 10px; margin-left: 4px;">{{ $users->count() }}</span>
            </button>
        @endif
    </div>

    <!-- Tab 1: Campus & Academic Term Settings -->
    <div class="settings-tab-pane {{ $activeTab === 'institutional' ? 'active' : '' }}" id="pane-institutional">
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <i class="fa-solid fa-building-columns" style="color: var(--primary);"></i>
                    <span>Institutional Identity &amp; Academic Calendar</span>
                </div>
                <span class="badge badge-primary">Campus Setup</span>
            </div>
            <form action="{{ route('settings.update_general') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label class="form-label" for="campus_name">
                                Campus Name <span style="color: var(--danger);">*</span>
                            </label>
                            <input 
                                type="text" 
                                name="campus_name" 
                                id="campus_name" 
                                class="form-control" 
                                value="{{ old('campus_name', $settings['campus_name'] ?? 'Pangasinan State University - Alaminos City Campus') }}" 
                                required
                            >
                            <span style="font-size: 11px; color: var(--text-muted);">Displays on official attendance headers, reports, and system banners.</span>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="system_name">
                                System Title / Branding <span style="color: var(--danger);">*</span>
                            </label>
                            <input 
                                type="text" 
                                name="system_name" 
                                id="system_name" 
                                class="form-control" 
                                value="{{ old('system_name', $settings['system_name'] ?? 'Pangasinan State University Attendance & Presence Verification System') }}" 
                                required
                            >
                            <span style="font-size: 11px; color: var(--text-muted);">Header title shown across the web portal and mobile app.</span>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 6px;">
                        <div class="form-group">
                            <label class="form-label" for="academic_year">
                                Current Academic Year <span style="color: var(--danger);">*</span>
                            </label>
                            <input 
                                type="text" 
                                name="academic_year" 
                                id="academic_year" 
                                class="form-control" 
                                value="{{ old('academic_year', $settings['academic_year'] ?? '2025-2026') }}" 
                                placeholder="e.g. 2025-2026"
                                required
                            >
                            <span style="font-size: 11px; color: var(--text-muted);">Format: YYYY-YYYY (used for term event filtering & reports).</span>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="academic_semester">
                                Current Academic Semester <span style="color: var(--danger);">*</span>
                            </label>
                            <select name="academic_semester" id="academic_semester" class="form-select" required>
                                @php
                                    $currentSemester = old('academic_semester', $settings['academic_semester'] ?? '1st Semester');
                                @endphp
                                <option value="1st Semester" {{ $currentSemester === '1st Semester' ? 'selected' : '' }}>1st Semester</option>
                                <option value="2nd Semester" {{ $currentSemester === '2nd Semester' ? 'selected' : '' }}>2nd Semester</option>
                                <option value="Midyear / Summer" {{ $currentSemester === 'Midyear / Summer' ? 'selected' : '' }}>Midyear / Summer</option>
                            </select>
                            <span style="font-size: 11px; color: var(--text-muted);">Active academic term for attendance accounting.</span>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 6px;">
                        <div class="form-group">
                            <label class="form-label" for="campus_head">
                                Campus Head / Executive Director
                            </label>
                            <input 
                                type="text" 
                                name="campus_head" 
                                id="campus_head" 
                                class="form-control" 
                                value="{{ old('campus_head', $settings['campus_head'] ?? 'Dr. Armando D. Junio') }}" 
                                placeholder="e.g. Dr. Armando D. Junio"
                            >
                            <span style="font-size: 11px; color: var(--text-muted);">Signatory printed on official certificates and campus rosters.</span>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="contact_email">
                                Official Support / Contact Email
                            </label>
                            <input 
                                type="email" 
                                name="contact_email" 
                                id="contact_email" 
                                class="form-control" 
                                value="{{ old('contact_email', $settings['contact_email'] ?? 'alaminos@psu.edu.ph') }}" 
                                placeholder="e.g. alaminos@psu.edu.ph"
                            >
                            <span style="font-size: 11px; color: var(--text-muted);">Contact address for technical inquiries and certificate validation.</span>
                        </div>
                    </div>

                    <div class="form-group" style="margin-top: 6px;">
                        <label class="form-label" for="campus_address">Campus Address / Location Tagline</label>
                        <input 
                            type="text" 
                            name="campus_address" 
                            id="campus_address" 
                            class="form-control" 
                            value="{{ old('campus_address', $settings['campus_address'] ?? 'City of Alaminos, Pangasinan 2404') }}" 
                            placeholder="e.g. City of Alaminos, Pangasinan 2404"
                        >
                    </div>

                    <div class="settings-help-box">
                        <i class="fa-solid fa-circle-info"></i>
                        <div>
                            <strong>Automatic System Integration:</strong>
                            Updating these parameters dynamically updates all generated certificate signatures, printable attendance sheets, and student mobile interfaces without modifying code.
                        </div>
                    </div>
                </div>
                <div class="card-footer" style="padding: 16px 24px; background: #f8fafc; border-top: 1px solid var(--card-border-subtle); display: flex; justify-content: flex-end;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fa-solid fa-floppy-disk"></i> Save Institutional Settings
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Tab 3: Staff & Administrator Accounts -->
    @if(Auth::user()?->isSuperAdmin())
    <div class="settings-tab-pane {{ $activeTab === 'users' ? 'active' : '' }}" id="pane-users">
        <div class="card">
            <div class="card-header" style="flex-wrap: wrap; gap: 12px;">
                <div>
                    <div class="card-title">
                        <i class="fa-solid fa-user-shield" style="color: var(--primary);"></i>
                        <span>Administrative &amp; Event Staff Accounts ({{ $users->count() }})</span>
                    </div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                        Manage privileged access roles: Super Administrators, Campus Administrators, and Event Officers.
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="position: relative;">
                        <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 12px; top: 11px; color: var(--text-light); font-size: 12px;"></i>
                        <input 
                            type="text" 
                            id="userSearchInput" 
                            placeholder="Filter accounts..." 
                            class="form-control" 
                            style="padding-left: 32px; font-size: 12px; width: 180px; height: 34px;"
                            onkeyup="filterUsersTable()"
                        >
                    </div>
                    <button type="button" class="btn btn-primary btn-sm" onclick="openCreateUserModal()">
                        <i class="fa-solid fa-user-plus"></i> New Staff Account
                    </button>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table" id="usersTable">
                    <thead>
                        <tr>
                            <th>Account Holder</th>
                            <th>Username</th>
                            <th>Privilege Role</th>
                            <th>Created On</th>
                            <th>Status</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($users as $user)
                            <tr class="user-row" data-name="{{ strtolower($user->name) }}" data-username="{{ strtolower($user->username) }}" data-role="{{ strtolower($user->role) }}">
                                <td>
                                    <div style="display: flex; align-items: center; gap: 12px;">
                                        @php
                                            $avatarBg = match($user->role) {
                                                'superadmin' => 'linear-gradient(135deg, #b45309, #f59e0b)',
                                                'admin' => 'linear-gradient(135deg, #07152d, #1259c3)',
                                                default => 'linear-gradient(135deg, #065f46, #10b981)',
                                            };
                                        @endphp
                                        <div class="user-avatar-circle" style="background: {{ $avatarBg }}; color: #ffffff;">
                                            {{ strtoupper(substr($user->name, 0, 1)) }}
                                        </div>
                                        <div>
                                            <div style="font-weight: 700; color: var(--text-main);">
                                                {{ $user->name }}
                                                @if(Auth::id() === $user->id)
                                                    <span class="badge badge-primary" style="font-size: 9px; padding: 2px 6px; margin-left: 4px;">You</span>
                                                @endif
                                            </div>
                                            <div style="font-size: 12px; color: var(--text-muted);">
                                                <i class="fa-regular fa-envelope" style="font-size: 10px;"></i> {{ $user->email }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span style="font-family: 'JetBrains Mono', monospace; font-size: 12px; font-weight: 700; color: var(--primary); background: #f1f5f9; padding: 3px 8px; border-radius: 4px;">
                                        {{ $user->username }}
                                    </span>
                                </td>
                                <td>
                                    @if($user->role === 'superadmin')
                                        <span class="badge badge-superadmin">
                                            <i class="fa-solid fa-crown" style="color: #d97706;"></i> Super Admin
                                        </span>
                                    @elseif($user->role === 'admin')
                                        <span class="badge badge-admin">
                                            <i class="fa-solid fa-shield-halved" style="color: #1d4ed8;"></i> Campus Admin
                                        </span>
                                    @else
                                        <span class="badge badge-officer">
                                            <i class="fa-solid fa-clipboard-check" style="color: #059669;"></i> Event Officer
                                        </span>
                                    @endif
                                </td>
                                <td style="font-size: 12px; color: var(--text-muted);">
                                    {{ $user->created_at ? $user->created_at->format('M d, Y') : 'Pre-configured' }}
                                </td>
                                <td>
                                    <span class="badge badge-success">
                                        <i class="fa-solid fa-circle" style="font-size: 6px;"></i> Active
                                    </span>
                                </td>
                                <td style="text-align: right;">
                                    <div style="display: inline-flex; gap: 6px;">
                                        <button 
                                            type="button" 
                                            class="btn btn-secondary btn-sm" 
                                            title="Edit Account"
                                            onclick="openEditUserModal({{ json_encode([
                                                'id' => $user->id,
                                                'name' => $user->name,
                                                'username' => $user->username,
                                                'email' => $user->email,
                                                'role' => $user->role,
                                                'update_url' => route('settings.users.update', $user),
                                            ]) }})"
                                        >
                                            <i class="fa-solid fa-pen-to-square"></i> Edit
                                        </button>

                                        @if(Auth::id() !== $user->id)
                                            <form action="{{ route('settings.users.destroy', $user) }}" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to permanently delete the account for {{ addslashes($user->name) }} ({{ $user->username }})?');">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Account">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </form>
                                        @else
                                            <button type="button" class="btn btn-secondary btn-sm" disabled title="Cannot delete your own active account" style="opacity: 0.5; cursor: not-allowed;">
                                                <i class="fa-solid fa-ban"></i>
                                            </button>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                                    <i class="fa-solid fa-user-slash" style="font-size: 28px; margin-bottom: 8px; display: block; opacity: 0.4;"></i>
                                    No administrative accounts located.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Modal: Create Staff Account -->
<div class="modal-overlay" id="createUserModal">
    <div class="modal-container">
        <div class="modal-header">
            <h3 class="modal-title">
                <i class="fa-solid fa-user-plus" style="color: var(--primary);"></i>
                <span>Add Administrator or Officer</span>
            </h3>
            <button type="button" class="modal-close" onclick="closeCreateUserModal()">&times;</button>
        </div>
        <form action="{{ route('settings.users.store') }}" method="POST">
            @csrf
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label" for="create_name">Full Name <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="name" id="create_name" class="form-control" placeholder="e.g. Maria Santos" required value="{{ old('name') }}">
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group">
                        <label class="form-label" for="create_username">Username <span style="color: var(--danger);">*</span></label>
                        <input type="text" name="username" id="create_username" class="form-control" placeholder="e.g. maria.santos" required value="{{ old('username') }}">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="create_role">Privilege Role <span style="color: var(--danger);">*</span></label>
                        <select name="role" id="create_role" class="form-select" required>
                            <option value="officer">Event Officer</option>
                            <option value="admin" selected>Campus Admin</option>
                            @if(Auth::user()?->isSuperAdmin())
                                <option value="superadmin">Super Admin</option>
                            @endif
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="create_email">Email Address <span style="color: var(--danger);">*</span></label>
                    <input type="email" name="email" id="create_email" class="form-control" placeholder="e.g. maria.santos@psu.edu.ph" required value="{{ old('email') }}">
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group">
                        <label class="form-label" for="create_password">Password <span style="color: var(--danger);">*</span></label>
                        <input type="password" name="password" id="create_password" class="form-control" placeholder="Minimum 6 chars" required minlength="6">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="create_password_confirmation">Confirm Password <span style="color: var(--danger);">*</span></label>
                        <input type="password" name="password_confirmation" id="create_password_confirmation" class="form-control" placeholder="Re-type password" required minlength="6">
                    </div>
                </div>

                <div class="settings-help-box" style="margin-top: 10px;">
                    <i class="fa-solid fa-shield-halved"></i>
                    <div>
                        <strong>Role Capabilities:</strong>
                        <strong>Super Admin:</strong> Complete control of system & account roles.
                        <br><strong>Campus Admin:</strong> Manages events, rosters, attendance, and certificates.
                        <br><strong>Officer:</strong> Operates scanner station and verifies attendees.
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeCreateUserModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-user-check"></i> Create Account
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal: Edit Staff Account -->
<div class="modal-overlay" id="editUserModal">
    <div class="modal-container">
        <div class="modal-header">
            <h3 class="modal-title">
                <i class="fa-solid fa-user-pen" style="color: var(--primary);"></i>
                <span>Edit Staff Account</span>
            </h3>
            <button type="button" class="modal-close" onclick="closeEditUserModal()">&times;</button>
        </div>
        <form id="editUserForm" action="" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label" for="edit_name">Full Name <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="name" id="edit_name" class="form-control" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group">
                        <label class="form-label" for="edit_username">Username <span style="color: var(--danger);">*</span></label>
                        <input type="text" name="username" id="edit_username" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="edit_role">Privilege Role <span style="color: var(--danger);">*</span></label>
                        <select name="role" id="edit_role" class="form-select" required>
                            <option value="officer">Event Officer</option>
                            <option value="admin">Campus Admin</option>
                            <option value="superadmin">Super Admin</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="edit_email">Email Address <span style="color: var(--danger);">*</span></label>
                    <input type="email" name="email" id="edit_email" class="form-control" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="form-group">
                        <label class="form-label" for="edit_password">Reset Password</label>
                        <input type="password" name="password" id="edit_password" class="form-control" placeholder="Leave blank to keep current">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="edit_password_confirmation">Confirm Password</label>
                        <input type="password" name="password_confirmation" id="edit_password_confirmation" class="form-control" placeholder="Confirm new password">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEditUserModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Update Account
                </button>
            </div>
        </form>
    </div>
</div>
    @endif

@push('scripts')
<script>
    function switchSettingsTab(tabName) {
        // Update URL query without full reload
        const url = new URL(window.location);
        url.searchParams.set('tab', tabName);
        window.history.pushState({}, '', url);

        // Update button states
        document.querySelectorAll('.settings-tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        const activeBtn = Array.from(document.querySelectorAll('.settings-tab-btn')).find(b => b.getAttribute('onclick')?.includes(tabName));
        if (activeBtn) activeBtn.classList.add('active');

        // Update panes
        document.querySelectorAll('.settings-tab-pane').forEach(pane => {
            pane.classList.remove('active');
        });
        const activePane = document.getElementById('pane-' + tabName);
        if (activePane) activePane.classList.add('active');
    }

    function filterUsersTable() {
        const query = document.getElementById('userSearchInput').value.toLowerCase().trim();
        const rows = document.querySelectorAll('.user-row');
        rows.forEach(row => {
            const name = row.getAttribute('data-name') || '';
            const username = row.getAttribute('data-username') || '';
            const role = row.getAttribute('data-role') || '';
            if (!query || name.includes(query) || username.includes(query) || role.includes(query)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }

    function openCreateUserModal() {
        document.getElementById('createUserModal').classList.add('active');
    }

    function closeCreateUserModal() {
        document.getElementById('createUserModal').classList.remove('active');
    }

    function openEditUserModal(data) {
        document.getElementById('editUserForm').action = data.update_url;
        document.getElementById('edit_name').value = data.name;
        document.getElementById('edit_username').value = data.username;
        document.getElementById('edit_email').value = data.email;
        document.getElementById('edit_role').value = data.role;
        document.getElementById('edit_password').value = '';
        document.getElementById('edit_password_confirmation').value = '';

        document.getElementById('editUserModal').classList.add('active');
    }

    function closeEditUserModal() {
        document.getElementById('editUserModal').classList.remove('active');
    }

    // Close modals on overlay backdrop click
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    });
</script>
@endpush
@endsection
