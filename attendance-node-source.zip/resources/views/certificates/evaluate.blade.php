@extends('layouts.app')

@section('page_title', 'Event Evaluation & E-Certificate Claim')

@section('content')
<div style="max-width: 820px; margin: 0 auto; display: flex; flex-direction: column; gap: 24px;">

    <!-- Evaluation Notice Banner -->
    <div style="background: linear-gradient(135deg, #07152d 0%, #1259c3 100%); border-radius: var(--radius-md); padding: 28px; color: #ffffff; box-shadow: var(--shadow-md);">
        <div style="display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
            <div>
                <span class="badge" style="background: rgba(245, 158, 11, 0.2); color: var(--gold); border: 1px solid rgba(245, 158, 11, 0.4); margin-bottom: 8px;">
                    <i class="fa-solid fa-award"></i> Certificate Requirement
                </span>
                <h1 style="font-size: 24px; font-weight: 800; color: #ffffff; margin-top: 6px;">
                    Event Evaluation: {{ $event->name }}
                </h1>
                <p style="color: #cbd5e1; font-size: 14px; margin-top: 6px; max-width: 620px;">
                    Please share your honest feedback below. Once submitted, your official <strong>Pangasinan State University E-Certificate of Participation</strong> with your full name (<strong>{{ $student->full_name }}</strong>) will be automatically generated and unlocked for instant download!
                </p>
            </div>
            <div style="text-align: right; background: rgba(255,255,255,0.08); padding: 12px 18px; border-radius: var(--radius-sm); border: 1px solid rgba(255,255,255,0.12);">
                <div style="font-size: 11px; color: #94a3b8; text-transform: uppercase;">Event Date</div>
                <div style="font-size: 14px; font-weight: 700; color: #ffffff;">
                    {{ $event->event_date?->format('M d, Y') }}
                </div>
            </div>
        </div>
    </div>

    <!-- Evaluation Form -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-list-check" style="color: var(--primary);"></i>
                <span>Evaluation Questionnaire (Rating Scale: 1 to 5 Stars)</span>
            </div>
            <span style="font-size: 12px; color: var(--text-muted);">
                Recipient: <strong>{{ $student->full_name }}</strong> ({{ $student->student_id }})
            </span>
        </div>
        <div class="card-body" style="padding: 32px 28px;">
            <form action="{{ route('events.evaluate.submit', $event) }}" method="POST">
                @csrf

                <!-- Criteria 1: Content -->
                <div style="margin-bottom: 26px; padding-bottom: 20px; border-bottom: 1px solid var(--line);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
                        <div>
                            <strong style="font-size: 15px; color: var(--text-main);">1. Program Content & Relevance</strong>
                            <div style="font-size: 12px; color: var(--text-muted);">How relevant, informative, and well-organized were the topics presented?</div>
                        </div>
                    </div>
                    <div style="display: flex; gap: 14px; flex-wrap: wrap;">
                        @for($i = 5; $i >= 1; $i--)
                            <label style="display: flex; align-items: center; gap: 6px; padding: 10px 16px; background: #f8fafc; border: 1px solid var(--card-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 13px; font-weight: 600;">
                                <input type="radio" name="rating_content" value="{{ $i }}" {{ $i === 5 ? 'checked' : '' }} required>
                                <span>{{ $i }} ★ ({{ $i === 5 ? 'Excellent' : ($i === 4 ? 'Very Good' : ($i === 3 ? 'Good' : ($i === 2 ? 'Fair' : 'Poor'))) }})</span>
                            </label>
                        @endfor
                    </div>
                </div>

                <!-- Criteria 2: Speaker / Facilitators -->
                <div style="margin-bottom: 26px; padding-bottom: 20px; border-bottom: 1px solid var(--line);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
                        <div>
                            <strong style="font-size: 15px; color: var(--text-main);">2. Speakers & Facilitators Effectiveness</strong>
                            <div style="font-size: 12px; color: var(--text-muted);">Mastery of the subject matter, clarity, and engagement with participants.</div>
                        </div>
                    </div>
                    <div style="display: flex; gap: 14px; flex-wrap: wrap;">
                        @for($i = 5; $i >= 1; $i--)
                            <label style="display: flex; align-items: center; gap: 6px; padding: 10px 16px; background: #f8fafc; border: 1px solid var(--card-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 13px; font-weight: 600;">
                                <input type="radio" name="rating_speaker" value="{{ $i }}" {{ $i === 5 ? 'checked' : '' }} required>
                                <span>{{ $i }} ★ ({{ $i === 5 ? 'Excellent' : ($i === 4 ? 'Very Good' : ($i === 3 ? 'Good' : ($i === 2 ? 'Fair' : 'Poor'))) }})</span>
                            </label>
                        @endfor
                    </div>
                </div>

                <!-- Criteria 3: Venue & Logistics -->
                <div style="margin-bottom: 26px; padding-bottom: 20px; border-bottom: 1px solid var(--line);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
                        <div>
                            <strong style="font-size: 15px; color: var(--text-main);">3. Venue, Facilities & Logistics</strong>
                            <div style="font-size: 12px; color: var(--text-muted);">Comfort, audio-visual technology, timeliness, and organization of the event.</div>
                        </div>
                    </div>
                    <div style="display: flex; gap: 14px; flex-wrap: wrap;">
                        @for($i = 5; $i >= 1; $i--)
                            <label style="display: flex; align-items: center; gap: 6px; padding: 10px 16px; background: #f8fafc; border: 1px solid var(--card-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 13px; font-weight: 600;">
                                <input type="radio" name="rating_venue" value="{{ $i }}" {{ $i === 5 ? 'checked' : '' }} required>
                                <span>{{ $i }} ★ ({{ $i === 5 ? 'Excellent' : ($i === 4 ? 'Very Good' : ($i === 3 ? 'Good' : ($i === 2 ? 'Fair' : 'Poor'))) }})</span>
                            </label>
                        @endfor
                    </div>
                </div>

                <!-- Criteria 4: Overall Satisfaction -->
                <div style="margin-bottom: 26px; padding-bottom: 20px; border-bottom: 1px solid var(--line);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
                        <div>
                            <strong style="font-size: 15px; color: var(--text-main);">4. Overall Satisfaction</strong>
                            <div style="font-size: 12px; color: var(--text-muted);">General experience and value of this university activity.</div>
                        </div>
                    </div>
                    <div style="display: flex; gap: 14px; flex-wrap: wrap;">
                        @for($i = 5; $i >= 1; $i--)
                            <label style="display: flex; align-items: center; gap: 6px; padding: 10px 16px; background: #f8fafc; border: 1px solid var(--card-border); border-radius: var(--radius-sm); cursor: pointer; font-size: 13px; font-weight: 600;">
                                <input type="radio" name="rating_overall" value="{{ $i }}" {{ $i === 5 ? 'checked' : '' }} required>
                                <span>{{ $i }} ★ ({{ $i === 5 ? 'Excellent' : ($i === 4 ? 'Very Good' : ($i === 3 ? 'Good' : ($i === 2 ? 'Fair' : 'Poor'))) }})</span>
                            </label>
                        @endfor
                    </div>
                </div>

                <!-- Qualitative Feedback -->
                <div class="form-group" style="margin-bottom: 20px;">
                    <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">
                        Key Learnings / What went well?
                    </label>
                    <textarea name="comments" rows="3" class="form-control" placeholder="Share your key takeaways from this event..."></textarea>
                </div>

                <div class="form-group" style="margin-bottom: 28px;">
                    <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">
                        Suggestions for future campus activities:
                    </label>
                    <textarea name="suggestions" rows="2" class="form-control" placeholder="How can the university improve future programs?"></textarea>
                </div>

                <!-- Submit CTA -->
                <div style="background: #f8fafc; border: 1px solid var(--line); border-radius: var(--radius-md); padding: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
                    <div style="font-size: 13px; color: var(--text-muted);">
                        <i class="fa-solid fa-lock" style="color: var(--success);"></i> By submitting, your evaluation is sealed and your e-certificate will be automatically issued.
                    </div>
                    <button type="submit" class="btn btn-primary" style="padding: 12px 28px; font-size: 14px; font-weight: 700; box-shadow: 0 4px 14px rgba(18, 89, 195, 0.4);">
                        <i class="fa-solid fa-award"></i> Submit Evaluation & Unlock E-Certificate
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>
@endsection
