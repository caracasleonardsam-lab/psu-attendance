@extends('layouts.app')

@section('page_title', 'E-Certificate Setup: ' . $event->name)

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Top Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
        <a href="{{ route('events.show', $event) }}" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-arrow-left"></i> Back to Event Details
        </a>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="{{ route('events.certificate.blank_template', $event) }}" class="btn btn-secondary btn-sm" title="Download clean Pangasinan State University template for editing in Canva or Photoshop">
                <i class="fa-solid fa-download" style="color: var(--primary);"></i> Download Official HD Template (PNG)
            </a>
            <a href="{{ route('events.evaluations', $event) }}" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-star-half-stroke" style="color: var(--gold);"></i> View Student Evaluations
            </a>
            <a href="{{ route('events.certificate.preview', $event) }}" target="_blank" class="btn btn-primary btn-sm">
                <i class="fa-solid fa-eye"></i> Full HD Resolution Preview
            </a>
        </div>
    </div>

    <!-- 2 Column Layout: Settings & Real-Time Preview -->
    <div style="display: grid; grid-template-columns: 460px 1fr; gap: 24px; align-items: start;">

        <!-- Certificate Configuration Card -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header">
                <div class="card-title">
                    <i class="fa-solid fa-award" style="color: var(--gold);"></i>
                    <span>E-Certificate Template Settings</span>
                </div>
                <span class="badge {{ $certificate->is_active ? 'badge-success' : 'badge-neutral' }}">
                    {{ $certificate->is_active ? 'Enabled' : 'Disabled' }}
                </span>
            </div>
            <div class="card-body">
                <form action="{{ route('events.certificate.update', $event) }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    <!-- Auto-Readability & HD Notice -->
                    <div style="margin-bottom: 20px; padding: 14px; background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px;">
                        <div style="display: flex; gap: 10px; align-items: flex-start;">
                            <i class="fa-solid fa-wand-magic-sparkles" style="color: var(--primary); font-size: 16px; margin-top: 2px;"></i>
                            <div style="font-size: 12px; color: #1e3a8a; line-height: 1.45;">
                                <strong>High-Definition (HD) Clarity Guaranteed:</strong>
                                Uploaded custom templates are preserved in 100% native resolution with zero compression blur. For razor-sharp results, use an HD image of at least <strong>1920×1080 px</strong> (or standard A4 <strong>2480×1754 px</strong>).
                            </div>
                        </div>
                    </div>

                    <!-- Template Upload -->
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">
                            <i class="fa-solid fa-cloud-arrow-up"></i> Upload Background Template (HD Image)
                        </label>
                        <input type="file" name="template_image" id="templateFileInput" class="form-control" accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp" onchange="inspectAndPreviewFile(this)">
                        
                        <!-- Client-side real-time resolution inspection notice -->
                        <div id="resolutionNotice" style="display: none; margin-top: 8px;"></div>

                        <div style="font-size: 11px; color: var(--text-muted); margin-top: 6px;">
                            Supported formats: PNG, JPG, WEBP. Maximum file size: 5 MB. Tip: Design templates in Canva or Photoshop in 1920×1080 or A4 Landscape.
                        </div>
                        @error('template_image')
                            <div role="alert" style="margin-top: 8px; color: #b91c1c; font-size: 12px;">{{ $message }}</div>
                        @enderror

                        @if($certificate->template_path)
                            <div style="margin-top: 10px; padding: 10px 12px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px;">
                                <div style="font-size: 12px; color: #166534; font-weight: 600; display: flex; align-items: center; gap: 6px;">
                                    <i class="fa-solid fa-circle-check"></i> Custom template active: {{ basename($certificate->template_path) }}
                                </div>
                                <label style="display: flex; align-items: center; gap: 8px; margin-top: 6px; font-size: 12px; color: #b91c1c; cursor: pointer; font-weight: 600;">
                                    <input type="checkbox" name="remove_custom_template" value="1">
                                    <i class="fa-solid fa-rotate-left"></i> Revert to Official Pangasinan State University Gold Template
                                </label>
                            </div>
                        @else
                            <div style="margin-top: 8px; font-size: 12px; color: var(--primary); font-weight: 600;">
                                <i class="fa-solid fa-certificate"></i> Currently using official Pangasinan State University built-in gold frame template
                            </div>
                        @endif
                    </div>

                    <!-- Certificate Title -->
                    <div class="form-group" style="margin-bottom: 16px;">
                        <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">Certificate Title</label>
                        <input type="text" name="title" class="form-control" value="{{ old('title', $certificate->title ?? 'Certificate of Participation') }}" required>
                    </div>

                    <!-- Subtitle / Presentation Text -->
                    <div class="form-group" style="margin-bottom: 16px;">
                        <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">Subtitle</label>
                        <input type="text" name="sub_title" class="form-control" value="{{ old('sub_title', $certificate->sub_title ?? 'is proudly presented to') }}">
                    </div>

                    <!-- Signatory Details -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                        <div>
                            <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">Signatory Name</label>
                            <input type="text" name="signatory_name" class="form-control" value="{{ old('signatory_name', $certificate->signatory_name ?? 'Dr. Campus Executive Director') }}">
                        </div>
                        <div>
                            <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">Signatory Title</label>
                            <input type="text" name="signatory_title" class="form-control" value="{{ old('signatory_title', $certificate->signatory_title ?? 'Campus Executive Director') }}">
                        </div>
                    </div>

                    <!-- Name Positioning (Y-coordinate %) -->
                    <div class="form-group" style="margin-bottom: 16px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                            <label class="form-label" style="font-weight: 700;">Student Name Vertical Position (Y)</label>
                            <span id="yValDisplay" style="font-weight: 700; color: var(--primary);">{{ $certificate->name_y_position ?? 48 }}%</span>
                        </div>
                        <input type="range" name="name_y_position" id="yRange" min="20" max="80" value="{{ $certificate->name_y_position ?? 48 }}" class="form-control" style="cursor: pointer;" oninput="document.getElementById('yValDisplay').innerText = this.value + '%'">
                        <div style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">
                            Adjust to slide where the student's name appears vertically over your template.
                        </div>
                    </div>

                    <!-- Styling: Font Size & Font Color -->
                    <div style="margin-bottom: 20px;">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 10px;">
                            <div>
                                <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">Base Font Size (px)</label>
                                <input type="number" name="font_size" class="form-control" min="20" max="90" value="{{ old('font_size', $certificate->font_size ?? 48) }}" required>
                                <span style="font-size: 11px; color: var(--text-muted);">Auto-scales if name is long</span>
                            </div>
                            <div>
                                <label class="form-label" style="font-weight: 700; margin-bottom: 6px; display: block;">Name Font Color</label>
                                <div style="display: flex; gap: 8px; align-items: center;">
                                    <input type="color" name="font_color" id="fontColorPicker" class="form-control" value="{{ old('font_color', $certificate->font_color ?? '#07152d') }}" style="width: 50px; height: 38px; padding: 2px;">
                                    <input type="text" id="fontColorHex" class="form-control" value="{{ old('font_color', $certificate->font_color ?? '#07152d') }}" style="font-family: 'JetBrains Mono', monospace; font-size: 12px;" oninput="syncColorInput(this.value)">
                                </div>
                            </div>
                        </div>

                        <!-- Quick Color Preset Chips -->
                        <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center; margin-top: 8px;">
                            <span style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Presets:</span>
                            <button type="button" class="btn btn-sm" style="background: #07152d; color: #ffffff; padding: 3px 8px; font-size: 11px;" onclick="setColorPreset('#07152d')">Pangasinan State University Navy</button>
                            <button type="button" class="btn btn-sm" style="background: #d97706; color: #ffffff; padding: 3px 8px; font-size: 11px;" onclick="setColorPreset('#d97706')">Gold</button>
                            <button type="button" class="btn btn-sm" style="background: #1259c3; color: #ffffff; padding: 3px 8px; font-size: 11px;" onclick="setColorPreset('#1259c3')">Royal Blue</button>
                            <button type="button" class="btn btn-sm" style="background: #111827; color: #ffffff; padding: 3px 8px; font-size: 11px;" onclick="setColorPreset('#111827')">Classic Black</button>
                            <button type="button" class="btn btn-sm" style="background: #f8fafc; color: #0f172a; border: 1px solid #cbd5e1; padding: 3px 8px; font-size: 11px;" onclick="setColorPreset('#ffffff')">White (Dark Templates)</button>
                        </div>
                    </div>

                    <!-- Active Toggle -->
                    <div style="margin-bottom: 24px; padding: 12px; background: #f8fafc; border: 1px solid var(--line); border-radius: var(--radius-sm); display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="is_active" id="is_active" value="1" {{ $certificate->is_active ? 'checked' : '' }} style="width: 18px; height: 18px;">
                        <label for="is_active" style="cursor: pointer; font-size: 13px; font-weight: 600;">
                            Enable Automatic E-Certificate Issuance after Evaluation
                        </label>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fa-solid fa-floppy-disk"></i> Save E-Certificate Settings
                    </button>
                </form>
            </div>
        </div>

        <!-- Live Preview Card -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header">
                <div class="card-title">
                    <i class="fa-solid fa-image" style="color: var(--primary);"></i>
                    <span>Live Stamped HD Preview (Sample Student: JUAN DELA CRUZ)</span>
                </div>
                <div style="display: flex; gap: 8px;">
                    <button type="button" class="btn btn-sm btn-secondary" onclick="reloadPreview()">
                        <i class="fa-solid fa-arrows-rotate"></i> Refresh
                    </button>
                </div>
            </div>
            <div class="card-body" style="padding: 20px; text-align: center; background: #07152d; border-radius: 0 0 var(--radius-md) var(--radius-md);">
                <div style="position: relative; display: inline-block; width: 100%; border: 3px solid rgba(255, 255, 255, 0.15); border-radius: 8px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.5);">
                    <img 
                        id="certPreviewImg" 
                        src="{{ route('events.certificate.preview', $event) }}?t={{ time() }}" 
                        alt="Certificate Preview" 
                        style="width: 100%; height: auto; display: block; image-rendering: -webkit-optimize-contrast;"
                    >
                </div>
                <div style="margin-top: 14px; color: #cbd5e1; font-size: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                    <span><i class="fa-solid fa-circle-info"></i> Full HD rendered with dynamic anti-aliased typography.</span>
                    <a href="{{ route('events.certificate.preview', $event) }}" target="_blank" style="color: var(--gold); text-decoration: underline;">
                        <i class="fa-solid fa-up-right-from-square"></i> Open Raw 1:1 HD Canvas
                    </a>
                </div>
            </div>
        </div>

    </div>

</div>

<script>
function reloadPreview() {
    const img = document.getElementById('certPreviewImg');
    if (img) {
        img.src = '{{ route("events.certificate.preview", $event) }}?t=' + new Date().getTime();
    }
}

function setColorPreset(hex) {
    const picker = document.getElementById('fontColorPicker');
    const hexInput = document.getElementById('fontColorHex');
    if (picker) picker.value = hex;
    if (hexInput) hexInput.value = hex;
}

function syncColorInput(val) {
    if (val.startsWith('#') && (val.length === 4 || val.length === 7)) {
        const picker = document.getElementById('fontColorPicker');
        if (picker) picker.value = val;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const certImg = document.getElementById('certPreviewImg');
    if (certImg) certImg.dataset.originalSrc = certImg.src;

    const picker = document.getElementById('fontColorPicker');
    if (picker) {
        picker.addEventListener('input', function() {
            const hexInput = document.getElementById('fontColorHex');
            if (hexInput) hexInput.value = this.value;
        });
    }
});

function inspectAndPreviewFile(input) {
    const noticeDiv = document.getElementById('resolutionNotice');
    const certImg = document.getElementById('certPreviewImg');
    const originalPreview = certImg ? certImg.dataset.originalSrc : null;

    if (!input.files || !input.files[0]) {
        if (noticeDiv) noticeDiv.style.display = 'none';
        if (certImg && originalPreview) certImg.src = originalPreview;
        return;
    }

    const file = input.files[0];
    if (file.size > 5 * 1024 * 1024) {
        if (noticeDiv) {
            noticeDiv.style.display = 'block';
            noticeDiv.textContent = 'This file is larger than the 5 MB limit. Choose a smaller image.';
        }
        input.value = '';
        if (certImg && originalPreview) certImg.src = originalPreview;
        return;
    }

    const reader = new FileReader();

    reader.onload = function(e) {
        const tempImg = new Image();
        tempImg.onload = function() {
            const w = tempImg.naturalWidth;
            const h = tempImg.naturalHeight;
            const fileSize = (file.size / (1024 * 1024)).toFixed(2);

            if (noticeDiv) {
                noticeDiv.style.display = 'block';
                if (w >= 1920 && h >= 1080) {
                    noticeDiv.innerHTML = `
                        <div style="padding: 10px 14px; background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; border-radius: 6px; font-size: 12px; display: flex; align-items: center; gap: 8px;">
                            <i class="fa-solid fa-circle-check" style="font-size: 16px;"></i>
                            <div><strong>Ultra HD: ${w} × ${h} px</strong><br>${fileSize} MB. Optimal for printing and downloads.</div>
                        </div>`;
                } else if (w >= 1200 && h >= 600) {
                    noticeDiv.innerHTML = `
                        <div style="padding: 10px 14px; background: #eff6ff; border: 1px solid #bfdbfe; color: #1e40af; border-radius: 6px; font-size: 12px; display: flex; align-items: center; gap: 8px;">
                            <i class="fa-solid fa-circle-info" style="font-size: 16px;"></i>
                            <div><strong>High Definition: ${w} × ${h} px</strong><br>${fileSize} MB. Good resolution for digital certificate issuance.</div>
                        </div>`;
                } else {
                    noticeDiv.innerHTML = `
                        <div style="padding: 10px 14px; background: #fffbeb; border: 1px solid #fef3c7; color: #92400e; border-radius: 6px; font-size: 12px; display: flex; align-items: flex-start; gap: 8px;">
                            <i class="fa-solid fa-triangle-exclamation" style="font-size: 16px; margin-top: 2px;"></i>
                            <div>
                                <strong>Low Resolution: ${w} × ${h} px</strong><br>
                                ${fileSize} MB.<br>
                                This image is smaller than standard HD (1920×1080). Scaling it up may cause visible blur. For best results, use an HD image or click <em>"Download Official HD Template"</em> above.
                            </div>
                        </div>`;
                }
            }

            if (certImg) {
                certImg.src = e.target.result;
            }
        };
        tempImg.onerror = function() {
            if (noticeDiv) {
                noticeDiv.style.display = 'block';
                noticeDiv.textContent = 'This image could not be previewed. Choose a valid PNG, JPG, or WEBP image.';
            }
        };
        tempImg.src = e.target.result;
    };

    reader.onerror = function() {
        if (noticeDiv) {
            noticeDiv.style.display = 'block';
            noticeDiv.textContent = 'The selected image could not be read. Please choose it again.';
        }
    };
    reader.readAsDataURL(file);
}
</script>
@endsection
