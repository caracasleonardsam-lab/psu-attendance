<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pangasinan State University Digital Certificate Verification | {{ $code }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary: #1259c3;
            --gold: #f59e0b;
            --success: #10b981;
            --danger: #ef4444;
            --text-main: #0f172a;
            --text-muted: #64748b;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
            background: linear-gradient(135deg, #07152d 0%, #0d2246 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            color: #ffffff;
        }
        .verify-card {
            background: #ffffff;
            color: var(--text-main);
            border-radius: 20px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            width: 100%;
            max-width: 580px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .card-header-banner {
            background: linear-gradient(135deg, #07152d 0%, #1e3a8a 100%);
            padding: 32px 28px;
            text-align: center;
            color: #ffffff;
            position: relative;
        }
        .campus-logo {
            width: 64px;
            height: 64px;
            background: transparent;
            padding: 0;
            object-fit: contain;
            filter: drop-shadow(0 0 16px rgba(245, 158, 11, 0.45));
            margin-bottom: 12px;
        }
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 16px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-top: 10px;
        }
        .status-valid {
            background: #ecfdf5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        .status-invalid {
            background: #fef2f2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        .card-body {
            padding: 32px 28px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 14px 0;
            border-bottom: 1px solid #e2e8f0;
            font-size: 14px;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .info-label {
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }
        .info-val {
            font-weight: 700;
            color: var(--text-main);
            text-align: right;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            border: none;
            transition: all 0.2s;
        }
        .btn-primary {
            background: var(--primary);
            color: #ffffff;
        }
        .btn-primary:hover {
            background: #0e469b;
        }
    </style>
</head>
<body>
    <div class="verify-card">
        <div class="card-header-banner">
            <img src="{{ asset('images/logo.png') }}" onerror="this.src='{{ asset('images/psu_logo.jpg') }}'" alt="Pangasinan State University Logo" class="campus-logo">
            <h2 style="font-size: 20px; font-weight: 800;">Pangasinan State University</h2>
            <div style="font-size: 12px; color: var(--gold); text-transform: uppercase; letter-spacing: 0.05em; margin-top: 2px;">
                Alaminos City Campus • Official Certificate Registry
            </div>

            @if($certificate)
                <div class="status-badge status-valid">
                    <i class="fa-solid fa-circle-check"></i> Officially Verified & Authentic
                </div>
            @else
                <div class="status-badge status-invalid">
                    <i class="fa-solid fa-triangle-exclamation"></i> Invalid or Unrecognized Certificate
                </div>
            @endif
        </div>

        <div class="card-body">
            @if($certificate)
                <div class="info-row">
                    <span class="info-label">Certificate Code</span>
                    <span class="info-val" style="font-family: 'JetBrains Mono', monospace; color: var(--primary);">
                        {{ $certificate->certificate_code }}
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Recipient Name</span>
                    <span class="info-val" style="font-size: 16px; color: #07152d;">
                        {{ $certificate->student_name }}
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Student ID</span>
                    <span class="info-val">
                        {{ $certificate->student?->student_id ?? 'Pangasinan State University Student' }}
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Event / Activity</span>
                    <span class="info-val">
                        {{ $certificate->event?->name ?? 'Campus Event' }}
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Date Issued</span>
                    <span class="info-val">
                        {{ $certificate->issued_at?->format('F d, Y h:i A') }}
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Evaluation Status</span>
                    <span class="info-val" style="color: var(--success);">
                        <i class="fa-solid fa-check"></i> Evaluated & Approved
                    </span>
                </div>

                <div style="margin-top: 24px;">
                    <a href="{{ route('certificates.show', $certificate->certificate_code) }}" class="btn btn-primary">
                        <i class="fa-solid fa-award"></i> View Official E-Certificate
                    </a>
                </div>
            @else
                <div style="text-align: center; padding: 20px 0;">
                    <i class="fa-solid fa-circle-xmark" style="font-size: 48px; color: var(--danger); margin-bottom: 12px;"></i>
                    <h3 style="font-size: 18px; font-weight: 800; color: var(--text-main);">Certificate Not Found</h3>
                    <p style="color: var(--text-muted); font-size: 13px; margin-top: 6px;">
                        No official Pangasinan State University event certificate was found matching the code <code>{{ $code }}</code>. Please check the code or contact the campus administration.
                    </p>
                </div>
            @endif
        </div>
    </div>
</body>
</html>
