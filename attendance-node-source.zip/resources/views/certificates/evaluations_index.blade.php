@extends('layouts.app')

@section('page_title', 'Event Evaluations: ' . $event->name)

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Top Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
        <a href="{{ route('events.show', $event) }}" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-arrow-left"></i> Back to Event Details
        </a>
        <div style="display: flex; gap: 10px;">
            @if(auth()->user()?->isAdmin())
                <a href="{{ route('events.certificate.setup', $event) }}" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-award"></i> Certificate Template Settings
                </a>
            @endif
        </div>
    </div>

    <div class="card" style="margin-bottom: 0;">
        <div class="card-body" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
            <div>
                <strong style="font-size: 14px; color: var(--text-main);">Student Evaluation & E-Certificate</strong>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 3px;">
                    {{ $event->evaluation_enabled && $event->status === 'completed' ? 'ON — present students can evaluate and claim their e-certificate.' : ($event->evaluation_enabled ? 'ON but locked — mark the event Completed before students can access it.' : 'OFF — students cannot access the evaluation yet.') }}
                </div>
            </div>
            <form action="{{ route('events.evaluation.toggle', $event) }}" method="POST" style="display: flex; align-items: center; gap: 10px;">
                @csrf
                <input type="hidden" name="evaluation_enabled" value="0">
                <label style="display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 700; color: var(--text-main); cursor: pointer; margin: 0;">
                    <input type="checkbox" name="evaluation_enabled" value="1" role="switch" {{ $event->evaluation_enabled ? 'checked' : '' }}>
                    <span>{{ $event->evaluation_enabled ? 'ON' : 'OFF' }}</span>
                </label>
                <button type="submit" class="btn {{ $event->evaluation_enabled ? 'btn-secondary' : 'btn-primary' }} btn-sm">
                    {{ $event->evaluation_enabled ? 'Turn OFF' : ($event->status === 'completed' ? 'Turn ON' : 'Mark Completed to Turn ON') }}
                </button>
            </form>
        </div>
    </div>

    <!-- Rating Summary Metric Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 18px;">
        <!-- Total Evaluations -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-body" style="padding: 20px;">
                <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Total Evaluated</div>
                <div style="font-size: 28px; font-weight: 800; color: var(--primary); margin-top: 4px;">
                    {{ number_format($totalEvaluations) }}
                </div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                    Certificates Issued: <strong>{{ number_format($issuedCertificatesCount) }}</strong>
                </div>
            </div>
        </div>

        <!-- Overall Score -->
        <div class="card" style="margin-bottom: 0; border-left: 4px solid var(--gold);">
            <div class="card-body" style="padding: 20px;">
                <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Overall Satisfaction</div>
                <div style="font-size: 28px; font-weight: 800; color: var(--gold); margin-top: 4px;">
                    {{ $avgOverall > 0 ? $avgOverall : 'N/A' }} <span style="font-size: 16px; color: #94a3b8;">/ 5.0</span>
                </div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                    <i class="fa-solid fa-star" style="color: var(--gold);"></i> General sentiment
                </div>
            </div>
        </div>

        <!-- Content Rating -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-body" style="padding: 20px;">
                <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Program & Content</div>
                <div style="font-size: 28px; font-weight: 800; color: var(--success); margin-top: 4px;">
                    {{ $avgContent > 0 ? $avgContent : 'N/A' }} <span style="font-size: 16px; color: #94a3b8;">/ 5.0</span>
                </div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Relevance & Clarity</div>
            </div>
        </div>

        <!-- Speaker Rating -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-body" style="padding: 20px;">
                <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Speakers & Facilitators</div>
                <div style="font-size: 28px; font-weight: 800; color: var(--primary); margin-top: 4px;">
                    {{ $avgSpeaker > 0 ? $avgSpeaker : 'N/A' }} <span style="font-size: 16px; color: #94a3b8;">/ 5.0</span>
                </div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Mastery & Delivery</div>
            </div>
        </div>

        <!-- Venue Rating -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-body" style="padding: 20px;">
                <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Venue & Organization</div>
                <div style="font-size: 28px; font-weight: 800; color: var(--text-main); margin-top: 4px;">
                    {{ $avgVenue > 0 ? $avgVenue : 'N/A' }} <span style="font-size: 16px; color: #94a3b8;">/ 5.0</span>
                </div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Logistics & Setup</div>
            </div>
        </div>
    </div>

    <!-- Evaluations Table -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-comments" style="color: var(--primary);"></i>
                <span>Student Submissions & Feedback ({{ $totalEvaluations }})</span>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        @if($canViewStudentIdentities)
                            <th>Student</th>
                            <th>Program</th>
                        @else
                            <th>Respondent</th>
                        @endif
                        <th>Content</th>
                        <th>Speaker</th>
                        <th>Venue</th>
                        <th>Overall</th>
                        <th>Feedback & Suggestions</th>
                        @if($canViewStudentIdentities)
                            <th>Submission Time</th>
                        @endif
                    </tr>
                </thead>
                <tbody>
                    @forelse($evaluations as $ev)
                        <tr>
                            @if($canViewStudentIdentities)
                                <td>
                                    <strong style="color: var(--text-main);">{{ $ev->student?->full_name ?? 'Student' }}</strong>
                                    <div style="font-size: 11px; color: var(--primary); font-family: monospace;">{{ $ev->student?->student_id }}</div>
                                </td>
                                <td><span class="badge badge-neutral">{{ $ev->student?->program?->name ?? 'N/A' }}</span></td>
                            @else
                                <td>Anonymous respondent</td>
                            @endif
                            <td><span class="badge badge-success">{{ $ev->rating_content }} ★</span></td>
                            <td><span class="badge badge-primary">{{ $ev->rating_speaker }} ★</span></td>
                            <td><span class="badge badge-neutral">{{ $ev->rating_venue }} ★</span></td>
                            <td><span class="badge badge-warning" style="font-weight: 800;">{{ $ev->rating_overall }} ★</span></td>
                            <td style="max-width: 320px;">
                                @if($ev->comments)
                                    <div style="font-size: 13px; color: var(--text-main); margin-bottom: 4px;">
                                        "{{ $ev->comments }}"
                                    </div>
                                @endif
                                @if($ev->suggestions)
                                    <div style="font-size: 11px; color: var(--text-muted);">
                                        <i class="fa-regular fa-lightbulb"></i> Suggestion: {{ $ev->suggestions }}
                                    </div>
                                @endif
                                @if(!$ev->comments && !$ev->suggestions)
                                    <span style="color: var(--text-light); font-size: 12px;">No written comments.</span>
                                @endif
                            </td>
                            @if($canViewStudentIdentities)
                                <td style="font-size: 12px; color: var(--text-muted); white-space: nowrap;">
                                    {{ $ev->submitted_at?->format('M d, Y h:i A') }}
                                </td>
                            @endif
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 36px;">
                                No student evaluations have been submitted for this event yet.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($evaluations->hasPages())
            <div style="padding: 16px 24px; border-top: 1px solid var(--card-border-subtle);">
                {{ $evaluations->links() }}
            </div>
        @endif
    </div>

</div>
@endsection
