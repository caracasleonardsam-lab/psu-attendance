@extends('layouts.app')

@section('page_title', 'E-Certificate: ' . $student->full_name)

@push('styles')
<style>
@media print {
    body * {
        visibility: hidden;
    }
    .print-certificate-container, .print-certificate-container * {
        visibility: visible;
    }
    .print-certificate-container {
        position: fixed;
        left: 0;
        top: 0;
        width: 100vw;
        height: 100vh;
        margin: 0;
        padding: 0;
        background: #ffffff !important;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;
    }
    .no-print {
        display: none !important;
    }
}
</style>
@endpush

@section('content')
<div style="max-width: 1100px; margin: 0 auto; display: flex; flex-direction: column; gap: 24px;">

    <!-- Celebratory Action Header -->
    <div class="no-print" style="background: linear-gradient(135deg, #07152d 0%, #1e3a8a 100%); border-radius: var(--radius-md); padding: 24px 28px; color: #ffffff; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
        <div>
            <div style="font-size: 11px; font-weight: 700; color: var(--gold); text-transform: uppercase; letter-spacing: 0.05em;">
                <i class="fa-solid fa-circle-check" style="color: #34d399;"></i> Evaluation Complete • Certificate Unlocked
            </div>
            <h1 style="font-size: 22px; font-weight: 800; color: #ffffff; margin-top: 4px;">
                Official E-Certificate of Participation
            </h1>
            <p style="color: #cbd5e1; font-size: 13px; margin-top: 4px;">
                Awarded to <strong>{{ $student->full_name }}</strong> for the event <strong>{{ $event->name }}</strong>
            </p>
        </div>

        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <a href="{{ route('certificates.download', $certificate->certificate_code) }}" class="btn btn-primary btn-sm" style="padding: 10px 18px; font-weight: 700; box-shadow: 0 4px 12px rgba(18, 89, 195, 0.4);">
                <i class="fa-solid fa-download"></i> Download PNG Image
            </a>
            <button type="button" class="btn btn-gold btn-sm" onclick="window.print()" style="padding: 10px 18px; font-weight: 700;">
                <i class="fa-solid fa-print"></i> Print / Save PDF
            </button>
            @if(Auth::check() && Auth::user()->role !== 'student')
            <a href="{{ route('events.show', $event->id) }}" class="btn btn-secondary btn-sm" style="padding: 10px 16px;">
                <i class="fa-solid fa-arrow-left"></i> Back to Event
            </a>
            @else
            <a href="{{ url('/') }}" class="btn btn-secondary btn-sm" style="padding: 10px 16px;">
                <i class="fa-solid fa-arrow-left"></i> Home
            </a>
            @endif
        </div>
    </div>

    <!-- Certificate Display Container -->
    <div class="print-certificate-container card" style="margin-bottom: 0; background: #07152d; padding: 24px; border-radius: var(--radius-md); text-align: center; box-shadow: var(--shadow-lg);">
        
        <!-- Live Stamped Certificate Image (Auto-generated with student's name) -->
        <div style="position: relative; max-width: 1000px; margin: 0 auto; background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.7);">
            <img 
                src="{{ route('certificates.download', $certificate->certificate_code) }}" 
                alt="E-Certificate: {{ $student->full_name }}" 
                style="width: 100%; height: auto; display: block;"
            >
        </div>

    </div>

    <!-- Verification & Security Badge Box -->
    <div class="no-print card" style="margin-bottom: 0;">
        <div class="card-body" style="padding: 20px 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div style="display: flex; align-items: center; gap: 14px;">
                <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--success-soft); color: var(--success); display: flex; align-items: center; justify-content: center; font-size: 22px;">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <div>
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Cryptographic Security Certificate</div>
                    <div style="font-family: 'JetBrains Mono', monospace; font-size: 15px; font-weight: 800; color: var(--primary);">
                        {{ $certificate->certificate_code }}
                    </div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                        Issued on {{ $certificate->issued_at?->format('F d, Y h:i A') }} • Registered in University Portal
                    </div>
                </div>
            </div>

            <div style="display: flex; gap: 10px; align-items: center;">
                <a href="{{ route('certificates.verify', $certificate->certificate_code) }}" target="_blank" class="btn btn-secondary btn-sm">
                    <i class="fa-solid fa-check-double"></i> Open Public Verification
                </a>
                <button type="button" class="btn btn-secondary btn-sm" onclick="copyVerifyUrl()">
                    <i class="fa-regular fa-copy"></i> Copy Link
                </button>
            </div>
        </div>
    </div>

</div>

<script>
function copyVerifyUrl() {
    const url = '{{ route("certificates.verify", $certificate->certificate_code) }}';
    navigator.clipboard.writeText(url).then(() => {
        alert('Verification URL copied to clipboard:\n' + url);
    });
}
</script>
@endsection
