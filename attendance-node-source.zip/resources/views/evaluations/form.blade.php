@extends('layouts.app')

@section('page_title', $form->exists ? 'Edit Evaluation' : 'Create Evaluation')

@section('content')
<div style="max-width:1000px;margin:0 auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
        <div><h2>{{ $form->exists ? 'Edit Evaluation Form' : 'Create Evaluation Form' }}</h2><p style="color:var(--text-muted)">Configure the event, eligibility, deadline, and dynamic questions.</p></div>
        <a href="{{ route('evaluations.index') }}" class="btn btn-secondary">Back</a>
    </div>
    @if($errors->any())<div class="alert alert-danger">{{ $errors->first() }}</div>@endif

    @php
        $questions = old('questions');
        if ($questions === null) {
            $questions = $form->exists
                ? $form->questions->map(fn($q) => ['text' => $q->question_text, 'type' => $q->question_type, 'required' => $q->is_required, 'options' => $q->options->pluck('option_text')->all()])->all()
                : [];
        }
    @endphp
    <form method="POST" action="{{ $form->exists ? route('evaluations.update', $form) : route('evaluations.store') }}">
        @csrf
        @if($form->exists) @method('PUT') @endif
        <div class="card"><div class="card-body">
            <div class="form-group">
                <label class="form-label">Evaluation title</label>
                <input class="form-control" name="title" value="{{ old('title', $form->title) }}" required maxlength="255">
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea class="form-control" name="description" rows="3">{{ old('description', $form->description) }}</textarea>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px">
                <div class="form-group">
                    <label class="form-label">Assigned event</label>
                    <select class="form-select" name="event_id" required>
                        <option value="">Select an event</option>
                        @foreach($events as $event)
                            <option value="{{ $event->id }}" @selected(old('event_id', $form->event_id) == $event->id)>{{ $event->name }} ({{ $event->event_date?->format('Y-m-d') }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Submission deadline</label>
                    <input class="form-control" type="datetime-local" name="deadline" value="{{ old('deadline', $form->deadline?->format('Y-m-d\TH:i')) }}">
                </div>
                <div class="form-group">
                    <label class="form-label">Eligible students</label>
                    <select class="form-select" name="eligibility_mode" required>
                        <option value="attended" @selected(old('eligibility_mode', $form->eligibility_mode) === 'attended')>Students with Present attendance</option>
                        <option value="participants" @selected(old('eligibility_mode', $form->eligibility_mode) === 'participants')>Registered event participants</option>
                    </select>
                </div>
            </div>
            <label style="display:flex;align-items:center;gap:8px;margin:8px 0 18px">
                <input type="checkbox" name="allow_resubmission" value="1" @checked(old('allow_resubmission', $form->allow_resubmission))>
                Allow resubmission (each submission is retained in results)
            </label>
        </div></div>

        <div class="card"><div class="card-header"><div class="card-title"><i class="fa-solid fa-list-check"></i> Questions</div><button type="button" class="btn btn-secondary btn-sm" id="addQuestion">Add question</button></div>
            <div class="card-body" id="questionList"></div>
        </div>
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Draft</button>
    </form>
</div>
@endsection

@push('scripts')
<script>
(() => {
    const list = document.getElementById('questionList');
    let questionIndex = 0;
    const typeLabels = {
        multiple_choice: 'Multiple Choice',
        rating: 'Rating Scale (1–5)',
        yes_no: 'Yes or No',
        short_answer: 'Short Answer',
        paragraph: 'Paragraph Answer'
    };

    function addQuestion(data = {}) {
        const index = questionIndex++;
        const card = document.createElement('section');
        card.className = 'card';
        card.style.cssText = 'padding:16px;margin-bottom:12px;border:1px solid var(--card-border)';
        const selectOptions = Object.entries(typeLabels).map(([value, label]) =>
            `<option value="${value}" ${data.type === value ? 'selected' : ''}>${label}</option>`
        ).join('');
        card.innerHTML = `
            <div style="display:flex;justify-content:space-between;gap:12px">
                <strong>Question</strong>
                <button type="button" class="btn btn-danger btn-sm remove-question">Delete</button>
            </div>
            <div class="form-group" style="margin-top:12px">
                <label class="form-label">Question text</label>
                <input class="form-control" name="questions[${index}][text]" maxlength="2000" required>
            </div>
            <div style="display:grid;grid-template-columns:1fr auto;gap:12px;align-items:end">
                <div class="form-group">
                    <label class="form-label">Question type</label>
                    <select class="form-select question-type" name="questions[${index}][type]" required>${selectOptions}</select>
                </div>
                <label style="display:flex;align-items:center;gap:7px;margin-bottom:16px">
                    <input type="checkbox" name="questions[${index}][required]" value="1" ${data.required === false || data.required === 0 ? '' : 'checked'}> Required
                </label>
            </div>
            <div class="options-area"></div>`;
        card.querySelector(`[name="questions[${index}][text]"]`).value = data.text || '';
        card.querySelector('.remove-question').addEventListener('click', () => card.remove());
        const typeSelect = card.querySelector('.question-type');
        const optionsArea = card.querySelector('.options-area');
        const renderOptions = (values = []) => {
            optionsArea.replaceChildren();
            if (typeSelect.value !== 'multiple_choice') return;
            optionsArea.innerHTML = '<label class="form-label">Answer options (at least two)</label>';
            const optionList = document.createElement('div');
            optionList.className = 'option-list';
            optionsArea.appendChild(optionList);
            const addOption = (value = '') => {
                const row = document.createElement('div');
                row.style.cssText = 'display:flex;gap:8px;margin:6px 0';
                row.innerHTML = `<input class="form-control" name="questions[${index}][options][]" maxlength="255" required><button type="button" class="btn btn-secondary btn-sm">Remove</button>`;
                row.querySelector('input').value = value;
                row.querySelector('button').addEventListener('click', () => row.remove());
                optionList.appendChild(row);
            };
            (values.length ? values : ['', '']).forEach(addOption);
            const add = document.createElement('button');
            add.type = 'button';
            add.className = 'btn btn-secondary btn-sm';
            add.textContent = 'Add option';
            add.addEventListener('click', () => addOption());
            optionsArea.appendChild(add);
        };
        typeSelect.addEventListener('change', () => renderOptions());
        renderOptions(data.options || []);
        list.appendChild(card);
    }

    @json($questions).forEach(addQuestion);
    document.getElementById('addQuestion').addEventListener('click', () => addQuestion({type: 'short_answer'}));
    if (!questionIndex) addQuestion({type: 'rating'});
})();
</script>
@endpush
