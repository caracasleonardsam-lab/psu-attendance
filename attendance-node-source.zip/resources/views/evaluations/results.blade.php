@extends('layouts.app')

@section('page_title', 'Evaluation Results')

@section('content')
<div style="display:flex;flex-direction:column;gap:18px">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
        <div><h2>Evaluation Results</h2><p style="color:var(--text-muted)">Review responses for reports opened by a Super Administrator. Student identities are protected.</p></div>
        @if(auth()->user()?->isSuperAdmin())<a href="{{ route('evaluations.index') }}" class="btn btn-secondary">Manage evaluations</a>@endif
    </div>
    <div class="card"><div class="card-body">
        <form method="GET" action="{{ route('evaluations.results') }}" style="display:flex;gap:12px;align-items:end;flex-wrap:wrap">
            <div class="form-group" style="min-width:220px;flex:1;margin:0">
                <label class="form-label">Event</label>
                <select class="form-select" name="event_id">
                    <option value="">All events</option>
                    @foreach($events as $event)<option value="{{ $event->id }}" @selected(request('event_id') == $event->id)>{{ $event->name }}</option>@endforeach
                </select>
            </div>
            <div class="form-group" style="min-width:220px;flex:1;margin:0">
                <label class="form-label">Evaluation</label>
                <select class="form-select" name="evaluation_id">
                    <option value="">All evaluations</option>
                    @foreach($forms as $form)<option value="{{ $form->id }}" @selected(request('evaluation_id') == $form->id)>{{ $form->title }} — {{ $form->event?->name }}</option>@endforeach
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Filter</button>
            @if($canViewStudentIdentities)
                <a class="btn btn-secondary" href="{{ route('evaluations.export', request()->only('event_id', 'evaluation_id')) }}">Export CSV</a>
            @endif
        </form>
    </div></div>

    @if($selectedForm)
        <div class="card"><div class="card-header"><div class="card-title">Average rating by question</div></div>
            <div class="card-body" style="display:flex;gap:12px;flex-wrap:wrap">
                @forelse($selectedForm->questions()->where('question_type', 'rating')->get() as $question)
                    <div class="badge badge-primary">{{ $question->question_text }}: {{ $ratingAverages[$question->id] ?? 0 }} / 5</div>
                @empty <span style="color:var(--text-muted)">No rating questions in this evaluation.</span> @endforelse
            </div>
        </div>
    @endif

    <div class="card">
        <div class="card-header"><div class="card-title">Submitted responses ({{ $responses->total() }})</div></div>
        <div class="card-body" style="display:flex;flex-direction:column;gap:14px">
        @forelse($responses as $response)
            <article style="border:1px solid var(--card-border);border-radius:10px;padding:14px">
                <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">
                    <strong>{{ $canViewStudentIdentities ? ($response->student?->full_name ?? 'Deleted student').' ('.($response->student?->student_id ?? 'N/A').')' : 'Anonymous respondent' }}</strong>
                    <span style="color:var(--text-muted)">{{ $response->form?->title }} · {{ $response->form?->event?->name }}@if($canViewStudentIdentities) · {{ $response->submitted_at?->format('M d, Y h:i A') }}@endif</span>
                </div>
                <div style="margin-top:12px;display:grid;gap:9px">
                    @foreach($response->answers as $answer)
                        <div><strong>{{ $answer->question?->question_text }}</strong><div style="white-space:pre-wrap;color:var(--text-muted)">{{ $answer->option?->option_text ?? $answer->answer_text ?? '—' }}</div></div>
                    @endforeach
                </div>
            </article>
        @empty <div style="padding:24px;text-align:center;color:var(--text-muted)">No responses match these filters.</div> @endforelse
        </div>
    </div>
    {{ $responses->links() }}
</div>
@endsection
