@extends('layouts.app')

@section('page_title', 'Evaluation Management')

@section('content')
<div style="display:flex;flex-direction:column;gap:20px">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
        <div>
            <h2 style="font-size:20px">Digital Evaluation and Feedback Management</h2>
            <p style="color:var(--text-muted);margin-top:4px">Build event evaluation forms and monitor student submissions.</p>
        </div>
        @if(auth()->user()?->isSuperAdmin())
            <a href="{{ route('evaluations.create') }}" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Create Evaluation</a>
        @endif
    </div>

    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    @if($errors->any())<div class="alert alert-danger">{{ $errors->first() }}</div>@endif

    <div class="card">
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Evaluation</th><th>Event</th><th>Status</th><th>Submitted</th><th>Pending</th><th>Deadline</th><th>Actions</th></tr></thead>
                <tbody>
                @forelse($forms as $form)
                    <tr>
                        <td><strong>{{ $form->title }}</strong><div style="font-size:11px;color:var(--text-muted)">{{ $form->questions()->count() }} questions · {{ $form->eligibility_mode === 'attended' ? 'Attendees' : 'Event participants' }}</div></td>
                        <td>{{ $form->event?->name ?? 'Event removed' }}</td>
                        <td><span class="badge {{ $form->is_published ? 'badge-success' : 'badge-neutral' }}">{{ $form->is_published ? 'Published' : 'Draft' }}</span></td>
                        <td>{{ number_format($form->submitted_students_count) }} / {{ number_format($form->eligible_students_count) }}</td>
                        <td>{{ number_format($form->pending_students_count) }}</td>
                        <td>{{ $form->deadline?->format('M d, Y h:i A') ?? 'No deadline' }}</td>
                        <td style="white-space:nowrap">
                            <a class="btn btn-secondary btn-sm" href="{{ route('evaluations.results', ['evaluation_id' => $form->id]) }}">Results</a>
                            @if(auth()->user()?->isSuperAdmin())
                                <a class="btn btn-secondary btn-sm" href="{{ route('evaluations.edit', $form) }}">Edit</a>
                                <form action="{{ route('evaluations.publish', $form) }}" method="POST" style="display:inline">
                                    @csrf
                                    <button class="btn {{ $form->is_published ? 'btn-secondary' : 'btn-primary' }} btn-sm" type="submit">{{ $form->is_published ? 'Unpublish' : 'Publish' }}</button>
                                </form>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">No evaluation forms have been created.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
    {{ $forms->links() }}
</div>
@endsection
