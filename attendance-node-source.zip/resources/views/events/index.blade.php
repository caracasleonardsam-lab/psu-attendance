@extends('layouts.app')

@section('page_title', 'Campus Events & Activities')

@push('styles')
<!-- Leaflet CSS for Interactive Location Pin Placement -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
<style>
    .map-preset-btn {
        background: #f1f5f9;
        border: 1px solid var(--line);
        color: var(--text-main);
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 700;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.15s ease;
        display: inline-flex;
        align-items: center;
        gap: 5px;
    }
    .map-preset-btn:hover, .map-preset-btn.active {
        background: var(--primary);
        color: #ffffff;
        border-color: var(--primary);
    }
    #newEventMap {
        height: 280px;
        width: 100%;
        border-radius: 8px;
        border: 1px solid var(--card-border);
        box-shadow: 0 1px 4px rgba(0,0,0,0.06);
        z-index: 1;
    }
    .custom-drag-pin {
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>
@endpush

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Action & Filter Bar -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-body" style="padding: 18px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;">
            <form action="{{ route('events.index') }}" method="GET" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center; flex: 1;">
                <input 
                    type="text" 
                    name="search" 
                    class="form-control" 
                    placeholder="Search events by title or venue..." 
                    value="{{ request('search') }}"
                    style="max-width: 280px;"
                >
                <select name="status" class="form-select" style="max-width: 160px;" onchange="this.form.submit()">
                    <option value="">All Statuses</option>
                    <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Active</option>
                    <option value="scheduled" {{ request('status') === 'scheduled' ? 'selected' : '' }}>Scheduled</option>
                    <option value="completed" {{ request('status') === 'completed' ? 'selected' : '' }}>Completed</option>
                    <option value="cancelled" {{ request('status') === 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                </select>
                <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
                @if(request()->hasAny(['search', 'status']))
                    <a href="{{ route('events.index') }}" class="btn btn-sm" style="color: var(--text-muted);">Clear</a>
                @endif
            </form>

            <button type="button" class="btn btn-primary" onclick="openNewEventModal()">
                <i class="fa-solid fa-plus"></i> Create New Event
            </button>
        </div>
    </div>

    <!-- Events Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 20px;">
        @forelse($events as $event)
            <div class="card" style="margin-bottom: 0; display: flex; flex-direction: column; justify-content: space-between; transition: transform 0.2s, box-shadow 0.2s;" onmouseenter="this.style.transform='translateY(-2px)'" onmouseleave="this.style.transform='none'">
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                        <span class="badge {{ $event->status === 'active' ? 'badge-success' : ($event->status === 'scheduled' ? 'badge-warning' : 'badge-neutral') }}">
                            {{ ucfirst($event->status) }}
                        </span>
                        <div style="font-size: 11px; color: var(--text-muted); font-weight: 600;">
                            <i class="fa-regular fa-clock"></i> {{ $event->start_time ?? 'TBA' }}
                        </div>
                    </div>

                    <h3 style="font-size: 16px; font-weight: 800; color: var(--text-main); margin-bottom: 6px;">
                        <a href="{{ route('events.show', $event) }}" style="color: inherit; text-decoration: none;">
                            {{ $event->name }}
                        </a>
                    </h3>

                    <p style="font-size: 13px; color: var(--text-muted); line-height: 1.4; margin-bottom: 16px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                        {{ $event->description ?: 'No additional description provided.' }}
                    </p>

                    <div style="display: flex; flex-direction: column; gap: 6px; font-size: 12px; color: var(--text-muted); border-top: 1px solid var(--card-border-subtle); padding-top: 12px;">
                        <div>
                            <i class="fa-regular fa-calendar" style="width: 16px; color: var(--primary);"></i>
                            <strong>Date:</strong> {{ $event->event_date?->format('F d, Y') }}
                        </div>
                        <div>
                            <i class="fa-solid fa-location-dot" style="width: 16px; color: var(--danger);"></i>
                            <strong>Venue:</strong> {{ $event->venue ?? 'Campus Wide' }}
                        </div>
                        <div>
                            <i class="fa-solid fa-users" style="width: 16px; color: var(--gold);"></i>
                            <strong>Organizer:</strong> {{ $event->organizer ?? 'University Admin' }}
                        </div>
                    </div>
                </div>

                <div class="card-footer" style="padding: 12px 20px; background: #f8fafc; border-top: 1px solid var(--card-border-subtle); display: flex; justify-content: space-between; align-items: center;">
                    <a href="{{ route('events.show', $event) }}" class="btn btn-sm btn-primary" style="width: 100%; justify-content: center;">
                        <span>Manage Event & Attendance</span>
                        <i class="fa-solid fa-arrow-right" style="font-size: 11px;"></i>
                    </a>
                </div>
            </div>
        @empty
            <div style="grid-column: 1 / -1; padding: 48px; text-align: center; background: #ffffff; border-radius: var(--radius-md); border: 1px solid var(--card-border);">
                <i class="fa-regular fa-calendar-xmark" style="font-size: 40px; color: var(--text-muted); margin-bottom: 12px; display: block;"></i>
                <h3 style="font-size: 16px; font-weight: 700; color: var(--text-main);">No Events Found</h3>
                <p style="color: var(--text-muted); font-size: 13px; margin-top: 4px;">Click "Create New Event" above to schedule an event and configure geofencing.</p>
            </div>
        @endforelse
    </div>

    <!-- Pagination -->
    <div>
        {{ $events->links() }}
    </div>

</div>

<!-- New Event Modal -->
<div class="modal-overlay" id="newEventModal">
    <div class="modal-container" style="max-width: 780px;">
        <div class="modal-header">
            <h3 class="modal-title">
                <i class="fa-solid fa-calendar-plus" style="color: var(--primary); margin-right: 6px;"></i>
                Schedule New Campus Event
            </h3>
            <button type="button" class="modal-close" onclick="closeNewEventModal()">&times;</button>
        </div>
        <form action="{{ route('events.store') }}" method="POST">
            @csrf
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label" for="ev_name">Event Name *</label>
                    <input type="text" name="name" id="ev_name" class="form-control" placeholder="e.g. University Week 2026 Opening" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="ev_desc">Description</label>
                    <textarea name="description" id="ev_desc" class="form-control" rows="2" placeholder="Brief event briefing..."></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label" for="ev_date">Event Date *</label>
                    <input type="date" name="event_date" id="ev_date" class="form-control" value="{{ date('Y-m-d') }}" required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label" for="ev_start">Start Time</label>
                        <input type="time" name="start_time" id="ev_start" class="form-control" value="08:00">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="ev_end">End Time</label>
                        <input type="time" name="end_time" id="ev_end" class="form-control" value="17:00">
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label" for="ev_venue">Venue Name</label>
                        <input type="text" name="venue" id="ev_venue" class="form-control" placeholder="e.g. Pangasinan State University Gymnasium / Audio-Visual Room">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="ev_organizer">Organizer</label>
                        <input type="text" name="organizer" id="ev_organizer" class="form-control" placeholder="e.g. SSC / DOIT">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="ev_organization">Exclusive Organization</label>
                    <select name="organization_id" id="ev_organization" class="form-select">
                        <option value="">All organizations can attend</option>
                        @foreach($organizations as $organization)
                            <option value="{{ $organization->id }}">{{ $organization->name }}</option>
                        @endforeach
                    </select>
                    <div style="font-size: 11.5px; color: var(--text-muted); margin-top: 4px;">
                        When selected, only members of this organization can join the queue and scan into the event.
                    </div>
                </div>

                <div style="margin-top: 10px; padding: 12px; background: #f8fafc; border-radius: 8px; border: 1px solid var(--line);">
                    <label style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; font-weight: 600; color: var(--text-main); cursor: pointer; margin-bottom: 0;">
                        <input type="checkbox" name="evaluation_enabled" value="1" role="switch">
                        <span>Enable evaluation & e-certificates after the event</span>
                    </label>
                    <div style="font-size: 11.5px; color: var(--text-muted); margin-left: 23px; margin-top: 2px;">
                        When enabled, only students marked Present can submit an evaluation and receive an e-certificate.
                    </div>
                </div>

                <!-- Interactive Venue Location Pin & Geofence Map -->
                <div style="border-top: 1px solid var(--line); padding-top: 16px; margin-top: 10px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 10px;">
                        <div>
                            <div style="font-size: 13px; font-weight: 800; color: var(--primary); text-transform: uppercase; letter-spacing: 0.5px;">
                                <i class="fa-solid fa-map-location-dot"></i> Venue Location & Interactive Geofence Map
                            </div>
                            <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                                📍 <strong>Drag the blue pin</strong> or <strong>click anywhere on the map</strong> to set your event's exact venue location.
                            </div>
                        </div>

                        <!-- Quick Jump Presets -->
                        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                            <button type="button" class="map-preset-btn" onclick="locateAdminPosition()" title="Center pin at your current GPS location">
                                <i class="fa-solid fa-location-crosshairs" style="color: var(--primary);"></i> Locate Me
                            </button>
                            <button type="button" class="map-preset-btn" onclick="setPresetLocation(16.115303, 119.967252, 'Pangasinan State University Alaminos Main Grounds')">
                                <i class="fa-solid fa-building-columns" style="color: var(--gold-dark);"></i> Pangasinan State University Campus
                            </button>
                            <button type="button" class="map-preset-btn" onclick="setPresetLocation(16.148800, 119.984600, 'Pangasinan State University Gymnasium')">
                                <i class="fa-solid fa-dumbbell"></i> Gym
                            </button>
                            <button type="button" class="map-preset-btn" onclick="setPresetLocation(16.147600, 119.985600, 'Audio-Visual Center (AVR)')">
                                <i class="fa-solid fa-video"></i> AVR
                            </button>
                        </div>
                    </div>

                    <!-- Map Container with Coordinate Badge -->
                    <div style="position: relative; margin-bottom: 14px;">
                        <div id="newEventMap"></div>
                        <div id="pinCoordinateBadge" style="position: absolute; bottom: 10px; left: 10px; z-index: 1000; background: rgba(7, 21, 45, 0.88); color: #ffffff; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-family: 'JetBrains Mono', monospace; backdrop-filter: blur(4px); box-shadow: 0 2px 6px rgba(0,0,0,0.3); pointer-events: none;">
                            <i class="fa-solid fa-location-dot" style="color: var(--gold);"></i> Pin: <span id="badgeLatDisplay">16.115303</span>, <span id="badgeLngDisplay">119.967252</span>
                        </div>
                    </div>

                    <!-- Lat, Lng, and Radius Inputs -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1.3fr; gap: 12px; align-items: flex-end;">
                        <div>
                            <label class="form-label" style="font-size: 11.5px; font-weight: 700;">Latitude</label>
                            <input type="number" step="0.000001" name="latitude" id="ev_lat" class="form-control" value="16.115303" oninput="updatePinFromInputs()">
                        </div>
                        <div>
                            <label class="form-label" style="font-size: 11.5px; font-weight: 700;">Longitude</label>
                            <input type="number" step="0.000001" name="longitude" id="ev_lng" class="form-control" value="119.967252" oninput="updatePinFromInputs()">
                        </div>
                        <div>
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                                <label class="form-label" style="font-size: 11.5px; font-weight: 700; margin-bottom: 0;">Geofence Radius</label>
                                <span id="radiusDisplayBadge" style="font-size: 11px; font-weight: 800; color: var(--primary);">100m</span>
                            </div>
                            <div style="display: flex; gap: 6px; align-items: center;">
                                <input type="number" name="radius_meters" id="ev_radius" class="form-control" value="100" min="10" max="5000" oninput="updateRadiusFromInput()">
                                <div style="display: flex; gap: 4px;">
                                    <button type="button" class="map-preset-btn radius-preset" onclick="applyModalRadiusPreset(50, this)">50m</button>
                                    <button type="button" class="map-preset-btn radius-preset active" onclick="applyModalRadiusPreset(100, this)">100m</button>
                                    <button type="button" class="map-preset-btn radius-preset" onclick="applyModalRadiusPreset(200, this)">200m</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Geofence presence enforcement -->
                    <div style="margin-top: 14px; padding: 12px; background: #f8fafc; border-radius: 8px; border: 1px solid var(--line);">
                        <label style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; font-weight: 600; color: var(--text-main); cursor: pointer; margin-bottom: 0;">
                            <input type="checkbox" name="presence_verification" value="1" checked>
                            <span>Enforce GPS Geofence Presence Verification for this Event</span>
                        </label>
                        <div style="font-size: 11.5px; color: var(--text-muted); margin-left: 23px; margin-top: 2px;">
                            Students must first be scanned at the entrance, then confirm location inside this perimeter circle via the Student Mobile App.
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeNewEventModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save & Launch Event</button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<!-- Leaflet JS for Draggable Pin Map -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<script>
    let newEventMap = null;
    let newEventMarker = null;
    let newEventCircle = null;

    function openNewEventModal() {
        document.getElementById('newEventModal').classList.add('active');
        setTimeout(function() {
            initNewEventMap();
        }, 150);
    }

    function closeNewEventModal() {
        document.getElementById('newEventModal').classList.remove('active');
    }

    // Close modal on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const modal = document.getElementById('newEventModal');
            if (modal && modal.classList.contains('active')) {
                closeNewEventModal();
            }
        }
    });

    function initNewEventMap() {
        const mapEl = document.getElementById('newEventMap');
        if (!mapEl) return;

        let lat = parseFloat(document.getElementById('ev_lat').value) || 16.115303;
        let lng = parseFloat(document.getElementById('ev_lng').value) || 119.967252;
        let radius = parseInt(document.getElementById('ev_radius').value, 10) || 100;

        if (!newEventMap) {
            newEventMap = L.map('newEventMap').setView([lat, lng], 17);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; OpenStreetMap contributors | Pangasinan State University'
            }).addTo(newEventMap);

            // Custom Draggable Pin Icon
            const customPinIcon = L.divIcon({
                className: 'custom-drag-pin',
                html: `<div style="width: 36px; height: 36px; border-radius: 50%; background: #1259c3; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 16px; border: 3px solid #ffffff; box-shadow: 0 4px 14px rgba(18, 89, 195, 0.6); cursor: grab;">
                        <i class="fa-solid fa-location-dot"></i>
                       </div>`,
                iconSize: [36, 36],
                iconAnchor: [18, 18],
                popupAnchor: [0, -18]
            });

            // Draggable Marker (Pin)
            newEventMarker = L.marker([lat, lng], {
                draggable: true,
                icon: customPinIcon,
                title: 'Drag me to place your event venue location'
            }).addTo(newEventMap);

            newEventMarker.bindPopup('<strong>Venue Location Pin</strong><br>Drag me anywhere on the map!').openPopup();

            // Geofence Perimeter Circle Overlay
            newEventCircle = L.circle([lat, lng], {
                radius: radius,
                color: '#1259c3',
                fillColor: '#1259c3',
                fillOpacity: 0.15,
                weight: 2,
                dashArray: '5, 5'
            }).addTo(newEventMap);

            // Handle Pin Drag
            newEventMarker.on('drag', function(e) {
                const pos = e.target.getLatLng();
                newEventCircle.setLatLng(pos);
                syncCoordinates(pos.lat, pos.lng);
            });

            newEventMarker.on('dragend', function(e) {
                const pos = e.target.getLatLng();
                newEventCircle.setLatLng(pos);
                syncCoordinates(pos.lat, pos.lng);
                newEventMarker.setPopupContent(`<strong>Venue Pin Placed!</strong><br>Lat: ${pos.lat.toFixed(6)}<br>Lng: ${pos.lng.toFixed(6)}`).openPopup();
            });

            // Handle Click anywhere on map to move pin
            newEventMap.on('click', function(e) {
                const clickedLat = e.latlng.lat;
                const clickedLng = e.latlng.lng;
                newEventMarker.setLatLng([clickedLat, clickedLng]);
                newEventCircle.setLatLng([clickedLat, clickedLng]);
                syncCoordinates(clickedLat, clickedLng);
                newEventMarker.setPopupContent(`<strong>Venue Pin Moved!</strong><br>Lat: ${clickedLat.toFixed(6)}<br>Lng: ${clickedLng.toFixed(6)}`).openPopup();
            });
        } else {
            newEventMap.invalidateSize();
        }
    }

    function syncCoordinates(lat, lng) {
        document.getElementById('ev_lat').value = lat.toFixed(6);
        document.getElementById('ev_lng').value = lng.toFixed(6);
        const bLat = document.getElementById('badgeLatDisplay');
        const bLng = document.getElementById('badgeLngDisplay');
        if (bLat) bLat.textContent = lat.toFixed(6);
        if (bLng) bLng.textContent = lng.toFixed(6);
    }

    function updatePinFromInputs() {
        const lat = parseFloat(document.getElementById('ev_lat').value);
        const lng = parseFloat(document.getElementById('ev_lng').value);

        if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
            if (newEventMarker) newEventMarker.setLatLng([lat, lng]);
            if (newEventCircle) newEventCircle.setLatLng([lat, lng]);
            if (newEventMap) newEventMap.panTo([lat, lng]);
            const bLat = document.getElementById('badgeLatDisplay');
            const bLng = document.getElementById('badgeLngDisplay');
            if (bLat) bLat.textContent = lat.toFixed(6);
            if (bLng) bLng.textContent = lng.toFixed(6);
        }
    }

    function updateRadiusFromInput() {
        const radius = parseInt(document.getElementById('ev_radius').value, 10);
        if (!isNaN(radius) && radius >= 10 && radius <= 5000) {
            if (newEventCircle) newEventCircle.setRadius(radius);
            const badge = document.getElementById('radiusDisplayBadge');
            if (badge) badge.textContent = radius + 'm';
        }
    }

    function applyModalRadiusPreset(radius, btn) {
        document.getElementById('ev_radius').value = radius;
        updateRadiusFromInput();
        document.querySelectorAll('.radius-preset').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
    }

    function setPresetLocation(lat, lng, name) {
        syncCoordinates(lat, lng);
        if (newEventMarker) newEventMarker.setLatLng([lat, lng]);
        if (newEventCircle) newEventCircle.setLatLng([lat, lng]);
        if (newEventMap) newEventMap.setView([lat, lng], 18);
        if (newEventMarker) {
            newEventMarker.setPopupContent(`<strong>${name}</strong><br>Lat: ${lat.toFixed(6)}<br>Lng: ${lng.toFixed(6)}`).openPopup();
        }
        const venueInput = document.getElementById('ev_venue');
        if (venueInput && (!venueInput.value || venueInput.value.trim() === '')) {
            venueInput.value = name;
        }
    }

    function locateAdminPosition() {
        if (!navigator.geolocation) {
            alert('Geolocation is not supported by your browser.');
            return;
        }

        navigator.geolocation.getCurrentPosition(
            function(position) {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                setPresetLocation(lat, lng, 'Your Current Location');
            },
            function(err) {
                alert('Could not determine your GPS location: ' + err.message);
            },
            { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
        );
    }
</script>
@endpush
@endsection
