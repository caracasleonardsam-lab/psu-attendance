@extends('layouts.app')

@section('page_title', $event->name)

@push('styles')
<!-- Leaflet CSS for Interactive Location Pin Placement -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
<style>
    .map-preset-btn {
        background: #f1f5f9;
        border: 1px solid var(--line);
        color: var(--text-main);
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 700;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.15s ease;
        display: inline-flex;
        align-items: center;
        gap: 5px;
    }
    .map-preset-btn:hover, .map-preset-btn.active {
        background: var(--primary);
        color: #ffffff;
        border-color: var(--primary);
    }
    #editEventMap {
        height: 280px;
        width: 100%;
        border-radius: 8px;
        border: 1px solid var(--card-border);
        box-shadow: 0 1px 4px rgba(0,0,0,0.06);
        z-index: 1;
    }
    .custom-drag-pin {
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>
@endpush

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Back Navigation & Actions -->
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
        <a href="{{ route('events.index') }}" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-arrow-left"></i> Back to Events
        </a>

        <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
            @if($event->scanning_enabled)
                <a href="{{ route('attendance.scanner', ['event_id' => $event->id]) }}" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-barcode"></i> Launch Live Scanner
                </a>
            @endif
            @if(auth()->user()?->isAdmin() && in_array($event->status, ['scheduled', 'active'], true))
                @if($event->scanning_enabled)
                    <form action="{{ route('events.scanning.update', $event) }}" method="POST">
                        @csrf
                        <input type="hidden" name="action" value="pause">
                        <button type="submit" class="btn btn-secondary btn-sm">
                            <i class="fa-solid fa-pause"></i> Pause Scanning
                        </button>
                    </form>
                @else
                    <form action="{{ route('events.scanning.update', $event) }}" method="POST">
                        @csrf
                        <input type="hidden" name="action" value="start">
                        <button type="submit" class="btn btn-success btn-sm"
                                title="Start attendance scanning at any time">
                            <i class="fa-solid fa-play"></i> Start Scanning Now
                        </button>
                    </form>
                @endif
            @endif
            <a href="{{ route('presence.index', ['event_id' => $event->id]) }}" class="btn btn-secondary btn-sm" title="Calibrate Geofence Perimeter">
                <i class="fa-solid fa-location-crosshairs" style="color: var(--danger);"></i> Geofence ({{ $event->radius_meters }}m)
            </a>
            <a href="{{ route('events.certificate.setup', $event) }}" class="btn btn-gold btn-sm">
                <i class="fa-solid fa-award"></i> E-Certificate
            </a>
            @if(auth()->user()?->isSuperAdmin())
                <form action="{{ route('events.evaluation_report_visibility', $event) }}" method="POST" style="display:inline-flex;align-items:center;gap:6px">
                    @csrf
                    <input type="hidden" name="evaluation_results_visible" value="0">
                    <label class="btn btn-sm {{ $event->evaluation_results_visible ? 'btn-success' : 'btn-secondary' }}" style="margin:0;cursor:pointer">
                        <input type="checkbox" name="evaluation_results_visible" value="1" {{ $event->evaluation_results_visible ? 'checked' : '' }}>
                        {{ $event->evaluation_results_visible ? 'Evaluation Report Open' : 'Open Evaluation Report' }}
                    </label>
                    <button type="submit" class="btn btn-secondary btn-sm">Save</button>
                </form>
            @elseif($event->evaluation_results_visible && auth()->user()?->isAdmin())
                <a href="{{ route('events.evaluations', $event) }}" class="btn btn-secondary btn-sm">Evaluation Report</a>
            @endif
            <button type="button" class="btn btn-secondary btn-sm" onclick="openEditEventModal()">
                <i class="fa-solid fa-pen"></i> Edit
            </button>
            @if(auth()->user()?->isAdmin() && in_array($event->status, ['scheduled', 'active', 'cancelled'], true))
                <button type="button" class="btn btn-secondary btn-sm" onclick="openRescheduleEventModal()">
                    <i class="fa-regular fa-calendar"></i> Reschedule
                </button>
            @endif
            @if(auth()->user()?->isAdmin() && in_array($event->status, ['scheduled', 'active'], true))
                <form action="{{ route('events.cancel', $event) }}" method="POST" onsubmit="return confirm('Cancel this event? Scanning will stop, but existing attendance records will be kept.');">
                    @csrf
                    <button type="submit" class="btn btn-danger btn-sm">
                        <i class="fa-solid fa-ban"></i> Cancel Event
                    </button>
                </form>
            @endif
            <form action="{{ route('events.destroy', $event) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this event and its attendance logs?')" style="display: inline;">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-sm" style="color: var(--danger); background: transparent;" title="Delete Event">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </form>
        </div>
    </div>

    <!-- Event Summary Card -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-body">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 14px; margin-bottom: 16px;">
                <div>
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
                        <h2 style="font-size: 22px; font-weight: 800; color: var(--text-main);">{{ $event->name }}</h2>
                        <span class="badge {{ $event->status === 'active' ? 'badge-success' : ($event->status === 'scheduled' ? 'badge-warning' : 'badge-neutral') }}">
                            {{ ucfirst($event->status) }}
                        </span>
                        <span class="badge {{ $event->scanning_enabled ? 'badge-success' : 'badge-neutral' }}">
                            Scanning {{ $event->scanning_enabled ? 'ON' : 'OFF' }}
                        </span>
                    </div>
                    @if($errors->has('scanning'))
                        <div role="alert" style="margin: 8px 0; color: var(--danger); font-size: 13px;">
                            {{ $errors->first('scanning') }}
                        </div>
                    @endif
                    @if($errors->has('event'))
                        <div role="alert" style="margin: 8px 0; color: var(--danger); font-size: 13px;">
                            {{ $errors->first('event') }}
                        </div>
                    @endif
                    <p style="color: var(--text-muted); font-size: 14px; max-width: 700px;">
                        {{ $event->description ?: 'No detailed description specified.' }}
                    </p>
                </div>

                <!-- Stats summary -->
                <div style="display: flex; gap: 16px; background: #f8fafc; padding: 14px 20px; border-radius: var(--radius-sm); border: 1px solid var(--line);">
                    <div style="text-align: center;">
                        <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Total Scans</div>
                        <div style="font-size: 22px; font-weight: 800; color: var(--primary);">{{ $attendeesCount }}</div>
                    </div>
                    <div style="width: 1px; background: var(--line);"></div>
                    <div style="text-align: center;">
                        <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Present</div>
                        <div style="font-size: 22px; font-weight: 800; color: var(--success);">{{ $presentCount }}</div>
                    </div>
                    <div style="width: 1px; background: var(--line);"></div>
                    <div style="text-align: center;">
                        <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Late</div>
                        <div style="font-size: 22px; font-weight: 800; color: var(--warning);">{{ $lateCount }}</div>
                    </div>
                </div>
            </div>

            <!-- Parameters Grid -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; padding-top: 16px; border-top: 1px solid var(--card-border-subtle); font-size: 13px;">
                <div>
                    <span style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; display: block;">Date & Time</span>
                    <strong>{{ $event->event_date?->format('F d, Y') }}</strong> ({{ $event->start_time ?? '08:00' }} - {{ $event->end_time ?? '17:00' }})
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; display: block;">Venue</span>
                    <strong>{{ $event->venue ?? 'Campus Wide' }}</strong>
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; display: block;">Organizer</span>
                    <strong>{{ $event->organizer ?? 'Admin' }}</strong>
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; display: block;">Organization Access</span>
                    <strong>{{ $event->organization?->name ?? 'Open to all organizations' }}</strong>
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 11px; text-transform: uppercase; display: block;">Geofence Radius</span>
                    <strong>{{ $event->radius_meters }}m</strong> (Lat: {{ $event->latitude }}, Lng: {{ $event->longitude }})
                </div>
            </div>
        </div>
    </div>

    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-user-tag" style="color: var(--primary);"></i>
                <span>Student Designations ({{ $event->studentDesignations->count() }})</span>
            </div>
        </div>
        <div class="card-body">
            <form id="designationAssignForm" action="{{ route('events.designations.assign', $event) }}" method="POST" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; align-items: start; margin-bottom: 18px;">
                @csrf
                <div>
                    <input type="hidden" name="student_id" id="designationStudentId">
                    <input type="text" id="designationStudentSearch" class="form-control" placeholder="Search student by name or ID..." autocomplete="off" required>
                    <div id="designationStudentResults" style="display: none; position: relative; z-index: 5; background: white; border: 1px solid var(--line); border-radius: 8px; max-height: 220px; overflow-y: auto;"></div>
                    <div id="designationStudentSelected" style="font-size: 12px; color: var(--success-dark); margin-top: 5px;"></div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-top: 5px;">Designated students still scan in at the entrance, but do not need geofence checks.</div>
                </div>
                <input type="text" name="designation" class="form-control" placeholder="Designation (e.g. Marshal)" maxlength="150" required>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Assign</button>
            </form>

            @if($event->studentDesignations->isEmpty())
                <div style="font-size: 13px; color: var(--text-muted);">No student designations have been assigned to this event.</div>
            @else
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Program</th>
                                <th>Year / Block</th>
                                <th>Designation</th>
                                <th style="text-align: right;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($event->studentDesignations as $designation)
                                <tr>
                                    <td>
                                        <strong>{{ $designation->student?->full_name ?? 'Student unavailable' }}</strong>
                                        <div style="font-size: 11px; color: var(--text-muted);">{{ $designation->student?->student_id }}</div>
                                    </td>
                                    <td>{{ $designation->student?->program?->name ?? 'N/A' }}</td>
                                    <td>{{ $designation->student?->year_level ?? 'N/A' }}{{ $designation->student?->block ? ' / ' . $designation->student->block : '' }}</td>
                                    <td><span class="badge badge-primary">{{ $designation->designation }}</span></td>
                                    <td style="text-align: right;">
                                        <form action="{{ route('events.designations.remove', [$event, $designation]) }}" method="POST" onsubmit="return confirm('Remove this event designation?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm" style="color: var(--danger); background: transparent;" title="Remove designation">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>

    <!-- Attendance Roster Table -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-users" style="color: var(--primary);"></i>
                <span>Registered Attendees ({{ $attendeesCount }})</span>
            </div>
            <a href="{{ route('events.export', $event) }}" class="btn btn-sm btn-secondary">
                <i class="fa-solid fa-file-csv"></i> Download CSV
            </a>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student ID</th>
                        <th>Full Name</th>
                        <th>Program</th>
                        <th>Organization</th>
                        <th>Designation</th>
                        <th>Status</th>
                        <th>Check-in Time</th>
                        <th>Scanned By</th>
                        <th style="text-align: right;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($event->attendances as $idx => $att)
                        <tr>
                            <td>{{ $idx + 1 }}</td>
                            <td style="font-family: 'JetBrains Mono', monospace; font-weight: 700;">{{ $att->student?->student_id }}</td>
                            <td style="font-weight: 700;">{{ $att->student?->full_name }}</td>
                            <td><span class="badge badge-primary">{{ $att->student?->program?->name ?? 'N/A' }}</span></td>
                            <td><span class="badge badge-neutral">{{ $att->student?->organization?->name ?? 'N/A' }}</span></td>
                            <td>{{ $event->studentDesignations->firstWhere('student_id', $att->student_id)?->designation ?? '—' }}</td>
                            <td>
                                <span class="badge {{ $att->status === 'present' ? 'badge-success' : 'badge-warning' }}">
                                    {{ strtoupper($att->status) }}
                                </span>
                            </td>
                            <td style="font-size: 12px; color: var(--text-muted); font-weight: 600;" title="{{ $att->scanned_at?->format('M d, Y h:i:s A') }}">{{ $att->scanned_at?->format('h:i:s A') }}</td>
                            <td style="font-size: 12px; color: var(--text-muted);">{{ $att->scanned_by ?? 'Barcode Scanner' }}</td>
                            <td style="text-align: right;">
                                <form action="{{ route('attendance.destroy', $att) }}" method="POST" onsubmit="return confirm('Remove this attendance record?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm" style="color: var(--danger); background: transparent;" title="Delete">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="10" style="text-align: center; color: var(--text-muted); padding: 32px;">
                                No attendance recorded for this event yet.
                                @if($event->scanning_enabled)
                                    <br><a href="{{ route('attendance.scanner', ['event_id' => $event->id]) }}" class="btn btn-primary btn-sm" style="margin-top: 10px;">
                                        Open Scanner
                                    </a>
                                @endif
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
    const designationSearch = document.getElementById('designationStudentSearch');
    const designationResults = document.getElementById('designationStudentResults');
    const designationStudentId = document.getElementById('designationStudentId');
    const designationSelected = document.getElementById('designationStudentSelected');
    const designationForm = document.getElementById('designationAssignForm');
    let designationSearchTimer;

    designationSearch.addEventListener('input', () => {
        designationStudentId.value = '';
        designationSelected.textContent = '';
        clearTimeout(designationSearchTimer);
        const query = designationSearch.value.trim();
        if (query.length < 2) {
            designationResults.style.display = 'none';
            return;
        }

        designationSearchTimer = setTimeout(async () => {
            try {
                const response = await fetch(`{{ route('attendance.search_students') }}?q=${encodeURIComponent(query)}`, {
                    headers: { 'Accept': 'application/json' }
                });
                if (!response.ok) {
                    throw new Error('Unable to search students.');
                }
                const students = await response.json();
                designationResults.replaceChildren();
                students.forEach(student => {
                    const option = document.createElement('button');
                    option.type = 'button';
                    option.textContent = `${student.full_name} (${student.student_id})`;
                    option.style.cssText = 'display:block;width:100%;padding:9px 12px;text-align:left;background:white;border:0;border-bottom:1px solid var(--line);cursor:pointer;';
                    option.addEventListener('click', () => {
                        designationStudentId.value = student.id;
                        designationSearch.value = option.textContent;
                        designationSelected.textContent = `${student.program} · ${student.year_level}`;
                        designationSelected.style.color = 'var(--success-dark)';
                        designationResults.style.display = 'none';
                    });
                    designationResults.appendChild(option);
                });
                if (!students.length) {
                    const empty = document.createElement('div');
                    empty.textContent = 'No matching students found.';
                    empty.style.cssText = 'padding:9px 12px;color:var(--text-muted);font-size:12px;';
                    designationResults.appendChild(empty);
                }
                designationResults.style.display = 'block';
            } catch (error) {
                designationResults.replaceChildren();
                const failure = document.createElement('div');
                failure.textContent = 'Student search failed. Please try again.';
                failure.style.cssText = 'padding:9px 12px;color:var(--danger);font-size:12px;';
                designationResults.appendChild(failure);
                designationResults.style.display = 'block';
            }
        }, 200);
    });

    designationForm.addEventListener('submit', event => {
        if (!designationStudentId.value) {
            event.preventDefault();
            designationSelected.textContent = 'Select a student from the search results.';
            designationSelected.style.color = 'var(--danger)';
            designationSearch.focus();
        }
    });
</script>

<!-- Edit Event Modal -->
<div class="modal-overlay" id="editEventModal">
    <div class="modal-container" style="max-width: 780px;">
        <div class="modal-header">
            <h3 class="modal-title">
                <i class="fa-solid fa-pen-to-square" style="color: var(--primary); margin-right: 6px;"></i>
                Edit Event Settings
            </h3>
            <button type="button" class="modal-close" onclick="closeEditEventModal()">&times;</button>
        </div>
        <form action="{{ route('events.update', $event) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Event Name *</label>
                    <input type="text" name="name" class="form-control" value="{{ $event->name }}" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="2">{{ $event->description }}</textarea>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label">Event Date *</label>
                        <input type="date" name="event_date" class="form-control" value="{{ $event->event_date?->format('Y-m-d') }}" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="active" {{ $event->status === 'active' ? 'selected' : '' }}>Active</option>
                            <option value="scheduled" {{ $event->status === 'scheduled' ? 'selected' : '' }}>Scheduled</option>
                            <option value="completed" {{ $event->status === 'completed' ? 'selected' : '' }}>Completed</option>
                            <option value="cancelled" {{ $event->status === 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                        </select>
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label">Venue Name</label>
                        <input type="text" name="venue" id="edit_ev_venue" class="form-control" value="{{ $event->venue }}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Organizer</label>
                        <input type="text" name="organizer" class="form-control" value="{{ $event->organizer }}">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="edit_ev_organization">Exclusive Organization</label>
                    <select name="organization_id" id="edit_ev_organization" class="form-select">
                        <option value="">All organizations can attend</option>
                        @foreach($organizations as $organization)
                            <option value="{{ $organization->id }}" {{ $event->organization_id === $organization->id ? 'selected' : '' }}>
                                {{ $organization->name }}
                            </option>
                        @endforeach
                    </select>
                    <div style="font-size: 11.5px; color: var(--text-muted); margin-top: 4px;">
                        Only members of the selected organization can queue or scan into this event.
                    </div>
                </div>

                <!-- Interactive Venue Location Pin & Geofence Map -->
                <div style="border-top: 1px solid var(--line); padding-top: 16px; margin-top: 10px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 10px;">
                        <div>
                            <div style="font-size: 13px; font-weight: 800; color: var(--primary); text-transform: uppercase; letter-spacing: 0.5px;">
                                <i class="fa-solid fa-map-location-dot"></i> Venue Location & Geofence Calibration
                            </div>
                            <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
                                📍 <strong>Drag the blue pin</strong> or <strong>click anywhere on the map</strong> to reposition this event's venue.
                            </div>
                        </div>

                        <!-- Quick Jump Presets -->
                        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                            <button type="button" class="map-preset-btn" onclick="locateAdminPositionEdit()" title="Center pin at your current GPS location">
                                <i class="fa-solid fa-location-crosshairs" style="color: var(--primary);"></i> Locate Me
                            </button>
                            <button type="button" class="map-preset-btn" onclick="setPresetLocationEdit(16.115303, 119.967252, 'Pangasinan State University Alaminos Main Grounds')">
                                <i class="fa-solid fa-building-columns" style="color: var(--gold-dark);"></i> Pangasinan State University Campus
                            </button>
                            <button type="button" class="map-preset-btn" onclick="setPresetLocationEdit(16.148800, 119.984600, 'Pangasinan State University Gymnasium')">
                                <i class="fa-solid fa-dumbbell"></i> Gym
                            </button>
                            <button type="button" class="map-preset-btn" onclick="setPresetLocationEdit(16.147600, 119.985600, 'Audio-Visual Center (AVR)')">
                                <i class="fa-solid fa-video"></i> AVR
                            </button>
                        </div>
                    </div>

                    <!-- Map Container with Coordinate Badge -->
                    <div style="position: relative; margin-bottom: 14px;">
                        <div id="editEventMap"></div>
                        <div id="editPinCoordinateBadge" style="position: absolute; bottom: 10px; left: 10px; z-index: 1000; background: rgba(7, 21, 45, 0.88); color: #ffffff; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-family: 'JetBrains Mono', monospace; backdrop-filter: blur(4px); box-shadow: 0 2px 6px rgba(0,0,0,0.3); pointer-events: none;">
                            <i class="fa-solid fa-location-dot" style="color: var(--gold);"></i> Pin: <span id="editBadgeLatDisplay">{{ number_format($event->latitude ?? 16.115303, 6, '.', '') }}</span>, <span id="editBadgeLngDisplay">{{ number_format($event->longitude ?? 119.967252, 6, '.', '') }}</span>
                        </div>
                    </div>

                    <!-- Lat, Lng, and Radius Inputs -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1.3fr; gap: 12px; align-items: flex-end;">
                        <div>
                            <label class="form-label" style="font-size: 11.5px; font-weight: 700;">Latitude</label>
                            <input type="number" step="0.000001" name="latitude" id="edit_ev_lat" class="form-control" value="{{ number_format($event->latitude ?? 16.115303, 6, '.', '') }}" oninput="updateEditPinFromInputs()">
                        </div>
                        <div>
                            <label class="form-label" style="font-size: 11.5px; font-weight: 700;">Longitude</label>
                            <input type="number" step="0.000001" name="longitude" id="edit_ev_lng" class="form-control" value="{{ number_format($event->longitude ?? 119.967252, 6, '.', '') }}" oninput="updateEditPinFromInputs()">
                        </div>
                        <div>
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                                <label class="form-label" style="font-size: 11.5px; font-weight: 700; margin-bottom: 0;">Geofence Radius</label>
                                <span id="editRadiusDisplayBadge" style="font-size: 11px; font-weight: 800; color: var(--primary);">{{ $event->radius_meters ?? 100 }}m</span>
                            </div>
                            <div style="display: flex; gap: 6px; align-items: center;">
                                <input type="number" name="radius_meters" id="edit_ev_radius" class="form-control" value="{{ $event->radius_meters ?? 100 }}" min="10" max="5000" oninput="updateEditRadiusFromInput()">
                                <div style="display: flex; gap: 4px;">
                                    <button type="button" class="map-preset-btn edit-radius-preset {{ ($event->radius_meters ?? 100) == 50 ? 'active' : '' }}" onclick="applyEditRadiusPreset(50, this)">50m</button>
                                    <button type="button" class="map-preset-btn edit-radius-preset {{ ($event->radius_meters ?? 100) == 100 ? 'active' : '' }}" onclick="applyEditRadiusPreset(100, this)">100m</button>
                                    <button type="button" class="map-preset-btn edit-radius-preset {{ ($event->radius_meters ?? 100) == 200 ? 'active' : '' }}" onclick="applyEditRadiusPreset(200, this)">200m</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Geofence presence enforcement -->
                    <div style="margin-top: 14px; padding: 12px; background: #f8fafc; border-radius: 8px; border: 1px solid var(--line);">
                        <label style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; font-weight: 600; color: var(--text-main); cursor: pointer; margin-bottom: 0;">
                            <input type="checkbox" name="presence_verification" id="ev_presence" value="1" {{ $event->presence_verification ? 'checked' : '' }}>
                            <span>Enforce GPS Geofence Presence Verification for Check-in</span>
                        </label>
                        <div style="font-size: 11.5px; color: var(--text-muted); margin-left: 23px; margin-top: 2px;">
                            Students must first be scanned at the entrance, then confirm location inside this perimeter circle via the Student Mobile App.
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEditEventModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Update Event</button>
            </div>
        </form>
    </div>
</div>

<!-- Reschedule Event Modal -->
<div class="modal-overlay" id="rescheduleEventModal">
    <div class="modal-container" style="max-width: 480px;">
        <div class="modal-header">
            <h3 class="modal-title">
                <i class="fa-regular fa-calendar" style="color: var(--primary); margin-right: 6px;"></i>
                Reschedule Event
            </h3>
            <button type="button" class="modal-close" onclick="closeRescheduleEventModal()">&times;</button>
        </div>
        <form action="{{ route('events.reschedule', $event) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label" for="reschedule_event_date">New Event Date *</label>
                    <input
                        type="date"
                        name="event_date"
                        id="reschedule_event_date"
                        class="form-control"
                        value="{{ max($event->event_date?->format('Y-m-d') ?? '', now()->addDay()->toDateString()) }}"
                        min="{{ now()->addDay()->toDateString() }}"
                        required
                    >
                </div>
                <p style="font-size: 12px; color: var(--text-muted); margin: 0;">
                    Scanning will be turned off and the event will return to Scheduled. Existing attendance records will be kept.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeRescheduleEventModal()">Keep Current Date</button>
                <button type="submit" class="btn btn-primary">Save New Date</button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<!-- Leaflet JS for Draggable Pin Map -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<script>
    let editEventMap = null;
    let editEventMarker = null;
    let editEventCircle = null;

    function openEditEventModal() {
        document.getElementById('editEventModal').classList.add('active');
        setTimeout(function() {
            initEditEventMap();
        }, 150);
    }

    function closeEditEventModal() {
        document.getElementById('editEventModal').classList.remove('active');
    }

    function openRescheduleEventModal() {
        document.getElementById('rescheduleEventModal').classList.add('active');
    }

    function closeRescheduleEventModal() {
        document.getElementById('rescheduleEventModal').classList.remove('active');
    }

    // Close modal on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const modal = document.getElementById('editEventModal');
            if (modal && modal.classList.contains('active')) {
                closeEditEventModal();
            }
            const rescheduleModal = document.getElementById('rescheduleEventModal');
            if (rescheduleModal && rescheduleModal.classList.contains('active')) {
                closeRescheduleEventModal();
            }
        }
    });

    function initEditEventMap() {
        const mapEl = document.getElementById('editEventMap');
        if (!mapEl) return;

        let lat = parseFloat(document.getElementById('edit_ev_lat').value) || 16.115303;
        let lng = parseFloat(document.getElementById('edit_ev_lng').value) || 119.967252;
        let radius = parseInt(document.getElementById('edit_ev_radius').value, 10) || 100;

        if (!editEventMap) {
            editEventMap = L.map('editEventMap').setView([lat, lng], 17);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; OpenStreetMap contributors | Pangasinan State University'
            }).addTo(editEventMap);

            // Custom Draggable Pin Icon
            const customPinIcon = L.divIcon({
                className: 'custom-drag-pin',
                html: `<div style="width: 36px; height: 36px; border-radius: 50%; background: #1259c3; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 16px; border: 3px solid #ffffff; box-shadow: 0 4px 14px rgba(18, 89, 195, 0.6); cursor: grab;">
                        <i class="fa-solid fa-location-dot"></i>
                       </div>`,
                iconSize: [36, 36],
                iconAnchor: [18, 18],
                popupAnchor: [0, -18]
            });

            // Draggable Marker (Pin)
            editEventMarker = L.marker([lat, lng], {
                draggable: true,
                icon: customPinIcon,
                title: 'Drag me to adjust event venue location'
            }).addTo(editEventMap);

            editEventMarker.bindPopup('<strong>Current Venue Location</strong><br>Drag me anywhere on the map!').openPopup();

            // Geofence Perimeter Circle Overlay
            editEventCircle = L.circle([lat, lng], {
                radius: radius,
                color: '#1259c3',
                fillColor: '#1259c3',
                fillOpacity: 0.15,
                weight: 2,
                dashArray: '5, 5'
            }).addTo(editEventMap);

            // Handle Pin Drag
            editEventMarker.on('drag', function(e) {
                const pos = e.target.getLatLng();
                editEventCircle.setLatLng(pos);
                syncEditCoordinates(pos.lat, pos.lng);
            });

            editEventMarker.on('dragend', function(e) {
                const pos = e.target.getLatLng();
                editEventCircle.setLatLng(pos);
                syncEditCoordinates(pos.lat, pos.lng);
                editEventMarker.setPopupContent(`<strong>Venue Pin Repositioned!</strong><br>Lat: ${pos.lat.toFixed(6)}<br>Lng: ${pos.lng.toFixed(6)}`).openPopup();
            });

            // Handle Click anywhere on map to move pin
            editEventMap.on('click', function(e) {
                const clickedLat = e.latlng.lat;
                const clickedLng = e.latlng.lng;
                editEventMarker.setLatLng([clickedLat, clickedLng]);
                editEventCircle.setLatLng([clickedLat, clickedLng]);
                syncEditCoordinates(clickedLat, clickedLng);
                editEventMarker.setPopupContent(`<strong>Venue Pin Moved!</strong><br>Lat: ${clickedLat.toFixed(6)}<br>Lng: ${clickedLng.toFixed(6)}`).openPopup();
            });
        } else {
            editEventMap.invalidateSize();
        }
    }

    function syncEditCoordinates(lat, lng) {
        document.getElementById('edit_ev_lat').value = lat.toFixed(6);
        document.getElementById('edit_ev_lng').value = lng.toFixed(6);
        const bLat = document.getElementById('editBadgeLatDisplay');
        const bLng = document.getElementById('editBadgeLngDisplay');
        if (bLat) bLat.textContent = lat.toFixed(6);
        if (bLng) bLng.textContent = lng.toFixed(6);
    }

    function updateEditPinFromInputs() {
        const lat = parseFloat(document.getElementById('edit_ev_lat').value);
        const lng = parseFloat(document.getElementById('edit_ev_lng').value);

        if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
            if (editEventMarker) editEventMarker.setLatLng([lat, lng]);
            if (editEventCircle) editEventCircle.setLatLng([lat, lng]);
            if (editEventMap) editEventMap.panTo([lat, lng]);
            const bLat = document.getElementById('editBadgeLatDisplay');
            const bLng = document.getElementById('editBadgeLngDisplay');
            if (bLat) bLat.textContent = lat.toFixed(6);
            if (bLng) bLng.textContent = lng.toFixed(6);
        }
    }

    function updateEditRadiusFromInput() {
        const radius = parseInt(document.getElementById('edit_ev_radius').value, 10);
        if (!isNaN(radius) && radius >= 10 && radius <= 5000) {
            if (editEventCircle) editEventCircle.setRadius(radius);
            const badge = document.getElementById('editRadiusDisplayBadge');
            if (badge) badge.textContent = radius + 'm';
        }
    }

    function applyEditRadiusPreset(radius, btn) {
        document.getElementById('edit_ev_radius').value = radius;
        updateEditRadiusFromInput();
        document.querySelectorAll('.edit-radius-preset').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
    }

    function setPresetLocationEdit(lat, lng, name) {
        syncEditCoordinates(lat, lng);
        if (editEventMarker) editEventMarker.setLatLng([lat, lng]);
        if (editEventCircle) editEventCircle.setLatLng([lat, lng]);
        if (editEventMap) editEventMap.setView([lat, lng], 18);
        if (editEventMarker) {
            editEventMarker.setPopupContent(`<strong>${name}</strong><br>Lat: ${lat.toFixed(6)}<br>Lng: ${lng.toFixed(6)}`).openPopup();
        }
        const venueInput = document.getElementById('edit_ev_venue');
        if (venueInput && (!venueInput.value || venueInput.value.trim() === '')) {
            venueInput.value = name;
        }
    }

    function locateAdminPositionEdit() {
        if (!navigator.geolocation) {
            alert('Geolocation is not supported by your browser.');
            return;
        }

        navigator.geolocation.getCurrentPosition(
            function(position) {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                setPresetLocationEdit(lat, lng, 'Your Current Location');
            },
            function(err) {
                alert('Could not determine your GPS location: ' + err.message);
            },
            { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
        );
    }
</script>
@endpush
@endsection
