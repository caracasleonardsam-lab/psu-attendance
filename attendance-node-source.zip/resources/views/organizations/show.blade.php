@extends('layouts.app')

@section('page_title', $organization->name)

@section('content')
<div style="display: flex; flex-direction: column; gap: 20px;">
    <a href="{{ route('organizations.index') }}" class="btn btn-secondary btn-sm" style="align-self: flex-start;">
        <i class="fa-solid fa-arrow-left"></i> All Organizations
    </a>

    @if($errors->any())
        <div role="alert" class="card" style="margin: 0; border-color: var(--danger);">
            <div class="card-body" style="color: var(--danger);">
                @foreach($errors->all() as $error)
                    <div>{{ $error }}</div>
                @endforeach
            </div>
        </div>
    @endif

    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-sitemap" style="color: var(--primary);"></i>
                <span>Organization Details</span>
            </div>
        </div>
        <div class="card-body">
            @if(auth()->user()?->isSuperAdmin())
                <form action="{{ route('organizations.update', $organization) }}" method="POST" style="display: flex; flex-wrap: wrap; gap: 10px;">
                    @csrf
                    @method('PUT')
                    <input type="text" name="name" class="form-control" style="flex: 1 1 240px;" value="{{ old('name', $organization->name) }}" aria-label="Organization name" required>
                    <button type="submit" class="btn btn-primary">
                        <i class="fa-solid fa-floppy-disk"></i> Save Name
                    </button>
                </form>
            @else
                <strong>{{ $organization->name }}</strong>
                <div style="font-size:12px;color:var(--text-muted)">Read-only access</div>
            @endif
        </div>
    </div>

    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-user-tie" style="color: var(--gold);"></i>
                <span>Organization Officers ({{ $organization->officers->count() }})</span>
            </div>
        </div>
        <div class="card-body">
            @if(auth()->user()?->isSuperAdmin())
            <form action="{{ route('organizations.officers.store', $organization) }}" method="POST" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; align-items: end; margin-bottom: 18px;">
                @csrf
                <div>
                    <label class="form-label" for="officer_position">Position</label>
                    <input id="officer_position" name="position" class="form-control" list="officer-positions" placeholder="e.g. President" maxlength="100" required>
                    <datalist id="officer-positions">
                        <option value="President"></option>
                        <option value="Vice President"></option>
                        <option value="Secretary"></option>
                        <option value="Treasurer"></option>
                        <option value="Auditor"></option>
                        <option value="Public Relations Officer"></option>
                        <option value="Representative"></option>
                    </datalist>
                </div>
                <div>
                    <label class="form-label" for="officer_student_id">Student ID</label>
                    <input id="officer_student_id" name="student_id" class="form-control" value="{{ old('student_id') }}" placeholder="Enter member's Student ID" maxlength="100" required>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-user-plus"></i> Assign Officer
                </button>
            </form>
            @endif

            <div style="display: flex; flex-direction: column; gap: 8px;">
                @forelse($organization->officers as $officer)
                    <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 10px; padding: 12px 14px; background: var(--bg-page); border: 1px solid var(--line); border-radius: var(--radius-sm);">
                        <div>
                            <strong style="color: var(--text-main);">{{ $officer->position }}</strong>
                            <span style="color: var(--text-muted);"> — {{ $officer->student?->full_name ?? 'Member unavailable' }}</span>
                        </div>
                        @if(auth()->user()?->isSuperAdmin())
                            <form action="{{ route('organizations.officers.destroy', [$organization, $officer]) }}" method="POST" onsubmit="return confirm('Remove this officer assignment?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-secondary">Remove</button>
                            </form>
                        @endif
                    </div>
                @empty
                    <div style="text-align: center; color: var(--text-muted); padding: 18px;">No officers assigned yet.</div>
                @endforelse
            </div>
        </div>
    </div>

    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-users" style="color: var(--success);"></i>
                <span>Members ({{ $organization->students->count() }})</span>
            </div>
        </div>
        <div class="card-body">
            @if(auth()->user()?->isSuperAdmin())
            <form action="{{ route('organizations.members.store', $organization) }}" method="POST" style="display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px;">
                @csrf
                <select name="student_id" class="form-control" style="flex: 1 1 260px;" required @disabled($availableStudents->isEmpty())>
                    <option value="">Select an unassigned student</option>
                    @foreach($availableStudents as $student)
                        <option value="{{ $student->id }}">{{ $student->full_name }} ({{ $student->student_id }})</option>
                    @endforeach
                </select>
                <button type="submit" class="btn btn-primary" @disabled($availableStudents->isEmpty())>
                    <i class="fa-solid fa-user-plus"></i> Add Member
                </button>
            </form>
            @endif

            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Member Name</th>
                            <th>Program</th>
                            <th>Year / Block</th>
                            <th style="text-align: right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($organization->students as $student)
                            <tr>
                                <td>{{ $student->student_id }}</td>
                                <td style="font-weight: 700;">{{ $student->full_name }}</td>
                                <td>{{ $student->program?->name ?? '—' }}</td>
                                <td>{{ trim(($student->year_level ?? '').' '.($student->block ?? '')) ?: '—' }}</td>
                                <td style="text-align: right;">
                                    @if(auth()->user()?->isSuperAdmin())
                                        <form action="{{ route('organizations.members.destroy', [$organization, $student]) }}" method="POST" onsubmit="return confirm('Remove {{ $student->full_name }} from this organization?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-secondary">Remove</button>
                                        </form>
                                    @else
                                        <span style="color:var(--text-muted)">Read only</span>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 24px;">No members in this organization yet.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
