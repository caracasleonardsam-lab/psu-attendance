@extends('layouts.app')

@section('page_title', 'Organization Management')

@section('content')
<div style="display: flex; flex-direction: column; gap: 20px;">
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-sitemap" style="color: var(--primary);"></i>
                <span>Organization Management</span>
            </div>
            <span class="badge badge-primary">{{ $organizations->count() }} Organizations</span>
        </div>
        <div class="card-body">
            @if(auth()->user()?->isSuperAdmin())
            <form action="{{ route('organizations.store') }}" method="POST" style="display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 20px;">
                @csrf
                <input type="text" name="name" class="form-control" style="flex: 1 1 240px;" placeholder="Organization name..." value="{{ old('name') }}" required>
                <button type="submit" class="btn btn-primary" style="white-space: nowrap;">
                    <i class="fa-solid fa-plus"></i> Add Organization
                </button>
            </form>
            @endif

            @error('name')
                <div role="alert" style="color: var(--danger); font-size: 13px; margin: -10px 0 16px;">{{ $message }}</div>
            @enderror

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 300px), 1fr)); gap: 12px;">
                @forelse($organizations as $organization)
                    <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 16px; background: var(--bg-page); border: 1px solid var(--line); border-radius: var(--radius-sm);">
                        <a href="{{ route('organizations.show', $organization) }}" style="flex: 1; min-width: 0; color: inherit; text-decoration: none;">
                            <strong style="display: block; font-size: 15px; color: var(--text-main);">{{ $organization->name }}</strong>
                            <span style="display: block; margin-top: 4px; color: var(--text-muted); font-size: 12px;">
                                {{ number_format($organization->students_count) }} members · {{ auth()->user()?->isSuperAdmin() ? 'Manage members and officers' : 'View members and officers' }}
                            </span>
                        </a>
                        <a href="{{ route('organizations.show', $organization) }}" class="btn btn-sm btn-secondary" aria-label="View {{ $organization->name }}">
                            <i class="fa-solid fa-arrow-right"></i> {{ auth()->user()?->isSuperAdmin() ? 'Manage' : 'View' }}
                        </a>
                        @if(auth()->user()?->isSuperAdmin())
                        <form action="{{ route('organizations.destroy', $organization) }}" method="POST" onsubmit="return confirm('Delete organization {{ $organization->name }}?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm" style="color: var(--danger); background: transparent;" title="Delete organization" aria-label="Delete {{ $organization->name }}">
                                <i class="fa-solid fa-trash-can"></i>
                            </button>
                        </form>
                        @endif
                    </div>
                @empty
                    <div style="grid-column: 1 / -1; text-align: center; color: var(--text-muted); padding: 32px;">
                        No organizations defined yet.
                    </div>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
