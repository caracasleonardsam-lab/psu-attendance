@extends('layouts.app')

@section('page_title', 'System Audit Trail & Activity Logs')

@push('styles')
<style>
    .audit-page {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .audit-filter-form {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .audit-filter-form .form-control {
        width: min(100%, 360px);
    }

    .audit-table {
        min-width: 860px;
    }

    .audit-table th:first-child,
    .audit-table td:first-child {
        width: 58px;
    }

    .audit-table th:nth-child(2),
    .audit-table td:nth-child(2) {
        width: 190px;
    }

    .audit-table th:nth-child(3),
    .audit-table td:nth-child(3) {
        width: 180px;
    }

    .audit-table th:nth-child(4),
    .audit-table td:nth-child(4) {
        width: 190px;
    }

    .audit-table td {
        overflow-wrap: anywhere;
    }

    .audit-table td.audit-timestamp {
        white-space: nowrap;
    }

    .audit-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 14px;
        flex-wrap: wrap;
        padding: 16px 24px;
        border-top: 1px solid var(--card-border-subtle);
    }

    .audit-results-count {
        color: var(--text-muted);
        font-size: 12px;
    }

    .audit-pagination {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 6px;
        flex-wrap: wrap;
    }

    .audit-page-link {
        min-width: 36px;
        height: 36px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0 10px;
        border: 1px solid var(--card-border);
        border-radius: 8px;
        background: var(--card-bg);
        color: var(--text-main);
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease;
    }

    .audit-page-link:hover {
        border-color: var(--primary);
        background: var(--primary-soft);
        color: var(--primary);
    }

    .audit-page-link.is-current {
        border-color: var(--primary);
        background: var(--primary);
        color: #ffffff;
    }

    .audit-page-link.is-disabled {
        color: var(--text-light);
        background: var(--bg-page);
        cursor: not-allowed;
        opacity: 0.65;
    }

    .audit-page-ellipsis {
        padding: 0 3px;
        color: var(--text-muted);
    }

    @media (max-width: 640px) {
        .audit-filter-form {
            align-items: stretch;
        }

        .audit-filter-form .form-control {
            width: 100%;
            max-width: none !important;
        }

        .audit-footer {
            align-items: flex-start;
            padding: 14px 16px;
        }

        .audit-pagination {
            justify-content: flex-start;
        }
    }
</style>
@endpush

@section('content')
<div class="audit-page">

    <!-- Filter Bar -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-body" style="padding: 18px 24px;">
            <form action="{{ route('logs.index') }}" method="GET" class="audit-filter-form">
                <input 
                    type="text" 
                    name="search" 
                    class="form-control" 
                    placeholder="Search logs by actor or action..." 
                    value="{{ request('search') }}"
                    aria-label="Search audit logs"
                >
                <button type="submit" class="btn btn-secondary btn-sm">Search Logs</button>
                @if(request('search'))
                    <a href="{{ route('logs.index') }}" class="btn btn-sm" style="color: var(--text-muted);">Reset</a>
                @endif
            </form>
        </div>
    </div>

    <!-- Logs Table -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-shield-halved" style="color: var(--primary);"></i>
                <span>Activity Audit Trail ({{ number_format($logs->total()) }})</span>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table audit-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Timestamp</th>
                        <th>User / Actor</th>
                        <th>Action</th>
                        <th>Event Details</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($logs as $idx => $log)
                        <tr>
                            <td style="color: var(--text-muted); font-size: 12px;">{{ $logs->firstItem() + $idx }}</td>
                            <td class="audit-timestamp" style="font-size: 12px; color: var(--text-muted);">
                                {{ $log->created_at?->format('M d, Y h:i:s A') }}
                            </td>
                            <td style="font-weight: 700;">{{ $log->actor }}</td>
                            <td><span class="badge badge-neutral">{{ $log->action }}</span></td>
                            <td style="color: var(--text-main);">{{ $log->details ?: '—' }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 32px;">
                                No activity logs recorded matching this filter.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="audit-footer">
            <div class="audit-results-count">
                Showing {{ number_format($logs->firstItem() ?? 0) }}–{{ number_format($logs->lastItem() ?? 0) }}
                of {{ number_format($logs->total()) }} logs
            </div>
            @if($logs->hasPages())
                @php
                    $currentPage = $logs->currentPage();
                    $lastPage = $logs->lastPage();
                    $startPage = max(1, $currentPage - 2);
                    $endPage = min($lastPage, $currentPage + 2);
                @endphp
                <nav class="audit-pagination" aria-label="Audit log pagination">
                    @if($logs->onFirstPage())
                        <span class="audit-page-link is-disabled" aria-disabled="true" aria-label="Previous page">
                            <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
                        </span>
                    @else
                        <a class="audit-page-link" href="{{ $logs->previousPageUrl() }}" rel="prev" aria-label="Previous page">
                            <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
                        </a>
                    @endif

                    @if($startPage > 1)
                        <a class="audit-page-link" href="{{ $logs->url(1) }}">1</a>
                        @if($startPage > 2)
                            <span class="audit-page-ellipsis" aria-hidden="true">…</span>
                        @endif
                    @endif

                    @for($page = $startPage; $page <= $endPage; $page++)
                        @if($page === $currentPage)
                            <span class="audit-page-link is-current" aria-current="page">{{ $page }}</span>
                        @else
                            <a class="audit-page-link" href="{{ $logs->url($page) }}">{{ $page }}</a>
                        @endif
                    @endfor

                    @if($endPage < $lastPage)
                        @if($endPage < $lastPage - 1)
                            <span class="audit-page-ellipsis" aria-hidden="true">…</span>
                        @endif
                        <a class="audit-page-link" href="{{ $logs->url($lastPage) }}">{{ $lastPage }}</a>
                    @endif

                    @if($logs->hasMorePages())
                        <a class="audit-page-link" href="{{ $logs->nextPageUrl() }}" rel="next" aria-label="Next page">
                            <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                        </a>
                    @else
                        <span class="audit-page-link is-disabled" aria-disabled="true" aria-label="Next page">
                            <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                        </span>
                    @endif
                </nav>
            </div>
            @endif
        </div>
    </div>

</div>
@endsection
