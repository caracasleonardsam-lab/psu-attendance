<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Official Attendance Report | Pangasinan State University Alaminos Campus</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
            background: #f1f5f9;
            color: #0f172a;
            font-size: 13px;
            line-height: 1.5;
            padding: 30px;
        }

        .report-page {
            max-width: 900px;
            margin: 0 auto;
            background: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
        }

        .report-header {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
            border-bottom: 2px solid #07152d;
            padding-bottom: 20px;
            margin-bottom: 24px;
            text-align: center;
        }

        .header-logo {
            width: 72px;
            height: 72px;
            object-fit: contain;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.15));
        }

        .header-text h3 {
            font-size: 12px;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.05em;
            color: #475569;
        }

        .header-text h1 {
            font-size: 18px;
            font-weight: 900;
            color: #07152d;
            letter-spacing: 0.02em;
            margin: 2px 0;
        }

        .header-text h2 {
            font-size: 13px;
            font-weight: 700;
            color: #1259c3;
        }

        .header-text p {
            font-size: 11px;
            color: #64748b;
            margin-top: 2px;
        }

        .report-title-banner {
            text-align: center;
            margin-bottom: 24px;
        }

        .report-title-banner h2 {
            font-size: 16px;
            font-weight: 800;
            color: #07152d;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        .meta-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px 20px;
            margin-bottom: 24px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 14px;
            font-size: 12px;
        }

        .meta-item strong {
            display: block;
            font-size: 10px;
            text-transform: uppercase;
            color: #64748b;
            letter-spacing: 0.05em;
            margin-bottom: 2px;
        }

        .meta-item span {
            font-weight: 700;
            color: #0f172a;
            font-size: 13px;
        }

        .stats-summary-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 24px;
            text-align: center;
        }

        .stats-tile {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px;
        }

        .stats-tile .tile-title {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            color: #64748b;
        }

        .stats-tile .tile-val {
            font-size: 20px;
            font-weight: 900;
            margin-top: 2px;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            font-size: 12px;
        }

        .report-table th {
            background: #07152d;
            color: #ffffff;
            font-weight: 700;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 10px 12px;
            text-align: left;
            border: 1px solid #07152d;
        }

        .report-table td {
            padding: 9px 12px;
            border: 1px solid #e2e8f0;
            vertical-align: middle;
        }

        .report-table tbody tr:nth-child(even) {
            background: #f8fafc;
        }

        .badge-status {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .badge-present { background: #dcfce7; color: #166534; }
        .badge-late { background: #fef3c7; color: #92400e; }

        .signatories-section {
            margin-top: 40px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            page-break-inside: avoid;
        }

        .sig-block {
            text-align: center;
        }

        .sig-line {
            width: 80%;
            margin: 40px auto 6px;
            border-top: 1px solid #0f172a;
        }

        .sig-name {
            font-weight: 800;
            font-size: 12px;
            text-transform: uppercase;
        }

        .sig-title {
            font-size: 11px;
            color: #64748b;
        }

        /* Action bar outside print */
        .print-toolbar {
            max-width: 900px;
            margin: 0 auto 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 18px;
            font-size: 13px;
            font-weight: 700;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s;
        }

        .btn-print { background: #1259c3; color: #ffffff; }
        .btn-print:hover { background: #0e469b; }
        .btn-close { background: #e2e8f0; color: #334155; }

        @media print {
            body {
                background: #ffffff;
                padding: 0;
            }
            .print-toolbar {
                display: none !important;
            }
            .report-page {
                box-shadow: none;
                border: none;
                padding: 0;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>

    <!-- On-screen Action Toolbar (Hidden during print) -->
    <div class="print-toolbar">
        <button type="button" class="btn-action btn-close" onclick="window.close()">
            <i class="fa-solid fa-arrow-left"></i> Close Window
        </button>
        <button type="button" class="btn-action btn-print" onclick="window.print()">
            <i class="fa-solid fa-print"></i> Print Official Document / Save PDF
        </button>
    </div>

    <!-- Official Printable Report Document -->
    <div class="report-page">
        
        <!-- Pangasinan State University Institutional Header -->
        <div class="report-header">
            <img src="{{ asset('images/logo.png') }}" alt="Pangasinan State University Seal" class="header-logo" onerror="this.src='{{ asset('images/psu_logo.jpg') }}'">
            <div class="header-text">
                <h3>Republic of the Philippines</h3>
                <h1>PANGASINAN STATE UNIVERSITY</h1>
                <h2>ALAMINOS CITY CAMPUS</h2>
                <p>City of Alaminos, Pangasinan 2404 | Web: psu.edu.ph</p>
                <p style="font-weight: 600; color: #07152d; margin-top: 3px;">Office of Student Affairs & Campus Attendance Management</p>
            </div>
        </div>

        <!-- Document Title -->
        <div class="report-title-banner">
            <h2>Official Attendance & Compliance Summary Report</h2>
        </div>

        <!-- Report Metadata -->
        <div class="meta-card">
            <div class="meta-item">
                <strong>Report Scope</strong>
                <span>{{ $scopeDesc }}</span>
            </div>
            <div class="meta-item">
                <strong>Event Session</strong>
                <span>{{ $event ? $event->name : 'All Scheduled Campus Events' }}</span>
            </div>
            <div class="meta-item">
                <strong>Date & Venue</strong>
                <span>{{ $event ? ($event->event_date?->format('F d, Y') . ' | ' . ($event->venue ?? 'Campus Wide')) : date('F d, Y') }}</span>
            </div>
            <div class="meta-item">
                <strong>Generated Timestamp</strong>
                <span>{{ now()->format('M d, Y h:i A') }}</span>
            </div>
        </div>

        <!-- KPI Metrics -->
        <div class="stats-summary-row">
            <div class="stats-tile">
                <div class="tile-title">Total Scanned</div>
                <div class="tile-val" style="color: #1259c3;">{{ $attendances->count() }}</div>
            </div>
            <div class="stats-tile">
                <div class="tile-title">On-Time (Present)</div>
                <div class="tile-val" style="color: #166534;">{{ $presentCount }}</div>
            </div>
            <div class="stats-tile">
                <div class="tile-title">Late Check-in</div>
                <div class="tile-val" style="color: #b45309;">{{ $lateCount }}</div>
            </div>
            <div class="stats-tile">
                <div class="tile-title">Turnout of Eligible Students</div>
                <div class="tile-val" style="color: #07152d;">
                    {{ $turnoutRate }}%
                </div>
                <div style="font-size: 10px; color: #64748b; margin-top: 3px;">
                    {{ number_format($attendedStudentCount) }} / {{ number_format($expectedStudentCount) }} eligible student-event slots
                </div>
            </div>
        </div>

        <!-- Attendance Roster -->
        <table class="report-table">
            <thead>
                <tr>
                    <th style="width: 30px;">#</th>
                    <th>Student ID</th>
                    <th>Student Full Name</th>
                    <th>Year</th>
                    <th>Block</th>
                    <th>Program</th>
                    <th>Organization</th>
                    <th>Status</th>
                    <th>Time In</th>
                    <th>Verified By</th>
                </tr>
            </thead>
            <tbody>
                @forelse($attendances as $idx => $att)
                    <tr>
                        <td style="color: #64748b; text-align: center;">{{ $idx + 1 }}</td>
                        <td style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #1259c3;">
                            {{ $att->student?->student_id ?? 'N/A' }}
                        </td>
                        <td style="font-weight: 700;">{{ $att->student?->full_name ?? 'N/A' }}</td>
                        <td>{{ $att->student?->year_level ?? 'N/A' }}</td>
                        <td>{{ $att->student?->block ?? 'N/A' }}</td>
                        <td>{{ $att->student?->program?->name ?? 'N/A' }}</td>
                        <td>{{ $att->student?->organization?->name ?? 'N/A' }}</td>
                        <td>
                            <span class="badge-status {{ $att->status === 'present' ? 'badge-present' : 'badge-late' }}">
                                {{ strtoupper($att->status) }}
                            </span>
                        </td>
                        <td style="font-size: 11px; color: #475569;">
                            {{ $att->scanned_at ? $att->scanned_at->format('h:i A') : 'N/A' }}
                        </td>
                        <td style="font-size: 11px; color: #64748b;">
                            {{ $att->scanned_by ?? 'Barcode Scanner' }}
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="10" style="text-align: center; color: #64748b; padding: 24px;">
                            No attendance records match the selected report scope.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>

        <!-- Signatories Footer -->
        <div class="signatories-section">
            <div class="sig-block">
                <div class="sig-line"></div>
                <div class="sig-name">{{ Auth::user()->name ?? 'Administrator' }}</div>
                <div class="sig-title">Prepared by / Attendance Lead</div>
            </div>
            <div class="sig-block">
                <div class="sig-line"></div>
                <div class="sig-name">{{ $event?->organizer ?? 'Organization Adviser' }}</div>
                <div class="sig-title">Verified by / Event Coordinator</div>
            </div>
            <div class="sig-block">
                <div class="sig-line"></div>
                <div class="sig-name">Campus Executive Director</div>
                <div class="sig-title">Approved by / Pangasinan State University Alaminos</div>
            </div>
        </div>

    </div>

</body>
</html>
