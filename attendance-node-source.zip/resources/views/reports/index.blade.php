@extends('layouts.app')

@section('page_title', 'Attendance Reports & Data Export')

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Analytics KPI Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 18px;">
        <div class="card" style="margin-bottom: 0; padding: 20px; border-left: 4px solid var(--primary);">
            <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Total Campus Enrollment</div>
            <div style="font-size: 28px; font-weight: 800; color: var(--text-main); margin-top: 4px;">{{ number_format($totalStudents) }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Across {{ $programs->count() }} degree programs</div>
        </div>

        <div class="card" style="margin-bottom: 0; padding: 20px; border-left: 4px solid #06b6d4;">
            <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Total Attendance Records</div>
            <div style="font-size: 28px; font-weight: 800; color: #0891b2; margin-top: 4px;">{{ number_format($totalAttendance) }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Verified campus check-ins</div>
        </div>

        <div class="card" style="margin-bottom: 0; padding: 20px; border-left: 4px solid var(--success);">
            <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">On-Time (Present)</div>
            <div style="font-size: 28px; font-weight: 800; color: var(--success); margin-top: 4px;">{{ number_format($presentCount) }}</div>
            <div style="font-size: 12px; color: var(--success); margin-top: 4px;">Compliant arrival</div>
        </div>

        <div class="card" style="margin-bottom: 0; padding: 20px; border-left: 4px solid var(--warning);">
            <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Late Check-ins</div>
            <div style="font-size: 28px; font-weight: 800; color: var(--warning); margin-top: 4px;">{{ number_format($lateCount) }}</div>
            <div style="font-size: 12px; color: var(--warning); margin-top: 4px;">After event call time</div>
        </div>
    </div>

    <!-- Attendance Report Generator & Custom Scope Download Studio -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header" style="background: linear-gradient(135deg, #07152d 0%, #0d2246 100%); color: #ffffff;">
            <div class="card-title" style="color: #ffffff;">
                <i class="fa-solid fa-file-export" style="color: var(--gold);"></i>
                <span>Download Attendance Report & Custom Filter Studio</span>
            </div>
            <span style="font-size: 12px; color: #94a3b8; font-weight: 600;">
                Select scope: Whole Campus, per Organization, per Year Level and optional Block, or per Program
            </span>
        </div>

        <div class="card-body" style="padding: 24px;">
            <form action="{{ route('reports.index') }}" method="GET" id="reportFilterForm">
                
                <!-- Scope Selection Radio Cards -->
                <div style="margin-bottom: 20px;">
                    <label class="form-label" style="font-size: 13px; font-weight: 800; text-transform: uppercase; color: var(--text-main); margin-bottom: 10px;">
                        1. Select Report Target Scope:
                    </label>

                    @php
                        $activeScope = request('scope') === 'block' ? 'year_level' : request('scope', 'all');
                    @endphp

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px;">
                        
                        <!-- Whole Campus -->
                        <label style="border: 2px solid {{ $activeScope === 'all' ? 'var(--primary)' : 'var(--card-border)' }}; background: {{ $activeScope === 'all' ? 'var(--primary-soft)' : '#ffffff' }}; border-radius: 10px; padding: 14px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.2s;">
                            <input type="radio" name="scope" value="all" {{ $activeScope === 'all' ? 'checked' : '' }} onchange="toggleScopeInputs()" style="accent-color: var(--primary);">
                            <div>
                                <div style="font-weight: 800; color: var(--text-main); font-size: 14px;">Whole Campus</div>
                                <div style="font-size: 11px; color: var(--text-muted);">All students & organizations</div>
                            </div>
                        </label>

                        <!-- Per Organization -->
                        <label style="border: 2px solid {{ $activeScope === 'organization' ? 'var(--primary)' : 'var(--card-border)' }}; background: {{ $activeScope === 'organization' ? 'var(--primary-soft)' : '#ffffff' }}; border-radius: 10px; padding: 14px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.2s;">
                            <input type="radio" name="scope" value="organization" {{ $activeScope === 'organization' ? 'checked' : '' }} onchange="toggleScopeInputs()" style="accent-color: var(--primary);">
                            <div>
                                <div style="font-weight: 800; color: var(--text-main); font-size: 14px;">Per Organization</div>
                                <div style="font-size: 11px; color: var(--text-muted);">DOIT, SAHARA, etc.</div>
                            </div>
                        </label>

                        <!-- Per Year Level -->
                        <label style="border: 2px solid {{ $activeScope === 'year_level' ? 'var(--primary)' : 'var(--card-border)' }}; background: {{ $activeScope === 'year_level' ? 'var(--primary-soft)' : '#ffffff' }}; border-radius: 10px; padding: 14px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.2s;">
                            <input type="radio" name="scope" value="year_level" {{ $activeScope === 'year_level' ? 'checked' : '' }} onchange="toggleScopeInputs()" style="accent-color: var(--primary);">
                            <div>
                                <div style="font-weight: 800; color: var(--text-main); font-size: 14px;">Per Year Level</div>
                                <div style="font-size: 11px; color: var(--text-muted);">Choose a year and optionally narrow it to a block</div>
                            </div>
                        </label>

                        <!-- Per Academic Program -->
                        <label style="border: 2px solid {{ $activeScope === 'program' ? 'var(--primary)' : 'var(--card-border)' }}; background: {{ $activeScope === 'program' ? 'var(--primary-soft)' : '#ffffff' }}; border-radius: 10px; padding: 14px; cursor: pointer; display: flex; align-items: center; gap: 12px; transition: all 0.2s;">
                            <input type="radio" name="scope" value="program" {{ $activeScope === 'program' ? 'checked' : '' }} onchange="toggleScopeInputs()" style="accent-color: var(--primary);">
                            <div>
                                <div style="font-weight: 800; color: var(--text-main); font-size: 14px;">Per Program</div>
                                <div style="font-size: 11px; color: var(--text-muted);">BSIT, BSED, etc.</div>
                            </div>
                        </label>

                    </div>
                </div>

                <!-- Scope-Specific Dropdowns (Shown dynamically based on chosen scope) -->
                <div style="background: #f8fafc; border-radius: 10px; padding: 18px; border: 1px solid var(--line); margin-bottom: 20px;">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; align-items: flex-end;">
                        
                        <!-- Organization Selector (visible when organization is selected) -->
                        <div id="scopeOrgWrapper" style="display: {{ $activeScope === 'organization' ? 'block' : 'none' }};">
                            <label class="form-label" for="orgSelector">Student Organization *</label>
                            <select name="organization_id" id="orgSelector" class="form-select">
                                <option value="">-- Choose Organization --</option>
                                @foreach($organizations as $org)
                                    <option value="{{ $org->id }}" {{ request('organization_id') == $org->id ? 'selected' : '' }}>
                                        {{ $org->name }} ({{ $org->students_count }} members)
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Year Level Selector (visible when year_level is selected) -->
                        <div id="scopeYearWrapper" style="display: {{ $activeScope === 'year_level' ? 'grid' : 'none' }}; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px;">
                            <div>
                                <label class="form-label" for="yearSelector">Year Level *</label>
                                <select name="year_level" id="yearSelector" class="form-select">
                                    <option value="">-- Choose Year Level --</option>
                                    @foreach($yearLevels as $yl)
                                        <option value="{{ $yl }}" {{ request('year_level') == $yl ? 'selected' : '' }}>
                                            {{ $yl }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div>
                                <label class="form-label" for="blockSelector">Block (Optional)</label>
                                <select name="block" id="blockSelector" class="form-select">
                                    <option value="">All Blocks</option>
                                    @foreach($blocks as $block)
                                        <option value="{{ $block }}" {{ request('block') == $block ? 'selected' : '' }}>
                                            Block {{ $block }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <!-- Academic Program Selector (visible when program is selected) -->
                        <div id="scopeProgWrapper" style="display: {{ $activeScope === 'program' ? 'block' : 'none' }};">
                            <label class="form-label" for="progSelector">Academic Program *</label>
                            <select name="program_id" id="progSelector" class="form-select">
                                <option value="">-- Choose Program --</option>
                                @foreach($programs as $p)
                                    <option value="{{ $p->id }}" {{ request('program_id') == $p->id ? 'selected' : '' }}>
                                        {{ $p->name }} ({{ $p->students_count }} enrolled)
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Event Selector -->
                        <div>
                            <label class="form-label" for="repEvent">Campus Event</label>
                            <select name="event_id" id="repEvent" class="form-select">
                                <option value="">All Events (Cumulative)</option>
                                @foreach($events as $ev)
                                    <option value="{{ $ev->id }}" {{ request('event_id') == $ev->id ? 'selected' : '' }}>
                                        {{ $ev->name }} ({{ $ev->event_date?->format('M d, Y') }})
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <!-- Attendance Status -->
                        <div>
                            <label class="form-label" for="repStatus">Attendance Status</label>
                            <select name="status" id="repStatus" class="form-select">
                                <option value="">All Statuses</option>
                                <option value="present" {{ request('status') === 'present' ? 'selected' : '' }}>Present (On-Time)</option>
                                <option value="late" {{ request('status') === 'late' ? 'selected' : '' }}>Late Only</option>
                                <option value="checked_out" {{ request('status') === 'checked_out' ? 'selected' : '' }}>Checked Out Only</option>
                            </select>
                        </div>

                        <!-- Date Range From -->
                        <div>
                            <label class="form-label" for="dateFrom">From Date</label>
                            <input type="date" name="date_from" id="dateFrom" class="form-control" value="{{ request('date_from') }}">
                        </div>

                        <!-- Date Range To -->
                        <div>
                            <label class="form-label" for="dateTo">To Date</label>
                            <input type="date" name="date_to" id="dateTo" class="form-control" value="{{ request('date_to') }}">
                        </div>

                    </div>
                </div>

                <!-- Action Toolbar: Filter / Preview / Download CSV / Print Document -->
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
                    <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                        <button type="submit" class="btn btn-secondary">
                            <i class="fa-solid fa-filter"></i> Apply Filter & Preview
                        </button>
                        @if(request()->hasAny(['scope', 'organization_id', 'year_level', 'block', 'program_id', 'event_id', 'status', 'date_from', 'date_to']))
                            <a href="{{ route('reports.index') }}" class="btn btn-sm" style="color: var(--text-muted);">
                                <i class="fa-solid fa-rotate-left"></i> Reset
                            </a>
                        @endif
                    </div>

                    <!-- Direct Download / Export Actions -->
                    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                        <!-- Download CSV -->
                        <a href="{{ route('reports.export', request()->all()) }}" class="btn btn-primary" style="box-shadow: 0 4px 12px rgba(18, 89, 195, 0.3);">
                            <i class="fa-solid fa-file-csv"></i> Download Alphabetical CSV Report
                        </a>

                        <!-- Printable Official Document -->
                        <a href="{{ route('reports.print', request()->all()) }}" target="_blank" class="btn btn-gold" style="box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);">
                            <i class="fa-solid fa-print"></i> Print Official Report Document
                        </a>
                    </div>
                </div>

            </form>
        </div>
    </div>

    <!-- Live Preview Roster Table -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div class="card-title">
                <i class="fa-solid fa-table-list" style="color: var(--primary);"></i>
                <span>Report Preview ({{ number_format($previewCount) }} Matching Records)</span>
            </div>

            <div style="display: flex; gap: 12px; font-size: 12px;">
                <span class="badge badge-success">Present: {{ number_format($filteredPresent) }}</span>
                <span class="badge badge-warning">Late: {{ number_format($filteredLate) }}</span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student ID</th>
                        <th>Full Name</th>
                        <th>Year</th>
                        <th>Block</th>
                        <th>Program</th>
                        <th>Organization</th>
                        <th>Event</th>
                        <th>Status</th>
                        <th>Time In</th>
                        <th>Scanned By</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($previewRecords as $idx => $att)
                        <tr>
                            <td style="color: var(--text-muted); font-size: 12px;">{{ $previewRecords->firstItem() + $idx }}</td>
                            <td style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: var(--primary);">
                                {{ $att->student?->student_id }}
                            </td>
                            <td style="font-weight: 700;">{{ $att->student?->full_name }}</td>
                            <td><span class="badge badge-neutral">{{ $att->student?->year_level ?? 'N/A' }}</span></td>
                            <td><span class="badge badge-neutral">{{ $att->student?->block ?? 'N/A' }}</span></td>
                            <td><span class="badge badge-primary">{{ $att->student?->program?->name ?? 'N/A' }}</span></td>
                            <td><span class="badge badge-neutral">{{ $att->student?->organization?->name ?? 'N/A' }}</span></td>
                            <td>{{ $att->event?->name ?? 'Campus Event' }}</td>
                            <td>
                                <span class="badge {{ $att->status === 'present' ? 'badge-success' : 'badge-warning' }}">
                                    {{ strtoupper($att->status) }}
                                </span>
                            </td>
                            <td style="font-size: 12px; color: var(--text-muted);">
                                {{ $att->scanned_at?->format('M d, Y h:i A') }}
                            </td>
                            <td style="font-size: 12px; color: var(--text-muted);">
                                {{ $att->scanned_by ?? 'Barcode Scanner' }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="11" style="text-align: center; color: var(--text-muted); padding: 36px;">
                                <i class="fa-regular fa-folder-open" style="font-size: 32px; display: block; margin-bottom: 8px;"></i>
                                No attendance records match the selected scope and criteria.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($previewRecords->hasPages())
            <div style="padding: 16px 24px; border-top: 1px solid var(--card-border-subtle);">
                {{ $previewRecords->links() }}
            </div>
        @endif
    </div>

    <!-- Academic Program Population & Attendance Summary Breakdown -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-chart-pie" style="color: var(--primary);"></i>
                <span>Program Attendance & Turnout Summary</span>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Program</th>
                        <th>Total Population</th>
                        <th>Attendance Recorded</th>
                        <th>Turnout (attended / eligible student-event slots)</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($programStats as $prog)
                        @php
                            $rate = $prog['expected'] > 0 ? round(($prog['attendances'] / $prog['expected']) * 100, 1) : 0;
                        @endphp
                        <tr>
                            <td style="font-weight: 700; font-size: 14px;">{{ $prog['name'] }}</td>
                            <td>{{ number_format($prog['students']) }} students</td>
                            <td style="font-weight: 600;">
                                {{ number_format($prog['attendances']) }} attended student-event slots
                                <div style="font-size: 11px; color: var(--text-muted);">{{ number_format($prog['expected']) }} eligible student-event slots</div>
                            </td>
                            <td style="width: 35%;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="flex: 1; height: 8px; background: #e2e8f0; border-radius: 999px; overflow: hidden;">
                                        <div style="height: 100%; width: {{ $rate }}%; background: linear-gradient(90deg, #1259c3, #10b981); border-radius: 999px;"></div>
                                    </div>
                                    <span style="font-size: 12px; font-weight: 700; color: var(--text-muted); min-width: 45px;">{{ $rate }}%</span>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
    function toggleScopeInputs() {
        const selectedScope = document.querySelector('input[name="scope"]:checked').value;
        const orgWrapper = document.getElementById('scopeOrgWrapper');
        const yearWrapper = document.getElementById('scopeYearWrapper');
        const progWrapper = document.getElementById('scopeProgWrapper');

        if (orgWrapper) orgWrapper.style.display = (selectedScope === 'organization') ? 'block' : 'none';
        if (yearWrapper) yearWrapper.style.display = (selectedScope === 'year_level') ? 'grid' : 'none';
        if (progWrapper) progWrapper.style.display = (selectedScope === 'program') ? 'block' : 'none';

        // Update card border styles
        document.querySelectorAll('input[name="scope"]').forEach(radio => {
            const label = radio.closest('label');
            if (radio.checked) {
                label.style.borderColor = 'var(--primary)';
                label.style.background = 'var(--primary-soft)';
            } else {
                label.style.borderColor = 'var(--card-border)';
                label.style.background = '#ffffff';
            }
        });
    }
</script>
@endpush
