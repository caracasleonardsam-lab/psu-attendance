@extends('layouts.app')

@section('page_title', 'Executive System Dashboard')

@push('styles')
<style>
    /* Metric Cards */
    .metric-card-enhanced {
        background: var(--card-bg);
        border: 1px solid var(--card-border);
        border-radius: var(--radius-md);
        padding: 22px;
        box-shadow: var(--shadow-sm);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        position: relative;
        overflow: hidden;
        transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
    }

    .metric-card-enhanced:hover {
        transform: translateY(-3px);
        box-shadow: var(--shadow-md);
        border-color: var(--primary-light);
    }

    .metric-card-enhanced::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 3px;
    }

    .metric-card-blue::after { background: linear-gradient(90deg, #1259c3, #3b82f6); }
    .metric-card-gold::after { background: linear-gradient(90deg, #d97706, #fbbf24); }
    .metric-card-emerald::after { background: linear-gradient(90deg, #059669, #34d399); }
    .metric-card-cyan::after { background: linear-gradient(90deg, #0891b2, #38bdf8); }
    .metric-card-purple::after { background: linear-gradient(90deg, #7c3aed, #a78bfa); }

    .metric-icon-box {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        flex-shrink: 0;
    }

    /* Hero Banner */
    .dashboard-hero-banner {
        background: linear-gradient(135deg, #07152d 0%, #0c2754 50%, #1259c3 100%);
        border-radius: var(--radius-lg);
        padding: 28px 32px;
        color: #ffffff;
        box-shadow: 0 10px 30px -5px rgba(7, 21, 45, 0.4);
        position: relative;
        overflow: hidden;
        border: 1px solid rgba(255, 215, 0, 0.2);
    }

    .dashboard-hero-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 20px;
        position: relative;
        z-index: 1;
    }

    .dashboard-welcome-copy {
        flex: 1 1 320px;
        min-width: 0;
    }

    .dashboard-quick-actions {
        display: flex;
        flex: 1 1 360px;
        justify-content: flex-end;
        align-items: center;
        flex-wrap: wrap;
        gap: 10px;
        min-width: 0;
        max-width: 100%;
    }

    .dashboard-hero-watermark {
        position: absolute;
        right: 28px;
        top: 50%;
        width: 260px;
        height: 260px;
        object-fit: contain;
        opacity: 0.09;
        transform: translateY(-50%);
        pointer-events: none;
        user-select: none;
    }

    .dashboard-hero-banner::before {
        content: '';
        position: absolute;
        right: -60px;
        top: -60px;
        width: 260px;
        height: 260px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(245, 158, 11, 0.15) 0%, transparent 70%);
        pointer-events: none;
    }

    .hero-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 18px;
        border-radius: var(--radius-sm);
        font-size: 13px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.2s ease;
        box-shadow: var(--shadow-sm);
        min-width: 0;
        max-width: 100%;
        white-space: normal;
        overflow-wrap: anywhere;
    }

    .dashboard-main-row {
        display: grid;
        grid-template-columns: minmax(0, 2fr) minmax(280px, 1fr);
        gap: 24px;
    }

    .dashboard-stream-actions {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-end;
        gap: 8px;
        min-width: 0;
    }

    @media (max-width: 1100px) {
        .dashboard-main-row {
            grid-template-columns: minmax(0, 1fr);
        }
    }

    @media (max-width: 640px) {
        .dashboard-hero-banner {
            padding: 22px 18px;
        }

        .dashboard-hero-content {
            align-items: stretch;
        }

        .dashboard-quick-actions {
            flex-basis: 100%;
            justify-content: flex-start;
        }

        .dashboard-quick-actions .hero-btn {
            flex: 1 1 150px;
            justify-content: center;
            text-align: center;
        }

        .dashboard-main-row {
            gap: 16px;
        }
    }

    .hero-btn-gold {
        background: linear-gradient(135deg, #f59e0b, #d97706);
        color: #ffffff;
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 4px 14px rgba(245, 158, 11, 0.4);
    }
    .hero-btn-gold:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(245, 158, 11, 0.5);
        color: #ffffff;
    }

    .hero-btn-glass {
        background: rgba(255, 255, 255, 0.12);
        color: #ffffff;
        border: 1px solid rgba(255, 255, 255, 0.2);
        backdrop-filter: blur(8px);
    }
    .hero-btn-glass:hover {
        background: rgba(255, 255, 255, 0.22);
        transform: translateY(-2px);
        color: #ffffff;
    }

    /* Event Calendar Mini Card */
    .calendar-event-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px 14px;
        border-radius: var(--radius-sm);
        background: var(--bg-page);
        border: 1px solid var(--card-border-subtle);
        margin-bottom: 10px;
        transition: all 0.15s ease;
    }
    .calendar-event-card:hover {
        border-color: var(--primary);
        background: var(--card-bg);
        transform: translateX(2px);
    }

    .calendar-date-box {
        width: 48px;
        height: 48px;
        border-radius: 10px;
        background: var(--primary-soft);
        color: var(--primary);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        line-height: 1.1;
        flex-shrink: 0;
        border: 1px solid rgba(18, 89, 195, 0.2);
    }

    .calendar-date-month {
        font-size: 9px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .calendar-date-day {
        font-size: 16px;
    }
</style>
@endpush

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Executive Hero Welcome Banner -->
    <div class="dashboard-hero-banner">
        <img
            src="{{ asset('images/logo.png') }}"
            alt=""
            aria-hidden="true"
            class="dashboard-hero-watermark"
            onerror="this.src='{{ asset('images/psu_logo.jpg') }}'"
        >
        <div class="dashboard-hero-content">
            <div class="dashboard-welcome-copy">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
                    <span class="badge" style="background: rgba(245, 158, 11, 0.25); color: #fef3c7; border: 1px solid rgba(245, 158, 11, 0.4); font-size: 11px;">
                        <i class="fa-solid fa-graduation-cap"></i> A.Y. {{ $academicYear }} • {{ $academicSemester }}
                    </span>
                    <span class="badge" style="background: rgba(16, 185, 129, 0.25); color: #a7f3d0; border: 1px solid rgba(16, 185, 129, 0.4); font-size: 11px;">
                        <i class="fa-solid fa-signal"></i> Active Session
                    </span>
                </div>
                <h2 style="font-size: 24px; font-weight: 800; color: #ffffff; letter-spacing: -0.02em;">
                    Welcome back, {{ Auth::user()->name ?? 'Administrator' }}!
                </h2>
                <p style="color: #cbd5e1; font-size: 13px; margin-top: 4px; max-width: 600px;">
                    Central campus attendance tracking, real-time optical barcode scanning, and GPS presence verification engine.
                </p>
            </div>

            <!-- Quick Action Command Bar -->
            <div class="dashboard-quick-actions">
                <a href="{{ route('attendance.scanner') }}" class="hero-btn hero-btn-gold">
                    <i class="fa-solid fa-barcode"></i> Launch Live Scanner
                </a>
                <a href="{{ route('presence.index') }}" class="hero-btn hero-btn-glass">
                    <i class="fa-solid fa-location-dot"></i> Geofence Radar
                </a>
                <a href="{{ route('events.index') }}" class="hero-btn hero-btn-glass">
                    <i class="fa-solid fa-calendar-plus"></i> New Event
                </a>
                <a href="{{ route('reports.index') }}" class="hero-btn hero-btn-glass">
                    <i class="fa-solid fa-chart-pie"></i> Reports
                </a>
            </div>
        </div>
    </div>

    <!-- 5 Enhanced KPI Metric Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 16px;">
        <!-- Students Card -->
        <div class="metric-card-enhanced metric-card-blue">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Enrolled Students</div>
                    <div style="font-size: 28px; font-weight: 900; color: var(--text-main); margin-top: 4px;">{{ number_format($totalStudents) }}</div>
                    <div style="font-size: 12px; color: var(--success); font-weight: 600; margin-top: 4px;">
                        <i class="fa-solid fa-user-check"></i> Active Roster
                    </div>
                </div>
                <div class="metric-icon-box" style="background: var(--primary-soft); color: var(--primary);">
                    <i class="fa-solid fa-user-graduate"></i>
                </div>
            </div>
        </div>

        <!-- Active Events Card -->
        <div class="metric-card-enhanced metric-card-emerald">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Active Events</div>
                    <div style="font-size: 28px; font-weight: 900; color: var(--text-main); margin-top: 4px;">{{ $activeEvents }}</div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                        {{ $upcomingEvents->count() }} Upcoming / Scheduled
                    </div>
                </div>
                <div class="metric-icon-box" style="background: var(--success-soft); color: var(--success);">
                    <i class="fa-solid fa-calendar-check"></i>
                </div>
            </div>
        </div>

        <!-- Scans Today Card -->
        <div class="metric-card-enhanced metric-card-gold">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Attendance Scans Today</div>
                    <div style="font-size: 28px; font-weight: 900; color: var(--gold-dark); margin-top: 4px;">{{ number_format($todayAttendance) }}</div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                        {{ number_format($totalAttendance) }} All-time scans
                    </div>
                </div>
                <div class="metric-icon-box" style="background: var(--gold-soft); color: var(--gold-dark);">
                    <i class="fa-solid fa-barcode"></i>
                </div>
            </div>
        </div>

        <!-- GPS Presence Verification Card -->
        <div class="metric-card-enhanced metric-card-cyan">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Active Event GPS Attendance</div>
                    <div style="font-size: 28px; font-weight: 900; color: var(--text-main); margin-top: 4px;">{{ $presenceRate }}%</div>
                    <div style="font-size: 12px; color: #0891b2; font-weight: 600; margin-top: 4px;">
                        <i class="fa-solid fa-satellite"></i> {{ number_format($verifiedPresenceCount) }} / {{ number_format($eligibleStudentCount) }} eligible students inside perimeter
                    </div>
                </div>
                <div class="metric-icon-box" style="background: #ecfeff; color: #0891b2;">
                    <i class="fa-solid fa-location-crosshairs"></i>
                </div>
            </div>
        </div>

        <!-- Programs & Organizations Card -->
        <div class="metric-card-enhanced metric-card-purple">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <div style="font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Organization Management</div>
                    <div style="font-size: 28px; font-weight: 900; color: var(--text-main); margin-top: 4px;">{{ $totalOrganizations }}</div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                        Manage organizations, members, and officers
                    </div>
                </div>
                <div class="metric-icon-box" style="background: #f3e8ff; color: #7c3aed;">
                    <i class="fa-solid fa-sitemap"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Real-time Attendance Stream & Upcoming Events Row -->
    <div class="dashboard-main-row">
        
        @if(auth()->user()?->isAdmin())
        <!-- Live Attendance Activity Stream -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header">
                <div class="card-title">
                    <i class="fa-solid fa-clock-rotate-left" style="color: var(--primary);"></i>
                    <span>Live Attendance Activity Stream</span>
                </div>
                <div class="dashboard-stream-actions">
                    <a href="{{ route('attendance.scanner') }}" class="btn btn-sm btn-primary">
                        <i class="fa-solid fa-barcode"></i> Scan Station
                    </a>
                    <a href="{{ route('attendance.index') }}" class="btn btn-sm btn-secondary">Full Log</a>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Full Name</th>
                            <th>Program</th>
                            <th>Event</th>
                            <th>Status</th>
                            <th style="text-align: right;">Time Scanned</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($recentAttendance as $att)
                            <tr>
                                <td>
                                    <span style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: var(--primary); font-size: 12px;">
                                        {{ $att->student?->student_id }}
                                    </span>
                                </td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 30px; height: 30px; border-radius: 50%; background: #07152d; color: var(--gold); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 11px;">
                                            {{ strtoupper(substr($att->student?->full_name ?? 'U', 0, 1)) }}
                                        </div>
                                        <span style="font-weight: 700;">{{ $att->student?->full_name }}</span>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge badge-primary">{{ $att->student?->program?->name ?? 'N/A' }}</span>
                                </td>
                                <td>
                                    <span style="font-weight: 600; color: var(--text-main);">
                                        {{ $att->event?->name ?? 'General Campus Event' }}
                                    </span>
                                </td>
                                <td>
                                    @if($att->status === 'present')
                                        <span class="badge badge-success">
                                            <i class="fa-solid fa-check"></i> Present
                                        </span>
                                    @elseif($att->status === 'late')
                                        <span class="badge badge-warning">
                                            <i class="fa-solid fa-clock"></i> Late
                                        </span>
                                    @else
                                        <span class="badge badge-danger">
                                            {{ ucfirst($att->status) }}
                                        </span>
                                    @endif
                                </td>
                                <td style="text-align: right; color: var(--text-muted); font-size: 12px;" title="{{ $att->scanned_at?->format('M d, Y h:i:s A') }}">
                                    <strong>{{ $att->scanned_at?->format('h:i:s A') }}</strong>
                                    <div style="font-size: 11px; opacity: 0.8;">{{ $att->scanned_at?->diffForHumans() }}</div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 36px; color: var(--text-muted);">
                                    <i class="fa-regular fa-clipboard" style="font-size: 32px; display: block; margin-bottom: 8px; opacity: 0.4;"></i>
                                    No attendance records logged yet today. <a href="{{ route('attendance.scanner') }}" style="color: var(--primary); font-weight: 700;">Start scanning now</a>.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        @endif

        <!-- Right Side: Scheduled & Upcoming Campus Events -->
        <div class="card" style="margin-bottom: 0;">
            <div class="card-header">
                <div class="card-title">
                    <i class="fa-solid fa-calendar-days" style="color: var(--success);"></i>
                    <span>Upcoming Events</span>
                </div>
                @if(auth()->user()?->isAdmin())
                    <a href="{{ route('events.index') }}" class="btn btn-sm btn-secondary">All</a>
                @endif
            </div>
            <div class="card-body" style="padding: 16px;">
                @forelse($upcomingEvents as $ev)
                    <div class="calendar-event-card">
                        <div class="calendar-date-box">
                            <span class="calendar-date-month">{{ $ev->event_date?->format('M') ?? 'ALL' }}</span>
                            <span class="calendar-date-day">{{ $ev->event_date?->format('d') ?? '--' }}</span>
                        </div>
                        <div style="flex: 1; min-width: 0;">
                            <h4 style="font-size: 13px; font-weight: 800; color: var(--text-main); margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                {{ $ev->name }}
                            </h4>
                            <div style="font-size: 11px; color: var(--text-muted); margin-top: 3px; display: flex; align-items: center; gap: 8px;">
                                <span><i class="fa-solid fa-location-dot" style="color: var(--gold);"></i> {{ $ev->venue ?? 'Campus' }}</span>
                                <span><i class="fa-solid fa-clock"></i> {{ $ev->start_time ? \Carbon\Carbon::parse($ev->start_time)->format('h:i A') : 'All Day' }}</span>
                            </div>
                        </div>
                        <div>
                            @if($ev->status === 'active')
                                <a href="{{ route('attendance.scanner', ['event_id' => $ev->id]) }}" class="btn btn-sm btn-gold" style="padding: 4px 8px; font-size: 11px;" title="Scan for this event">
                                    <i class="fa-solid fa-barcode"></i>
                                </a>
                            @else
                                <span class="badge badge-neutral" style="font-size: 10px;">{{ ucfirst($ev->status) }}</span>
                            @endif
                        </div>
                    </div>
                @empty
                    <div style="text-align: center; color: var(--text-muted); padding: 24px; font-size: 13px;">
                        <i class="fa-regular fa-calendar" style="font-size: 28px; opacity: 0.4; display: block; margin-bottom: 8px;"></i>
                        No upcoming events scheduled.
                    </div>
                @endforelse
            </div>
        </div>

    </div>

    @if(auth()->user()?->isSuperAdmin())
    <!-- Audit Trail Section -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-shield-halved" style="color: #6366f1;"></i>
                <span>Recent System Audit Trail</span>
            </div>
            <a href="{{ route('logs.index') }}" class="btn btn-sm btn-secondary">Full Audit Trail</a>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($recentLogs as $log)
                        <tr>
                            <td style="color: var(--text-muted); font-size: 12px; white-space: nowrap;">{{ $log->created_at?->diffForHumans() }}</td>
                            <td style="font-weight: 700; color: var(--text-main);">{{ $log->actor }}</td>
                            <td><span class="badge badge-neutral">{{ $log->action }}</span></td>
                            <td style="color: var(--text-muted); font-size: 13px;">{{ $log->details }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    @endif

</div>

@endsection
