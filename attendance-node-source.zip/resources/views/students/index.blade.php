@extends('layouts.app')

@section('page_title', 'Students Directory')

@section('content')
<div style="display: flex; flex-direction: column; gap: 24px;">

    <!-- Filter & Action Bar -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-body" style="padding: 18px 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;">
            <form action="{{ route('students.index') }}" method="GET" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center; flex: 1;">
                <input 
                    type="text" 
                    name="search" 
                    class="form-control" 
                    placeholder="Search by ID, Name or Email..." 
                    value="{{ request('search') }}"
                    style="max-width: 260px;"
                >
                <select name="program_id" class="form-select" style="max-width: 170px;" onchange="this.form.submit()">
                    <option value="">All Programs</option>
                    @foreach($programs as $p)
                        <option value="{{ $p->id }}" {{ request('program_id') == $p->id ? 'selected' : '' }}>
                            {{ $p->name }}
                        </option>
                    @endforeach
                </select>
                <select name="organization_id" class="form-select" style="max-width: 170px;" onchange="this.form.submit()">
                    <option value="">All Organizations</option>
                    @foreach($organizations as $o)
                        <option value="{{ $o->id }}" {{ request('organization_id') == $o->id ? 'selected' : '' }}>
                            {{ $o->name }}
                        </option>
                    @endforeach
                </select>
                <select name="year_level" class="form-select" style="max-width: 150px;" onchange="this.form.submit()">
                    <option value="">All Years</option>
                    @foreach($yearLevels as $yearLevel)
                        <option value="{{ $yearLevel }}" {{ request('year_level') === $yearLevel ? 'selected' : '' }}>
                            {{ $yearLevel }}
                        </option>
                    @endforeach
                </select>
                <select name="block" class="form-select" style="max-width: 130px;" onchange="this.form.submit()">
                    <option value="">All Blocks</option>
                    @foreach($blocks as $block)
                        <option value="{{ $block }}" {{ request('block') === $block ? 'selected' : '' }}>
                            Block {{ $block }}
                        </option>
                    @endforeach
                </select>
                <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
                @if(request()->hasAny(['search', 'program_id', 'organization_id', 'year_level', 'block']))
                    <a href="{{ route('students.index') }}" class="btn btn-sm" style="color: var(--text-muted);">Reset</a>
                @endif
                @if(auth()->user()?->isSuperAdmin())
                    <a href="{{ route('students.export', request()->query()) }}" class="btn btn-secondary btn-sm">
                        <i class="fa-solid fa-file-csv"></i> Download CSV
                    </a>
                @endif
            </form>

            @if(auth()->user()?->isSuperAdmin())
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <button type="button" class="btn btn-secondary" onclick="openImportStudentModal()">
                        <i class="fa-solid fa-file-import"></i> Import CSV
                    </button>
                    <button type="button" class="btn btn-primary" onclick="openNewStudentModal()">
                        <i class="fa-solid fa-user-plus"></i> Register Student
                    </button>
                </div>
            @endif
        </div>
    </div>

    <!-- Students Roster Card -->
    <div class="card" style="margin-bottom: 0;">
        <div class="card-header">
            <div class="card-title">
                <i class="fa-solid fa-graduation-cap" style="color: var(--primary);"></i>
                <span>Enrolled Students Roster ({{ number_format($students->total()) }})</span>
            </div>
            <div style="font-size: 12px; color: var(--text-muted);">
                Showing page {{ $students->currentPage() }} of {{ $students->lastPage() }}
            </div>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student ID</th>
                        <th>Full Name</th>
                        <th>Program</th>
                        <th>Organization</th>
                        <th>Year / Block</th>
                        <th>Email / Contact</th>
                        <th style="text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($students as $idx => $student)
                        <tr>
                            <td style="color: var(--text-muted); font-size: 12px;">{{ $students->firstItem() + $idx }}</td>
                            <td>
                                <span style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: var(--primary);">
                                    {{ $student->student_id }}
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 32px; height: 32px; border-radius: 50%; background: #07152d; color: var(--gold); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 11px;">
                                        {{ strtoupper(substr($student->full_name, 0, 1)) }}
                                    </div>
                                    <span style="font-weight: 700;">{{ $student->full_name }}</span>
                                </div>
                            </td>
                            <td><span class="badge badge-primary">{{ $student->program?->name ?? 'N/A' }}</span></td>
                            <td><span class="badge badge-neutral">{{ $student->organization?->name ?? 'N/A' }}</span></td>
                            <td>
                                <span class="badge badge-neutral">{{ $student->year_level ?? 'N/A' }}</span>
                                @if($student->block)
                                    <span class="badge badge-primary">{{ $student->block }}</span>
                                @endif
                            </td>
                            <td style="font-size: 12px; color: var(--text-muted);">
                                <div>{{ $student->email }}</div>
                                @if($student->phone)
                                    <div><i class="fa-solid fa-phone" style="font-size: 10px;"></i> {{ $student->phone }}</div>
                                @endif
                            </td>
                            <td style="text-align: right;">
                                <div style="display: inline-flex; gap: 6px;">
                                    @if(auth()->user()?->isSuperAdmin())
                                    <button
                                        type="button"
                                        class="btn btn-sm btn-secondary"
                                        title="Edit student details"
                                        onclick="openEditStudentModal(@js([
                                            'id' => $student->id,
                                            'student_id' => $student->student_id,
                                            'full_name' => $student->full_name,
                                            'program_id' => $student->program_id,
                                            'organization_id' => $student->organization_id,
                                            'year_level' => $student->year_level,
                                            'block' => $student->block,
                                            'email' => $student->email,
                                            'phone' => $student->phone,
                                        ]))"
                                    >
                                        <i class="fa-solid fa-pen"></i> Edit
                                    </button>
                                    @endif
                                    <button 
                                        type="button" 
                                        class="btn btn-sm btn-secondary" 
                                        title="View Student Barcode"
                                        onclick="showStudentBarcode(@js($student->student_id), @js($student->full_name), @js($student->program?->name))"
                                    >
                                        <i class="fa-solid fa-barcode"></i> Barcode
                                    </button>
                                    @if(auth()->user()?->isSuperAdmin())
                                    <form action="{{ route('students.destroy', $student) }}" method="POST" onsubmit="return confirm('Archive this student from the active roster? Attendance and certificate history will be preserved.')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm" style="color: var(--danger); background: transparent;" title="Archive student">
                                            <i class="fa-solid fa-box-archive"></i>
                                        </button>
                                    </form>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 32px;">
                                No student records matched your search filters.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div style="padding: 16px 24px; border-top: 1px solid var(--card-border-subtle); display: flex; justify-content: space-between; align-items: center;">
            <div style="font-size: 12px; color: var(--text-muted);">
                Showing {{ $students->firstItem() ?? 0 }} to {{ $students->lastItem() ?? 0 }} of {{ number_format($students->total()) }} students
            </div>
            <div>
                {{ $students->links() }}
            </div>
        </div>
    </div>

</div>

<!-- New Student Modal -->
<div class="modal-overlay" id="newStudentModal">
    <div class="modal-container">
        <div class="modal-header">
            <h3 class="modal-title">Register New Student</h3>
            <button type="button" class="modal-close" onclick="closeNewStudentModal()">&times;</button>
        </div>
        <form action="{{ route('students.store') }}" method="POST">
            @csrf
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label" for="st_id">Student ID / Barcode *</label>
                    <input type="text" name="student_id" id="st_id" class="form-control" placeholder="e.g. 2024999" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="st_name">Full Name *</label>
                    <input type="text" name="full_name" id="st_name" class="form-control" placeholder="Last Name, First Name M.I." required>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label" for="st_prog">Program</label>
                        <select name="program_id" id="st_prog" class="form-select">
                            <option value="">Select Program</option>
                            @foreach($programs as $p)
                                <option value="{{ $p->id }}">{{ $p->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="st_org">Organization</label>
                        <select name="organization_id" id="st_org" class="form-select">
                            <option value="">Select Organization</option>
                            @foreach($organizations as $o)
                                <option value="{{ $o->id }}">{{ $o->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label" for="st_year">Year Level</label>
                        <input type="text" name="year_level" id="st_year" class="form-control" placeholder="e.g. First Year">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="st_block">Block</label>
                        <input type="text" name="block" id="st_block" class="form-control" placeholder="e.g. A">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="st_phone">Phone Number</label>
                    <input type="text" name="phone" id="st_phone" class="form-control" placeholder="09xxxxxxxxx">
                </div>

                <div class="form-group">
                    <label class="form-label" for="st_email">Email Address</label>
                    <input type="email" name="email" id="st_email" class="form-control" placeholder="student@psu.edu.ph">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeNewStudentModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Student</button>
            </div>
        </form>
    </div>
</div>

<!-- Import Student Roster Modal -->
<div class="modal-overlay" id="importStudentModal">
    <div class="modal-container" style="max-width: 620px;">
        <div class="modal-header">
            <h3 class="modal-title">Import Student Roster</h3>
            <button type="button" class="modal-close" onclick="closeImportStudentModal()">&times;</button>
        </div>
        <form action="{{ route('students.import') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="modal-body">
                <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 14px;">
                    Upload a CSV roster. Existing student numbers will be updated; new courses and organizations will be added automatically. Year and block are stored separately.
                </p>
                <div class="form-group">
                    <label class="form-label" for="student_file">CSV File *</label>
                    <input type="file" name="student_file" id="student_file" class="form-control" accept=".csv,text/csv" required>
                </div>
                <p style="font-size: 12px; color: var(--text-muted);">
                    Required columns: Student Number, Full Name, Course. Optional: Year Level, Block, Organization, Email, Phone.
                    <a href="{{ route('students.template') }}">Download CSV template</a>.
                    Maximum 5,000 rows and 10 MB per upload.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeImportStudentModal()">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-upload"></i> Import Students</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Student Modal -->
<div class="modal-overlay" id="editStudentModal">
    <div class="modal-container">
        <div class="modal-header">
            <h3 class="modal-title">Edit Student Details</h3>
            <button type="button" class="modal-close" onclick="closeEditStudentModal()">&times;</button>
        </div>
        <form id="editStudentForm" method="POST">
            @csrf
            @method('PUT')
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label" for="edit_st_id">Student Number / Barcode</label>
                    <input type="text" id="edit_st_id" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label" for="edit_st_name">Full Name *</label>
                    <input type="text" name="full_name" id="edit_st_name" class="form-control" required>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label" for="edit_st_prog">Course / Program</label>
                        <select name="program_id" id="edit_st_prog" class="form-select">
                            <option value="">Select Program</option>
                            @foreach($programs as $p)
                                <option value="{{ $p->id }}">{{ $p->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="edit_st_org">Organization</label>
                        <select name="organization_id" id="edit_st_org" class="form-select">
                            <option value="">Select Organization</option>
                            @foreach($organizations as $o)
                                <option value="{{ $o->id }}">{{ $o->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px;">
                    <div class="form-group">
                        <label class="form-label" for="edit_st_year">Year Level</label>
                        <input type="text" name="year_level" id="edit_st_year" class="form-control" placeholder="e.g. Second Year">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="edit_st_block">Block</label>
                        <input type="text" name="block" id="edit_st_block" class="form-control" placeholder="e.g. A">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="edit_st_email">Email Address</label>
                    <input type="email" name="email" id="edit_st_email" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label" for="edit_st_phone">Phone Number</label>
                    <input type="text" name="phone" id="edit_st_phone" class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEditStudentModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<!-- Student Barcode Modal -->
<div class="modal-overlay" id="studentBarcodeModal">
    <div class="modal-container" style="max-width: 400px; text-align: center;">
        <div class="modal-header">
            <h3 class="modal-title">Student Digital Pass</h3>
            <button type="button" class="modal-close" onclick="closeStudentBarcodeModal()">&times;</button>
        </div>
        <div class="modal-body" style="padding: 28px;">
            <h4 id="barcodeModalName" style="font-size: 18px; font-weight: 800; color: var(--text-main);"></h4>
            <div id="barcodeModalId" style="font-family: 'JetBrains Mono', monospace; font-size: 14px; font-weight: 700; color: var(--primary); margin-top: 4px;"></div>
            <div id="barcodeModalProg" class="badge badge-primary" style="margin-top: 8px;"></div>

            <div style="margin: 24px auto; padding: 16px; background: #ffffff; border: 2px dashed #cbd5e1; border-radius: 12px; display: inline-block; max-width: 100%; overflow-x: auto;">
                <svg id="studentBarcode" role="img" aria-label="Student ID barcode" style="display: block; max-width: 100%; height: auto;"></svg>
            </div>

            <p style="font-size: 12px; color: var(--text-muted);">
                Scan this barcode with the event scanner. The barcode contains the student ID shown above.
            </p>
        </div>
        <div class="modal-footer" style="justify-content: center;">
            <button type="button" class="btn btn-primary" onclick="printStudentBarcode()">
                <i class="fa-solid fa-print"></i> Print Barcode
            </button>
            <button type="button" class="btn btn-secondary" onclick="closeStudentBarcodeModal()">Close</button>
        </div>
    </div>
</div>

@push('scripts')
<script>
    function openNewStudentModal() {
        document.getElementById('newStudentModal').classList.add('active');
    }
    function closeNewStudentModal() {
        document.getElementById('newStudentModal').classList.remove('active');
    }
    function openImportStudentModal() {
        document.getElementById('importStudentModal').classList.add('active');
    }
    function closeImportStudentModal() {
        document.getElementById('importStudentModal').classList.remove('active');
    }
    function openEditStudentModal(student) {
        const form = document.getElementById('editStudentForm');
        form.action = @js(url('/students')) + '/' + student.id;
        document.getElementById('edit_st_id').value = student.student_id || '';
        document.getElementById('edit_st_name').value = student.full_name || '';
        document.getElementById('edit_st_prog').value = student.program_id || '';
        document.getElementById('edit_st_org').value = student.organization_id || '';
        document.getElementById('edit_st_year').value = student.year_level || '';
        document.getElementById('edit_st_block').value = student.block || '';
        document.getElementById('edit_st_email').value = student.email || '';
        document.getElementById('edit_st_phone').value = student.phone || '';
        document.getElementById('editStudentModal').classList.add('active');
    }
    function closeEditStudentModal() {
        document.getElementById('editStudentModal').classList.remove('active');
    }

    function showStudentBarcode(id, name, prog) {
        document.getElementById('barcodeModalName').textContent = name;
        document.getElementById('barcodeModalId').textContent = id;
        document.getElementById('barcodeModalProg').textContent = prog || 'Pangasinan State University Student';

        const encodedId = String(id);
        const barcode = document.getElementById('studentBarcode');
        barcode.replaceChildren();
        barcode.style.display = 'block';
        document.getElementById('barcodeModalProg').className = 'badge badge-primary';
        try {
            window.JsBarcode(barcode, encodedId, {
                format: 'CODE128',
                lineColor: '#07152d',
                background: '#ffffff',
                width: 2,
                height: 72,
                margin: 16,
                displayValue: true,
                font: 'monospace',
                fontSize: 14,
            });
            barcode.setAttribute('aria-label', `Code 128 barcode for student ID ${id}`);
        } catch {
            barcode.replaceChildren();
            barcode.style.display = 'none';
            barcode.setAttribute('aria-label', 'Barcode unavailable for this student ID');
            document.getElementById('barcodeModalProg').textContent = 'This student ID cannot be encoded as a Code 128 barcode.';
            document.getElementById('barcodeModalProg').className = 'badge badge-warning';
        }
        document.getElementById('studentBarcodeModal').classList.add('active');
    }
    function printStudentBarcode() {
        const barcode = document.getElementById('studentBarcode');
        if (!barcode?.children.length) return;

        const printWindow = window.open('', '_blank', 'width=640,height=420');
        if (!printWindow) {
            window.alert('Allow pop-ups to print the student barcode.');
            return;
        }

        printWindow.document.open();
        printWindow.document.write('<!doctype html><html><head><title>Student Barcode Pass</title><style>body{font-family:Arial,sans-serif;text-align:center;padding:32px;color:#0f172a}svg{max-width:100%;height:auto}.student-id{font-family:monospace;font-size:18px;font-weight:bold;margin:8px 0 20px}@media print{body{padding:0}}</style></head><body><main></main></body></html>');
        printWindow.document.close();

        const main = printWindow.document.querySelector('main');
        const name = printWindow.document.createElement('h2');
        name.textContent = document.getElementById('barcodeModalName').textContent;
        const id = printWindow.document.createElement('div');
        id.className = 'student-id';
        id.textContent = document.getElementById('barcodeModalId').textContent;
        main.append(name, id, printWindow.document.importNode(barcode, true));

        printWindow.setTimeout(() => {
            printWindow.focus();
            printWindow.print();
        }, 250);
    }
    function closeStudentBarcodeModal() {
        document.getElementById('studentBarcodeModal').classList.remove('active');
    }
</script>
@endpush
@endsection
