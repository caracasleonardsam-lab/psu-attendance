<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? 'Pangasinan State University Attendance System' }} | Pangasinan State University</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    @vite('resources/js/app.js')
    
    <style>
        :root {
            --sidebar-bg: #1259c3;
            --sidebar-alt: #0e469b;
            --sidebar-border: rgba(255, 255, 255, 0.08);
            --sidebar-text: #e2e8f0;
            --sidebar-text-muted: #dbeafe;
            
            --bg-page: #ffffff;
            --card-bg: #ffffff;
            --card-border: #e2e8f0;
            --card-border-subtle: #edf2f7;
            
            --primary: #1259c3;
            --primary-hover: #0e469b;
            --primary-light: #2563eb;
            --primary-soft: #eff6ff;
            
            --gold: #f59e0b;
            --gold-hover: #d97706;
            --gold-soft: #fef3c7;
            --gold-dark: #b45309;
            
            --success: #10b981;
            --success-soft: #ecfdf5;
            --success-dark: #065f46;
            
            --warning: #f59e0b;
            --warning-soft: #fffbeb;
            --warning-dark: #92400e;
            
            --danger: #ef4444;
            --danger-soft: #fef2f2;
            --danger-dark: #991b1b;
            
            --text-main: #0f172a;
            --text-muted: #64748b;
            --text-light: #94a3b8;
            
            --line: #e2e8f0;
            --shadow-sm: 0 1px 3px rgba(15, 23, 42, 0.06), 0 1px 2px rgba(15, 23, 42, 0.04);
            --shadow-md: 0 4px 20px -2px rgba(15, 23, 42, 0.06), 0 2px 6px -1px rgba(15, 23, 42, 0.04);
            --shadow-lg: 0 12px 30px -4px rgba(15, 23, 42, 0.08), 0 4px 12px -2px rgba(15, 23, 42, 0.04);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
        }

        [data-theme="dark"] {
            --bg-page: #080f1e;
            --card-bg: #0f1c33;
            --card-border: #1e2e4a;
            --card-border-subtle: #16243d;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --text-light: #64748b;
            --line: #1e2e4a;
            --primary-soft: rgba(18, 89, 195, 0.25);
            --gold-soft: rgba(245, 158, 11, 0.22);
            --success-soft: rgba(16, 185, 129, 0.2);
            --danger-soft: rgba(239, 68, 68, 0.2);
            --warning-soft: rgba(245, 158, 11, 0.2);
        }

        [data-theme="dark"] .card {
            background: var(--card-bg);
            border-color: var(--card-border);
        }

        [data-theme="dark"] .top-navbar {
            background: rgba(15, 28, 51, 0.85);
            border-color: var(--line);
        }

        [data-theme="dark"] .table th {
            background: #091325;
            border-color: var(--line);
            color: var(--text-muted);
        }

        [data-theme="dark"] .table td {
            border-color: var(--card-border-subtle);
            color: var(--text-main);
        }

        [data-theme="dark"] .table tbody tr:hover {
            background: rgba(255, 255, 255, 0.035);
        }

        [data-theme="dark"] .form-control, [data-theme="dark"] .form-select {
            background: #091325;
            border-color: var(--card-border);
            color: var(--text-main);
        }

        [data-theme="dark"] .btn-secondary {
            background: #172640;
            color: #e2e8f0;
            border-color: #263c61;
        }

        [data-theme="dark"] .btn-secondary:hover {
            background: #1f3354;
            color: #ffffff;
        }

        [data-theme="dark"] .modal-container {
            background: #0f1c33;
            border-color: var(--card-border);
        }

        [data-theme="dark"] .modal-header, [data-theme="dark"] .modal-footer {
            border-color: var(--line);
            background: #091325;
        }

        [data-theme="dark"] .card-footer {
            background: #091325 !important;
            border-color: var(--line) !important;
        }

        [data-theme="dark"] .settings-help-box {
            background: #091325;
            border-color: #1e2e4a;
        }

        [data-theme="dark"] .badge-neutral {
            background: #172640;
            color: #94a3b8;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
            background: var(--bg-page);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            font-size: 14px;
            line-height: 1.5;
        }

        /* Sidebar */
        .sidebar {
            width: 270px;
            background: linear-gradient(180deg, var(--sidebar-bg) 0%, var(--sidebar-alt) 100%);
            color: var(--sidebar-text);
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
            position: sticky;
            top: 0;
            height: 100vh;
            border-right: 1px solid var(--sidebar-border);
            z-index: 50;
            overflow-y: auto;
            transition: width 0.22s ease;
        }

        .sidebar.is-collapsed {
            width: 76px;
        }

        .sidebar-brand {
            padding: 16px 14px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid var(--sidebar-border);
            background: rgba(7, 21, 45, 0.12);
        }

        .sidebar-brand-identity {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
        }

        .sidebar:not(.is-collapsed) .sidebar-brand {
            flex-direction: row;
            justify-content: flex-start;
        }

        .sidebar:not(.is-collapsed) .sidebar-brand-identity {
            justify-content: flex-start;
            width: auto;
        }

        .sidebar:not(.is-collapsed) .sidebar-toggle {
            order: -1;
        }

        .sidebar-toggle {
            width: 38px;
            height: 38px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            border: 1px solid rgba(255, 255, 255, 0.14);
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.08);
            color: #ffffff;
            cursor: pointer;
            transition: background 0.2s ease, border-color 0.2s ease;
        }

        .sidebar-toggle:hover,
        .sidebar-toggle:focus-visible {
            background: rgba(255, 255, 255, 0.16);
            border-color: rgba(255, 255, 255, 0.3);
            outline: none;
        }

        .brand-logo {
            width: 44px;
            height: 44px;
            background: transparent;
            padding: 0;
            object-fit: contain;
            filter: drop-shadow(0 2px 8px rgba(245, 158, 11, 0.3));
        }

        .brand-text h2 {
            font-size: 15px;
            font-weight: 800;
            letter-spacing: -0.01em;
            color: #ffffff;
            line-height: 1.2;
        }

        .brand-text span {
            font-size: 11px;
            color: var(--gold);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .sidebar-nav {
            padding: 16px 12px;
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .nav-category {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #fde68a;
            padding: 12px 12px 6px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            border-radius: var(--radius-sm);
            color: var(--sidebar-text-muted);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .nav-item i {
            font-size: 15px;
            width: 20px;
            text-align: center;
            flex-shrink: 0;
        }

        .nav-item:hover {
            color: #ffffff;
            background: rgba(245, 158, 11, 0.2);
            transform: translateX(2px);
        }

        .nav-item.active {
            color: #12305b;
            background: linear-gradient(90deg, #fbbf24, #f59e0b);
            box-shadow: 0 4px 12px rgba(7, 21, 45, 0.2);
            font-weight: 600;
        }

        .nav-item.active i {
            color: #12305b;
        }

        .sidebar.is-collapsed .sidebar-brand {
            flex-direction: column;
            justify-content: center;
            padding: 14px 8px;
        }

        .sidebar.is-collapsed .sidebar-brand-identity {
            width: auto;
        }

        .sidebar.is-collapsed .sidebar-toggle {
            order: 1;
        }

        .sidebar.is-collapsed .brand-text,
        .sidebar.is-collapsed .nav-category,
        .sidebar.is-collapsed .nav-item span,
        .sidebar.is-collapsed .user-details {
            display: none;
        }

        .sidebar.is-collapsed .sidebar-nav {
            align-items: center;
            padding: 14px 8px;
        }

        .sidebar.is-collapsed .nav-item {
            width: 48px;
            height: 46px;
            justify-content: center;
            padding: 0;
            border-radius: 12px;
        }

        .sidebar.is-collapsed .nav-item:hover {
            transform: none;
        }

        .sidebar.is-collapsed .nav-item i {
            width: auto;
            font-size: 17px;
        }

        .sidebar-user {
            padding: 16px;
            border-top: 1px solid var(--sidebar-border);
            background: rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: var(--gold);
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 13px;
            border: 2px solid #fde68a;
        }

        .user-details h4 {
            font-size: 13px;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.2;
        }

        .user-details span {
            font-size: 11px;
            color: var(--sidebar-text-muted);
            text-transform: capitalize;
        }

        .btn-logout {
            background: transparent;
            border: none;
            color: var(--sidebar-text-muted);
            font-size: 16px;
            cursor: pointer;
            padding: 6px;
            border-radius: 6px;
            transition: all 0.2s;
        }

        .btn-logout:hover {
            color: var(--danger);
            background: rgba(239, 68, 68, 0.1);
        }

        .sidebar.is-collapsed .sidebar-user {
            flex-direction: column;
            gap: 12px;
            padding: 14px 8px;
        }

        .sidebar.is-collapsed .user-info {
            justify-content: center;
        }

        .sidebar.is-collapsed .sidebar-user form,
        .sidebar.is-collapsed .btn-logout {
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .sidebar-tooltip {
            position: fixed;
            z-index: 1000;
            max-width: 220px;
            padding: 7px 10px;
            border-radius: 7px;
            background: #0b1a30;
            color: #ffffff;
            font-size: 12px;
            font-weight: 600;
            line-height: 1.3;
            white-space: nowrap;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.24);
            pointer-events: none;
            opacity: 0;
            transform: translateY(-50%) translateX(-4px);
            transition: opacity 0.12s ease, transform 0.12s ease;
        }

        .sidebar-tooltip.is-visible {
            opacity: 1;
            transform: translateY(-50%) translateX(0);
        }

        /* Main Content */
        .main-wrapper {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
            overflow-x: hidden;
        }

        /* Glassmorphic Top Navbar */
        .top-navbar {
            height: 64px;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-bottom: 1px solid var(--line);
            padding: 0 28px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 40;
            box-shadow: 0 1px 4px rgba(0,0,0,0.03);
            transition: background 0.25s ease, border-color 0.25s ease;
        }

        .live-clock-pill {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            font-size: 12px;
            font-weight: 700;
            font-family: 'JetBrains Mono', monospace;
            color: var(--text-muted);
            background: var(--card-border-subtle);
            padding: 5px 12px;
            border-radius: 999px;
            border: 1px solid var(--card-border);
        }

        .top-navbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .page-header-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-main);
        }

        .campus-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: var(--gold-soft);
            color: var(--gold-dark);
            font-size: 12px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 999px;
            border: 1px solid rgba(245, 158, 11, 0.25);
        }

        .top-navbar-right {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .content-area {
            padding: 28px;
            flex: 1;
        }

        /* Utility Cards */
        .card {
            background: #ffffff;
            border: 1px solid var(--card-border);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            margin-bottom: 24px;
        }

        .card-header {
            padding: 18px 24px;
            border-bottom: 1px solid var(--card-border-subtle);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-title {
            font-size: 16px;
            font-weight: 700;
            color: var(--text-main);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-body {
            padding: 24px;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 9px 16px;
            font-size: 13px;
            font-weight: 600;
            border-radius: var(--radius-sm);
            border: 1px solid transparent;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            line-height: 1.2;
        }

        .btn-primary {
            background: var(--primary);
            color: #ffffff;
            box-shadow: 0 2px 6px rgba(18, 89, 195, 0.25);
        }

        .btn-primary:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
        }

        .btn-success {
            background: var(--success);
            color: #ffffff;
        }

        .btn-success:hover {
            background: #059669;
        }

        .btn-gold {
            background: var(--gold);
            color: #ffffff;
        }

        .btn-gold:hover {
            background: var(--gold-hover);
        }

        .btn-danger {
            background: var(--danger);
            color: #ffffff;
        }

        .btn-secondary {
            background: #f1f5f9;
            color: var(--text-main);
            border-color: #cbd5e1;
        }

        .btn-secondary:hover {
            background: #e2e8f0;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }

        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 8px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .badge-success { background: var(--success-soft); color: var(--success-dark); }
        .badge-warning { background: var(--warning-soft); color: var(--warning-dark); }
        .badge-danger { background: var(--danger-soft); color: var(--danger-dark); }
        .badge-primary { background: var(--primary-soft); color: var(--primary); }
        .badge-neutral { background: #f1f5f9; color: #475569; }

        /* Tables */
        .table-responsive {
            overflow-x: auto;
            border-radius: var(--radius-sm);
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        .table th {
            background: #f8fafc;
            color: var(--text-muted);
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 12px 16px;
            border-bottom: 1px solid var(--line);
        }

        .table td {
            padding: 14px 16px;
            border-bottom: 1px solid var(--card-border-subtle);
            font-size: 13px;
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background: #f8fafc;
        }

        /* Form Controls */
        .form-group {
            margin-bottom: 16px;
        }

        .form-label {
            display: block;
            font-size: 12px;
            font-weight: 700;
            color: var(--text-main);
            margin-bottom: 6px;
        }

        .form-control, .form-select {
            width: 100%;
            padding: 9px 14px;
            font-size: 13px;
            border: 1px solid var(--card-border);
            border-radius: var(--radius-sm);
            background: #ffffff;
            color: var(--text-main);
            transition: all 0.2s;
            font-family: inherit;
        }

        .form-control:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary-light);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
        }

        /* Alerts */
        .alert {
            padding: 14px 18px;
            border-radius: var(--radius-sm);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 13px;
            font-weight: 500;
        }

        .alert-success {
            background: var(--success-soft);
            color: var(--success-dark);
            border: 1px solid rgba(16, 185, 129, 0.25);
        }

        .alert-danger {
            background: var(--danger-soft);
            color: var(--danger-dark);
            border: 1px solid rgba(239, 68, 68, 0.25);
        }

        .alert-warning {
            background: var(--warning-soft);
            color: var(--warning-dark);
            border: 1px solid rgba(245, 158, 11, 0.25);
        }

        /* Modal backdrop & container */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 100;
            padding: 20px;
        }

        .modal-overlay.active {
            display: flex;
        }

        .modal-container {
            background: #ffffff;
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-xl);
            width: 100%;
            max-width: 560px;
            max-height: 90vh;
            overflow-y: auto;
            border: 1px solid var(--card-border);
        }

        .modal-header {
            padding: 18px 24px;
            border-bottom: 1px solid var(--line);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .modal-title {
            font-size: 16px;
            font-weight: 700;
            color: var(--text-main);
        }

        .modal-close {
            background: transparent;
            border: none;
            font-size: 18px;
            color: var(--text-muted);
            cursor: pointer;
        }

        .modal-body {
            padding: 24px;
        }

        .modal-footer {
            padding: 16px 24px;
            border-top: 1px solid var(--line);
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            background: #f8fafc;
        }
    </style>
    @stack('styles')
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar is-collapsed" id="appSidebar">
        <div class="sidebar-brand">
            <div class="sidebar-brand-identity">
                <img src="{{ asset('images/logo.png') }}" alt="Pangasinan State University Seal" class="brand-logo" onerror="this.src='{{ asset('images/psu_logo.jpg') }}'">
                <div class="brand-text">
                    <h2>Pangasinan State University Attendance</h2>
                    <span>Alaminos City Campus</span>
                </div>
            </div>
            <button type="button" class="sidebar-toggle" id="sidebarToggle"
                    aria-label="Expand navigation" aria-expanded="false">
                <i class="fa-solid fa-bars" aria-hidden="true"></i>
            </button>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-category">Main Menu</div>
            <a href="{{ route('dashboard') }}" class="nav-item {{ request()->routeIs('dashboard') ? 'active' : '' }}" data-tooltip="Dashboard" aria-label="Dashboard">
                <i class="fa-solid fa-gauge-high" aria-hidden="true"></i>
                <span>Dashboard</span>
            </a>
            <a href="{{ route('attendance.scanner') }}" class="nav-item {{ request()->routeIs('attendance.scanner') ? 'active' : '' }}" data-tooltip="Barcode Scanner" aria-label="Barcode Scanner">
                <i class="fa-solid fa-barcode" aria-hidden="true"></i>
                <span>Barcode Scanner</span>
            </a>
            @if(Auth::user()?->isAdmin())
                <a href="{{ route('events.index') }}" class="nav-item {{ request()->routeIs('events.*') ? 'active' : '' }}" data-tooltip="Events" aria-label="Events">
                    <i class="fa-solid fa-calendar-check" aria-hidden="true"></i>
                    <span>Events</span>
                </a>
            @endif
            @if(Auth::user()?->isSuperAdmin())
                <a href="{{ route('evaluations.index') }}" class="nav-item {{ request()->routeIs('evaluations.index', 'evaluations.create', 'evaluations.edit') ? 'active' : '' }}" data-tooltip="Evaluation Management" aria-label="Evaluation Management">
                    <i class="fa-solid fa-clipboard-question" aria-hidden="true"></i>
                    <span>Evaluation Management</span>
                </a>
            @endif
            @if(Auth::user()?->isAdmin() || Auth::user()?->isOfficer())
                <a href="{{ route('evaluations.results') }}" class="nav-item {{ request()->routeIs('evaluations.results') ? 'active' : '' }}" data-tooltip="Evaluation Results" aria-label="Evaluation Results">
                    <i class="fa-solid fa-chart-bar" aria-hidden="true"></i>
                    <span>Evaluation Results</span>
                </a>
            @endif
            @if(Auth::user()?->isAdmin())
                <a href="{{ route('attendance.index') }}" class="nav-item {{ request()->routeIs('attendance.index', 'attendance.trash') ? 'active' : '' }}" data-tooltip="Attendance Log" aria-label="Attendance Log">
                    <i class="fa-solid fa-clipboard-user" aria-hidden="true"></i>
                    <span>Attendance Log</span>
                </a>
            @endif

            <div class="nav-category">Student & Campus</div>
            @if(Auth::user()?->isAdmin())
                <a href="{{ route('students.index') }}" class="nav-item {{ request()->routeIs('students.*') ? 'active' : '' }}" data-tooltip="Students Roster" aria-label="Students Roster">
                    <i class="fa-solid fa-user-graduate" aria-hidden="true"></i>
                    <span>Students Roster</span>
                </a>
                <a href="{{ route('organizations.index') }}" class="nav-item {{ request()->routeIs('organizations.*') ? 'active' : '' }}" data-tooltip="Organization Management" aria-label="Organization Management">
                    <i class="fa-solid fa-sitemap" aria-hidden="true"></i>
                    <span>Organization Management</span>
                </a>
            @endif
            @if(Auth::user()?->isAdmin())
                <a href="{{ route('presence.index') }}" class="nav-item {{ request()->routeIs('presence.*') ? 'active' : '' }}" data-tooltip="Presence & Geofence" aria-label="Presence & Geofence">
                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                    <span>Presence & Geofence</span>
                </a>
            @endif

            <div class="nav-category">Management & Analytics</div>
            @if(Auth::user()?->isAdmin())
                <a href="{{ route('reports.index') }}" class="nav-item {{ request()->routeIs('reports.*') ? 'active' : '' }}" data-tooltip="Reports & Analytics" aria-label="Reports & Analytics">
                    <i class="fa-solid fa-chart-pie" aria-hidden="true"></i>
                    <span>Reports & Analytics</span>
                </a>
            @endif
            @if(Auth::user()?->isSuperAdmin())
                <a href="{{ route('logs.index') }}" class="nav-item {{ request()->routeIs('logs.*') ? 'active' : '' }}" data-tooltip="Audit Logs" aria-label="Audit Logs">
                    <i class="fa-solid fa-clock-rotate-left" aria-hidden="true"></i>
                    <span>Audit Logs</span>
                </a>
            @endif
            @if(Auth::user()?->isSuperAdmin())
                <a href="{{ route('settings.index') }}" class="nav-item {{ request()->routeIs('settings.*') ? 'active' : '' }}" data-tooltip="System Settings" aria-label="System Settings">
                    <i class="fa-solid fa-sliders" aria-hidden="true"></i>
                    <span>System Settings</span>
                </a>
            @endif
        </nav>

        <div class="sidebar-user">
            <div class="user-info">
                <div class="user-avatar">
                    {{ strtoupper(substr(Auth::user()->name ?? 'U', 0, 1)) }}
                </div>
                <div class="user-details">
                    <h4>{{ Auth::user()->name ?? 'User' }}</h4>
                    <span>{{ Auth::user()->role ?? 'Admin' }}</span>
                </div>
            </div>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="btn-logout" data-tooltip="Log Out" aria-label="Log Out">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </button>
            </form>
        </div>
    </aside>

    <!-- Main Content Wrapper -->
    <div class="main-wrapper">
        <header class="top-navbar">
            <div class="top-navbar-left">
                <h1 class="page-header-title">@yield('page_title', 'Attendance Management')</h1>
                <div class="campus-pill">
                    <i class="fa-solid fa-shield-halved"></i>
                    <span>{{ \App\Models\SystemSetting::get('campus_name', 'Pangasinan State University - Alaminos City Campus') }}</span>
                </div>
            </div>
            <div class="top-navbar-right">
                <div style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--success-dark); background: var(--success-soft); padding: 5px 12px; border-radius: 999px; font-weight: 600; border: 1px solid rgba(16, 185, 129, 0.2);">
                    <span style="width: 7px; height: 7px; border-radius: 50%; background: var(--success); display: inline-block;"></span>
                    <span>Live Attendance Online</span>
                </div>
                <div class="live-clock-pill" title="Live System Time">
                    <i class="fa-regular fa-clock" style="color: var(--primary);"></i>
                    <span id="topLiveClock">{{ now()->format('h:i:s A') }}</span>
                </div>
            </div>
        </header>

        <main class="content-area">
            @if(session('success'))
                <div class="alert alert-success">
                    <i class="fa-solid fa-circle-check"></i>
                    <span>{{ session('success') }}</span>
                </div>
            @endif

            @if(session('warning'))
                <div class="alert alert-warning">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    <span>{{ session('warning') }}</span>
                </div>
            @endif

            @if(session('error'))
                <div class="alert alert-danger">
                    <i class="fa-solid fa-circle-xmark"></i>
                    <span>{{ session('error') }}</span>
                </div>
            @endif

            @if($errors->any())
                <div class="alert alert-danger">
                    <i class="fa-solid fa-circle-xmark"></i>
                    <div>
                        @foreach($errors->all() as $error)
                            <div>{{ $error }}</div>
                        @endforeach
                    </div>
                </div>
            @endif

            @yield('content')
        </main>
    </div>

    <script>
        const appSidebar = document.getElementById('appSidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebarTooltip = document.createElement('div');
        sidebarTooltip.className = 'sidebar-tooltip';
        sidebarTooltip.setAttribute('role', 'tooltip');
        document.body.appendChild(sidebarTooltip);

        function setSidebarCollapsed(collapsed) {
            appSidebar.classList.toggle('is-collapsed', collapsed);
            sidebarToggle.setAttribute('aria-expanded', String(!collapsed));
            sidebarToggle.setAttribute(
                'aria-label',
                collapsed ? 'Expand navigation' : 'Collapse navigation'
            );
            sidebarTooltip.classList.remove('is-visible');
        }

        sidebarToggle.addEventListener('click', () => {
            setSidebarCollapsed(!appSidebar.classList.contains('is-collapsed'));
        });

        appSidebar.querySelectorAll('[data-tooltip]').forEach((item) => {
            const showTooltip = () => {
                if (!appSidebar.classList.contains('is-collapsed')) return;
                const bounds = item.getBoundingClientRect();
                sidebarTooltip.textContent = item.dataset.tooltip;
                sidebarTooltip.style.left = `${bounds.right + 10}px`;
                sidebarTooltip.style.top = `${bounds.top + bounds.height / 2}px`;
                sidebarTooltip.classList.add('is-visible');
            };
            const hideTooltip = () => sidebarTooltip.classList.remove('is-visible');

            item.addEventListener('mouseenter', showTooltip);
            item.addEventListener('mouseleave', hideTooltip);
            item.addEventListener('focus', showTooltip);
            item.addEventListener('blur', hideTooltip);
        });

        function updateLiveClock() {
            const clockEl = document.getElementById('topLiveClock');
            if (!clockEl) return;
            const now = new Date();
            clockEl.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
        }
        setInterval(updateLiveClock, 1000);

    </script>
    @stack('scripts')
</body>
</html>
