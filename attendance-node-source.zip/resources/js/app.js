import './bootstrap';
import JsBarcode from 'jsbarcode';

window.JsBarcode = JsBarcode;
