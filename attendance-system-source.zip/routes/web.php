<?php

use App\Http\Controllers\ActivityLogController;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CertificateController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\EvaluationController;
use App\Http\Controllers\OrganizationController;
use App\Http\Controllers\PresenceController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\StudentController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// Public Certificate Verification & Direct Viewing (accessible without authentication)
Route::get('/verify-certificate/{code}', [CertificateController::class, 'verify'])->name('certificates.verify');
Route::get('/certificates/{code}', [CertificateController::class, 'showCertificate'])->name('certificates.show');
Route::get('/certificates/{code}/download', [CertificateController::class, 'downloadImage'])->name('certificates.download');

// Legacy query-param router fallback (?page=scanner, ?page=events, etc.)
Route::get('/', function (Request $request) {
    if ($request->has('page')) {
        $page = $request->query('page');

        return match ($page) {
            'login' => redirect()->route('login'),
            'logout' => redirect()->route('logout'),
            'scanner' => redirect()->route('attendance.scanner'),
            'events' => redirect()->route('events.index'),
            'presence' => redirect()->route('presence.index'),
            'students' => redirect()->route('students.index'),
            'organizations' => redirect()->route('organizations.index'),
            'reports' => redirect()->route('reports.index'),
            'activity_logs' => redirect()->route('logs.index'),
            'settings' => redirect()->route('settings.index'),
            'mobile_app' => redirect()->route('dashboard'),
            default => redirect()->route('dashboard'),
        };
    }

    if (Auth::check()) {
        if (Auth::user()->role === 'student') {
            Auth::logout();

            return redirect()->route('login')->withErrors([
                'username' => 'Student accounts must access the system using the Attendance Mobile App.',
            ]);
        }

        return redirect()->route('dashboard');
    }

    return redirect()->route('login');
});

// Authentication routes
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::match(['get', 'post'], '/logout', [AuthController::class, 'logout'])->name('logout');

// Backwards-compatible route for legacy api.php calls
Route::match(['get', 'post'], '/api.php', [ApiController::class, 'handle']);

// Protected routes
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Events
    Route::get('/events', [EventController::class, 'index'])->name('events.index');
    Route::post('/events', [EventController::class, 'store'])->name('events.store');
    Route::get('/events/{event}', [EventController::class, 'show'])->name('events.show');
    Route::put('/events/{event}', [EventController::class, 'update'])->name('events.update');
    Route::post('/events/{event}/evaluation-availability', [EventController::class, 'toggleEvaluation'])->name('events.evaluation.toggle');
    Route::post('/events/{event}/evaluation-report-visibility', [EventController::class, 'toggleEvaluationReportVisibility'])->name('events.evaluation_report_visibility');
    Route::post('/events/{event}/scanning', [EventController::class, 'updateScanning'])->name('events.scanning.update');
    Route::post('/events/{event}/cancel', [EventController::class, 'cancel'])->name('events.cancel');
    Route::put('/events/{event}/reschedule', [EventController::class, 'reschedule'])->name('events.reschedule');
    Route::delete('/events/{event}', [EventController::class, 'destroy'])->name('events.destroy');
    Route::get('/events/{event}/export', [EventController::class, 'exportAttendance'])->name('events.export');
    Route::post('/events/{event}/designations', [EventController::class, 'assignStudentDesignation'])->name('events.designations.assign');
    Route::delete('/events/{event}/designations/{designation}', [EventController::class, 'removeStudentDesignation'])->name('events.designations.remove');

    // Admin: E-Certificate Template Management & Evaluation Analytics
    Route::get('/events/{event}/certificate', [CertificateController::class, 'edit'])->name('events.certificate.setup');
    Route::post('/events/{event}/certificate', [CertificateController::class, 'update'])->name('events.certificate.update');
    Route::get('/events/{event}/certificate/preview', [CertificateController::class, 'preview'])->name('events.certificate.preview');
    Route::get('/events/{event}/certificate/blank-template', [CertificateController::class, 'downloadBlankTemplate'])->name('events.certificate.blank_template');
    Route::get('/events/{event}/evaluations', [CertificateController::class, 'evaluations'])->name('events.evaluations');

    // Dynamic evaluation management. System Admin manages forms; admins can review results.
    Route::get('/evaluations', [EvaluationController::class, 'index'])->name('evaluations.index');
    Route::get('/evaluations/create', [EvaluationController::class, 'create'])->name('evaluations.create');
    Route::post('/evaluations', [EvaluationController::class, 'store'])->name('evaluations.store');
    Route::get('/evaluations/results', [EvaluationController::class, 'results'])->name('evaluations.results');
    Route::get('/evaluations/export', [EvaluationController::class, 'export'])->name('evaluations.export');
    Route::get('/evaluations/{evaluation}/edit', [EvaluationController::class, 'edit'])->name('evaluations.edit');
    Route::put('/evaluations/{evaluation}', [EvaluationController::class, 'update'])->name('evaluations.update');
    Route::post('/evaluations/{evaluation}/publish', [EvaluationController::class, 'togglePublish'])->name('evaluations.publish');

    // Student: Event Evaluation & Automatic E-Certificate Claiming
    Route::get('/events/{event}/evaluate', [CertificateController::class, 'showEvaluation'])->name('events.evaluate');
    Route::post('/events/{event}/evaluate', [CertificateController::class, 'submitEvaluation'])->name('events.evaluate.submit');

    // Attendance & Scanner
    Route::get('/scanner', [AttendanceController::class, 'scanner'])->name('attendance.scanner');
    Route::post('/attendance/scan', [AttendanceController::class, 'recordScan'])->name('attendance.scan');
    Route::get('/attendance/search-students', [AttendanceController::class, 'searchStudents'])->name('attendance.search_students');
    Route::get('/attendance', [AttendanceController::class, 'index'])->name('attendance.index');
    Route::delete('/attendance/{attendance}', [AttendanceController::class, 'destroy'])->name('attendance.destroy');
    Route::get('/attendance/trash', [AttendanceController::class, 'trash'])->name('attendance.trash');
    Route::post('/attendance/{attendance}/restore', [AttendanceController::class, 'restore'])->name('attendance.restore');

    // Students
    Route::get('/students', [StudentController::class, 'index'])->name('students.index');
    Route::get('/students/export', [StudentController::class, 'export'])->name('students.export');
    Route::get('/students/template', [StudentController::class, 'template'])->name('students.template');
    Route::post('/students/import', [StudentController::class, 'import'])->name('students.import');
    Route::post('/students', [StudentController::class, 'store'])->name('students.store');
    Route::put('/students/{student}', [StudentController::class, 'update'])->name('students.update');
    Route::delete('/students/{student}', [StudentController::class, 'destroy'])->name('students.destroy');

    // Organization Management
    Route::get('/organizations', [OrganizationController::class, 'index'])->name('organizations.index');
    Route::get('/organizations/{organization}', [OrganizationController::class, 'show'])->name('organizations.show');
    Route::post('/programs', [OrganizationController::class, 'storeProgram'])->name('programs.store');
    Route::delete('/programs/{program}', [OrganizationController::class, 'destroyProgram'])->name('programs.destroy');
    Route::post('/organizations', [OrganizationController::class, 'storeOrganization'])->name('organizations.store');
    Route::put('/organizations/{organization}', [OrganizationController::class, 'updateOrganization'])->name('organizations.update');
    Route::post('/organizations/{organization}/members', [OrganizationController::class, 'addMember'])->name('organizations.members.store');
    Route::delete('/organizations/{organization}/members/{student}', [OrganizationController::class, 'removeMember'])->name('organizations.members.destroy');
    Route::post('/organizations/{organization}/officers', [OrganizationController::class, 'assignOfficer'])->name('organizations.officers.store');
    Route::delete('/organizations/{organization}/officers/{officer}', [OrganizationController::class, 'removeOfficer'])->name('organizations.officers.destroy');
    Route::delete('/organizations/{organization}', [OrganizationController::class, 'destroyOrganization'])->name('organizations.destroy');

    // Presence & Geofencing
    Route::get('/presence', [PresenceController::class, 'index'])->name('presence.index');
    Route::post('/presence/geofence', [PresenceController::class, 'updateGeofence'])->name('presence.update_geofence');
    Route::put('/presence/{presenceVerification}', [PresenceController::class, 'updateVerification'])
        ->name('presence.verifications.update');
    Route::delete('/presence/{presenceVerification}', [PresenceController::class, 'destroyVerification'])
        ->name('presence.verifications.destroy');

    // Reports & Analytics
    Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
    Route::get('/reports/export', [ReportController::class, 'export'])->name('reports.export');
    Route::get('/reports/print', [ReportController::class, 'printReport'])->name('reports.print');

    // Settings & Administration
    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::post('/settings', [SettingsController::class, 'update'])->name('settings.update');
    Route::post('/settings/general', [SettingsController::class, 'updateGeneral'])->name('settings.update_general');
    Route::post('/settings/attendance', [SettingsController::class, 'updateAttendance'])->name('settings.update_attendance');
    Route::post('/settings/users', [SettingsController::class, 'storeUser'])->name('settings.users.store');
    Route::put('/settings/users/{user}', [SettingsController::class, 'updateUser'])->name('settings.users.update');
    Route::delete('/settings/users/{user}', [SettingsController::class, 'destroyUser'])->name('settings.users.destroy');

    // Activity Logs
    Route::get('/logs', [ActivityLogController::class, 'index'])->name('logs.index');
});
