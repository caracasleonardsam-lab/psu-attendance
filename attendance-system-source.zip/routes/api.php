<?php

use App\Http\Controllers\ApiController;
use App\Http\Controllers\StudentEvaluationApiController;
use Illuminate\Support\Facades\Route;

// Standalone REST routes
Route::post('/login', [ApiController::class, 'login']);
Route::post('/change-password', [ApiController::class, 'changePassword']);
Route::get('/students', [ApiController::class, 'getStudents']);
Route::get('/events', [ApiController::class, 'getEvents']);
Route::get('/history', [ApiController::class, 'getHistory']);
Route::post('/self-checkin', [ApiController::class, 'selfCheckin']);
Route::post('/event-queue', [ApiController::class, 'joinEventQueue']);
Route::get('/student-dashboard', [ApiController::class, 'getStudentDashboard']);
Route::get('/student/evaluations', [StudentEvaluationApiController::class, 'index']);
Route::get('/student/evaluations/{evaluation}', [StudentEvaluationApiController::class, 'show']);
Route::post('/student/evaluations/{evaluation}/responses', [StudentEvaluationApiController::class, 'submit']);

Route::match(['get', 'post'], '/verify-geofence', [ApiController::class, 'pingPresence']);
Route::match(['get', 'post'], '/confirm-location', [ApiController::class, 'pingPresence']);
Route::match(['get', 'post'], '/ping-presence', [ApiController::class, 'pingPresence']);

// Unified action dispatcher (backwards-compatible with legacy API callers)
Route::match(['get', 'post'], '/', [ApiController::class, 'handle']);
Route::match(['get', 'post'], '/dispatch', [ApiController::class, 'handle']);
