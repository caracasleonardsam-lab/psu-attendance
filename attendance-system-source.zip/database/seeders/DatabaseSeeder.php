<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Program;
use App\Models\Organization;
use App\Models\Student;
use App\Models\Event;
use App\Models\Attendance;
use App\Models\ActivityLog;
use App\Models\SystemSetting;
use App\Models\Notification;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use PDO;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $sqlitePath = base_path('legacy_php/storage/attendance_system.sqlite');
        $sqlite = null;

        if (file_exists($sqlitePath)) {
            try {
                $sqlite = new PDO('sqlite:' . $sqlitePath);
                $sqlite->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (\Exception $e) {
                $this->command?->warn('Could not open legacy SQLite database: ' . $e->getMessage());
            }
        }

        // 1. Users
        if ($sqlite) {
            $legacyUsers = $sqlite->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($legacyUsers as $u) {
                User::updateOrCreate(
                    ['username' => $u['username']],
                    [
                        'name' => $u['full_name'] ?? $u['username'],
                        'email' => ($u['username'] ?? 'user') . '@psu.edu.ph',
                        'password' => $u['password_hash'], // Already hashed or compatible
                        'role' => $u['role'] ?? 'admin',
                    ]
                );
            }
        }

        // A fresh production install must provide a private initial admin password.
        if (!User::where('role', 'superadmin')->exists()) {
            $initialAdmin = config('app.initial_superadmin');
            $password = app()->environment('testing') ? 'admin123' : ($initialAdmin['password'] ?? '');

            if (!app()->environment('testing') && strlen($password) < 12) {
                throw new \RuntimeException(
                    'Set INITIAL_SUPERADMIN_PASSWORD to a unique password of at least 12 characters before seeding.'
                );
            }

            User::create([
                'username' => $initialAdmin['username'] ?? 'superadmin',
                'name' => $initialAdmin['name'] ?? 'System Super Admin',
                'email' => $initialAdmin['email'] ?? 'superadmin@psu.edu.ph',
                'password' => Hash::make($password),
                'role' => 'superadmin',
            ]);
        }

        if (app()->environment('testing') && !User::where('username', 'admin')->exists()) {
            User::create([
                'username' => 'admin',
                'name' => 'Campus Admin',
                'email' => 'admin@psu.edu.ph',
                'password' => Hash::make('admin123'),
                'role' => 'admin',
            ]);
        }

        // 2. Organizations
        $orgMap = []; // old id => new id
        if ($sqlite) {
            $legacyOrgs = $sqlite->query("SELECT * FROM organizations ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($legacyOrgs as $o) {
                $org = Organization::firstOrCreate(['name' => $o['name']]);
                $orgMap[$o['id']] = $org->id;
            }
        } else {
            $defaultOrgs = ['DOIT', 'SAHARA', 'LAKBAY', 'SYBA', 'GEG', 'CS', 'TAGNAWA', 'PRIME'];
            foreach ($defaultOrgs as $name) {
                Organization::firstOrCreate(['name' => $name]);
            }
        }

        // 3. Programs
        $programMap = []; // old id => new id
        if ($sqlite) {
            $legacyPrograms = $sqlite->query("SELECT * FROM programs ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($legacyPrograms as $p) {
                $prog = Program::firstOrCreate(['name' => $p['name']]);
                $programMap[$p['id']] = $prog->id;
            }
        } else {
            $defaultPrograms = ['BSIT', 'BSED', 'BSBA', 'BSHM'];
            foreach ($defaultPrograms as $name) {
                Program::firstOrCreate(['name' => $name]);
            }
        }

        // 4. Students
        if ($sqlite) {
            $legacyStudents = $sqlite->query("SELECT * FROM students ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
            $batch = [];
            $now = now();
            foreach ($legacyStudents as $s) {
                $newProgId = isset($s['program_id']) && isset($programMap[$s['program_id']]) ? $programMap[$s['program_id']] : null;
                $newOrgId = isset($s['organization_id']) && isset($orgMap[$s['organization_id']]) ? $orgMap[$s['organization_id']] : null;

                $batch[] = [
                    'student_id' => $s['student_id'],
                    'full_name' => $s['full_name'],
                    'program_id' => $newProgId,
                    'organization_id' => $newOrgId,
                    'year_level' => $s['year_level'] ?? '1A',
                    'email' => $s['email'] ?? ($s['student_id'] . '@psu.edu.ph'),
                    'phone' => $s['phone'] ?? null,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];

                if (count($batch) >= 200) {
                    DB::table('students')->upsert($batch, ['student_id'], ['full_name', 'program_id', 'organization_id', 'year_level', 'email', 'phone', 'updated_at']);
                    $batch = [];
                }
            }
            if (!empty($batch)) {
                DB::table('students')->upsert($batch, ['student_id'], ['full_name', 'program_id', 'organization_id', 'year_level', 'email', 'phone', 'updated_at']);
            }
        }

        // 5. System Settings
        $defaultSettings = [
            'attendance_threshold' => '80',
            'verification_interval' => '15',
            'event_radius_meters' => '100',
            'session_timeout_minutes' => '30',
            'grace_period_minutes' => '15',
            'auto_checkout_enabled' => '1',
            'campus_name' => 'Pangasinan State University - Alaminos City Campus',
            'system_name' => 'PSU Attendance & Presence Verification System',
            'campus_head' => 'Dr. Armando D. Junio',
            'contact_email' => 'alaminos@psu.edu.ph',
            'campus_address' => 'City of Alaminos, Pangasinan 2404',
            'academic_year' => '2025-2026',
            'academic_semester' => '1st Semester',
        ];
        foreach ($defaultSettings as $key => $val) {
            SystemSetting::updateOrCreate(['key_name' => $key], ['value_text' => $val]);
        }

        // 6. Notifications
        if (Notification::count() === 0) {
            $admin = User::where('role', 'admin')->orWhere('role', 'superadmin')->first();
            if ($admin) {
                Notification::create([
                    'user_id' => $admin->id,
                    'type' => 'info',
                    'title' => 'System Migrated to Laravel',
                    'message' => 'The Attendance System has been successfully upgraded to Laravel 12 & MySQL.',
                ]);
            }
        }

        // 7. Activity Logs
        if ($sqlite) {
            $legacyLogs = $sqlite->query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($legacyLogs as $l) {
                ActivityLog::create([
                    'actor' => $l['actor'],
                    'action' => $l['action'],
                    'details' => $l['details'],
                ]);
            }
        } else {
            ActivityLog::log('system', 'System Initialized', 'Laravel attendance system database seeded successfully.');
        }
    }
}
