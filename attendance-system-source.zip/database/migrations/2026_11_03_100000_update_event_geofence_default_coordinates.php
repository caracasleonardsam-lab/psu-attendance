<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('events', function (Blueprint $table) {
            $table->double('latitude')->default(16.115303)->change();
            $table->double('longitude')->default(119.967252)->change();
        });
    }

    public function down(): void
    {
        Schema::table('events', function (Blueprint $table) {
            $table->double('latitude')->default(16.1482)->change();
            $table->double('longitude')->default(119.9851)->change();
        });
    }
};
