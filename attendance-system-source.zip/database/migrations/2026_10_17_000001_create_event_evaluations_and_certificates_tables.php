<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Event Certificate Settings & Templates (configured by Admin)
        Schema::create('event_certificates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->unique()->constrained('events')->cascadeOnDelete();
            $table->string('template_path')->nullable(); // Uploaded image template
            $table->string('title')->default('Certificate of Participation');
            $table->string('sub_title')->nullable()->default('is proudly presented to');
            $table->text('description')->nullable();
            $table->string('signatory_name')->nullable()->default('Dr. Campus Executive Director');
            $table->string('signatory_title')->nullable()->default('Campus Executive Director');
            $table->integer('name_y_position')->default(50); // percentage height (0 - 100)
            $table->integer('font_size')->default(42);
            $table->string('font_color', 20)->default('#07152d');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // Student Event Evaluations (Submitted by student after attending)
        Schema::create('event_evaluations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained('events')->cascadeOnDelete();
            $table->foreignId('student_id')->constrained('students')->cascadeOnDelete();
            $table->integer('rating_content')->default(5); // 1 - 5
            $table->integer('rating_speaker')->default(5); // 1 - 5
            $table->integer('rating_venue')->default(5);   // 1 - 5
            $table->integer('rating_overall')->default(5); // 1 - 5
            $table->text('comments')->nullable();
            $table->text('suggestions')->nullable();
            $table->timestamp('submitted_at')->useCurrent();
            $table->timestamps();

            $table->unique(['event_id', 'student_id']);
        });

        // Issued E-Certificates
        Schema::create('issued_certificates', function (Blueprint $table) {
            $table->id();
            $table->string('certificate_code', 50)->unique();
            $table->foreignId('event_id')->constrained('events')->cascadeOnDelete();
            $table->foreignId('student_id')->constrained('students')->cascadeOnDelete();
            $table->string('student_name');
            $table->timestamp('issued_at')->useCurrent();
            $table->string('file_path')->nullable();
            $table->timestamps();

            $table->unique(['event_id', 'student_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('issued_certificates');
        Schema::dropIfExists('event_evaluations');
        Schema::dropIfExists('event_certificates');
    }
};
