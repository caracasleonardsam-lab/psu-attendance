<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('student_api_tokens', function (Blueprint $table) {
            $table->id();
            $table->foreignId('student_id')->constrained()->cascadeOnDelete();
            $table->string('token_hash', 64)->unique();
            $table->timestamp('expires_at');
            $table->timestamps();

            $table->index(['student_id', 'expires_at']);
        });

        Schema::create('event_queue_entries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained()->cascadeOnDelete();
            $table->foreignId('student_id')->constrained()->cascadeOnDelete();
            $table->timestamp('entered_at');
            $table->double('latitude');
            $table->double('longitude');
            $table->double('accuracy_meters');
            $table->double('distance_meters');
            $table->timestamp('checked_in_at')->nullable();
            $table->timestamp('invalidated_at')->nullable();
            $table->timestamps();

            $table->index(['event_id', 'student_id', 'invalidated_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('event_queue_entries');
        Schema::dropIfExists('student_api_tokens');
    }
};
