<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('evaluation_forms', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained()->cascadeOnDelete();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->timestamp('deadline')->nullable();
            $table->string('eligibility_mode', 20)->default('attended');
            $table->boolean('allow_resubmission')->default(false);
            $table->boolean('is_published')->default(false);
            $table->timestamps();

            $table->index(['event_id', 'is_published']);
        });

        Schema::create('evaluation_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('evaluation_form_id')->constrained()->cascadeOnDelete();
            $table->text('question_text');
            $table->string('question_type', 30);
            $table->boolean('is_required')->default(true);
            $table->unsignedInteger('position')->default(0);
            $table->timestamps();

            $table->index(['evaluation_form_id', 'position']);
        });

        Schema::create('evaluation_options', function (Blueprint $table) {
            $table->id();
            $table->foreignId('evaluation_question_id')->constrained()->cascadeOnDelete();
            $table->string('option_text');
            $table->unsignedInteger('position')->default(0);
            $table->timestamps();

            $table->unique(['evaluation_question_id', 'position']);
        });

        Schema::create('evaluation_responses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('evaluation_form_id')->constrained()->cascadeOnDelete();
            $table->foreignId('student_id')->constrained()->cascadeOnDelete();
            $table->timestamp('submitted_at')->useCurrent();
            $table->timestamps();

            $table->index(['evaluation_form_id', 'student_id', 'submitted_at'], 'evaluation_response_lookup');
        });

        Schema::create('evaluation_answers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('evaluation_response_id')->constrained()->cascadeOnDelete();
            $table->foreignId('evaluation_question_id')->constrained()->cascadeOnDelete();
            $table->foreignId('evaluation_option_id')->nullable()->constrained()->nullOnDelete();
            $table->text('answer_text')->nullable();
            $table->timestamps();

            $table->unique(['evaluation_response_id', 'evaluation_question_id'], 'evaluation_answer_once');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('evaluation_answers');
        Schema::dropIfExists('evaluation_responses');
        Schema::dropIfExists('evaluation_options');
        Schema::dropIfExists('evaluation_questions');
        Schema::dropIfExists('evaluation_forms');
    }
};
