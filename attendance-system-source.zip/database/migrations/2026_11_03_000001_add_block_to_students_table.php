<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('students', function (Blueprint $table) {
            $table->string('block', 20)->nullable()->after('year_level');
        });

        $yearNames = [
            1 => 'First Year',
            2 => 'Second Year',
            3 => 'Third Year',
            4 => 'Fourth Year',
            5 => 'Fifth Year',
            6 => 'Sixth Year',
        ];

        DB::table('students')
            ->select(['id', 'year_level'])
            ->whereNotNull('year_level')
            ->orderBy('id')
            ->chunkById(500, function ($students) use ($yearNames): void {
                foreach ($students as $student) {
                    if (preg_match('/^([1-6])\s*[- ]?\s*([a-z])$/i', trim($student->year_level), $matches)) {
                        DB::table('students')
                            ->where('id', $student->id)
                            ->update([
                                'year_level' => $yearNames[(int) $matches[1]],
                                'block' => strtoupper($matches[2]),
                            ]);
                    }
                }
            });
    }

    public function down(): void
    {
        $yearNumbers = [
            'First Year' => 1,
            'Second Year' => 2,
            'Third Year' => 3,
            'Fourth Year' => 4,
            'Fifth Year' => 5,
            'Sixth Year' => 6,
        ];

        DB::table('students')
            ->select(['id', 'year_level', 'block'])
            ->whereNotNull('block')
            ->orderBy('id')
            ->chunkById(500, function ($students) use ($yearNumbers): void {
                foreach ($students as $student) {
                    $year = $yearNumbers[$student->year_level] ?? null;

                    if ($year !== null) {
                        DB::table('students')
                            ->where('id', $student->id)
                            ->update(['year_level' => $year . strtoupper($student->block)]);
                    }
                }
            });

        Schema::table('students', function (Blueprint $table) {
            $table->dropColumn('block');
        });
    }
};
