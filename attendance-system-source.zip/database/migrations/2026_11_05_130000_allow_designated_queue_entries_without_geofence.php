<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('event_queue_entries', function (Blueprint $table) {
            $table->double('latitude')->nullable()->change();
            $table->double('longitude')->nullable()->change();
            $table->double('accuracy_meters')->nullable()->change();
            $table->double('distance_meters')->nullable()->change();
        });
    }

    public function down(): void
    {
        $hasUnverifiedQueueEntries = DB::table('event_queue_entries')
            ->whereNull('latitude')
            ->orWhereNull('longitude')
            ->orWhereNull('accuracy_meters')
            ->orWhereNull('distance_meters')
            ->exists();
        if ($hasUnverifiedQueueEntries) {
            throw new \RuntimeException(
                'Cannot restore required geofence coordinates while designated queue entries without GPS data exist.'
            );
        }

        Schema::table('event_queue_entries', function (Blueprint $table) {
            $table->double('latitude')->nullable(false)->change();
            $table->double('longitude')->nullable(false)->change();
            $table->double('accuracy_meters')->nullable(false)->change();
            $table->double('distance_meters')->nullable(false)->change();
        });
    }
};
