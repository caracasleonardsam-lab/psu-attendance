<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventStudentDesignation;
use App\Models\Student;
use App\Models\User;
use Tests\TestCase;

class EventDesignationAndStudentExportTest extends TestCase
{
    public function test_event_designation_can_be_assigned_updated_removed_and_exported(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $event = Event::create([
            'name' => 'Designation Test ' . uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'active',
            'venue' => 'Test Venue',
        ]);
        $student = Student::create([
            'student_id' => 'DESIGNATION-' . uniqid(),
            'full_name' => 'Taylor Test Student',
            'year_level' => 'First Year',
            'block' => 'A',
        ]);

        try {
            $this->actingAs($admin)->post(route('events.designations.assign', $event), [
                'student_id' => $student->id,
                'designation' => 'Event Marshal',
            ])->assertRedirect();

            $designation = EventStudentDesignation::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->firstOrFail();

            $this->assertSame('Event Marshal', $designation->designation);

            $this->post(route('events.designations.assign', $event), [
                'student_id' => $student->id,
                'designation' => 'Registration Lead',
            ])->assertRedirect();

            $this->assertSame(
                1,
                EventStudentDesignation::where('event_id', $event->id)
                    ->where('student_id', $student->id)
                    ->count()
            );
            $this->assertDatabaseHas('event_student_designations', [
                'id' => $designation->id,
                'designation' => 'Registration Lead',
            ]);

            Attendance::create([
                'event_id' => $event->id,
                'student_id' => $student->id,
                'status' => 'present',
                'scanned_at' => now(),
            ]);

            $this->get(route('events.show', $event))
                ->assertOk()
                ->assertSee('Student Designations')
                ->assertSee('Registration Lead')
                ->assertSee('Designation');

            $csv = $this->get(route('events.export', $event))
                ->assertOk()
                ->streamedContent();

            $this->assertStringContainsString('Registration Lead', $csv);
            $this->assertStringContainsString('Block', $csv);

            $this->delete(route('events.designations.remove', [$event, $designation]))
                ->assertRedirect();

            $this->assertDatabaseMissing('event_student_designations', ['id' => $designation->id]);
        } finally {
            $event->delete();
            $student->forceDelete();
            $admin->delete();
        }
    }

    public function test_student_csv_download_filters_by_year_and_block_and_is_alphabetical(): void
    {
        $admin = User::factory()->create(['role' => 'superadmin']);
        $students = collect([
            ['student_id' => 'EXPORT-Z-' . uniqid(), 'full_name' => 'Zoe Export', 'year_level' => 'First Year', 'block' => 'A'],
            ['student_id' => 'EXPORT-A-' . uniqid(), 'full_name' => 'Ada Export', 'year_level' => 'First Year', 'block' => 'B'],
            ['student_id' => 'EXPORT-B-' . uniqid(), 'full_name' => 'Ben Export', 'year_level' => 'Second Year', 'block' => 'B'],
        ])->map(fn (array $data) => Student::create($data));

        try {
            $allCampusCsv = $this->actingAs($admin)
                ->get(route('students.export'))
                ->assertOk()
                ->streamedContent();

            $this->assertStringContainsString('Zoe Export', $allCampusCsv);
            $this->assertLessThan(
                strpos($allCampusCsv, 'Ben Export'),
                strpos($allCampusCsv, 'Ada Export'),
                'Student CSV downloads should be sorted alphabetically.'
            );

            $filteredCsv = $this->get(route('students.export', [
                'year_level' => 'First Year',
                'block' => 'B',
            ]))->assertOk()->streamedContent();

            $this->assertStringContainsString('Ada Export', $filteredCsv);
            $this->assertStringNotContainsString('Ben Export', $filteredCsv);
            $this->assertStringNotContainsString('Zoe Export', $filteredCsv);

            $this->get(route('students.index', [
                'year_level' => 'First Year',
                'block' => 'B',
            ]))
                ->assertOk()
                ->assertSee('Ada Export')
                ->assertDontSee('Ben Export')
                ->assertSee('Download CSV');
        } finally {
            $students->each->forceDelete();
            $admin->delete();
        }
    }
}
