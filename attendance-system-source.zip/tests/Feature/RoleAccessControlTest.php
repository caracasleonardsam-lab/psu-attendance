<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventEvaluation;
use App\Models\EvaluationAnswer;
use App\Models\EvaluationForm;
use App\Models\EvaluationQuestion;
use App\Models\EvaluationResponse;
use App\Models\Organization;
use App\Models\Student;
use App\Models\User;
use Tests\TestCase;

class RoleAccessControlTest extends TestCase
{
    public function test_admin_cannot_manage_staff_audit_logs_students_or_organizations(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $student = Student::create([
            'student_id' => 'ROLE-'.uniqid(),
            'full_name' => 'Protected Student',
        ]);
        $organization = Organization::create(['name' => 'Protected Org '.uniqid()]);

        try {
            $this->actingAs($admin)
                ->get('/settings')
                ->assertForbidden();
            $this->get(route('dashboard'))
                ->assertOk()
                ->assertDontSee('System Settings');
            $this->post('/settings/general', [
                'campus_name' => 'Tampered Settings',
                'system_name' => 'Tampered',
                'academic_year' => '2099-2100',
                'academic_semester' => '1st Semester',
            ])->assertForbidden();
            $this->post('/settings/users', [
                'name' => 'Unauthorized Staff',
                'username' => 'unauthorized-'.uniqid(),
                'email' => uniqid().'@example.test',
                'role' => 'officer',
                'password' => 'password123',
                'password_confirmation' => 'password123',
            ])->assertForbidden();
            $this->get(route('logs.index'))->assertForbidden();
            $this->get(route('dashboard'))
                ->assertOk()
                ->assertDontSee('Recent System Audit Trail')
                ->assertDontSee('Full Audit Trail');
            $this->get(route('students.index'))
                ->assertOk()
                ->assertDontSee('onclick="openEditStudentModal(')
                ->assertDontSee('Import CSV')
                ->assertDontSee('Register Student');
            $this->put(route('students.update', $student), [
                'full_name' => 'Tampered Student',
            ])->assertForbidden();
            $this->get(route('organizations.show', $organization))
                ->assertOk()
                ->assertDontSee('Add Member')
                ->assertDontSee('Assign Officer');
            $this->put(route('organizations.update', $organization), [
                'name' => 'Tampered Organization',
            ])->assertForbidden();

            $this->assertSame('Protected Student', $student->fresh()->full_name);
            $this->assertSame($organization->name, $organization->fresh()->name);
        } finally {
            $student->forceDelete();
            $organization->delete();
            $admin->delete();
        }
    }

    public function test_admin_can_soft_delete_and_restore_attendance_records(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $student = Student::create([
            'student_id' => 'BIN-'.uniqid(),
            'full_name' => 'Bin Test Student',
        ]);
        $event = Event::create([
            'name' => 'Attendance Bin Event '.uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'completed',
        ]);
        $attendance = Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => now(),
        ]);

        try {
            $this->actingAs($admin)
                ->delete(route('attendance.destroy', $attendance))
                ->assertRedirect();
            $this->assertSoftDeleted('attendance', ['id' => $attendance->id]);
            $this->get(route('attendance.trash'))->assertOk()->assertSee('Bin Test Student');

            $this->post(route('attendance.restore', $attendance->id))
                ->assertRedirect(route('attendance.trash'));
            $this->assertDatabaseHas('attendance', [
                'id' => $attendance->id,
                'deleted_at' => null,
            ]);
        } finally {
            Attendance::withTrashed()->whereKey($attendance->id)->forceDelete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
        }
    }

    public function test_only_superadmin_can_open_evaluation_report_and_non_admin_roles_see_anonymized_results(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $officer = User::factory()->create(['role' => 'officer']);
        $superAdmin = User::factory()->create(['role' => 'superadmin']);
        $student = Student::create([
            'student_id' => 'PRIVATE-'.uniqid(),
            'full_name' => 'Private Evaluation Student',
        ]);
        $event = Event::create([
            'name' => 'Evaluation Visibility Event '.uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'completed',
        ]);
        $form = EvaluationForm::create([
            'event_id' => $event->id,
            'title' => 'Protected Evaluation '.uniqid(),
            'eligibility_mode' => 'attended',
            'is_published' => true,
        ]);
        $question = EvaluationQuestion::create([
            'evaluation_form_id' => $form->id,
            'question_text' => 'How was the event?',
            'question_type' => 'short_answer',
            'is_required' => true,
            'position' => 0,
        ]);
        $response = EvaluationResponse::create([
            'evaluation_form_id' => $form->id,
            'student_id' => $student->id,
            'submitted_at' => now(),
        ]);
        EvaluationAnswer::create([
            'evaluation_response_id' => $response->id,
            'evaluation_question_id' => $question->id,
            'answer_text' => 'A good event',
        ]);
        $evaluation = EventEvaluation::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'rating_content' => 4,
            'rating_speaker' => 4,
            'rating_venue' => 5,
            'rating_overall' => 4,
            'comments' => 'Useful event feedback',
            'suggestions' => 'More sessions',
            'submitted_at' => now(),
        ]);

        try {
            $this->actingAs($admin)
                ->post(route('events.evaluation_report_visibility', $event), [
                    'evaluation_results_visible' => '1',
                ])
                ->assertForbidden();
            $this->actingAs($officer)
                ->get(route('events.evaluations', $event))
                ->assertForbidden();
            $this->actingAs($admin)
                ->get(route('evaluations.results'))
                ->assertOk()
                ->assertDontSee($form->title)
                ->assertDontSee($student->full_name);

            $this->actingAs($superAdmin)
                ->post(route('events.evaluation_report_visibility', $event), [
                    'evaluation_results_visible' => '1',
                ])
                ->assertRedirect();
            $this->assertTrue((bool) $event->fresh()->evaluation_results_visible);

            $this->actingAs($admin)
                ->get(route('events.evaluations', $event))
                ->assertOk()
                ->assertSee('Anonymous respondent')
                ->assertDontSee($student->full_name)
                ->assertDontSee($student->student_id);
            $this->actingAs($officer)
                ->get(route('events.evaluations', $event))
                ->assertOk()
                ->assertSee('Anonymous respondent')
                ->assertDontSee($student->full_name)
                ->assertDontSee($student->student_id);
            $this->get(route('evaluations.results'))
                ->assertOk()
                ->assertSee($form->title)
                ->assertSee('Anonymous respondent')
                ->assertDontSee($student->full_name)
                ->assertDontSee($student->student_id);
            $this->get(route('evaluations.export'))->assertForbidden();
            $this->actingAs($superAdmin)
                ->get(route('evaluations.results'))
                ->assertOk()
                ->assertSee($student->full_name)
                ->assertSee($student->student_id);
        } finally {
            $evaluation->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            $officer->delete();
            $superAdmin->delete();
        }
    }

    public function test_officers_cannot_access_student_roster_audit_attendance_or_system_settings(): void
    {
        $officer = User::factory()->create(['role' => 'officer']);

        try {
            $this->actingAs($officer)->get(route('students.index'))->assertForbidden();
            $this->get(route('organizations.index'))->assertForbidden();
            $this->get(route('attendance.index'))->assertForbidden();
            $this->get(route('logs.index'))->assertForbidden();
            $this->get(route('reports.index'))->assertForbidden();
            $this->get(route('settings.index'))->assertForbidden();
            $this->get(route('presence.index'))->assertForbidden();
        } finally {
            $officer->delete();
        }
    }
}
