<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Event;
use App\Models\Student;
use App\Models\User;
use Tests\TestCase;

class AttendanceSystemTest extends TestCase
{
    public function test_login_page_loads_successfully(): void
    {
        $response = $this->get('/login');
        $response->assertStatus(200);
        $response->assertSee('Pangasinan State University Attendance');
    }

    public function test_user_authentication_works(): void
    {
        $user = User::factory()->create([
            'username' => 'admin',
            'password' => 'admin123',
            'role' => 'admin',
        ]);

        $response = $this->post('/login', [
            'username' => 'admin',
            'password' => 'admin123',
        ]);

        $response->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($user);
    }

    public function test_api_student_dashboard_returns_json(): void
    {
        $this->get('/api/student-dashboard')->assertNotFound();

        $student = $this->createStudent();
        $response = $this->get('/api/student-dashboard?student_id='.urlencode($student->student_id));
        $response->assertStatus(200);
        $response->assertJsonStructure([
            'success',
            'student' => ['id', 'student_id', 'full_name', 'program'],
            'stats',
        ]);
    }

    public function test_api_students_list_returns_registered_students(): void
    {
        $admin = $this->createAdmin();
        $officer = User::factory()->create(['role' => 'officer']);
        $superAdmin = User::factory()->create(['role' => 'superadmin']);
        $student = $this->createStudent();
        $this->get('/api/students')->assertForbidden();
        $this->actingAs($admin)->get('/api/students')->assertForbidden();
        $this->actingAs($officer)->get('/api/students')->assertForbidden();

        $response = $this->actingAs($superAdmin)->get('/api/students');
        $response->assertOk()
            ->assertJson(['success' => true])
            ->assertJsonFragment(['student_id' => $student->student_id]);
    }

    public function test_attendance_scanner_records_scan(): void
    {
        $admin = $this->createAdmin();
        $student = $this->createStudent();
        $event = $this->createActiveEvent();

        $response = $this->actingAs($admin)->post('/attendance/scan', [
            'event_id' => $event->id,
            'barcode' => $student->student_id,
        ], ['Accept' => 'application/json']);

        $response->assertStatus(200);
        $response->assertJson(['success' => true]);
    }

    public function test_scanner_requires_an_explicit_checkout_scan_mode(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $student = Student::create([
            'student_id' => 'SCANNER-MODE-' . uniqid(),
            'full_name' => 'Scanner Mode Test Student',
        ]);
        $event = Event::create([
            'name' => uniqid('Explicit Scan Mode Test '),
            'event_date' => now()->toDateString(),
            'status' => 'active',
            'venue' => 'Test Venue',
            'require_checkout' => true,
            'scanning_enabled' => true,
        ]);

        try {
            $scannerPage = $this->actingAs($admin)->get('/scanner');
            $scannerPage->assertOk()
                ->assertSee('Check-In Only')
                ->assertSee('Connect a USB or Bluetooth barcode scanner')
                ->assertSee('Hardware Scanner')
                ->assertDontSee('Enable Camera')
                ->assertDontSee('Html5Qrcode')
                ->assertDontSee('Auto (In/Out)')
                ->assertDontSee('Voice:');

            $autoScan = $this->actingAs($admin)->post('/attendance/scan', [
                'event_id' => $event->id,
                'barcode' => $student->student_id,
                'scan_mode' => 'auto',
            ], ['Accept' => 'application/json']);
            $autoScan->assertUnprocessable();

            $checkIn = $this->actingAs($admin)->post('/attendance/scan', [
                'event_id' => $event->id,
                'barcode' => $student->student_id,
                'scan_mode' => 'checkin',
            ], ['Accept' => 'application/json']);
            $checkIn->assertOk()->assertJson(['success' => true, 'action' => 'checkin']);

            $duplicateCheckIn = $this->actingAs($admin)->post('/attendance/scan', [
                'event_id' => $event->id,
                'barcode' => $student->student_id,
            ], ['Accept' => 'application/json']);
            $duplicateCheckIn->assertOk()->assertJson(['already_recorded' => true]);

            $checkOut = $this->actingAs($admin)->post('/attendance/scan', [
                'event_id' => $event->id,
                'barcode' => $student->student_id,
                'scan_mode' => 'checkout',
            ], ['Accept' => 'application/json']);
            $checkOut->assertOk()->assertJson(['success' => true, 'action' => 'checkout']);
        } finally {
            $event->attendances()->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
        }
    }

    public function test_scanner_smart_parsing_supports_json_and_unhyphenated_codes(): void
    {
        $admin = $this->createAdmin();
        $student = $this->createStudent();
        $event = $this->createActiveEvent();

        // 1. Test JSON QR payload format
        $jsonPayload = json_encode(['student_id' => $student->student_id, 'type' => 'student_pass']);
        $responseJson = $this->actingAs($admin)->post('/attendance/scan', [
            'event_id' => $event->id,
            'barcode' => $jsonPayload,
        ], ['Accept' => 'application/json']);

        $responseJson->assertStatus(200);
        $responseJson->assertJson(['success' => true]);

        // Clean up
        Attendance::where('event_id', $event->id)->where('student_id', $student->id)->delete();

        // 2. Test unhyphenated code (e.g. 23AC0395 matching 23-AC-0395)
        $unhyphenated = str_replace(['-', ' '], '', $student->student_id);
        $responseUnhyphenated = $this->actingAs($admin)->post('/attendance/scan', [
            'event_id' => $event->id,
            'barcode' => $unhyphenated,
        ], ['Accept' => 'application/json']);

        $responseUnhyphenated->assertStatus(200);
        $responseUnhyphenated->assertJson(['success' => true]);
    }

    public function test_scanner_manual_search_and_undo_endpoints(): void
    {
        $admin = $this->createAdmin();
        $student = $this->createStudent();
        $event = $this->createActiveEvent();

        // Test manual search autocomplete
        $searchResponse = $this->actingAs($admin)->get('/attendance/search-students?q=' . substr($student->student_id, 0, 4));
        $searchResponse->assertStatus(200);
        $this->assertNotEmpty($searchResponse->json());

        // Test record and undo (delete) with AJAX stats response
        $scan = Attendance::firstOrCreate(
            ['event_id' => $event->id, 'student_id' => $student->id],
            ['status' => 'present', 'scanned_at' => now()]
        );

        $deleteResponse = $this->actingAs($admin)->delete('/attendance/' . $scan->id, [], ['Accept' => 'application/json']);
        $deleteResponse->assertStatus(200);
        $deleteResponse->assertJson(['success' => true]);
    }

    public function test_legacy_api_php_endpoint_is_backward_compatible(): void
    {
        $response = $this->get('/api.php?action=get_events');
        $response->assertStatus(200);
        $response->assertJson(['success' => true]);
    }

    public function test_unknown_legacy_api_action_returns_a_client_error(): void
    {
        $this->postJson('/api.php', ['action' => 'not_a_supported_action'])
            ->assertBadRequest()
            ->assertJsonPath('code', 'ACTION_NOT_SUPPORTED');
    }

    public function test_all_admin_pages_load_successfully(): void
    {
        $admin = $this->createAdmin();

        $routes = [
            '/dashboard',
            '/scanner',
            '/events',
            '/attendance',
            '/students',
            '/organizations',
            '/presence',
            '/reports',
        ];

        foreach ($routes as $route) {
            $response = $this->actingAs($admin)->get($route);
            $response->assertStatus(200);
        }
        $this->actingAs($admin)->get('/settings')->assertForbidden();
        $this->actingAs($admin)->get('/logs')->assertForbidden();

        // Student portal should no longer exist on web
        $portalResponse = $this->actingAs($admin)->get('/student-portal');
        $portalResponse->assertStatus(404);
    }

    public function test_student_web_login_is_rejected_with_mobile_app_notice(): void
    {
        $studentUser = User::firstOrCreate(
            ['username' => 'test_student_web'],
            [
                'name' => 'Test Student User',
                'email' => 'test_student_web@psu.edu.ph',
                'password' => \Illuminate\Support\Facades\Hash::make('password123'),
                'role' => 'student',
            ]
        );

        $response = $this->post('/login', [
            'username' => 'test_student_web',
            'password' => 'password123',
        ]);

        $response->assertSessionHasErrors('username');
        $this->assertGuest();
    }

    private function createAdmin(): User
    {
        return User::factory()->create([
            'username' => 'test-admin-'.uniqid(),
            'role' => 'admin',
        ]);
    }

    private function createStudent(): Student
    {
        return Student::create([
            'student_id' => 'TEST-'.uniqid(),
            'full_name' => 'Feature Test Student',
        ]);
    }

    private function createActiveEvent(): Event
    {
        return Event::create([
            'name' => 'Feature Test Event '.uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'active',
            'scanning_enabled' => true,
            'venue' => 'Test Venue',
        ]);
    }
}
