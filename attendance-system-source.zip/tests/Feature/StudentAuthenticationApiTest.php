<?php

namespace Tests\Feature;

use App\Models\Student;
use App\Models\StudentApiToken;
use App\Models\User;
use Tests\TestCase;

class StudentAuthenticationApiTest extends TestCase
{
    public function test_default_student_password_stops_working_after_password_change(): void
    {
        $student = Student::create([
            'student_id' => 'AUTH-'.uniqid(),
            'full_name' => 'Authentication Test Student',
        ]);

        $this->postJson('/api/login', [
            'username' => $student->student_id,
            'password' => $student->student_id,
        ])
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonPath('requires_password_change', true);

        $this->postJson('/api/change-password', [
            'student_id' => $student->student_id,
            'current_password' => $student->student_id,
            'new_password' => 'NewSecurePass123',
        ])
            ->assertOk()
            ->assertJsonPath('success', true);

        $this->postJson('/api/login', [
            'username' => $student->student_id,
            'password' => $student->student_id,
        ])
            ->assertOk()
            ->assertJsonPath('success', false);

        $this->postJson('/api/login', [
            'username' => $student->student_id,
            'password' => 'NewSecurePass123',
        ])
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonPath('requires_password_change', false);
    }

    public function test_password_reset_revokes_existing_student_api_tokens(): void
    {
        $student = Student::create([
            'student_id' => 'RESET-'.uniqid(),
            'full_name' => 'Password Reset Test Student',
            'email' => 'password-reset-'.uniqid().'@example.test',
        ]);
        User::create([
            'name' => $student->full_name,
            'username' => $student->student_id,
            'email' => $student->email,
            'password' => 'OldSecurePass123',
            'role' => 'student',
        ]);
        $token = StudentApiToken::create([
            'student_id' => $student->id,
            'token_hash' => hash('sha256', 'existing-student-token'),
            'expires_at' => now()->addDay(),
        ]);

        $this->postJson('/api.php', [
            'action' => 'reset_password',
            'student_id' => $student->student_id,
            'email' => $student->email,
        ])
            ->assertOk()
            ->assertJsonPath('success', true);

        $this->assertDatabaseMissing('student_api_tokens', ['id' => $token->id]);
    }
}
