<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\EvaluationForm;
use App\Models\EvaluationQuestion;
use App\Models\EvaluationResponse;
use App\Models\Event;
use App\Models\Student;
use App\Models\StudentApiToken;
use Carbon\Carbon;
use Tests\TestCase;

class StudentEvaluationAvailabilityTest extends TestCase
{
    public function test_published_evaluation_unlocks_as_soon_as_scheduled_event_ends(): void
    {
        $endsAt = Carbon::parse('2026-11-05 14:00:00', config('app.timezone'));
        $this->travelTo($endsAt->copy()->subMinute());

        $student = Student::create([
            'student_id' => 'EVAL-END-'.uniqid(),
            'full_name' => 'Evaluation Event-End Student',
        ]);
        $event = Event::create([
            'name' => 'Evaluation End-Time Event '.uniqid(),
            'event_date' => $endsAt->toDateString(),
            'start_time' => '12:00:00',
            'end_time' => $endsAt->format('H:i:s'),
            'status' => 'active',
            'scanning_enabled' => true,
        ]);
        $attendance = Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => $endsAt->copy()->subHours(2),
        ]);
        $form = EvaluationForm::create([
            'event_id' => $event->id,
            'title' => 'Event feedback',
            'eligibility_mode' => 'attended',
            'is_published' => true,
            'allow_resubmission' => false,
        ]);
        $question = EvaluationQuestion::create([
            'evaluation_form_id' => $form->id,
            'question_text' => 'Rate the event',
            'question_type' => 'rating',
            'is_required' => true,
            'position' => 0,
        ]);
        $token = 'evaluation-token-'.uniqid();
        $apiToken = StudentApiToken::create([
            'student_id' => $student->id,
            'token_hash' => hash('sha256', $token),
            'expires_at' => $endsAt->copy()->addDay(),
        ]);

        try {
            $this->withToken($token)
                ->getJson('/api/student/evaluations')
                ->assertOk()
                ->assertJsonCount(0, 'evaluations');
            $this->withToken($token)
                ->getJson("/api/student/evaluations/{$form->id}")
                ->assertForbidden();
            $this->withToken($token)
                ->postJson("/api/student/evaluations/{$form->id}/responses", [
                    'answers' => [(string) $question->id => 5],
                ])
                ->assertForbidden();

            $this->travelTo($endsAt);

            $available = $this->withToken($token)
                ->getJson('/api/student/evaluations')
                ->assertOk()
                ->assertJsonCount(1, 'evaluations')
                ->assertJsonPath('evaluations.0.id', $form->id);

            $available->assertJsonPath('evaluations.0.event_name', $event->name);
            $this->assertSame('completed', $event->fresh()->status);
            $this->assertTrue($event->fresh()->evaluation_enabled);

            $this->withToken($token)
                ->postJson("/api/student/evaluations/{$form->id}/responses", [
                    'answers' => [(string) $question->id => 5],
                ])
                ->assertOk()
                ->assertJsonPath('success', true);

            $this->assertDatabaseHas('evaluation_responses', [
                'evaluation_form_id' => $form->id,
                'student_id' => $student->id,
            ]);

            $form->update(['allow_resubmission' => true]);
            $this->withToken($token)
                ->get('/api.php?action=get_available_evaluations')
                ->assertOk()
                ->assertJsonFragment(['id' => $form->id]);

            $this->withToken($token)
                ->post('/api.php', [
                    'action' => 'submit_dynamic_evaluation',
                    'evaluation_id' => $form->id,
                    'answers' => json_encode([(string) $question->id => 4]),
                ])
                ->assertOk()
                ->assertJsonPath('success', true);

            $this->assertSame(
                2,
                EvaluationResponse::where('evaluation_form_id', $form->id)
                    ->where('student_id', $student->id)
                    ->count()
            );
        } finally {
            EvaluationResponse::where('evaluation_form_id', $form->id)->delete();
            $form->delete();
            $attendance->delete();
            $event->delete();
            $apiToken->delete();
            $student->forceDelete();
            $this->travelBack();
        }
    }
}
