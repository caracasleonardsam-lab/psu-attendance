<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventEligibility;
use App\Models\EventQueueEntry;
use App\Models\EventStudentDesignation;
use App\Models\Organization;
use App\Models\Student;
use App\Models\SystemSetting;
use App\Models\User;
use Carbon\Carbon;
use Tests\TestCase;

class EventQueueCheckinTest extends TestCase
{
    public function test_admin_can_create_an_event_for_a_single_organization(): void
    {
        $admin = User::create([
            'name' => 'Org Event Admin '.uniqid(),
            'username' => 'org-event-admin-'.uniqid(),
            'email' => 'org-event-admin-'.uniqid().'@example.test',
            'password' => 'password',
            'role' => 'admin',
        ]);
        $organization = Organization::create(['name' => 'Exclusive Event Org '.uniqid()]);
        $eventName = 'Exclusive Org Event '.uniqid();

        try {
            $this->actingAs($admin)
                ->get('/events')
                ->assertOk()
                ->assertSee('Exclusive Organization')
                ->assertSee($organization->name);

            $this->post('/events', [
                'name' => $eventName,
                'event_date' => now()->addDay()->toDateString(),
                'organization_id' => $organization->id,
            ])->assertRedirect();

            $this->assertDatabaseHas('events', [
                'name' => $eventName,
                'organization_id' => $organization->id,
                'attendance_mode' => 'Barcode + Student ID',
            ]);
        } finally {
            Event::where('name', $eventName)->delete();
            $organization->delete();
            $admin->delete();
        }
    }

    public function test_org_exclusive_event_rejects_other_org_scans_and_queue_entries(): void
    {
        $start = Carbon::parse('2026-11-05 10:00:00', config('app.timezone'));
        $this->travelTo($start->copy()->subMinutes(10));
        [$admin, $student, $event, $token] = $this->createQueueScenario($start);
        $eventOrganization = Organization::create(['name' => 'Event Org '.uniqid()]);
        $studentOrganization = Organization::create(['name' => 'Other Org '.uniqid()]);
        $student->update(['organization_id' => $studentOrganization->id]);
        $event->update(['organization_id' => $eventOrganization->id]);

        try {
            $this->getJson('/api/events?student_id='.$student->student_id)
                ->assertOk()
                ->assertJsonMissing(['id' => $event->id]);

            $this->withToken($token)
                ->postJson('/api/event-queue', [
                    'student_id' => $student->student_id,
                    'event_id' => $event->id,
                ])
                ->assertForbidden()
                ->assertJsonPath('code', 'ORGANIZATION_NOT_ELIGIBLE');

            $this->actingAs($admin)
                ->postJson('/attendance/scan', [
                    'event_id' => $event->id,
                    'barcode' => $student->student_id,
                    'allow_override' => true,
                ])
                ->assertForbidden()
                ->assertJsonPath('code', 'ORGANIZATION_NOT_ELIGIBLE');

            $this->assertDatabaseMissing('attendance', [
                'event_id' => $event->id,
                'student_id' => $student->id,
            ]);
            $this->assertDatabaseMissing('event_queue_entries', [
                'event_id' => $event->id,
                'student_id' => $student->id,
            ]);

            $student->update(['organization_id' => $eventOrganization->id]);
            $this->getJson('/api/events?student_id='.$student->student_id)
                ->assertOk()
                ->assertJsonFragment(['id' => $event->id]);
            $this->withToken($token)
                ->postJson('/api/event-queue', [
                    'student_id' => $student->student_id,
                    'event_id' => $event->id,
                    'latitude' => $event->latitude,
                    'longitude' => $event->longitude,
                    'accuracy_meters' => 8,
                ])
                ->assertOk()
                ->assertJsonPath('success', true);
        } finally {
            Attendance::where('event_id', $event->id)->delete();
            EventQueueEntry::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $eventOrganization->delete();
            $studentOrganization->delete();
            $admin->delete();
            $this->travelBack();
        }
    }

    public function test_student_can_queue_before_scanning_starts_and_late_scan_uses_queue_time(): void
    {
        $start = Carbon::parse('2026-11-05 10:00:00', config('app.timezone'));
        $this->travelTo($start->copy()->subMinutes(30));
        [$admin, $student, $event, $token] = $this->createQueueScenario($start);
        $event->update(['status' => 'scheduled', 'scanning_enabled' => false]);

        try {
            $events = $this->getJson('/api/events?student_id='.$student->student_id)
                ->assertOk()
                ->json('events');
            $syncedEvent = collect($events)->firstWhere('id', $event->id);
            $this->assertTrue($syncedEvent['queue_available']);
            $this->assertFalse($syncedEvent['is_designated']);

            $queueResponse = $this->withToken($token)
                ->postJson('/api/event-queue', [
                    'student_id' => $student->student_id,
                    'event_id' => $event->id,
                    'latitude' => $event->latitude,
                    'longitude' => $event->longitude,
                    'accuracy_meters' => 8,
                    'is_mocked' => false,
                ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('geofence_verified', true);

            $queueEntry = EventQueueEntry::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->firstOrFail();
            $this->assertDatabaseMissing('attendance', [
                'event_id' => $event->id,
                'student_id' => $student->id,
            ]);
            $this->assertSame(
                $start->copy()->subMinutes(30)->toDateTimeString(),
                $queueEntry->entered_at->toDateTimeString()
            );

            $this->travelTo($start->copy()->addMinutes(25));
            $event->update(['status' => 'active', 'scanning_enabled' => true]);
            $this->actingAs($admin)
                ->postJson('/attendance/scan', [
                    'event_id' => $event->id,
                    'barcode' => $student->student_id,
                ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('attendance.status', 'present')
                ->assertJsonPath('attendance.scanned_at', $queueEntry->entered_at->format('h:i:s A'))
                ->assertJsonPath('attendance.checked_in_at', $start->copy()->addMinutes(25)->toIso8601String());

            $attendance = Attendance::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->firstOrFail();
            $this->assertSame('present', $attendance->status);
            $this->assertSame(
                $queueEntry->entered_at->toDateTimeString(),
                $attendance->scanned_at->toDateTimeString()
            );
            $this->assertSame(
                $start->copy()->addMinutes(25)->toDateTimeString(),
                $queueEntry->fresh()->checked_in_at->toDateTimeString()
            );
        } finally {
            Attendance::where('event_id', $event->id)->delete();
            EventQueueEntry::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            $this->travelBack();
        }
    }

    public function test_queue_is_available_for_active_event_without_configured_times(): void
    {
        $start = Carbon::parse('2026-11-05 10:00:00', config('app.timezone'));
        $this->travelTo($start->copy()->addHours(3));
        [$admin, $student, $event, $token] = $this->createQueueScenario($start);
        $event->update([
            'start_time' => null,
            'end_time' => null,
        ]);

        try {
            $events = $this->getJson('/api/events?student_id='.$student->student_id)
                ->assertOk()
                ->json('events');
            $syncedEvent = collect($events)->firstWhere('id', $event->id);
            $this->assertTrue($syncedEvent['queue_available']);

            $this->withToken($token)
                ->postJson('/api/event-queue', [
                    'student_id' => $student->student_id,
                    'event_id' => $event->id,
                    'latitude' => $event->latitude,
                    'longitude' => $event->longitude,
                    'accuracy_meters' => 8,
                    'is_mocked' => false,
                ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('geofence_verified', true);
        } finally {
            Attendance::where('event_id', $event->id)->delete();
            EventQueueEntry::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            $this->travelBack();
        }
    }

    public function test_queue_entry_without_a_barcode_scan_does_not_create_attendance(): void
    {
        $start = Carbon::parse('2026-11-05 10:00:00', config('app.timezone'));
        $this->travelTo($start->copy()->subMinutes(10));
        [$admin, $student, $event, $token] = $this->createQueueScenario($start);

        try {
            $this->withToken($token)
                ->postJson('/api/event-queue', [
                    'student_id' => $student->student_id,
                    'event_id' => $event->id,
                    'latitude' => $event->latitude,
                    'longitude' => $event->longitude,
                    'accuracy_meters' => 8,
                    'is_mocked' => false,
                ])
                ->assertOk()
                ->assertJsonPath('success', true);

            $this->assertDatabaseMissing('attendance', [
                'event_id' => $event->id,
                'student_id' => $student->id,
            ]);

            $this->travelTo($start->copy()->addHours(2));
            app(\App\Services\EventLifecycleService::class)->completeExpiredEvents();

            $this->assertSame('completed', $event->fresh()->status);
            $this->assertDatabaseMissing('attendance', [
                'event_id' => $event->id,
                'student_id' => $student->id,
            ]);
            $this->getJson('/api/history?student_id='.$student->student_id)
                ->assertOk()
                ->assertJsonCount(0, 'history');
        } finally {
            Attendance::where('event_id', $event->id)->delete();
            EventQueueEntry::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            $this->travelBack();
        }
    }

    public function test_designated_student_can_queue_without_gps_and_is_exempt_from_geofence_monitoring(): void
    {
        $start = Carbon::parse('2026-11-05 10:00:00', config('app.timezone'));
        $this->travelTo($start->copy()->subMinutes(10));
        [$admin, $student, $event, $token] = $this->createQueueScenario($start);
        $event->update(['status' => 'scheduled', 'scanning_enabled' => false]);
        $designation = EventStudentDesignation::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'designation' => 'Event Marshal',
            'assigned_by' => $admin->id,
        ]);
        EventEligibility::create([
            'event_id' => $event->id,
            'year_level' => 'Third Year',
        ]);

        try {
            $events = $this->getJson('/api/events?student_id='.$student->student_id)
                ->assertOk()
                ->json('events');
            $syncedEvent = collect($events)->firstWhere('id', $event->id);
            $this->assertTrue($syncedEvent['queue_available']);
            $this->assertTrue($syncedEvent['is_designated']);

            $this->withToken($token)
                ->postJson('/api/event-queue', [
                    'student_id' => $student->student_id,
                    'event_id' => $event->id,
                ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('geofence_verified', false);

            $queueEntry = EventQueueEntry::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->firstOrFail();
            $this->assertNull($queueEntry->latitude);
            $this->assertNull($queueEntry->distance_meters);

            $this->travelTo($start->copy()->addMinutes(25));
            $event->update(['status' => 'active', 'scanning_enabled' => true]);
            $this->actingAs($admin)
                ->postJson('/attendance/scan', [
                    'event_id' => $event->id,
                    'barcode' => $student->student_id,
                ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('attendance.status', 'present');

            $this->withToken($token)
                ->postJson('/api/verify-geofence', [
                    'student_id' => $student->student_id,
                    'event_id' => $event->id,
                ])
                ->assertOk()
                ->assertJsonPath('geofence_exempt', true)
                ->assertJsonPath('can_confirm_geofence', false);

            $attendance = Attendance::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->firstOrFail();
            $this->assertSame('present', $attendance->status);
            $this->assertStringContainsString('Event designation', $attendance->notes);
        } finally {
            Attendance::where('event_id', $event->id)->delete();
            EventQueueEntry::where('event_id', $event->id)->delete();
            $designation->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            $this->travelBack();
        }
    }

    public function test_geofence_verified_queue_time_prevents_scan_line_delay_from_marking_student_late(): void
    {
        $start = Carbon::parse('2026-11-05 10:00:00', config('app.timezone'));
        $this->travelTo($start->copy()->subMinutes(10));

        [$admin, $student, $event, $token] = $this->createQueueScenario($start);
        $previousGracePeriod = SystemSetting::get('grace_period_minutes');
        SystemSetting::set('grace_period_minutes', '15');

        try {
            $queueResponse = $this->withToken($token)
                ->postJson('/api/event-queue', [
                    'student_id' => $student->student_id,
                    'event_id' => $event->id,
                    'latitude' => $event->latitude,
                    'longitude' => $event->longitude,
                    'accuracy_meters' => 8,
                    'is_mocked' => false,
                ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('is_queued', true);

            $queueEntry = EventQueueEntry::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->firstOrFail();
            $this->assertSame(
                $start->copy()->subMinutes(10)->toDateTimeString(),
                $queueEntry->entered_at->toDateTimeString()
            );
            $this->assertNotNull($queueResponse->json('queue_entered_at'));
            $this->assertDatabaseMissing('attendance', [
                'event_id' => $event->id,
                'student_id' => $student->id,
            ]);

            $this->travelTo($start->copy()->addMinutes(25));
            $this->actingAs($admin)
                ->postJson('/attendance/scan', [
                    'event_id' => $event->id,
                    'barcode' => $student->student_id,
                ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('attendance.status', 'present')
                ->assertJsonPath('attendance.scanned_at', $queueEntry->entered_at->format('h:i:s A'))
                ->assertJsonPath('attendance.checked_in_at', $start->copy()->addMinutes(25)->toIso8601String());

            $attendance = Attendance::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->firstOrFail();
            $this->assertSame('present', $attendance->status);
            $this->assertSame(
                $queueEntry->entered_at->toDateTimeString(),
                $attendance->scanned_at->toDateTimeString()
            );
            $this->assertNotNull($queueEntry->fresh()->checked_in_at);
            $this->assertSame(
                $start->copy()->addMinutes(25)->toDateTimeString(),
                $queueEntry->fresh()->checked_in_at->toDateTimeString()
            );
            $this->assertStringContainsString('Geofence queue entry at', $attendance->notes);
            $this->assertStringContainsString('Barcode scanned at', $attendance->notes);
        } finally {
            SystemSetting::where('key_name', 'grace_period_minutes')->delete();
            if ($previousGracePeriod !== null) {
                SystemSetting::set('grace_period_minutes', $previousGracePeriod);
            }
            Attendance::where('event_id', $event->id)->delete();
            EventQueueEntry::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            $this->travelBack();
        }
    }

    public function test_queue_entry_requires_authenticated_student_and_verified_geofence(): void
    {
        $start = Carbon::parse('2026-11-05 10:00:00', config('app.timezone'));
        $this->travelTo($start->copy()->subMinutes(10));
        [$admin, $student, $event, $token] = $this->createQueueScenario($start);

        try {
            $payload = [
                'student_id' => $student->student_id,
                'event_id' => $event->id,
                'latitude' => $event->latitude + 0.01,
                'longitude' => $event->longitude,
                'accuracy_meters' => 5,
                'is_mocked' => false,
            ];

            $this->postJson('/api/event-queue', $payload)
                ->assertUnauthorized()
                ->assertJsonPath('code', 'UNAUTHENTICATED');

            $this->withToken($token)
                ->postJson('/api/event-queue', $payload)
                ->assertStatus(422)
                ->assertJsonPath('code', 'OUTSIDE_GEOFENCE');

            $this->withToken($token)
                ->postJson('/api/event-queue', [
                    ...$payload,
                    'latitude' => $event->latitude,
                    'longitude' => $event->longitude,
                    'is_mocked' => true,
                ])
                ->assertStatus(422)
                ->assertJsonPath('code', 'MOCK_LOCATION');

            $this->assertDatabaseCount('event_queue_entries', 0);
        } finally {
            EventQueueEntry::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            $this->travelBack();
        }
    }

    private function createQueueScenario(Carbon $start): array
    {
        $admin = User::create([
            'name' => 'Queue Test Admin ' . uniqid(),
            'username' => 'queue-admin-' . uniqid(),
            'email' => 'queue-admin-' . uniqid() . '@example.test',
            'password' => 'password',
            'role' => 'admin',
        ]);
        $student = Student::create([
            'student_id' => 'QUEUE-' . uniqid(),
            'full_name' => 'Queue Check-In Student',
        ]);
        $user = User::create([
            'name' => $student->full_name,
            'username' => $student->student_id,
            'email' => $student->student_id . '@example.test',
            'password' => $student->student_id,
            'role' => 'student',
        ]);
        $event = Event::create([
            'name' => 'Queue Check-In Event ' . uniqid(),
            'event_date' => $start->toDateString(),
            'start_time' => $start->format('H:i:s'),
            'end_time' => $start->copy()->addHours(2)->format('H:i:s'),
            'status' => 'active',
            'scanning_enabled' => true,
            'latitude' => 16.115303,
            'longitude' => 119.967252,
            'radius_meters' => 100,
        ]);

        $login = $this->postJson('/api/login', [
            'username' => $student->student_id,
            'password' => $student->student_id,
        ])->assertOk()->assertJsonPath('success', true);

        return [$admin, $student, $event, $login->json('token')];
    }
}
