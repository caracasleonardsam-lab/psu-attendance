<?php

namespace Tests\Feature;

use App\Models\User;
use Tests\TestCase;

class DashboardTest extends TestCase
{
    public function test_dashboard_renders_without_analytics_charts(): void
    {
        $admin = User::create([
            'name' => 'Dashboard Test Admin',
            'username' => 'dashboard-test-' . uniqid(),
            'email' => 'dashboard-test-' . uniqid() . '@example.test',
            'password' => 'password',
            'role' => 'admin',
        ]);

        try {
            $this->actingAs($admin)
                ->get('/dashboard')
                ->assertOk()
                ->assertSee('Live Attendance Activity Stream')
                ->assertSee('dashboard-quick-actions')
                ->assertSee('dashboard-stream-actions')
                ->assertSee('grid-template-columns: minmax(0, 1fr)')
                ->assertDontSee('attendanceTrendChart')
                ->assertDontSee('programDistributionChart')
                ->assertDontSee('<canvas', false);
        } finally {
            $admin->delete();
        }
    }
}
