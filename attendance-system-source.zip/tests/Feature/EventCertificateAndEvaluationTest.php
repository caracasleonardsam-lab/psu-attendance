<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventCertificate;
use App\Models\EventEvaluation;
use App\Models\IssuedCertificate;
use App\Models\Student;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class EventCertificateAndEvaluationTest extends TestCase
{
    private User $admin;

    private User $studentUser;

    private Student $student;

    private Event $event;

    protected function setUp(): void
    {
        parent::setUp();

        $studentId = 'CERT-TEST-'.uniqid();
        $this->admin = User::factory()->create([
            'username' => 'certificate-admin-'.uniqid(),
            'role' => 'admin',
        ]);
        $this->student = Student::create([
            'student_id' => $studentId,
            'full_name' => 'Certificate Test Student',
        ]);
        $this->studentUser = User::factory()->create([
            'username' => $studentId,
            'role' => 'student',
        ]);
        $this->event = Event::create([
            'name' => 'Certificate Test Event '.uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'active',
            'venue' => 'Test Venue',
            'evaluation_enabled' => true,
        ]);
        EventCertificate::create(['event_id' => $this->event->id]);
    }

    public function test_admin_can_access_certificate_setup(): void
    {
        $response = $this->actingAs($this->admin)->get("/events/{$this->event->id}/certificate");
        $response->assertStatus(200);
        $response->assertSee('E-Certificate Template Settings');
    }

    public function test_admin_can_toggle_event_evaluation_availability(): void
    {
        $event = $this->event;
        $event->update(['status' => 'active', 'evaluation_enabled' => false]);

        $this->actingAs($this->admin)
            ->post("/events/{$event->id}/evaluation-availability", ['evaluation_enabled' => '1'])
            ->assertRedirect();
        $this->assertFalse((bool) $event->fresh()->evaluation_enabled);

        $event->update(['status' => 'completed']);
        $this->post("/events/{$event->id}/evaluation-availability", ['evaluation_enabled' => '1'])
            ->assertRedirect();

        $this->assertTrue((bool) $event->fresh()->evaluation_enabled);
        $this->actingAs(User::factory()->create(['role' => 'superadmin']))
            ->post(route('events.evaluation_report_visibility', $event), ['evaluation_results_visible' => '1'])
            ->assertRedirect();
        $this->get("/events/{$event->id}/evaluations")
            ->assertOk()
            ->assertSee('Student Evaluation & E-Certificate', false);
        $this->get('/events')->assertOk()->assertSee('Enable evaluation');

        $this->post("/events/{$event->id}/evaluation-availability", ['evaluation_enabled' => '0'])
            ->assertRedirect();

        $this->assertFalse((bool) $event->fresh()->evaluation_enabled);
    }

    public function test_event_editing_does_not_expose_or_change_evaluation_availability(): void
    {
        $event = $this->event;
        $originalEvaluationEnabled = (bool) $event->evaluation_enabled;
        $event->update(['evaluation_enabled' => false]);

        try {
            $this->actingAs($this->admin)
                ->get("/events/{$event->id}")
                ->assertOk()
                ->assertDontSee('Evaluations')
                ->assertDontSee('Evaluation & E-Certificate')
                ->assertSee('E-Certificate')
                ->assertDontSee('name="evaluation_enabled"', false);

            $this->put("/events/{$event->id}", [
                'name' => $event->name,
                'event_date' => $event->event_date?->format('Y-m-d'),
                'status' => $event->status,
                'evaluation_enabled' => '1',
            ])->assertRedirect("/events/{$event->id}");

            $this->assertFalse((bool) $event->fresh()->evaluation_enabled);
        } finally {
            $event->update(['evaluation_enabled' => $originalEvaluationEnabled]);
        }
    }

    public function test_admin_can_update_certificate_settings(): void
    {
        $event = $this->event;

        $response = $this->actingAs($this->admin)->post("/events/{$event->id}/certificate", [
            'title' => 'Certificate of Outstanding Participation',
            'sub_title' => 'is proudly presented to',
            'signatory_name' => 'Dr. Maria Santos',
            'signatory_title' => 'Campus Executive Director',
            'name_y_position' => 50,
            'font_size' => 44,
            'font_color' => '#07152d',
            'is_active' => '1',
        ]);

        $response->assertRedirect("/events/{$event->id}/certificate");
        $this->assertDatabaseHas('event_certificates', [
            'event_id' => $event->id,
            'title' => 'Certificate of Outstanding Participation',
            'signatory_name' => 'Dr. Maria Santos',
        ]);
    }

    public function test_admin_can_upload_and_replace_certificate_template(): void
    {
        Storage::fake('public');

        $event = $this->event;
        $settings = [
            'title' => 'Certificate of Participation',
            'sub_title' => 'is proudly presented to',
            'signatory_name' => 'Dr. Maria Santos',
            'signatory_title' => 'Campus Executive Director',
            'name_y_position' => 50,
            'font_size' => 44,
            'font_color' => '#07152d',
            'is_active' => '1',
        ];

        $this->actingAs($this->admin)->post("/events/{$event->id}/certificate", $settings + [
            'template_image' => UploadedFile::fake()->image('first-template.png', 100, 80),
        ])->assertRedirect("/events/{$event->id}/certificate");

        $firstPath = $event->fresh()->certificate->template_path;
        Storage::disk('public')->assertExists($firstPath);

        $this->post("/events/{$event->id}/certificate", $settings + [
            'template_image' => UploadedFile::fake()->image('replacement-template.png', 120, 90),
        ])->assertRedirect("/events/{$event->id}/certificate");

        $replacementPath = $event->fresh()->certificate->template_path;
        $this->assertNotSame($firstPath, $replacementPath);
        Storage::disk('public')->assertExists($replacementPath);
        Storage::disk('public')->assertMissing($firstPath);
    }

    public function test_certificate_preview_renders_png_image(): void
    {
        $event = $this->event;

        $response = $this->actingAs($this->admin)->get("/events/{$event->id}/certificate/preview");
        $response->assertStatus(200);
        $this->assertEquals('image/png', $response->headers->get('Content-Type'));
    }

    public function test_student_can_evaluate_event_and_automatically_receive_certificate(): void
    {
        $admin = $this->admin;
        $student = $this->student;
        $event = $this->event;
        $event->update(['status' => 'completed']);
        $studentUser = $this->studentUser;

        // Ensure clean state for this student & event
        EventEvaluation::where('event_id', $event->id)->where('student_id', $student->id)->delete();
        IssuedCertificate::where('event_id', $event->id)->where('student_id', $student->id)->delete();
        $event->update(['evaluation_enabled' => true]);
        Attendance::updateOrCreate(
            ['event_id' => $event->id, 'student_id' => $student->id],
            ['status' => 'present', 'scanned_at' => now(), 'scanned_by' => 'Feature Test']
        );

        // 1. Visit evaluation form
        $response = $this->actingAs($studentUser)->get("/events/{$event->id}/evaluate");
        $response->assertStatus(200);
        $response->assertSee('Evaluation Questionnaire');

        // 2. Submit evaluation
        $postResponse = $this->actingAs($studentUser)->post("/events/{$event->id}/evaluate", [
            'rating_content' => 5,
            'rating_speaker' => 5,
            'rating_venue' => 4,
            'rating_overall' => 5,
            'comments' => 'Excellent and engaging presentations!',
            'suggestions' => 'Provide more Q&A time next time.',
        ]);

        // 3. Verify evaluation was stored
        $this->assertDatabaseHas('event_evaluations', [
            'event_id' => $event->id,
            'student_id' => $student->id,
            'rating_overall' => 5,
        ]);

        // 4. Verify certificate was automatically issued with student name
        $issued = IssuedCertificate::where('event_id', $event->id)->where('student_id', $student->id)->first();
        $this->assertNotNull($issued);
        $this->assertEquals($student->full_name, $issued->student_name);

        // 5. Verify redirected to certificate view
        $postResponse->assertRedirect("/certificates/{$issued->certificate_code}");

        // 6. View certificate page
        $certPage = $this->actingAs($admin)->get("/certificates/{$issued->certificate_code}");
        $certPage->assertStatus(200);
        $certPage->assertSee($student->full_name);
        $certPage->assertSee($issued->certificate_code);

        // 7. Verify PNG download endpoint returns image/png
        $downloadResponse = $this->actingAs($admin)->get("/certificates/{$issued->certificate_code}/download");
        $downloadResponse->assertStatus(200);
        $this->assertEquals('image/png', $downloadResponse->headers->get('Content-Type'));

        // 8. Public verification page works without authentication
        $verifyResponse = $this->get("/verify-certificate/{$issued->certificate_code}");
        $verifyResponse->assertStatus(200);
        $verifyResponse->assertSee('Officially Verified');
        $verifyResponse->assertSee($issued->certificate_code);
    }

    public function test_student_without_present_attendance_cannot_evaluate(): void
    {
        $student = $this->student;
        $event = Event::create([
            'name' => 'Evaluation Eligibility Test '.uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'completed',
            'evaluation_enabled' => true,
        ]);
        $studentUser = $this->studentUser;

        $this->actingAs($studentUser)
            ->get("/events/{$event->id}/evaluate")
            ->assertRedirect('/');

        Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'late',
            'scanned_at' => now(),
            'scanned_by' => 'Feature Test',
        ]);

        $this->post("/events/{$event->id}/evaluate", [
            'rating_content' => 5,
            'rating_speaker' => 5,
            'rating_venue' => 5,
            'rating_overall' => 5,
        ])->assertRedirect('/');

        $this->assertDatabaseMissing('event_evaluations', [
            'event_id' => $event->id,
            'student_id' => $student->id,
        ]);
        $this->assertDatabaseMissing('issued_certificates', [
            'event_id' => $event->id,
            'student_id' => $student->id,
        ]);
        $this->assertDatabaseHas('attendance', [
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'late',
        ]);
    }

    public function test_admin_can_download_blank_hd_template(): void
    {
        $event = $this->event;

        $response = $this->actingAs($this->admin)->get("/events/{$event->id}/certificate/blank-template");
        $response->assertStatus(200);
        $this->assertEquals('image/png', $response->headers->get('Content-Type'));
        $this->assertStringContainsString('Pangasinan-State-University-Blank-HD-Certificate-Template.png', (string) $response->headers->get('Content-Disposition'));
    }

    public function test_admin_can_remove_custom_template(): void
    {
        $event = $this->event;

        // Give event a dummy template path
        $cert = $event->certificate;
        $cert->template_path = 'certificates/templates/dummy.png';
        $cert->save();

        $response = $this->actingAs($this->admin)->post("/events/{$event->id}/certificate", [
            'title' => 'Updated Title',
            'sub_title' => 'is proudly presented to',
            'signatory_name' => 'Campus Executive Director',
            'signatory_title' => 'PSU ACC',
            'name_y_position' => 50,
            'font_size' => 45,
            'font_color' => '#07152d',
            'remove_custom_template' => '1',
        ]);

        $response->assertRedirect("/events/{$event->id}/certificate");
        $this->assertNull($cert->fresh()->template_path);
    }
}
