<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\ActivityLog;
use App\Models\Event;
use App\Models\Student;
use App\Models\User;
use Carbon\Carbon;
use Tests\TestCase;

class EventScanningControlTest extends TestCase
{
    public function test_new_event_starts_scheduled_with_scanning_disabled(): void
    {
        $admin = $this->createAdmin();

        try {
            $this->actingAs($admin)
                ->post('/events', [
                    'name' => 'Scanning Control Event ' . uniqid(),
                    'event_date' => now()->toDateString(),
                    'start_time' => now()->addHour()->format('H:i'),
                    'end_time' => now()->addHours(2)->format('H:i'),
                    'status' => 'active',
                ])
                ->assertRedirect();

            $event = Event::where('name', 'like', 'Scanning Control Event%')->latest('id')->firstOrFail();
            $this->assertSame('scheduled', $event->status);
            $this->assertFalse($event->scanning_enabled);
        } finally {
            Event::where('name', 'like', 'Scanning Control Event%')->delete();
            $admin->delete();
        }
    }

    public function test_admin_can_pause_scanning_without_completing_event_before_its_end_time(): void
    {
        $eventDay = Carbon::today(config('app.timezone'));
        $this->travelTo($eventDay->copy()->setTime(9, 0));
        $admin = $this->createAdmin();
        $student = $this->createStudent();
        $lateStudent = $this->createStudent();
        $event = $this->createEvent(
            'Future Event',
            $eventDay->copy()->setTime(10, 0),
            $eventDay->copy()->setTime(14, 0)
        );

        try {
            $this->actingAs($admin)
                ->get(route('attendance.scanner', ['event_id' => $event->id]))
                ->assertOk()
                ->assertSee('Scanner Paused')
                ->assertSee('Start Scanning');

            $this->actingAs($admin)
                ->post(route('events.scanning.update', $event), ['action' => 'start'])
                ->assertRedirect(route('events.show', $event));
            $this->assertTrue($event->fresh()->scanning_enabled);

            $this->actingAs($admin)
                ->postJson('/attendance/scan', [
                    'event_id' => $event->id,
                    'barcode' => $student->student_id,
                ])
                ->assertOk()
                ->assertJsonPath('success', true);

            $this->travelTo($eventDay->copy()->setTime(13, 0));
            $this->actingAs($admin)
                ->get(route('attendance.scanner', ['event_id' => $event->id]))
                ->assertOk()
                ->assertSee('Scanner Active');
            $this->actingAs($admin)
                ->postJson('/attendance/scan', [
                    'event_id' => $event->id,
                    'barcode' => $lateStudent->student_id,
                ])
                ->assertOk()
                ->assertJsonPath('success', true);

            $this->actingAs($admin)
                ->post(route('events.scanning.update', $event), ['action' => 'pause'])
                ->assertRedirect(route('events.show', $event));
            $this->assertSame('active', $event->fresh()->status);
            $this->assertFalse($event->fresh()->scanning_enabled);
            $this->assertDatabaseHas('attendance', [
                'event_id' => $event->id,
                'student_id' => $student->id,
            ]);

            $this->travelTo($eventDay->copy()->setTime(14, 0));
            $this->actingAs($admin)
                ->get(route('events.show', $event))
                ->assertOk();
            $this->assertSame('completed', $event->fresh()->status);
        } finally {
            $event->delete();
            $student->forceDelete();
            $lateStudent->forceDelete();
            $admin->delete();
            $this->travelBack();
        }
    }

    public function test_admin_can_start_and_pause_scanning_during_the_event_schedule(): void
    {
        $start = Carbon::parse('2026-11-03 10:00:00', config('app.timezone'));
        $this->travelTo($start);
        $admin = $this->createAdmin();
        $student = $this->createStudent();
        $event = $this->createEvent(
            'Scan Lifecycle',
            $start->copy()->addHour(),
            $start->copy()->addHours(2)
        );

        try {
            $this->actingAs($admin)->get(route('events.show', $event))
                ->assertOk()
                ->assertSee('Start Scanning');

            $this->actingAs($admin)
                ->get(route('attendance.scanner', ['event_id' => $event->id]))
                ->assertOk()
                ->assertSee('Scanner Paused')
                ->assertSee('Start Scanning');

            $this->actingAs($admin)
                ->post(route('events.scanning.update', $event), [
                    'action' => 'start',
                    'return_to_scanner' => '1',
                ])
                ->assertRedirect(route('attendance.scanner', ['event_id' => $event->id]));

            $this->assertSame('active', $event->fresh()->status);
            $this->assertTrue($event->fresh()->scanning_enabled);

            $this->actingAs($admin)
                ->get(route('events.show', $event))
                ->assertOk()
                ->assertSee('Pause Scanning')
                ->assertDontSee('End Scanning');

            $this->actingAs($admin)
                ->get(route('attendance.scanner', ['event_id' => $event->id]))
                ->assertOk()
                ->assertSee('Scanner Active')
                ->assertSee('id="barcodeInput"', false)
                ->assertSee('required', false)
                ->assertSee("addEventListener('submit', handleScanSubmit)", false);

            $this->actingAs($admin)
                ->postJson('/attendance/scan', [
                    'event_id' => $event->id,
                    'barcode' => $student->student_id,
                ])
                ->assertOk()
                ->assertJsonPath('success', true);

            $this->actingAs($admin)
                ->post(route('events.scanning.update', $event), ['action' => 'pause'])
                ->assertRedirect(route('events.show', $event))
                ->assertSessionHas('success', 'Scanning is paused. The event will remain open until its scheduled end time.');

            $this->assertSame('active', $event->fresh()->status);
            $this->assertFalse($event->fresh()->scanning_enabled);

            $this->actingAs($admin)
                ->postJson('/attendance/scan', [
                    'event_id' => $event->id,
                    'barcode' => $student->student_id,
                ])
                ->assertStatus(423)
                ->assertJsonPath('code', 'SCANNING_DISABLED');

            $this->travelTo($start->copy()->addHours(2));
            $this->actingAs($admin)
                ->get(route('events.show', $event))
                ->assertOk();
            $this->assertSame('completed', $event->fresh()->status);
        } finally {
            Attendance::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            $this->travelBack();
        }
    }

    public function test_admin_can_cancel_event_without_deleting_attendance(): void
    {
        $admin = $this->createAdmin();
        $student = $this->createStudent();
        $event = $this->createEvent(
            'Cancelled Event',
            now()->addDay(),
            now()->addDay()->addHours(2)
        );
        $event->update(['status' => 'active', 'scanning_enabled' => true]);
        $attendance = Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => now(),
        ]);

        try {
            $this->actingAs($admin)
                ->get(route('events.show', $event))
                ->assertOk()
                ->assertSee('Reschedule')
                ->assertSee('Cancel Event');

            $this->actingAs($admin)
                ->post(route('events.cancel', $event))
                ->assertRedirect(route('events.show', $event))
                ->assertSessionHas('success');

            $this->assertSame('cancelled', $event->fresh()->status);
            $this->assertFalse($event->fresh()->scanning_enabled);
            $this->assertDatabaseHas('attendance', ['id' => $attendance->id]);
        } finally {
            ActivityLog::where('action', 'Cancelled Event')
                ->where('details', 'like', '%' . $event->name . '%')
                ->delete();
            Attendance::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
        }
    }

    public function test_admin_can_reschedule_event_and_disable_scanning(): void
    {
        $admin = $this->createAdmin();
        $student = $this->createStudent();
        $event = $this->createEvent(
            'Rescheduled Event',
            now()->addDay(),
            now()->addDay()->addHours(2)
        );
        $event->update(['status' => 'active', 'scanning_enabled' => true]);
        $attendance = Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => now(),
        ]);
        $newDate = now()->addDays(3)->toDateString();

        try {
            $this->actingAs($admin)
                ->get(route('events.show', $event))
                ->assertOk()
                ->assertSee('Reschedule')
                ->assertSee(route('events.reschedule', $event), false);

            $this->actingAs($admin)
                ->put(route('events.reschedule', $event), ['event_date' => $newDate])
                ->assertRedirect(route('events.show', $event))
                ->assertSessionHas('success');

            $this->assertSame($newDate, $event->fresh()->event_date->format('Y-m-d'));
            $this->assertSame('scheduled', $event->fresh()->status);
            $this->assertFalse($event->fresh()->scanning_enabled);
            $this->assertDatabaseHas('attendance', ['id' => $attendance->id]);
        } finally {
            ActivityLog::where('action', 'Rescheduled Event')
                ->where('details', 'like', '%' . $event->name . '%')
                ->delete();
            Attendance::where('event_id', $event->id)->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
        }
    }

    public function test_rescheduling_requires_a_future_date(): void
    {
        $admin = $this->createAdmin();
        $event = $this->createEvent(
            'Invalid Reschedule',
            now()->addDay(),
            now()->addDay()->addHours(2)
        );
        $originalDate = $event->event_date->format('Y-m-d');

        try {
            $this->actingAs($admin)
                ->from(route('events.show', $event))
                ->put(route('events.reschedule', $event), ['event_date' => now()->toDateString()])
                ->assertRedirect(route('events.show', $event))
                ->assertSessionHasErrors('event_date');

            $this->assertSame($originalDate, $event->fresh()->event_date->format('Y-m-d'));
            $this->assertSame('scheduled', $event->fresh()->status);
        } finally {
            $event->delete();
            $admin->delete();
        }
    }

    private function createAdmin(): User
    {
        return User::create([
            'name' => 'Scanning Control Admin ' . uniqid(),
            'username' => 'scan-admin-' . uniqid(),
            'email' => 'scan-admin-' . uniqid() . '@example.test',
            'password' => 'password',
            'role' => 'admin',
        ]);
    }

    private function createStudent(): Student
    {
        return Student::create([
            'student_id' => 'SCAN-' . uniqid(),
            'full_name' => 'Scanning Control Student',
        ]);
    }

    private function createEvent(string $name, Carbon $start, Carbon $end): Event
    {
        return Event::create([
            'name' => $name . ' ' . uniqid(),
            'event_date' => $start->toDateString(),
            'start_time' => $start->format('H:i:s'),
            'end_time' => $end->format('H:i:s'),
            'status' => 'scheduled',
            'scanning_enabled' => false,
        ]);
    }
}
