<?php

namespace Tests\Feature;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\Student;
use App\Models\SystemSetting;
use App\Models\User;
use App\Services\EventLifecycleService;
use Carbon\Carbon;
use Tests\TestCase;

class EventAutoCompletionTest extends TestCase
{
    public function test_command_completes_active_events_after_their_end_time(): void
    {
        $this->travelTo(Carbon::parse('2026-11-03 15:00:00', config('app.timezone')));

        $expiredEvent = $this->createEvent('Expired', '2026-11-02', '17:00:00');
        $justEndedEvent = $this->createEvent('Just ended', '2026-11-03', '14:59:00');
        $upcomingEvent = $this->createEvent('Upcoming', '2026-11-03', '15:01:00');
        $noEndTimeEvent = $this->createEvent('No end time', '2026-11-03', null);
        $manuallyStartedEvent = $this->createEvent('Manually started', '2026-11-02', '17:00:00');
        $manuallyStartedEvent->update(['scanning_enabled' => true]);
        $student = Student::create([
            'student_id' => 'AUTO-CHECKOUT-' . uniqid(),
            'full_name' => 'Automatic Checkout Test Student',
        ]);
        $attendance = Attendance::create([
            'event_id' => $manuallyStartedEvent->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => Carbon::parse('2026-11-02 09:00:00', config('app.timezone')),
        ]);
        $previousAutoCheckoutSetting = SystemSetting::get('auto_checkout_enabled');
        SystemSetting::set('auto_checkout_enabled', '1');
        $cancelledEvent = $this->createEvent('Cancelled', '2026-11-02', '17:00:00', 'cancelled');
        $existingCompletionLogs = ActivityLog::where('action', 'Event Completed')->count();

        try {
            $this->artisan('events:complete-expired')
                ->expectsOutput('Completed 3 expired event(s).')
                ->assertExitCode(0);

            $this->assertSame('completed', $expiredEvent->fresh()->status);
            $this->assertSame('completed', $justEndedEvent->fresh()->status);
            $this->assertSame('active', $upcomingEvent->fresh()->status);
            $this->assertSame('active', $noEndTimeEvent->fresh()->status);
            $this->assertSame('completed', $manuallyStartedEvent->fresh()->status);
            $this->assertFalse($manuallyStartedEvent->fresh()->scanning_enabled);
            $this->assertStringContainsString('Checked out automatically at', $attendance->fresh()->notes);
            $this->assertSame(
                1,
                substr_count($attendance->fresh()->notes, 'Checked out automatically at')
            );
            $this->assertFalse(app(EventLifecycleService::class)->completeEvent($manuallyStartedEvent, now()));
            $this->assertSame('cancelled', $cancelledEvent->fresh()->status);
            $this->assertSame(
                $existingCompletionLogs + 3,
                ActivityLog::where('action', 'Event Completed')->count()
            );
        } finally {
            $testEvents = [
                $expiredEvent->id,
                $justEndedEvent->id,
                $upcomingEvent->id,
                $noEndTimeEvent->id,
                $manuallyStartedEvent->id,
                $cancelledEvent->id,
            ];
            foreach ([$expiredEvent, $justEndedEvent, $manuallyStartedEvent] as $completedEvent) {
                ActivityLog::where('action', 'Event Completed')
                    ->where('details', 'like', '%' . $completedEvent->name . '%')
                    ->delete();
            }
            Event::whereIn('id', $testEvents)->delete();
            $student->forceDelete();
            if ($previousAutoCheckoutSetting === null) {
                SystemSetting::where('key_name', 'auto_checkout_enabled')->delete();
            } else {
                SystemSetting::set('auto_checkout_enabled', $previousAutoCheckoutSetting);
            }
            $this->travelBack();
        }
    }

    public function test_pausing_scanning_does_not_complete_or_check_out_before_event_end(): void
    {
        $admin = User::create([
            'name' => 'Manual End Admin ' . uniqid(),
            'username' => 'manual-end-' . uniqid(),
            'email' => 'manual-end-' . uniqid() . '@example.test',
            'password' => 'password',
            'role' => 'admin',
        ]);
        $student = Student::create([
            'student_id' => 'MANUAL-END-' . uniqid(),
            'full_name' => 'Manual End Test Student',
        ]);
        $event = $this->createEvent('Manual event end', now()->toDateString(), now()->addHour()->format('H:i:s'));
        $previousAutoCheckoutSetting = SystemSetting::get('auto_checkout_enabled');
        SystemSetting::set('auto_checkout_enabled', '1');
        $attendance = Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => now(),
        ]);

        try {
            $this->actingAs($admin)
                ->post(route('events.scanning.update', $event), ['action' => 'pause'])
                ->assertRedirect(route('events.show', $event))
                ->assertSessionHas('success');

            $this->assertSame('active', $event->fresh()->status);
            $this->assertFalse($event->fresh()->scanning_enabled);
            $this->assertNull($attendance->fresh()->notes);

            $this->travelTo(now()->addHours(2));
            app(EventLifecycleService::class)->completeExpiredEvents();
            $this->assertSame('completed', $event->fresh()->status);
            $this->assertStringContainsString('Checked out automatically at', $attendance->fresh()->notes);
        } finally {
            $event->delete();
            $student->forceDelete();
            $admin->delete();
            if ($previousAutoCheckoutSetting === null) {
                SystemSetting::where('key_name', 'auto_checkout_enabled')->delete();
            } else {
                SystemSetting::set('auto_checkout_enabled', $previousAutoCheckoutSetting);
            }
            $this->travelBack();
        }
    }

    public function test_overnight_event_completes_at_end_time_on_following_day(): void
    {
        $this->travelTo(Carbon::parse('2026-11-03 23:30:00', config('app.timezone')));
        $event = $this->createEvent('Overnight', '2026-11-03', '01:00:00', 'active', '22:00:00');

        try {
            $this->artisan('events:complete-expired')->assertExitCode(0);
            $this->assertSame('active', $event->fresh()->status);

            $this->travelTo(Carbon::parse('2026-11-04 01:00:00', config('app.timezone')));
            $this->artisan('events:complete-expired')->assertExitCode(0);
            $this->assertSame('completed', $event->fresh()->status);
        } finally {
            ActivityLog::where('action', 'Event Completed')
                ->where('details', 'like', '%' . $event->name . '%')
                ->delete();
            $event->delete();
            $this->travelBack();
        }
    }

    public function test_scheduled_event_starts_at_start_time_and_completes_at_end_time(): void
    {
        $event = $this->createEvent(
            'Scheduled lifecycle',
            '2026-11-04',
            '12:00:00',
            'scheduled',
            '11:00:00'
        );

        try {
            $this->travelTo(Carbon::parse('2026-11-04 10:59:00', config('app.timezone')));
            app(EventLifecycleService::class)->completeExpiredEvents();
            $this->assertSame('scheduled', $event->fresh()->status);
            $this->assertFalse($event->fresh()->scanning_enabled);

            $this->travelTo(Carbon::parse('2026-11-04 11:00:00', config('app.timezone')));
            app(EventLifecycleService::class)->completeExpiredEvents();
            $this->assertSame('active', $event->fresh()->status);
            $this->assertTrue($event->fresh()->scanning_enabled);

            $this->travelTo(Carbon::parse('2026-11-04 12:00:00', config('app.timezone')));
            app(EventLifecycleService::class)->completeExpiredEvents();
            $this->assertSame('completed', $event->fresh()->status);
            $this->assertFalse($event->fresh()->scanning_enabled);
        } finally {
            ActivityLog::whereIn('action', ['Event Scanning Started', 'Event Completed'])
                ->where('details', 'like', '%' . $event->name . '%')
                ->delete();
            $event->delete();
            $this->travelBack();
        }
    }

    public function test_event_list_completes_expired_events_when_loaded(): void
    {
        $admin = User::create([
            'name' => 'Event Lifecycle Admin',
            'username' => 'event-lifecycle-' . uniqid(),
            'email' => 'event-lifecycle-' . uniqid() . '@example.test',
            'password' => 'password',
            'role' => 'admin',
        ]);
        $this->travelTo(Carbon::parse('2026-11-03 15:00:00', config('app.timezone')));
        $event = $this->createEvent('Page-triggered completion', '2026-11-03', '14:00:00');

        try {
            $this->actingAs($admin)
                ->get('/events')
                ->assertOk()
                ->assertSee($event->name);
            $this->assertSame('completed', $event->fresh()->status);
        } finally {
            ActivityLog::where('action', 'Event Completed')
                ->where('details', 'like', '%' . $event->name . '%')
                ->delete();
            $event->delete();
            $admin->delete();
            $this->travelBack();
        }
    }

    private function createEvent(
        string $name,
        string $date,
        ?string $endTime,
        string $status = 'active',
        ?string $startTime = '08:00:00'
    ): Event {
        return Event::create([
            'name' => $name . ' ' . uniqid(),
            'event_date' => $date,
            'start_time' => $startTime,
            'end_time' => $endTime,
            'status' => $status,
        ]);
    }
}
