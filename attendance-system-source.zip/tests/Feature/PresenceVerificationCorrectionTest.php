<?php

namespace Tests\Feature;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\PresenceVerification;
use App\Models\Student;
use App\Models\User;
use Tests\TestCase;

class PresenceVerificationCorrectionTest extends TestCase
{
    public function test_admin_can_edit_telemetry_without_changing_attendance(): void
    {
        [$admin, $event, $student, $verification, $attendance] = $this->createTelemetryRecords('admin');

        try {
            $this->actingAs($admin)
                ->get(route('presence.index'))
                ->assertOk()
                ->assertSee('Select an event to view telemetry')
                ->assertDontSee('Real-Time GPS Verification Telemetry Logs');

            $this->actingAs($admin)
                ->get(route('presence.index', ['event_id' => $event->id]))
                ->assertOk()
                ->assertSee('Real-Time GPS Verification Telemetry Logs')
                ->assertSee('Edit log');

            $this->actingAs($admin)
                ->put(route('presence.verifications.update', $verification), [
                    'status' => 'outside',
                    'distance_meters' => 135.5,
                    'verified_at' => '2026-11-03T10:15',
                    'notes' => 'GPS: 16.115303, 119.967252',
                ])
                ->assertRedirect(route('presence.index', ['event_id' => $event->id]));

            $this->assertSame('outside', $verification->fresh()->status);
            $this->assertSame(135.5, (float) $verification->fresh()->distance_meters);
            $this->assertSame('present', $attendance->fresh()->status);
            $this->assertDatabaseHas('activity_logs', [
                'action' => 'Edited GPS Verification Log',
                'actor' => $admin->name,
            ]);
        } finally {
            ActivityLog::where('action', 'Edited GPS Verification Log')
                ->where('actor', $admin->name)
                ->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
        }
    }

    public function test_officer_cannot_access_or_edit_telemetry(): void
    {
        [$officer, $event, $student, $verification] = $this->createTelemetryRecords('officer');

        try {
            $this->actingAs($officer)
                ->get(route('presence.index', ['event_id' => $event->id]))
                ->assertForbidden();

            $this->actingAs($officer)
                ->put(route('presence.verifications.update', $verification), [
                    'status' => 'outside',
                    'distance_meters' => 135.5,
                    'verified_at' => '2026-11-03T10:15',
                ])
                ->assertForbidden();

            $this->assertSame('inside', $verification->fresh()->status);
        } finally {
            $event->delete();
            $student->forceDelete();
            $officer->delete();
        }
    }

    public function test_superadmin_can_edit_telemetry(): void
    {
        [$superadmin, $event, $student, $verification] = $this->createTelemetryRecords('superadmin');

        try {
            $this->actingAs($superadmin)
                ->put(route('presence.verifications.update', $verification), [
                    'status' => 'outside',
                    'distance_meters' => 80,
                    'verified_at' => '2026-11-03T10:15',
                ])
                ->assertRedirect(route('presence.index', ['event_id' => $event->id]));

            $this->assertSame('outside', $verification->fresh()->status);
        } finally {
            ActivityLog::where('action', 'Edited GPS Verification Log')
                ->where('actor', $superadmin->name)
                ->delete();
            $event->delete();
            $student->forceDelete();
            $superadmin->delete();
        }
    }

    public function test_admin_can_delete_telemetry_without_deleting_attendance(): void
    {
        [$admin, $event, $student, $verification, $attendance] = $this->createTelemetryRecords('admin');
        $verificationId = $verification->id;

        try {
            $this->actingAs($admin)
                ->delete(route('presence.verifications.destroy', $verification))
                ->assertRedirect(route('presence.index', ['event_id' => $event->id]));

            $this->assertDatabaseMissing('presence_verifications', ['id' => $verificationId]);
            $this->assertSame('present', $attendance->fresh()->status);
            $this->assertDatabaseHas('attendance', ['id' => $attendance->id]);
            $this->assertDatabaseHas('activity_logs', [
                'action' => 'Deleted GPS Verification Log',
                'actor' => $admin->name,
            ]);
        } finally {
            ActivityLog::where('action', 'Deleted GPS Verification Log')
                ->where('actor', $admin->name)
                ->delete();
            $event->delete();
            $student->forceDelete();
            $admin->delete();
        }
    }

    public function test_non_admin_cannot_delete_telemetry(): void
    {
        [$officer, $event, $student, $verification] = $this->createTelemetryRecords('officer');

        try {
            $this->actingAs($officer)
                ->delete(route('presence.verifications.destroy', $verification))
                ->assertForbidden();

            $this->assertDatabaseHas('presence_verifications', ['id' => $verification->id]);
        } finally {
            $event->delete();
            $student->forceDelete();
            $officer->delete();
        }
    }

    public function test_invalid_telemetry_correction_is_rejected(): void
    {
        [$admin, $event, $student, $verification] = $this->createTelemetryRecords('admin');
        $existingCorrectionLogs = ActivityLog::where('action', 'Edited GPS Verification Log')->count();

        try {
            $this->actingAs($admin)
                ->put(route('presence.verifications.update', $verification), [
                    'status' => 'unknown',
                    'distance_meters' => -1,
                    'verified_at' => 'not-a-date',
                ])
                ->assertSessionHasErrors(['status', 'distance_meters', 'verified_at']);

            $this->assertSame('inside', $verification->fresh()->status);
            $this->assertSame(25.0, (float) $verification->fresh()->distance_meters);
            $this->assertSame(
                $existingCorrectionLogs,
                ActivityLog::where('action', 'Edited GPS Verification Log')->count()
            );
        } finally {
            $event->delete();
            $student->forceDelete();
            $admin->delete();
        }
    }

    private function createTelemetryRecords(string $role): array
    {
        $user = User::create([
            'name' => ucfirst($role) . ' Telemetry Test ' . uniqid(),
            'username' => strtolower($role) . '-telemetry-' . uniqid(),
            'email' => strtolower($role) . '-telemetry-' . uniqid() . '@example.test',
            'password' => 'password',
            'role' => $role,
        ]);
        $student = Student::create([
            'student_id' => 'TELEMETRY-' . uniqid(),
            'full_name' => 'Telemetry Test Student',
        ]);
        $event = Event::create([
            'name' => 'Telemetry Test Event ' . uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'active',
        ]);
        $verification = PresenceVerification::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'inside',
            'distance_meters' => 25,
            'verified_at' => now(),
            'notes' => 'Original note',
        ]);
        $attendance = Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => now(),
        ]);

        return [$user, $event, $student, $verification, $attendance];
    }
}
