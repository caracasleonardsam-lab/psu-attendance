<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Event;
use App\Models\Organization;
use App\Models\Program;
use App\Models\Student;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Tests\TestCase;

class StudentManagementTest extends TestCase
{
    public function test_student_roster_displays_a_printable_code128_barcode_pass(): void
    {
        $superAdmin = User::factory()->create(['role' => 'superadmin']);
        $student = Student::create([
            'student_id' => 'CODE128-' . uniqid(),
            'full_name' => 'Barcode Pass Student',
        ]);

        try {
            $this->actingAs($superAdmin)
                ->get(route('students.index'))
                ->assertOk()
                ->assertSee('Student Digital Pass')
                ->assertSee('Code 128 barcode')
                ->assertSee('format: \'CODE128\'', false)
                ->assertSee('Print Barcode');
        } finally {
            $student->forceDelete();
            $superAdmin->delete();
        }
    }

    public function test_admin_can_edit_student_academic_details_and_year_block_are_normalized(): void
    {
        $admin = User::factory()->create(['role' => 'superadmin']);
        $student = Student::create([
            'student_id' => 'EDIT-' . uniqid(),
            'full_name' => 'Original Name',
            'year_level' => 'First Year',
            'block' => 'A',
        ]);
        $program = Program::create(['name' => 'Updated Course ' . uniqid()]);

        try {
            $this->actingAs($admin)->get(route('students.index'))
                ->assertOk()
                ->assertSee('openEditStudentModal(')
                ->assertSee('Import Student Roster');

            $this->actingAs($admin)->put(route('students.update', $student), [
                'student_id' => 'CHANGED-' . uniqid(),
                'full_name' => 'Updated Name',
                'program_id' => $program->id,
                'year_level' => '3',
                'block' => 'c',
            ])->assertRedirect();

            $this->assertDatabaseHas('students', [
                'id' => $student->id,
                'student_id' => $student->getOriginal('student_id'),
                'full_name' => 'Updated Name',
                'program_id' => $program->id,
                'year_level' => 'Third Year',
                'block' => 'C',
            ]);
        } finally {
            $student->forceDelete();
            $program->delete();
            $admin->delete();
        }
    }

    public function test_csv_import_creates_and_updates_students_with_course_and_academic_details(): void
    {
        $admin = User::factory()->create(['role' => 'superadmin']);
        $studentId = 'IMPORT-' . uniqid();
        $existing = Student::create([
            'student_id' => $studentId,
            'full_name' => 'Old Name',
            'year_level' => 'First Year',
            'block' => 'A',
        ]);
        $organizationName = 'Imported Organization ' . uniqid();
        $courseName = 'Imported Course ' . uniqid();
        $newStudentId = 'NEW-' . uniqid();
        $csv = implode("\n", [
            'Student Number,Full Name,Course,Year Level,Block,Organization,Email,Phone',
            "{$studentId},Updated Name,{$courseName},Second Year,b,{$organizationName},updated@example.com,09123456789",
            "{$newStudentId},New Student,{$courseName},1,a,,new@example.com,",
        ]);

        try {
            $this->actingAs($admin)->post(route('students.import'), [
                'student_file' => UploadedFile::fake()->createWithContent('roster.csv', $csv),
            ])->assertRedirect()->assertSessionHas('success', 'Student roster imported: 1 added, 1 updated.');

            $this->assertDatabaseHas('students', [
                'id' => $existing->id,
                'full_name' => 'Updated Name',
                'year_level' => 'Second Year',
                'block' => 'B',
                'email' => 'updated@example.com',
            ]);
            $this->assertDatabaseHas('programs', ['name' => $courseName]);
            $this->assertDatabaseHas('organizations', ['name' => $organizationName]);
            $this->assertDatabaseHas('students', [
                'student_id' => $newStudentId,
                'year_level' => 'First Year',
                'block' => 'A',
            ]);
        } finally {
            Student::withTrashed()->where('student_id', $studentId)->forceDelete();
            Student::withTrashed()->where('student_id', $newStudentId)->forceDelete();
            Program::where('name', $courseName)->delete();
            Organization::where('name', $organizationName)->delete();
            $admin->delete();
        }
    }

    public function test_invalid_csv_does_not_partially_import_students(): void
    {
        $admin = User::factory()->create(['role' => 'superadmin']);
        $validStudentId = 'VALID-IMPORT-' . uniqid();
        $invalidCsv = implode("\n", [
            'Student Number,Full Name,Course',
            "{$validStudentId},Valid Name,Valid Course",
            'INVALID-ROW,Missing Course,',
        ]);

        try {
            $this->actingAs($admin)->post(route('students.import'), [
                'student_file' => UploadedFile::fake()->createWithContent('invalid-roster.csv', $invalidCsv),
            ])->assertSessionHasErrors('student_file');

            $this->assertDatabaseMissing('students', ['student_id' => $validStudentId]);
        } finally {
            Student::withTrashed()->where('student_id', $validStudentId)->forceDelete();
            $admin->delete();
        }
    }

    public function test_archiving_student_preserves_attendance_and_officers_cannot_edit_roster(): void
    {
        $admin = User::factory()->create(['role' => 'superadmin']);
        $officer = User::factory()->create(['role' => 'officer']);
        $student = Student::create(['student_id' => 'ARCHIVE-' . uniqid(), 'full_name' => 'Archived Student']);
        $event = Event::create([
            'name' => 'Student Archive Test ' . uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'active',
        ]);
        $attendance = Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => now(),
        ]);

        try {
            $this->actingAs($officer)->put(route('students.update', $student), [
                'student_id' => $student->student_id,
                'full_name' => 'Unauthorized Change',
            ])->assertForbidden();

            $this->actingAs($admin)->delete(route('students.destroy', $student))->assertRedirect();

            $this->assertSoftDeleted('students', ['id' => $student->id]);
            $this->assertDatabaseHas('attendance', ['id' => $attendance->id, 'student_id' => $student->id]);
            $this->assertSame('Archived Student', $attendance->fresh()->student->full_name);
        } finally {
            $student->forceDelete();
            $attendance->delete();
            $event->delete();
            $admin->delete();
            $officer->delete();
        }
    }

}
