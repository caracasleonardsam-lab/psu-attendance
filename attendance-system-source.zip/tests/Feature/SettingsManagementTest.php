<?php

namespace Tests\Feature;

use App\Models\ActivityLog;
use App\Models\Event;
use App\Models\SystemSetting;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class SettingsManagementTest extends TestCase
{
    protected User $admin;
    protected User $superAdmin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->superAdmin = User::firstOrCreate(
            ['username' => 'superadmin'],
            [
                'name' => 'System Super Admin',
                'email' => 'superadmin@psu.edu.ph',
                'password' => Hash::make('admin123'),
                'role' => 'superadmin',
            ]
        );

        $this->admin = User::firstOrCreate(
            ['username' => 'test_admin_user'],
            [
                'name' => 'Test Campus Admin',
                'email' => 'test_admin@psu.edu.ph',
                'password' => Hash::make('admin123'),
                'role' => 'admin',
            ]
        );
    }

    public function test_only_superadmin_can_view_settings(): void
    {
        $this->actingAs($this->admin)
            ->get('/settings')
            ->assertForbidden();

        $response = $this->actingAs($this->superAdmin)->get('/settings');

        $response->assertOk();
        $response->assertSee('System Settings &amp; Parameters', false);
        $response->assertSee('Campus &amp; Academic Term', false);
        $response->assertSee('Staff &amp; Administrator Accounts', false);
        $response->assertSee($this->superAdmin->name);
    }

    public function test_only_superadmin_can_update_institutional_and_academic_settings(): void
    {
        $payload = [
            'campus_name' => 'PSU - Alaminos City Campus Main',
            'system_name' => 'PSU Smart Presence & Attendance Portal',
            'campus_head' => 'Dr. Armando D. Junio, Ph.D.',
            'contact_email' => 'support@alaminos.psu.edu.ph',
            'campus_address' => 'Brgy. Bolaney, Alaminos City, Pangasinan',
            'academic_year' => '2026-2027',
            'academic_semester' => '2nd Semester',
        ];

        $this->actingAs($this->admin)
            ->post('/settings/general', $payload)
            ->assertForbidden();
        $this->assertDatabaseMissing('system_settings', [
            'key_name' => 'campus_name',
            'value_text' => 'PSU - Alaminos City Campus Main',
        ]);

        $response = $this->actingAs($this->superAdmin)
            ->post('/settings/general', $payload);
        $response->assertRedirect('/settings?tab=institutional');
        $response->assertSessionHas('success');

        $this->assertEquals('PSU - Alaminos City Campus Main', SystemSetting::get('campus_name'));
        $this->assertEquals('PSU Smart Presence & Attendance Portal', SystemSetting::get('system_name'));
        $this->assertEquals('Dr. Armando D. Junio, Ph.D.', SystemSetting::get('campus_head'));
        $this->assertEquals('2026-2027', SystemSetting::get('academic_year'));
        $this->assertEquals('2nd Semester', SystemSetting::get('academic_semester'));

        $this->assertDatabaseHas('activity_logs', [
            'action' => 'Updated Institutional Settings',
        ]);
    }

    public function test_only_superadmin_can_update_attendance_and_geofencing_defaults(): void
    {
        $payload = [
            'event_radius_meters' => 150,
            'verification_interval' => 20,
            'attendance_threshold' => 85,
            'session_timeout_minutes' => 45,
            'grace_period_minutes' => 20,
            'auto_checkout_enabled' => 1,
        ];

        $this->actingAs($this->admin)
            ->post('/settings/attendance', $payload)
            ->assertForbidden();
        $this->assertDatabaseMissing('system_settings', [
            'key_name' => 'event_radius_meters',
            'value_text' => '150',
        ]);

        $response = $this->actingAs($this->superAdmin)
            ->post('/settings/attendance', $payload);
        $response->assertRedirect('/settings?tab=attendance');
        $response->assertSessionHas('success');

        $this->assertEquals('150', SystemSetting::get('event_radius_meters'));
        $this->assertEquals('20', SystemSetting::get('verification_interval'));
        $this->assertEquals('85', SystemSetting::get('attendance_threshold'));
        $this->assertEquals('45', SystemSetting::get('session_timeout_minutes'));
        $this->assertEquals('20', SystemSetting::get('grace_period_minutes'));
        $this->assertEquals('1', SystemSetting::get('auto_checkout_enabled'));

        $this->assertDatabaseHas('activity_logs', [
            'action' => 'Updated Attendance Rules',
        ]);
    }

    public function test_superadmin_can_create_new_staff_account(): void
    {
        $uniqueUsername = 'officer_' . uniqid();
        $uniqueEmail = $uniqueUsername . '@psu.edu.ph';

        $payload = [
            'name' => 'Officer Juana Dela Cruz',
            'username' => $uniqueUsername,
            'email' => $uniqueEmail,
            'role' => 'officer',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ];

        $response = $this->actingAs($this->superAdmin)
            ->post('/settings/users', $payload);

        $response->assertRedirect('/settings?tab=users');
        $response->assertSessionHas('success');

        $this->assertDatabaseHas('users', [
            'username' => $uniqueUsername,
            'email' => $uniqueEmail,
            'role' => 'officer',
        ]);

        $createdUser = User::where('username', $uniqueUsername)->first();
        $this->assertTrue(Hash::check('password123', $createdUser->password));
    }

    public function test_admin_cannot_update_staff_account(): void
    {
        $user = User::create([
            'name' => 'Temporary Officer',
            'username' => 'temp_officer_' . uniqid(),
            'email' => 'temp_' . uniqid() . '@psu.edu.ph',
            'password' => Hash::make('oldpassword'),
            'role' => 'officer',
        ]);

        $response = $this->actingAs($this->admin)->put("/settings/users/{$user->id}", [
            'name' => 'Updated Officer Name',
            'username' => $user->username,
            'email' => $user->email,
            'role' => 'officer',
            'password' => 'newpassword123',
            'password_confirmation' => 'newpassword123',
        ]);

        $response->assertForbidden();

        $user->refresh();
        $this->assertEquals('Temporary Officer', $user->name);
        $this->assertTrue(Hash::check('oldpassword', $user->password));
    }

    public function test_safeguard_prevents_user_from_deleting_self(): void
    {
        $response = $this->actingAs($this->superAdmin)
            ->delete("/settings/users/{$this->superAdmin->id}");

        $response->assertRedirect('/settings?tab=users');
        $response->assertSessionHas('error');

        $this->assertDatabaseHas('users', ['id' => $this->superAdmin->id]);
    }

    public function test_safeguard_prevents_deleting_only_superadmin(): void
    {
        // Ensure only 1 superadmin exists
        User::where('role', 'superadmin')->where('id', '!=', $this->superAdmin->id)->delete();

        // Admin cannot delete the last superadmin
        $response = $this->actingAs($this->superAdmin)
            ->delete("/settings/users/{$this->superAdmin->id}");

        $response->assertRedirect('/settings?tab=users');
        $response->assertSessionHas('error');

        $this->assertDatabaseHas('users', ['id' => $this->superAdmin->id]);
    }

    public function test_admin_cannot_delete_an_officer_account(): void
    {
        $officer = User::create([
            'name' => 'Officer To Delete',
            'username' => 'officer_delete_' . uniqid(),
            'email' => 'del_' . uniqid() . '@psu.edu.ph',
            'password' => Hash::make('password123'),
            'role' => 'officer',
        ]);

        $response = $this->actingAs($this->admin)
            ->delete("/settings/users/{$officer->id}");

        $response->assertForbidden();

        $this->assertDatabaseHas('users', ['id' => $officer->id]);
    }

    public function test_event_creation_uses_settings_defaults_when_not_specified(): void
    {
        SystemSetting::set('event_radius_meters', '250');
        SystemSetting::set('verification_interval', '25');
        SystemSetting::set('attendance_threshold', '90');

        $response = $this->actingAs($this->admin)->post('/events', [
            'name' => 'Campus Leadership Summit ' . uniqid(),
            'event_date' => now()->addDays(5)->format('Y-m-d'),
            'status' => 'scheduled',
            'attendance_mode' => 'smart_qr_gps',
        ]);

        $response->assertRedirect();

        $event = Event::orderBy('id', 'desc')->first();
        $this->assertNotNull($event);
        $this->assertEquals(250, $event->radius_meters);
        $this->assertEquals(25, $event->verification_interval_minutes);
        $this->assertEquals(90, $event->minimum_required_presence);
        $this->assertEqualsWithDelta(16.115303, $event->latitude, 0.0000001);
        $this->assertEqualsWithDelta(119.967252, $event->longitude, 0.0000001);
    }
}
