<?php

namespace Tests\Feature;

use App\Models\Student;
use Tests\TestCase;

class StudentBlockApiTest extends TestCase
{
    public function test_mobile_profile_update_saves_a_normalized_block_and_year(): void
    {
        $student = Student::create([
            'student_id' => 'BLOCK-API-' . uniqid(),
            'full_name' => 'Block API Test Student',
        ]);

        try {
            $this->getJson('/api/student-dashboard?student_id=' . $student->student_id)
                ->assertOk()
                ->assertJsonPath('student.requires_block', true);

            $this->postJson('/api.php', [
                'action' => 'update_profile',
                'student_id' => $student->student_id,
                'year_level' => 'Second Year',
                'block' => 'A',
                'section_block' => 'A',
            ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('student.year_level', 'Second Year')
                ->assertJsonPath('student.block', 'A')
                ->assertJsonPath('student.section_block', 'A')
                ->assertJsonPath('student.requires_block', false);

            $this->assertDatabaseHas('students', [
                'id' => $student->id,
                'year_level' => 'Second Year',
                'block' => 'A',
            ]);
        } finally {
            $student->forceDelete();
        }
    }

    public function test_legacy_combined_section_block_is_split_before_saving(): void
    {
        $student = Student::create([
            'student_id' => 'LEGACY-BLOCK-' . uniqid(),
            'full_name' => 'Legacy Block Test Student',
        ]);

        try {
            $this->postJson('/api.php', [
                'action' => 'update_profile',
                'student_id' => $student->student_id,
                'section_block' => '2C',
            ])
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonPath('student.year_level', 'Second Year')
                ->assertJsonPath('student.block', 'C');

            $this->assertDatabaseHas('students', [
                'id' => $student->id,
                'year_level' => 'Second Year',
                'block' => 'C',
            ]);
        } finally {
            $student->forceDelete();
        }
    }

    public function test_mobile_profile_update_does_not_change_an_unrelated_student_for_unknown_id(): void
    {
        $student = Student::create([
            'student_id' => 'BLOCK-SAFE-' . uniqid(),
            'full_name' => 'Unchanged Student',
            'year_level' => 'First Year',
            'block' => 'A',
        ]);

        try {
            $this->postJson('/api.php', [
                'action' => 'update_profile',
                'student_id' => 'UNKNOWN-' . uniqid(),
                'block' => 'B',
            ])->assertNotFound()->assertJsonPath('success', false);

            $this->assertDatabaseHas('students', [
                'id' => $student->id,
                'year_level' => 'First Year',
                'block' => 'A',
            ]);
        } finally {
            $student->forceDelete();
        }
    }
}
