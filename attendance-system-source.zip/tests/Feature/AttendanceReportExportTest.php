<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Event;
use App\Models\Organization;
use App\Models\PresenceVerification;
use App\Models\Program;
use App\Models\Student;
use App\Models\User;
use Tests\TestCase;

class AttendanceReportExportTest extends TestCase
{
    public function test_attendance_exports_are_alphabetical_and_filter_by_year_and_block(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $event = Event::create([
            'name' => 'Alphabetical Report Test ' . uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'active',
            'venue' => 'Test Venue',
        ]);
        $students = collect([
            ['student_id' => 'REPORT-A-' . uniqid(), 'full_name' => 'Zoe Zebra', 'year_level' => 'First Year', 'block' => 'A'],
            ['student_id' => 'REPORT-B-' . uniqid(), 'full_name' => 'Ada Alpha', 'year_level' => 'First Year', 'block' => 'B'],
            ['student_id' => 'REPORT-C-' . uniqid(), 'full_name' => 'Ben Beta', 'year_level' => 'Second Year', 'block' => 'B'],
        ])->map(fn (array $data) => Student::create($data));

        try {
            foreach ($students as $student) {
                Attendance::create([
                    'event_id' => $event->id,
                    'student_id' => $student->id,
                    'status' => 'present',
                    'scanned_at' => now(),
                ]);
            }

            $allCampusCsv = $this->actingAs($admin)
                ->get(route('reports.export', ['event_id' => $event->id]))
                ->assertOk()
                ->streamedContent();

            $this->assertStringContainsString('Ada Alpha', $allCampusCsv);
            $this->assertStringContainsString('Ben Beta', $allCampusCsv);
            $this->assertStringContainsString('Zoe Zebra', $allCampusCsv);
            $this->assertLessThan(
                strpos($allCampusCsv, 'Ben Beta'),
                strpos($allCampusCsv, 'Ada Alpha'),
                'Campus attendance should be sorted alphabetically by student name.'
            );
            $this->assertLessThan(
                strpos($allCampusCsv, 'Zoe Zebra'),
                strpos($allCampusCsv, 'Ben Beta'),
                'Campus attendance should be sorted alphabetically by student name.'
            );
            $this->assertStringContainsString('Block', $allCampusCsv);

            $blockCsv = $this->get(route('reports.export', [
                'event_id' => $event->id,
                'scope' => 'block',
                'block' => 'B',
            ]))->assertOk()->streamedContent();

            $this->assertStringContainsString('Ada Alpha', $blockCsv);
            $this->assertStringContainsString('Ben Beta', $blockCsv);
            $this->assertStringNotContainsString('Zoe Zebra', $blockCsv);

            $yearCsv = $this->get(route('reports.export', [
                'event_id' => $event->id,
                'scope' => 'year_level',
                'year_level' => 'Second Year',
            ]))->assertOk()->streamedContent();

            $this->assertStringContainsString('Ben Beta', $yearCsv);
            $this->assertStringNotContainsString('Ada Alpha', $yearCsv);
            $this->assertStringNotContainsString('Zoe Zebra', $yearCsv);

            $yearBlockCsv = $this->get(route('reports.export', [
                'event_id' => $event->id,
                'scope' => 'year_level',
                'year_level' => 'First Year',
                'block' => 'B',
            ]))->assertOk()->streamedContent();

            $this->assertStringContainsString('Year Level - First Year / Block B', $yearBlockCsv);
            $this->assertStringContainsString('Ada Alpha', $yearBlockCsv);
            $this->assertStringNotContainsString('Zoe Zebra', $yearBlockCsv);
            $this->assertStringNotContainsString('Ben Beta', $yearBlockCsv);

            $this->get(route('reports.index', [
                'scope' => 'year_level',
                'year_level' => 'First Year',
                'block' => 'B',
            ]))
                ->assertOk()
                ->assertSee('Block (Optional)')
                ->assertSee('All Blocks')
                ->assertDontSee('Per Block');
        } finally {
            $event->delete();
            $students->each->forceDelete();
            $admin->delete();
        }
    }

    public function test_student_registration_saves_year_and_block_separately(): void
    {
        $admin = User::factory()->create(['role' => 'superadmin']);
        $studentId = 'BLOCK-TEST-' . uniqid();

        $this->actingAs($admin)->post(route('students.store'), [
            'student_id' => $studentId,
            'full_name' => 'Block Test Student',
            'year_level' => 'Third Year',
            'block' => 'c',
        ])->assertRedirect();

        $this->assertDatabaseHas('students', [
            'student_id' => $studentId,
            'year_level' => 'Third Year',
            'block' => 'C',
        ]);

        Student::withTrashed()->where('student_id', $studentId)->forceDelete();
        $admin->delete();
    }

    public function test_turnout_percentage_uses_the_event_organization_population(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $organization = Organization::create(['name' => 'Turnout Org ' . uniqid()]);
        $otherOrganization = Organization::create(['name' => 'Other Org ' . uniqid()]);
        $program = Program::create(['name' => 'Turnout Program ' . uniqid()]);
        $event = Event::create([
            'name' => 'Organization Turnout Test ' . uniqid(),
            'event_date' => now()->toDateString(),
            'organization_id' => $organization->id,
            'status' => 'completed',
        ]);
        $members = collect([
            Student::create([
                'student_id' => 'TURNOUT-A-' . uniqid(),
                'full_name' => 'Attending Member',
                'organization_id' => $organization->id,
                'program_id' => $program->id,
            ]),
            Student::create([
                'student_id' => 'TURNOUT-B-' . uniqid(),
                'full_name' => 'Absent Member',
                'organization_id' => $organization->id,
                'program_id' => $program->id,
            ]),
        ]);
        $outsideStudent = Student::create([
            'student_id' => 'TURNOUT-C-' . uniqid(),
            'full_name' => 'Outside Student',
            'organization_id' => $otherOrganization->id,
            'program_id' => $program->id,
        ]);

        try {
            Attendance::create([
                'event_id' => $event->id,
                'student_id' => $members[0]->id,
                'status' => 'present',
                'scanned_at' => now(),
            ]);

            $this->actingAs($admin)
                ->get(route('reports.print', ['event_id' => $event->id]))
                ->assertOk()
                ->assertSee('50%')
                ->assertSee('1 / 2 eligible student-event slots');
            $partialTurnoutCsv = $this->get(route('reports.export', ['event_id' => $event->id]))
                ->assertOk()
                ->streamedContent();
            $this->assertStringContainsString('"Turnout Among Eligible Students",50%', $partialTurnoutCsv);
            $this->get(route('reports.index'))
                ->assertOk()
                ->assertSee('50%')
                ->assertSee('2 eligible student-event slots');

            Attendance::create([
                'event_id' => $event->id,
                'student_id' => $members[1]->id,
                'status' => 'late',
                'scanned_at' => now(),
            ]);

            $this->get(route('reports.print', ['event_id' => $event->id]))
                ->assertOk()
                ->assertSee('100%')
                ->assertSee('2 / 2 eligible student-event slots');
            $fullTurnoutCsv = $this->get(route('reports.export', ['event_id' => $event->id]))
                ->assertOk()
                ->streamedContent();
            $this->assertStringContainsString('"Eligible Student-Event Slots",2', $fullTurnoutCsv);
        } finally {
            Attendance::where('event_id', $event->id)->delete();
            $event->delete();
            $members->each->forceDelete();
            $outsideStudent->forceDelete();
            $organization->delete();
            $otherOrganization->delete();
            $program->delete();
            $admin->delete();
        }
    }

    public function test_dashboard_gps_percentage_uses_eligible_students_in_the_active_event(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $organization = Organization::create(['name' => 'Dashboard Org ' . uniqid()]);
        $otherOrganization = Organization::create(['name' => 'Dashboard Other Org ' . uniqid()]);
        $event = Event::create([
            'name' => 'Dashboard Turnout Test ' . uniqid(),
            'event_date' => now()->toDateString(),
            'organization_id' => $organization->id,
            'status' => 'active',
        ]);
        $members = collect([
            Student::create([
                'student_id' => 'DASH-TURNOUT-A-' . uniqid(),
                'full_name' => 'Dashboard Member A',
                'organization_id' => $organization->id,
            ]),
            Student::create([
                'student_id' => 'DASH-TURNOUT-B-' . uniqid(),
                'full_name' => 'Dashboard Member B',
                'organization_id' => $organization->id,
            ]),
        ]);
        $outsideStudent = Student::create([
            'student_id' => 'DASH-TURNOUT-C-' . uniqid(),
            'full_name' => 'Dashboard Outside Student',
            'organization_id' => $otherOrganization->id,
        ]);

        try {
            PresenceVerification::create([
                'event_id' => $event->id,
                'student_id' => $members[0]->id,
                'status' => 'inside',
                'verified_at' => now(),
            ]);

            $this->actingAs($admin)
                ->get(route('dashboard'))
                ->assertOk()
                ->assertSee('50%')
                ->assertSee('1 / 2 eligible students inside perimeter');

            PresenceVerification::create([
                'event_id' => $event->id,
                'student_id' => $members[1]->id,
                'status' => 'inside',
                'verified_at' => now(),
            ]);

            $this->get(route('dashboard'))
                ->assertOk()
                ->assertSee('100%')
                ->assertSee('2 / 2 eligible students inside perimeter');
        } finally {
            PresenceVerification::where('event_id', $event->id)->delete();
            $event->delete();
            $members->each->forceDelete();
            $outsideStudent->forceDelete();
            $organization->delete();
            $otherOrganization->delete();
            $admin->delete();
        }
    }
}
