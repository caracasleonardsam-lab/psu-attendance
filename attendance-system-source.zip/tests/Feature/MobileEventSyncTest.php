<?php

namespace Tests\Feature;

use App\Models\Event;
use App\Models\Student;
use Tests\TestCase;

class MobileEventSyncTest extends TestCase
{
    public function test_mobile_event_endpoint_returns_newly_created_web_events_and_schedule_details(): void
    {
        $student = Student::create([
            'student_id' => 'EVENT-SYNC-' . uniqid(),
            'full_name' => 'Event Sync Test Student',
        ]);
        $event = Event::create([
            'name' => 'New Web Event ' . uniqid(),
            'event_date' => '2099-06-15',
            'start_time' => '09:30:00',
            'end_time' => '12:00:00',
            'venue' => 'Main Hall',
            'status' => 'scheduled',
            'attendance_mode' => 'QR + Student ID',
            'verification_interval_minutes' => 20,
            'radius_meters' => 150,
        ]);

        try {
            $this->getJson('/api/events?student_id=' . $student->student_id)
                ->assertOk()
                ->assertJsonPath('success', true)
                ->assertJsonFragment([
                    'id' => $event->id,
                    'name' => $event->name,
                    'event_date' => '2099-06-15',
                    'start_time' => '09:30:00',
                    'end_time' => '12:00:00',
                    'venue' => 'Main Hall',
                    'status' => 'scheduled',
                    'attendance_mode' => 'QR + Student ID',
                    'verification_interval_minutes' => 20,
                    'radius_meters' => 150,
                ]);

            $this->getJson('/api/student-dashboard?student_id=' . $student->student_id)
                ->assertOk()
                ->assertJsonFragment([
                    'id' => $event->id,
                    'event_date' => '2099-06-15',
                    'start_time' => '09:30:00',
                    'end_time' => '12:00:00',
                ]);
        } finally {
            $event->delete();
            $student->forceDelete();
        }
    }
}
