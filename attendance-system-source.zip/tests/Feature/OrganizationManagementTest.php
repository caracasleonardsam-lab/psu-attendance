<?php

namespace Tests\Feature;

use App\Models\Organization;
use App\Models\OrganizationOfficer;
use App\Models\Student;
use App\Models\User;
use Tests\TestCase;

class OrganizationManagementTest extends TestCase
{
    public function test_organization_management_page_lists_organizations_without_program_management(): void
    {
        $admin = $this->createAdmin();
        $organization = Organization::create(['name' => 'Organization Management '.uniqid()]);

        try {
            $this->actingAs($admin)
                ->get(route('organizations.index'))
                ->assertOk()
                ->assertSee('Organization Management')
                ->assertSee($organization->name)
                ->assertSee(route('organizations.show', $organization), false)
                ->assertDontSee('Academic Programs');
        } finally {
            $organization->delete();
            $admin->delete();
        }
    }

    public function test_admin_can_manage_members_and_officers_for_an_organization(): void
    {
        $admin = $this->createAdmin();
        $organization = Organization::create(['name' => 'Organization Details '.uniqid()]);
        $member = $this->createStudent('Org Member');
        $newMember = $this->createStudent('Available Member');
        $renamedOrganization = 'Renamed Organization '.uniqid();

        try {
            $member->update(['organization_id' => $organization->id]);

            $this->actingAs($admin)
                ->get(route('organizations.show', $organization))
                ->assertOk()
                ->assertSee($member->full_name)
                ->assertSee('Organization Officers')
                ->assertSee('Members')
                ->assertSee('name="student_id"', false)
                ->assertSee("Enter member's Student ID", false);

            $this->post(route('organizations.members.store', $organization), [
                'student_id' => $newMember->id,
            ])->assertRedirect();
            $this->assertSame($organization->id, $newMember->fresh()->organization_id);

            $this->post(route('organizations.officers.store', $organization), [
                'student_id' => $member->student_id,
                'position' => 'President',
            ])->assertRedirect();
            $this->assertDatabaseHas('organization_officers', [
                'organization_id' => $organization->id,
                'student_id' => $member->id,
                'position' => 'President',
            ]);

            $this->post(route('organizations.officers.store', $organization), [
                'student_id' => $newMember->student_id,
                'position' => 'President',
            ])->assertRedirect();
            $this->assertDatabaseHas('organization_officers', [
                'organization_id' => $organization->id,
                'student_id' => $newMember->id,
                'position' => 'President',
            ]);
            $this->assertDatabaseMissing('organization_officers', [
                'organization_id' => $organization->id,
                'student_id' => $member->id,
                'position' => 'President',
            ]);

            $this->from(route('organizations.show', $organization))
                ->post(route('organizations.officers.store', $organization), [
                    'student_id' => 'UNKNOWN-STUDENT-ID',
                    'position' => 'Secretary',
                ])
                ->assertRedirect(route('organizations.show', $organization))
                ->assertSessionHasErrors('student_id');
            $this->assertDatabaseMissing('organization_officers', [
                'organization_id' => $organization->id,
                'position' => 'Secretary',
            ]);

            $this->post(route('organizations.officers.store', $organization), [
                'student_id' => $member->student_id,
                'position' => 'President',
            ])->assertRedirect();

            $this->put(route('organizations.update', $organization), [
                'name' => $renamedOrganization,
            ])->assertRedirect();
            $this->assertSame($renamedOrganization, $organization->fresh()->name);

            $this->delete(route('organizations.members.destroy', [$organization, $newMember]))
                ->assertRedirect();
            $this->assertNull($newMember->fresh()->organization_id);
            $this->assertDatabaseMissing('organization_officers', [
                'organization_id' => $organization->id,
                'student_id' => $newMember->id,
            ]);

            $officer = OrganizationOfficer::where('organization_id', $organization->id)->firstOrFail();
            $this->delete(route('organizations.officers.destroy', [$organization, $officer]))
                ->assertRedirect();
            $this->assertDatabaseMissing('organization_officers', ['id' => $officer->id]);
        } finally {
            OrganizationOfficer::where('organization_id', $organization->id)->delete();
            $member->forceDelete();
            $newMember->forceDelete();
            $organization->delete();
            $admin->delete();
        }
    }

    private function createAdmin(): User
    {
        return User::create([
            'name' => 'Organization Management Admin '.uniqid(),
            'username' => 'org-management-'.uniqid(),
            'email' => 'org-management-'.uniqid().'@example.test',
            'password' => 'password',
            'role' => 'superadmin',
        ]);
    }

    private function createStudent(string $name): Student
    {
        return Student::create([
            'student_id' => 'ORG-MEMBER-'.uniqid(),
            'full_name' => $name.' '.uniqid(),
        ]);
    }
}
