<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Event;
use App\Models\PresenceVerification;
use App\Models\Student;
use Carbon\Carbon;
use Tests\TestCase;

class LunchBreakGeofenceTest extends TestCase
{
    public function test_geofence_is_paused_during_lunch_and_resumes_at_one_pm(): void
    {
        $student = Student::create([
            'student_id' => 'LUNCH-'.uniqid(),
            'full_name' => 'Lunch Break Test Student',
        ]);
        $event = Event::create([
            'name' => 'Lunch Break Geofence Test '.uniqid(),
            'event_date' => now()->toDateString(),
            'status' => 'active',
            'latitude' => 16.115303,
            'longitude' => 119.967252,
            'radius_meters' => 100,
            'presence_verification' => true,
        ]);
        $attendance = Attendance::create([
            'event_id' => $event->id,
            'student_id' => $student->id,
            'status' => 'present',
            'scanned_at' => now(),
            'scanned_by' => 'Lunch Break Test',
        ]);

        try {
            $payload = [
                'event_id' => $event->id,
                'student_id' => $student->student_id,
                'latitude' => 16.125303,
                'longitude' => 119.967252,
            ];

            foreach (['12:00:00', '12:30:00', '12:59:59'] as $time) {
                $this->travelTo(Carbon::parse('2026-11-03 '.$time, 'Asia/Manila'));

                $this->postJson('/api/ping-presence', $payload)
                    ->assertOk()
                    ->assertJsonPath('success', true)
                    ->assertJsonPath('lunch_break', true)
                    ->assertJsonPath('geofence_required', false);

                $this->postJson('/api/self-checkin', $payload)
                    ->assertOk()
                    ->assertJsonPath('success', true)
                    ->assertJsonPath('lunch_break', true)
                    ->assertJsonPath('geofence_required', false);

                $this->getJson('/api/student-dashboard?student_id='.$student->student_id)
                    ->assertOk()
                    ->assertJsonPath('lunch_break.active', true);
            }

            $this->assertSame(0, PresenceVerification::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->count());
            $this->assertSame('present', $attendance->fresh()->status);

            $this->travelTo(Carbon::parse('2026-11-03 13:00:00', 'Asia/Manila'));
            $this->getJson('/api/student-dashboard?student_id='.$student->student_id)
                ->assertOk()
                ->assertJsonPath('lunch_break.active', false);

            $payloadWithoutCoordinates = [
                'event_id' => $event->id,
                'student_id' => $student->student_id,
            ];
            $this->postJson('/api/ping-presence', $payloadWithoutCoordinates)
                ->assertStatus(422)
                ->assertJsonPath('success', false);
            $this->postJson('/api/self-checkin', $payloadWithoutCoordinates)
                ->assertStatus(422)
                ->assertJsonPath('success', false);
            $this->assertSame(0, PresenceVerification::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->count());

            $this->postJson('/api/ping-presence', $payload)
                ->assertOk()
                ->assertJsonMissingPath('lunch_break')
                ->assertJsonPath('in_range', false);

            $this->postJson('/api/self-checkin', $payload)
                ->assertOk()
                ->assertJsonPath('geofence_violation', true);

            $this->assertSame(2, PresenceVerification::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->count());
        } finally {
            $this->travelBack();
            $event->delete();
            $student->forceDelete();
        }
    }
}
