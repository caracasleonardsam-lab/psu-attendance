<?php
require_once __DIR__ . '/public/api.php';
