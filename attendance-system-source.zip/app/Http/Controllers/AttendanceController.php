<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventEligibility;
use App\Models\EventQueueEntry;
use App\Models\EventStudentDesignation;
use App\Models\Program;
use App\Models\Student;
use App\Models\SystemSetting;
use App\Services\EventLifecycleService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class AttendanceController extends Controller
{
    public function scanner(Request $request): View
    {
        abort_unless(Auth::user()?->isAdmin() || Auth::user()?->isOfficer(), 403);
        app(EventLifecycleService::class)->completeExpiredEvents();

        $events = Event::whereIn('status', ['active', 'scheduled'])->orderBy('event_date', 'asc')->get();
        $defaultEvent = $events->first(
            fn (Event $event) => $event->status === 'active' && $event->scanning_enabled
        ) ?? $events->firstWhere('status', 'active') ?? $events->first();
        $selectedEventId = $request->input('event_id', $defaultEvent?->id);
        $selectedEvent = $events->firstWhere('id', $selectedEventId) ?? $defaultEvent;

        $recentScans = collect();
        $stats = [
            'total_present' => 0,
            'total_late' => 0,
            'total_checkout' => 0,
            'total_scanned' => 0,
            'total_students' => Student::count(),
        ];

        if ($selectedEvent) {
            $recentScans = Attendance::with(['student.program', 'student.organization'])
                ->where('event_id', $selectedEvent->id)
                ->orderBy('scanned_at', 'desc')
                ->take(25)
                ->get();

            $stats = array_merge($stats, $this->getEventStats($selectedEvent->id));
        }

        $scanAvailabilityMessage = null;
        if ($selectedEvent) {
            $scanAvailabilityMessage = ! $selectedEvent->scanning_enabled
                ? 'Scanning is off. Start scanning to accept attendance at any time.'
                : null;
        }
        $canScan = $selectedEvent
            && $selectedEvent->status === 'active'
            && $selectedEvent->scanning_enabled
            && $scanAvailabilityMessage === null;
        $lifecycleRefreshAt = null;
        if ($selectedEvent?->status === 'scheduled' && $selectedEvent->start_time) {
            $lifecycleRefreshAt = Carbon::parse(
                $selectedEvent->event_date->format('Y-m-d').' '.$selectedEvent->start_time,
                config('app.timezone')
            )->getTimestamp() * 1000;
        } elseif ($selectedEvent?->status === 'active' && $selectedEvent->end_time) {
            $endsAt = Carbon::parse(
                $selectedEvent->event_date->format('Y-m-d').' '.$selectedEvent->end_time,
                config('app.timezone')
            );
            if ($selectedEvent->start_time && $selectedEvent->end_time < $selectedEvent->start_time) {
                $endsAt->addDay();
            }
            $lifecycleRefreshAt = $endsAt->getTimestamp() * 1000;
        }

        return view('attendance.scanner', compact(
            'events',
            'selectedEvent',
            'recentScans',
            'stats',
            'canScan',
            'scanAvailabilityMessage',
            'lifecycleRefreshAt'
        ));
    }

    public function recordScan(Request $request): JsonResponse|RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin() || Auth::user()?->isOfficer(), 403);
        app(EventLifecycleService::class)->completeExpiredEvents();
        $request->validate([
            'event_id' => ['required', 'exists:events,id'],
            'barcode' => ['required', 'string'],
            'scan_mode' => ['sometimes', 'in:checkin,checkout'],
        ]);

        $eventId = (int) $request->input('event_id');
        $rawBarcode = trim((string) $request->input('barcode'));
        $scanMode = (string) $request->input('scan_mode', 'checkin');
        $allowOverride = $request->boolean('allow_override', false);
        $event = Event::findOrFail($eventId);
        $wantsJson = $request->wantsJson() || $request->ajax();

        if (! $event->scanning_enabled || $event->status !== 'active') {
            $message = 'Scanning is not active for this event. Start scanning from the event details page.';

            return $wantsJson
                ? response()->json(['success' => false, 'message' => $message, 'code' => 'SCANNING_DISABLED'], 423)
                : back()->with('error', $message);
        }

        // Keep accepting legacy QR payloads while new passes use Code 128 barcodes.
        $extractedId = $rawBarcode;

        // Legacy JSON pass compatibility (e.g. {"student_id":"...", ...})
        if (str_starts_with($rawBarcode, '{') && str_ends_with($rawBarcode, '}')) {
            $json = json_decode($rawBarcode, true);
            if (is_array($json)) {
                $extractedId = $json['student_id'] ?? $json['id'] ?? $json['studentNumber'] ?? $json['code'] ?? $rawBarcode;
            }
        }

        // Legacy URL pass compatibility (e.g. .../student/23-AC-0395 or ?student_id=...)
        if (filter_var($rawBarcode, FILTER_VALIDATE_URL)) {
            $parsed = parse_url($rawBarcode);
            if (isset($parsed['query'])) {
                parse_str($parsed['query'], $params);
                if (!empty($params['student_id'])) {
                    $extractedId = $params['student_id'];
                } elseif (!empty($params['id'])) {
                    $extractedId = $params['id'];
                }
            }
            if ($extractedId === $rawBarcode && isset($parsed['path'])) {
                $parts = array_filter(explode('/', $parsed['path']));
                if (!empty($parts)) {
                    $lastPart = end($parts);
                    if (strlen($lastPart) >= 3) {
                        $extractedId = $lastPart;
                    }
                }
            }
        }

        // Strip prefixes like "ID:", "STU:", "STUDENT:"
        $cleanId = trim((string) $extractedId);
        if (preg_match('/^(?:ID|STU|STUDENT)[\s\:\-]+(.+)$/i', $cleanId, $m)) {
            $cleanId = trim($m[1]);
        }

        // Alphanumeric sanitized version (for matching '23AC0395' with '23-AC-0395')
        $alphanumeric = preg_replace('/[^a-zA-Z0-9]/', '', $cleanId);

        // Find Student
        $student = Student::with(['program', 'organization'])
            ->where('student_id', $cleanId)
            ->orWhereRaw('LOWER(TRIM(student_id)) = ?', [strtolower($cleanId)])
            ->orWhereRaw("REPLACE(REPLACE(student_id, '-', ''), ' ', '') = ?", [$alphanumeric])
            ->orWhere('email', $cleanId)
            ->orWhere('phone', $cleanId)
            ->first();

        if (!$student) {
            $errorMsg = "Student not found for Barcode / ID: '{$rawBarcode}'";
            if ($wantsJson) {
                return response()->json([
                    'success' => false,
                    'message' => $errorMsg,
                    'code' => 'STUDENT_NOT_FOUND',
                ], 404);
            }
            return back()->with('error', $errorMsg)->withInput();
        }

        if ($event->organization_id !== null
            && (int) $student->organization_id !== (int) $event->organization_id) {
            $organizationName = $event->organization?->name ?? 'the assigned organization';
            $eligibilityMsg = "Organization restriction: {$student->full_name} is not a member of {$organizationName}, so they cannot scan into {$event->name}.";

            if ($wantsJson) {
                return response()->json([
                    'success' => false,
                    'message' => $eligibilityMsg,
                    'code' => 'ORGANIZATION_NOT_ELIGIBLE',
                ], 403);
            }

            return back()->with('error', $eligibilityMsg);
        }

        // 2. Check Event Eligibility Rules
        $eligibilityRulesCount = EventEligibility::where('event_id', $eventId)->count();
        $isDesignated = EventStudentDesignation::where('event_id', $eventId)
            ->where('student_id', $student->id)
            ->exists();
        if ($eligibilityRulesCount > 0 && ! $allowOverride && ! $isDesignated) {
            $isEligible = EventEligibility::where('event_id', $eventId)
                ->where(function ($q) use ($student) {
                    $q->where('program_id', $student->program_id)
                      ->orWhere('organization_id', $student->organization_id)
                      ->orWhere('year_level', $student->year_level);
                })
                ->exists();

            if (!$isEligible) {
                $programName = $student->program?->name ?? 'Unassigned';
                $orgName = $student->organization?->name ?? 'Unassigned';
                $eligibilityMsg = "Eligibility Notice: {$student->full_name} ({$programName} / {$orgName}) is not in the designated program/org eligibility list for {$event->name}.";

                if ($wantsJson) {
                    return response()->json([
                        'success' => false,
                        'eligibility_warning' => true,
                        'message' => $eligibilityMsg,
                        'student' => [
                            'id' => $student->id,
                            'student_id' => $student->student_id,
                            'full_name' => $student->full_name,
                            'program' => $student->program?->name,
                            'organization' => $student->organization?->name,
                            'year_level' => $student->year_level,
                            'block' => $student->block,
                        ],
                    ], 200);
                }
                return back()->with('warning', $eligibilityMsg);
            }
        }

        // Check Existing Attendance
        $existing = Attendance::where('event_id', $eventId)
            ->where('student_id', $student->id)
            ->first();

        $operator = Auth::user()?->name ?? 'Scanner Device';
        $currentTime = now();

        // Check-out only occurs when explicitly selected by the operator.
        if ($scanMode === 'checkout') {
            if (!$existing) {
                $err = "Cannot check out: {$student->full_name} has not checked in for this event yet.";
                if ($wantsJson) {
                    return response()->json(['success' => false, 'message' => $err], 422);
                }
                return back()->with('error', $err);
            }

            // Already checked out?
            if (str_contains($existing->notes ?? '', 'Checked out')) {
                $warn = "{$student->full_name} has already completed Check-in and Check-out for this event.";
                if ($wantsJson) {
                    return response()->json([
                        'success' => false,
                        'already_recorded' => true,
                        'message' => $warn,
                        'student' => $student,
                        'attendance' => $existing,
                    ], 200);
                }
                return back()->with('warning', $warn);
            }

            // Record checkout
            $existing->notes = trim(($existing->notes ? $existing->notes . ' | ' : '') . 'Checked out at ' . $currentTime->format('h:i:s A'));
            $existing->save();

            ActivityLog::log(
                $operator,
                'Recorded Check-Out',
                "Checked out {$student->full_name} ({$student->student_id}) from {$event->name} at {$currentTime->format('h:i A')}"
            );

            $msg = "Check-out confirmed: {$student->full_name} ({$student->student_id}) at " . $currentTime->format('h:i:s A');
            if ($wantsJson) {
                return response()->json([
                    'success' => true,
                    'action' => 'checkout',
                    'message' => $msg,
                    'student' => [
                        'id' => $student->id,
                        'student_id' => $student->student_id,
                        'full_name' => $student->full_name,
                        'program' => $student->program?->name,
                        'organization' => $student->organization?->name,
                        'year_level' => $student->year_level,
                        'block' => $student->block,
                    ],
                    'attendance' => [
                        'id' => $existing->id,
                        'status' => 'CHECKED OUT',
                        'scanned_at' => $currentTime->format('h:i:s A'),
                    ],
                    'stats' => $this->getEventStats($eventId),
                ]);
            }
            return back()->with('success', $msg);
        }

        // If duplicate check-in
        if ($existing) {
            $warnMsg = "Attendance already recorded for {$student->full_name} ({$student->student_id}) at " . $existing->scanned_at->format('h:i A');
            if ($wantsJson) {
                return response()->json([
                    'success' => false,
                    'already_recorded' => true,
                    'message' => $warnMsg,
                    'student' => $student,
                    'attendance' => $existing,
                ], 200);
            }
            return back()->with('warning', $warnMsg);
        }

        $queueEntry = EventQueueEntry::query()
            ->where('event_id', $eventId)
            ->where('student_id', $student->id)
            ->whereNull('invalidated_at')
            ->whereNull('checked_in_at')
            ->latest('entered_at')
            ->first();

        // The server-recorded queue time is the attendance time; scanning is still required.
        $status = 'present';
        $checkInTime = $queueEntry?->entered_at ?? $currentTime;
        if ($event->start_time && $event->event_date) {
            $startTime = Carbon::parse(
                $event->event_date->format('Y-m-d').' '.$event->start_time,
                $currentTime->timezone
            );
            $gracePeriodMinutes = max(0, (int) SystemSetting::get('grace_period_minutes', '15'));
            if ($checkInTime->gt($startTime->addMinutes($gracePeriodMinutes))) {
                $status = 'late';
            }
        }

        $source = $request->input('source', 'Barcode Scanner');
        $notes = 'Scanned via '.$source.($allowOverride ? ' [Eligibility Overridden]' : '');
        if ($isDesignated) {
            $notes .= ' | Event designation: geofence monitoring exempt';
        }
        if ($queueEntry) {
            $notes .= ' | Barcode scanned at '.$currentTime->format('h:i:s A');
            $notes .= $queueEntry->distance_meters !== null
                ? ' | Geofence queue entry at '.$queueEntry->entered_at->format('h:i:s A')
                    .' ('.$queueEntry->distance_meters.'m from venue; geofence verified)'
                : ' | Designated queue entry at '.$queueEntry->entered_at->format('h:i:s A');
        }
        $attendance = Attendance::create([
            'event_id' => $eventId,
            'student_id' => $student->id,
            'status' => $status,
            'scanned_at' => $checkInTime,
            'scanned_by' => $operator,
            'notes' => $notes,
        ]);
        if ($queueEntry) {
            $queueEntry->update(['checked_in_at' => $currentTime]);
        }

        ActivityLog::log(
            $operator,
            'Scanned Attendance',
            "Recorded {$status} for {$student->full_name} ({$student->student_id}) in {$event->name}"
        );

        $successMsg = "Success: {$student->full_name} ({$student->student_id}) recorded as " . strtoupper($status) . "!";

        if ($wantsJson) {
            return response()->json([
                'success' => true,
                'action' => 'checkin',
                'message' => $successMsg,
                'student' => [
                    'id' => $student->id,
                    'student_id' => $student->student_id,
                    'full_name' => $student->full_name,
                    'program' => $student->program?->name,
                    'organization' => $student->organization?->name,
                    'year_level' => $student->year_level,
                    'block' => $student->block,
                ],
                'attendance' => [
                    'id' => $attendance->id,
                    'status' => $attendance->status,
                    'scanned_at' => $attendance->scanned_at->format('h:i:s A'),
                    'checked_in_at' => $currentTime->toIso8601String(),
                    'queue_entered_at' => $queueEntry?->entered_at?->toIso8601String(),
                ],
                'stats' => $this->getEventStats($eventId),
            ]);
        }

        return back()->with('success', $successMsg);
    }

    public function searchStudents(Request $request): JsonResponse
    {
        abort_unless(Auth::user()?->isAdmin() || Auth::user()?->isOfficer(), 403);
        $q = trim((string) $request->input('q', ''));
        if (strlen($q) < 2) {
            return response()->json([]);
        }

        $students = Student::with(['program', 'organization'])
            ->where(function ($query) use ($q) {
                if (Auth::user()?->isOfficer()) {
                    $query->where('student_id', $q);
                } else {
                    $query->where('student_id', 'like', "%{$q}%")
                        ->orWhere('full_name', 'like', "%{$q}%")
                        ->orWhere('email', 'like', "%{$q}%");
                }
            })
            ->limit(10)
            ->get()
            ->map(function ($s) {
                $student = [
                    'id' => $s->id,
                    'student_id' => $s->student_id,
                    'full_name' => $s->full_name,
                ];
                if (Auth::user()?->isAdmin()) {
                    $student += [
                    'program' => $s->program?->name ?? 'N/A',
                    'organization' => $s->organization?->name ?? 'N/A',
                    'year_level' => $s->year_level,
                    'block' => $s->block,
                    ];
                }

                return $student;
            });

        return response()->json($students);
    }

    public function index(Request $request): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $query = Attendance::with(['student.program', 'student.organization', 'event']);

        if ($request->filled('event_id')) {
            $query->where('event_id', $request->event_id);
        }

        if ($request->filled('program_id')) {
            $query->whereHas('student', function ($q) use ($request) {
                $q->where('program_id', $request->program_id);
            });
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->whereHas('student', function ($q) use ($search) {
                $q->where('student_id', 'like', "%{$search}%")
                  ->orWhere('full_name', 'like', "%{$search}%");
            });
        }

        if ($request->filled('date')) {
            $query->whereDate('scanned_at', $request->date);
        }

        $attendances = $query->orderBy('scanned_at', 'desc')->paginate(20)->withQueryString();
        $events = Event::orderBy('name')->get();
        $programs = Program::orderBy('name')->get();

        return view('attendance.index', compact('attendances', 'events', 'programs'));
    }

    public function destroy(Attendance $attendance): RedirectResponse|JsonResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $eventId = $attendance->event_id;
        $studentName = $attendance->student?->full_name ?? 'Student';
        $eventName = $attendance->event?->name ?? 'Event';
        $attendance->delete();

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Deleted Attendance',
            "Removed attendance record of {$studentName} from {$eventName}"
        );

        if (request()->wantsJson() || request()->ajax()) {
            return response()->json([
                'success' => true,
                'message' => "Removed attendance record of {$studentName}.",
                'stats' => $this->getEventStats($eventId),
            ]);
        }

        return back()->with('success', 'Attendance record deleted successfully.');
    }

    public function trash(Request $request): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);

        $attendances = Attendance::onlyTrashed()
            ->with(['student.program', 'event'])
            ->orderByDesc('deleted_at')
            ->paginate(20)
            ->withQueryString();

        return view('attendance.trash', compact('attendances'));
    }

    public function restore(int $attendance): RedirectResponse|JsonResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);

        $record = Attendance::onlyTrashed()->findOrFail($attendance);
        if (Attendance::query()
            ->where('event_id', $record->event_id)
            ->where('student_id', $record->student_id)
            ->exists()) {
            return back()->withErrors([
                'attendance' => 'An active attendance record already exists for this student and event. Remove the duplicate before restoring this one.',
            ]);
        }
        $record->restore();

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Restored Attendance',
            "Restored attendance record for {$record->student?->full_name} from {$record->event?->name}"
        );

        if (request()->wantsJson() || request()->ajax()) {
            return response()->json(['success' => true, 'message' => 'Attendance record restored.']);
        }

        return redirect()->route('attendance.trash')->with('success', 'Attendance record restored successfully.');
    }

    private function getEventStats(int $eventId): array
    {
        return [
            'total_present' => Attendance::where('event_id', $eventId)->where('status', 'present')->count(),
            'total_late' => Attendance::where('event_id', $eventId)->where('status', 'late')->count(),
            'total_checkout' => Attendance::where('event_id', $eventId)
                ->where(function ($q) {
                    $q->where('status', 'checked_out')
                      ->orWhere('notes', 'like', '%Checked out%');
                })->count(),
            'total_scanned' => Attendance::where('event_id', $eventId)->count(),
        ];
    }
}
