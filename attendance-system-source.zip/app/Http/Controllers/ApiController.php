<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventEvaluation;
use App\Models\EvaluationForm;
use App\Models\EventQueueEntry;
use App\Models\EventStudentDesignation;
use App\Models\IssuedCertificate;
use App\Models\PresenceVerification;
use App\Models\Student;
use App\Models\StudentApiToken;
use App\Models\User;
use App\Services\CertificateService;
use App\Services\EventLifecycleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class ApiController extends Controller
{
    /**
     * Handle single-entrypoint legacy queries (action=...)
     */
    public function handle(Request $request): JsonResponse
    {
        $action = $request->input('action', 'get_student_dashboard');

        return match ($action) {
            'login' => $this->login($request),
            'change_password' => $this->changePassword($request),
            'reset_password' => $this->resetPassword($request),
            'update_profile' => $this->updateProfile($request),
            'get_students' => $this->getStudents($request),
            'get_events' => $this->getEvents($request),
            'get_history' => $this->getHistory($request),
            'get_student_dashboard' => $this->getStudentDashboard($request),
            'self_checkin' => $this->selfCheckin($request),
            'join_event_queue' => $this->joinEventQueue($request),
            'ping_presence', 'verify_presence', 'verify_geofence', 'confirm_location', 'confirm_geofence' => $this->pingPresence($request),
            'submit_evaluation' => $this->submitEvaluation($request),
            'get_certificate' => $this->getCertificate($request),
            'get_available_evaluations' => app(StudentEvaluationApiController::class)->index($request),
            'submit_dynamic_evaluation' => $this->submitDynamicEvaluation($request),
            default => response()->json([
                'success' => false,
                'message' => 'Unsupported API action.',
                'code' => 'ACTION_NOT_SUPPORTED',
            ], 400),
        };
    }

    private function submitDynamicEvaluation(Request $request): JsonResponse
    {
        $evaluationId = filter_var($request->input('evaluation_id'), FILTER_VALIDATE_INT);
        if (! $evaluationId || $evaluationId < 1) {
            return response()->json([
                'success' => false,
                'message' => 'A valid evaluation ID is required.',
            ], 422);
        }

        $evaluation = EvaluationForm::find($evaluationId);
        if (! $evaluation) {
            return response()->json([
                'success' => false,
                'message' => 'Evaluation not found.',
            ], 404);
        }

        $answers = $request->input('answers');
        if (is_string($answers)) {
            $answers = json_decode($answers, true);
        }
        if (! is_array($answers)) {
            return response()->json([
                'success' => false,
                'message' => 'Answers must be provided as a valid object.',
            ], 422);
        }

        $request->merge(['answers' => $answers]);

        return app(StudentEvaluationApiController::class)->submit($request, $evaluation);
    }

    public function login(Request $request): JsonResponse
    {
        $username = trim((string) ($request->input('username') ?? $request->input('student_id') ?? ''));
        $password = trim((string) $request->input('password', ''));

        if ($username === '' || $password === '') {
            return response()->json([
                'success' => false,
                'message' => 'Please enter both Student ID and Password.',
            ]);
        }
        $student = Student::with(['program', 'organization'])
            ->where('student_id', $username)
            ->orWhere('email', strtolower($username).'@psu.edu.ph')
            ->first();

        if (! $student) {
            return response()->json([
                'success' => false,
                'message' => 'Student ID "'.$username.'" not found in university registry.',
            ]);
        }

        $user = User::where('username', $student->student_id)->first();
        if (! $user) {
            $user = User::create([
                'name' => $student->full_name,
                'username' => $student->student_id,
                'email' => $student->email ?? ($student->student_id.'@psu.edu.ph'),
                'password' => Hash::make($student->student_id),
                'role' => 'student',
            ]);
        }

        $isValid = false;
        if (Hash::check($password, $user->password) || password_verify($password, $user->password)) {
            $isValid = true;
        }

        if (! $isValid) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid Password for Student ID '.$student->student_id.'.',
            ]);
        }

        $requiresPasswordChange = ($password === $student->student_id) || Hash::check($student->student_id, $user->password);
        $plainTextToken = Str::random(80);
        StudentApiToken::where('student_id', $student->id)->delete();
        StudentApiToken::create([
            'student_id' => $student->id,
            'token_hash' => hash('sha256', $plainTextToken),
            'expires_at' => now()->addDays(30),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Login successful!',
            'token' => $plainTextToken,
            'requires_password_change' => $requiresPasswordChange,
            'student' => [
                'id' => $student->id,
                'student_id' => $student->student_id,
                'full_name' => $student->full_name,
                'program' => $student->program?->name ?: 'BSIT',
                'organization' => $student->organization?->name ?: 'DOIT',
                'year_level' => $student->year_level,
                'block' => $student->block,
                'section_block' => $student->block,
                'requires_block' => blank($student->block),
                'email' => $student->email ?: 'student@psu.edu.ph',
                'phone' => $student->phone ?: '09171112222',
                'campus' => 'Pangasinan State University - Alaminos Campus',
            ],
        ]);
    }

    public function changePassword(Request $request): JsonResponse
    {
        $username = trim((string) ($request->input('student_id') ?? $request->input('username') ?? ''));
        $currentPassword = trim((string) $request->input('current_password', ''));
        $newPassword = trim((string) $request->input('new_password', ''));

        if ($username === '' || $currentPassword === '' || $newPassword === '') {
            return response()->json(['success' => false, 'message' => 'All password fields are required.']);
        }

        if (strlen($newPassword) < 6) {
            return response()->json(['success' => false, 'message' => 'New password must be at least 6 characters.']);
        }

        $user = User::where('username', $username)->first();
        if (! $user) {
            return response()->json(['success' => false, 'message' => 'Student account not found.']);
        }

        $isValid = Hash::check($currentPassword, $user->password) || password_verify($currentPassword, $user->password);
        if (! $isValid) {
            return response()->json(['success' => false, 'message' => 'Current password is incorrect.']);
        }

        $user->password = Hash::make($newPassword);
        $user->save();

        ActivityLog::log($user->name, 'Student Changed Password', 'Updated account password via API');

        return response()->json(['success' => true, 'message' => 'Password updated successfully!']);
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $studentId = trim((string) $request->input('student_id', ''));
        $email = strtolower(trim((string) $request->input('email', '')));
        if ($studentId === '' || $email === '') {
            return response()->json([
                'success' => false,
                'message' => 'Student ID and registered email are required.',
            ], 422);
        }

        $student = Student::where('student_id', $studentId)->first();
        if (! $student) {
            return response()->json([
                'success' => false,
                'message' => 'Student record not found.',
            ], 404);
        }

        $registeredEmail = strtolower(trim((string) ($student->email ?: ($studentId.'@psu.edu.ph'))));
        if ($email !== $registeredEmail) {
            return response()->json([
                'success' => false,
                'message' => 'The email does not match the student record.',
            ], 403);
        }

        $user = User::where('username', $studentId)->first();
        if (! $user) {
            $user = User::create([
                'name' => $student->full_name,
                'username' => $studentId,
                'email' => $student->email ?? $studentId.'@psu.edu.ph',
                'password' => Hash::make($studentId),
                'role' => 'student',
            ]);
        } else {
            $user->password = Hash::make($studentId);
            $user->save();
        }
        StudentApiToken::where('student_id', $student->id)->delete();

        return response()->json([
            'success' => true,
            'message' => 'Password reset. Sign in with your Student ID as the temporary password.',
        ]);
    }

    public function getStudents(Request $request): JsonResponse
    {
        abort_unless(auth()->user()?->isSuperAdmin(), 403);
        $students = Student::with(['program', 'organization'])
            ->orderBy('full_name', 'asc')
            ->get()
            ->map(function ($s) {
                return [
                    'id' => $s->id,
                    'student_id' => $s->student_id,
                    'full_name' => $s->full_name,
                    'program_id' => $s->program_id,
                    'organization_id' => $s->organization_id,
                    'program_name' => $s->program?->name,
                    'organization_name' => $s->organization?->name,
                    'year_level' => $s->year_level,
                    'block' => $s->block,
                    'email' => $s->email,
                    'phone' => $s->phone,
                ];
            });

        return response()->json([
            'success' => true,
            'students' => $students,
        ]);
    }

    public function getEvents(Request $request): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $student = $this->resolveStudent($request);
        $attendedEventIds = $student
            ? Attendance::where('student_id', $student->id)->pluck('event_id')->all()
            : [];
        $queuedEvents = $student
            ? EventQueueEntry::query()
                ->where('student_id', $student->id)
                ->whereNull('invalidated_at')
                ->get()
                ->keyBy('event_id')
            : collect();
        $designatedEventIds = $student
            ? EventStudentDesignation::query()
                ->where('student_id', $student->id)
                ->pluck('event_id')
                ->all()
            : [];
        $now = now();

        $eventsQuery = Event::with('organization')
            ->whereIn('status', ['active', 'scheduled', 'completed', 'cancelled']);
        if ($student) {
            $eventsQuery->where(function ($query) use ($student) {
                $query->whereNull('organization_id')
                    ->orWhere('organization_id', $student->organization_id);
            });
        }
        $events = $eventsQuery->orderBy('event_date', 'asc')
            ->get()
            ->map(function ($e) use ($attendedEventIds, $queuedEvents, $designatedEventIds, $now) {
                $queueEntry = $queuedEvents->get($e->id);
                $hasScanned = in_array($e->id, $attendedEventIds);
                $isQueued = $queueEntry !== null && $queueEntry->checked_in_at === null;

                return [
                    'id' => $e->id,
                    'name' => $e->name,
                    'event_date' => $e->event_date?->format('Y-m-d') ?? now()->toDateString(),
                    'start_time' => $e->start_time,
                    'end_time' => $e->end_time,
                    'venue' => $e->venue ?? 'Campus Grounds',
                    'status' => $e->status,
                    'scanning_enabled' => $e->scanning_enabled,
                    'attendance_mode' => $e->attendance_mode ?? 'Barcode + Student ID',
                    'organizer' => $e->organizer ?? 'Student Affairs Office',
                    'organization_id' => $e->organization_id,
                    'organization_name' => $e->organization?->name,
                    'verification_interval_minutes' => $e->verification_interval_minutes,
                    'radius_meters' => $e->radius_meters,
                    'has_scanned' => $hasScanned,
                    'is_queued' => $isQueued,
                    'queue_entered_at' => $queueEntry?->entered_at?->toIso8601String(),
                    'queue_available' => ! $hasScanned
                        && ! $isQueued
                        && $this->isQueueWindowOpen($e, $now),
                    'is_designated' => in_array($e->id, $designatedEventIds),
                    'evaluation_enabled' => $e->evaluation_enabled,
                ];
            });

        return response()->json([
            'success' => true,
            'events' => $events,
        ]);
    }

    public function getHistory(Request $request): JsonResponse
    {
        $student = $this->resolveStudent($request);
        if (! $student) {
            return response()->json(['success' => false, 'error' => 'No student profile found'], 404);
        }

        $history = Attendance::where('student_id', $student->id)
            ->with('event')
            ->orderBy('scanned_at', 'desc')
            ->get();
        $evaluatedEventIds = EventEvaluation::where('student_id', $student->id)->pluck('event_id')->all();
        $certificates = IssuedCertificate::where('student_id', $student->id)->get()->keyBy('event_id');
        $history = $history->map(function ($att) use ($evaluatedEventIds, $certificates) {
                $certificate = $certificates->get($att->event_id);

                return [
                    'id' => $att->id,
                    'event_id' => $att->event_id,
                    'event_name' => $att->event?->name ?? 'Unknown Event',
                    'venue' => $att->event?->venue ?? 'Main Campus',
                    'event_status' => $att->event?->status ?? 'completed',
                    'status' => $att->status,
                    'scanned_at' => $att->scanned_at?->toIso8601String() ?? (string) $att->scanned_at,
                    'has_evaluated' => in_array($att->event_id, $evaluatedEventIds),
                    'certificate_serial' => $certificate?->certificate_code,
                    'evaluation_enabled' => (bool) $att->event?->evaluation_enabled,
                ];
            });

        return response()->json([
            'success' => true,
            'history' => $history,
        ]);
    }

    public function selfCheckin(Request $request): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $student = $this->resolveStudent($request);
        if (! $student) {
            return response()->json(['success' => false, 'message' => 'Student not found.'], 404);
        }

        $eventId = (int) $request->input('event_id', 0);
        if ($eventId <= 0) {
            $activeEvent = Event::where('status', 'active')
                ->where(function ($query) use ($student) {
                    $query->whereNull('organization_id')
                        ->orWhere('organization_id', $student->organization_id);
                })
                ->first();
            $eventId = $activeEvent ? $activeEvent->id : 0;
        }

        if ($eventId <= 0) {
            return response()->json([
                'success' => false,
                'message' => 'No active event currently available for check-in.',
            ]);
        }

        $event = Event::find($eventId);
        if (! $event) {
            return response()->json([
                'success' => false,
                'message' => 'Event not found.',
            ]);
        }
        if (! $this->studentCanAccessEvent($event, $student)) {
            return response()->json([
                'success' => false,
                'error_code' => 'ORGANIZATION_NOT_ELIGIBLE',
                'message' => 'This event is exclusive to '.$event->organization?->name.'.',
            ], 403);
        }

        // MANDATORY ENTRANCE SCAN PREREQUISITE:
        // A student must be scanned first by the event scanner at the entrance before geofence location can be used or confirmed!
        $attRecord = Attendance::where('event_id', $eventId)
            ->where('student_id', $student->id)
            ->first();

        if (! $attRecord) {
            return response()->json([
                'success' => false,
                'has_scanned' => false,
                'can_confirm_geofence' => false,
                'error_code' => 'ENTRANCE_SCAN_REQUIRED',
                'message' => 'Entrance Scan Required: You must be scanned by the event scanner at the entrance first before you can use Geofence to confirm your location.',
            ]);
        }

        if (EventStudentDesignation::where('event_id', $event->id)
            ->where('student_id', $student->id)
            ->exists()) {
            return response()->json([
                'success' => true,
                'has_scanned' => true,
                'can_confirm_geofence' => false,
                'geofence_required' => false,
                'geofence_exempt' => true,
                'status' => $attRecord->status,
                'message' => 'Your event designation exempts you from geofence monitoring. Entrance check-in is still required.',
            ]);
        }

        if ($this->isLunchBreak()) {
            return response()->json([
                'success' => true,
                'has_scanned' => true,
                'can_confirm_geofence' => false,
                'lunch_break' => true,
                'geofence_required' => false,
                'status' => $attRecord->status,
                'message' => 'Lunch break (12:00 PM–1:00 PM): geofence verification is not required.',
            ]);
        }

        if (! $this->hasValidCoordinates($request)) {
            return response()->json([
                'success' => false,
                'message' => 'Valid device latitude and longitude are required for geofence verification.',
            ], 422);
        }

        // GPS Geofence Verification
        $userLat = (float) $request->input('latitude');
        $userLng = (float) $request->input('longitude');
        $distanceMeters = 0;
        $isInside = true;
        $radius = (float) ($event->radius_meters ?: 100);

        if ($event->latitude && $event->longitude) {
            $distanceMeters = $this->calculateDistance($userLat, $userLng, (float) $event->latitude, (float) $event->longitude);
            $isInside = ($distanceMeters <= $radius);

            // Log presence ping
            PresenceVerification::create([
                'event_id' => $event->id,
                'student_id' => $student->id,
                'status' => $isInside ? 'inside' : 'outside',
                'distance_meters' => round($distanceMeters, 1),
                'verified_at' => now(),
                'notes' => "GPS: {$userLat},{$userLng} | ".($isInside ? 'Confirmed inside geofence perimeter' : 'Geofence check outside perimeter ('.round($distanceMeters, 1).'m from venue)'),
            ]);

            // If geofence is strictly enforced and student is outside allowed radius
            if ($event->presence_verification && ! $isInside) {
                return response()->json([
                    'success' => false,
                    'has_scanned' => true,
                    'can_confirm_geofence' => true,
                    'geofence_violation' => true,
                    'distance_meters' => round($distanceMeters, 1),
                    'radius_meters' => $radius,
                    'message' => 'Geofence Check Failed: You are '.round($distanceMeters)."m away from '{$event->venue}'. Allowed radius is {$radius}m. Please move closer to the event venue to confirm your location.",
                ]);
            }
        }

        // Confirmed present
        if ($attRecord->status !== 'present') {
            $attRecord->status = 'present';
            $attRecord->save();
        }

        ActivityLog::log(
            $student->full_name,
            'Geofence Location Confirmed',
            "Location confirmed via Geofence for event: {$event->name}".($userLat ? ' (GPS Verified: '.round($distanceMeters, 1).'m from venue)' : '')
        );

        return response()->json([
            'success' => true,
            'has_scanned' => true,
            'can_confirm_geofence' => true,
            'already_checked_in' => true,
            'distance_meters' => round($distanceMeters, 1),
            'radius_meters' => $radius,
            'within_geofence' => $isInside,
            'message' => 'Geofence location confirmed successfully! Attendance verified.',
        ]);
    }

    public function joinEventQueue(Request $request): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $plainTextToken = $request->bearerToken();
        $token = $plainTextToken
            ? StudentApiToken::with('student')
                ->where('token_hash', hash('sha256', $plainTextToken))
                ->where('expires_at', '>', now())
                ->first()
            : null;
        if (! $token?->student) {
            return response()->json([
                'success' => false,
                'message' => 'Please sign in again before joining an event queue.',
                'code' => 'UNAUTHENTICATED',
            ], 401);
        }
        $student = $token->student;

        $validated = $request->validate([
            'event_id' => ['required', 'integer', 'exists:events,id'],
        ]);
        $event = Event::findOrFail($validated['event_id']);
        if (! $this->studentCanAccessEvent($event, $student)) {
            return response()->json([
                'success' => false,
                'message' => 'This event is exclusive to '.$event->organization?->name.'.',
                'code' => 'ORGANIZATION_NOT_ELIGIBLE',
            ], 403);
        }
        $isDesignated = EventStudentDesignation::where('event_id', $event->id)
            ->where('student_id', $student->id)
            ->exists();
        $locationRules = $isDesignated ? ['nullable'] : ['required'];
        $validated = array_merge($validated, $request->validate([
            'latitude' => [...$locationRules, 'numeric', 'between:-90,90'],
            'longitude' => [...$locationRules, 'numeric', 'between:-180,180'],
            'accuracy_meters' => [...$locationRules, 'numeric', 'min:0', 'max:50'],
            'is_mocked' => ['sometimes', 'boolean'],
        ]));
        if (! $isDesignated && $request->boolean('is_mocked')) {
            return response()->json([
                'success' => false,
                'message' => 'Mocked GPS locations cannot be used to join the event queue.',
                'code' => 'MOCK_LOCATION',
            ], 422);
        }

        if (! in_array($event->status, ['scheduled', 'active'], true)) {
            return response()->json([
                'success' => false,
                'message' => 'Queue entry is available only for scheduled or active events.',
                'code' => 'QUEUE_UNAVAILABLE',
            ], 422);
        }
        if (Attendance::where('event_id', $event->id)->where('student_id', $student->id)->exists()) {
            return response()->json([
                'success' => false,
                'message' => 'You have already been scanned into this event.',
                'code' => 'ALREADY_CHECKED_IN',
            ], 409);
        }

        $now = now();
        if (! $this->isQueueWindowOpen($event, $now)) {
            return response()->json([
                'success' => false,
                'message' => 'Queue entry opens one hour before the event and closes when the event ends.',
                'code' => 'QUEUE_OUTSIDE_EVENT_WINDOW',
            ], 422);
        }

        $latitude = null;
        $longitude = null;
        $accuracyMeters = null;
        $distanceMeters = null;
        if (! $isDesignated) {
            $latitude = (float) $validated['latitude'];
            $longitude = (float) $validated['longitude'];
            $accuracyMeters = (float) $validated['accuracy_meters'];
            $distanceMeters = $this->calculateDistance(
                $latitude,
                $longitude,
                (float) $event->latitude,
                (float) $event->longitude
            );
            $radiusMeters = (float) ($event->radius_meters ?: 100);

            if ($distanceMeters + $accuracyMeters > $radiusMeters) {
                return response()->json([
                    'success' => false,
                    'message' => 'Queue entry requires a GPS fix confidently inside the event geofence. Move closer to the venue and try again.',
                    'code' => 'OUTSIDE_GEOFENCE',
                    'distance_meters' => round($distanceMeters, 1),
                    'accuracy_meters' => round($accuracyMeters, 1),
                    'radius_meters' => $radiusMeters,
                ], 422);
            }
        }

        $queueEntry = DB::transaction(function () use (
            $event,
            $student,
            $now,
            $latitude,
            $longitude,
            $accuracyMeters,
            $distanceMeters
        ) {
            $lockedEvent = Event::query()->whereKey($event->id)->lockForUpdate()->firstOrFail();
            if (! in_array($lockedEvent->status, ['scheduled', 'active'], true)
                || ! $this->isQueueWindowOpen($lockedEvent, $now)) {
                return null;
            }

            if (Attendance::where('event_id', $event->id)->where('student_id', $student->id)->exists()) {
                return null;
            }

            $existing = EventQueueEntry::query()
                ->where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->whereNull('invalidated_at')
                ->first();

            if ($existing) {
                return $existing;
            }

            return EventQueueEntry::create([
                'event_id' => $event->id,
                'student_id' => $student->id,
                'entered_at' => $now,
                'latitude' => $latitude,
                'longitude' => $longitude,
                'accuracy_meters' => $accuracyMeters,
                'distance_meters' => $distanceMeters === null ? null : round($distanceMeters, 1),
            ]);
        });

        if (! $queueEntry) {
            return response()->json([
                'success' => false,
                'message' => 'Scanning stopped or attendance was recorded before your queue entry could be saved.',
                'code' => 'QUEUE_UNAVAILABLE',
            ], 409);
        }

        return response()->json([
            'success' => true,
            'is_queued' => true,
            'queue_entered_at' => $queueEntry->entered_at->toIso8601String(),
            'distance_meters' => $queueEntry->distance_meters,
            'radius_meters' => $event->radius_meters,
            'geofence_verified' => ! $isDesignated,
            'message' => $isDesignated
                ? 'Queue entry recorded using server time under your event designation; geofence is not required.'
                : 'Queue entry recorded using server time and verified within the event geofence.',
        ]);
    }

    public function pingPresence(Request $request): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $student = $this->resolveStudent($request);
        if (! $student) {
            return response()->json(['success' => false, 'message' => 'Student not found.'], 404);
        }

        $eventId = (int) $request->input('event_id', 0);
        $event = $eventId > 0
            ? Event::find($eventId)
            : Event::where('status', 'active')
                ->where(function ($query) use ($student) {
                    $query->whereNull('organization_id')
                        ->orWhere('organization_id', $student->organization_id);
                })
                ->first();

        if (! $event) {
            return response()->json([
                'success' => false,
                'message' => 'No active event found.',
            ]);
        }
        if (! $this->studentCanAccessEvent($event, $student)) {
            return response()->json([
                'success' => false,
                'error_code' => 'ORGANIZATION_NOT_ELIGIBLE',
                'message' => 'This event is exclusive to '.$event->organization?->name.'.',
            ], 403);
        }

        // MANDATORY SCAN PREREQUISITE: Must be scanned/checked-in first at entrance!
        $attRecord = Attendance::where('event_id', $event->id)
            ->where('student_id', $student->id)
            ->first();

        if (! $attRecord) {
            return response()->json([
                'success' => false,
                'has_scanned' => false,
                'can_confirm_geofence' => false,
                'error_code' => 'ENTRANCE_SCAN_REQUIRED',
                'message' => 'Entrance Scan Required: Present your Barcode Campus Pass to the scanners at the event entrance before Geofence Location Tracking activates.',
            ]);
        }

        if (EventStudentDesignation::where('event_id', $event->id)
            ->where('student_id', $student->id)
            ->exists()) {
            return response()->json([
                'success' => true,
                'has_scanned' => true,
                'can_confirm_geofence' => false,
                'geofence_required' => false,
                'geofence_exempt' => true,
                'status' => $attRecord->status,
                'message' => 'Your event designation exempts you from geofence monitoring. Entrance check-in is still required.',
            ]);
        }

        if ($this->isLunchBreak()) {
            return response()->json([
                'success' => true,
                'has_scanned' => true,
                'can_confirm_geofence' => false,
                'lunch_break' => true,
                'geofence_required' => false,
                'status' => $attRecord->status,
                'message' => 'Lunch break (12:00 PM–1:00 PM): geofence verification is paused.',
            ]);
        }

        if (! $this->hasValidCoordinates($request)) {
            return response()->json([
                'success' => false,
                'message' => 'Valid device latitude and longitude are required for geofence verification.',
            ], 422);
        }

        $eventLat = (float) ($event?->latitude ?? 16.115303);
        $eventLng = (float) ($event?->longitude ?? 119.967252);
        $userLat = (float) $request->input('latitude');
        $userLng = (float) $request->input('longitude');

        $distanceMeters = $this->calculateDistance($userLat, $userLng, $eventLat, $eventLng);
        $radius = (float) ($event?->radius_meters ?: 100);
        $inRange = ($distanceMeters <= $radius);

        $lastVer = PresenceVerification::where('event_id', $event?->id ?? 1)
            ->where('student_id', $student->id)
            ->orderBy('id', 'desc')
            ->first();

        $currentWarnings = $lastVer ? (int) ($lastVer->notes ?? 0) : 0;

        if ($inRange) {
            PresenceVerification::create([
                'event_id' => $event?->id ?? 1,
                'student_id' => $student->id,
                'status' => 'inside',
                'distance_meters' => round($distanceMeters, 1),
                'verified_at' => now(),
                'notes' => '0',
            ]);

            Attendance::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->update(['status' => 'present']);

            return response()->json([
                'success' => true,
                'has_scanned' => true,
                'can_confirm_geofence' => true,
                'in_range' => true,
                'distance_meters' => round($distanceMeters, 1),
                'radius_meters' => $radius,
                'warning_count' => 0,
                'status' => 'present',
                'message' => 'Location verified! You are within venue geofence ('.round($distanceMeters).'m). Attendance status: PRESENT.',
            ]);
        } else {
            $newWarnings = $currentWarnings + 1;

            PresenceVerification::create([
                'event_id' => $event->id,
                'student_id' => $student->id,
                'status' => 'outside',
                'distance_meters' => round($distanceMeters, 1),
                'verified_at' => now(),
                'notes' => (string) $newWarnings,
            ]);

            if ($newWarnings >= 3) {
                Attendance::where('event_id', $event->id)
                    ->where('student_id', $student->id)
                    ->update(['status' => 'absent']);

                return response()->json([
                    'success' => true,
                    'has_scanned' => true,
                    'can_confirm_geofence' => true,
                    'in_range' => false,
                    'distance_meters' => round($distanceMeters, 1),
                    'radius_meters' => $radius,
                    'warning_count' => 3,
                    'status' => 'absent',
                    'message' => 'ABSENT WARNING EXCEEDED (3/3): You stayed out of venue range ('.round($distanceMeters).'m away). Attendance status marked ABSENT.',
                ]);
            } else {
                return response()->json([
                    'success' => true,
                    'has_scanned' => true,
                    'can_confirm_geofence' => true,
                    'in_range' => false,
                    'distance_meters' => round($distanceMeters, 1),
                    'radius_meters' => $radius,
                    'warning_count' => $newWarnings,
                    'status' => 'warning',
                    'message' => 'GEOFENCE WARNING '.$newWarnings.'/3: You are '.round($distanceMeters).'m away from event venue (Max: '.$radius.'m). Return to venue bounds to remain marked PRESENT!',
                ]);
            }
        }
    }

    private function studentCanAccessEvent(Event $event, Student $student): bool
    {
        return $event->organization_id === null
            || (int) $event->organization_id === (int) $student->organization_id;
    }

    private function calculateDistance(float $lat1, float $lon1, float $lat2, float $lon2): float
    {
        $earthRadius = 6371000;
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat / 2) * sin($dLat / 2) +
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
             sin($dLon / 2) * sin($dLon / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c;
    }

    private function isLunchBreak(): bool
    {
        $time = now()->format('H:i:s');

        return $time >= '12:00:00' && $time < '13:00:00';
    }

    private function hasValidCoordinates(Request $request): bool
    {
        $latitude = $request->input('latitude');
        $longitude = $request->input('longitude');

        return is_numeric($latitude)
            && is_numeric($longitude)
            && (float) $latitude >= -90
            && (float) $latitude <= 90
            && (float) $longitude >= -180
            && (float) $longitude <= 180;
    }

    private function isQueueWindowOpen(Event $event, \Illuminate\Support\Carbon $now): bool
    {
        if (! in_array($event->status, ['scheduled', 'active'], true)) {
            return false;
        }

        if (! $event->event_date || ! $event->start_time || ! $event->end_time) {
            return true;
        }

        $eventDate = $event->event_date->format('Y-m-d');
        $startsAt = \Illuminate\Support\Carbon::parse(
            "{$eventDate} {$event->start_time}",
            $now->timezone
        );
        $endsAt = \Illuminate\Support\Carbon::parse(
            "{$eventDate} {$event->end_time}",
            $now->timezone
        );
        if ($endsAt->lessThanOrEqualTo($startsAt)) {
            $endsAt->addDay();
        }

        return $now->greaterThanOrEqualTo($startsAt->copy()->subHour())
            && $now->lessThanOrEqualTo($endsAt);
    }

    public function getStudentDashboard(Request $request): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $student = $this->resolveStudent($request);
        if (! $student) {
            return response()->json([
                'success' => false,
                'error' => 'No student profile found',
            ], 404);
        }

        $lunchBreakActive = $this->isLunchBreak();
        $evaluatedEventIds = EventEvaluation::where('student_id', $student->id)
            ->pluck('event_id')
            ->toArray();

        $certificates = IssuedCertificate::where('student_id', $student->id)->get()->keyBy('event_id');
        $designatedEventIds = EventStudentDesignation::where('student_id', $student->id)
            ->pluck('event_id')
            ->all();

        $recentAttendance = Attendance::where('student_id', $student->id)
            ->with('event')
            ->orderBy('scanned_at', 'desc')
            ->limit(6)
            ->get()
            ->map(function ($att) use ($evaluatedEventIds, $certificates) {
                $cert = $certificates->get($att->event_id);

                return [
                    'id' => $att->id,
                    'event_id' => $att->event_id,
                    'event_name' => $att->event?->name ?? 'Unknown Event',
                    'venue' => $att->event?->venue ?? 'Main Campus',
                    'event_status' => $att->event?->status ?? 'completed',
                    'status' => $att->status,
                    'scanned_at' => $att->scanned_at?->format('Y-m-d H:i:s') ?? (string) $att->scanned_at,
                    'has_evaluated' => in_array($att->event_id, $evaluatedEventIds, true),
                    'certificate_serial' => $cert?->certificate_code,
                    'evaluation_enabled' => (bool) $att->event?->evaluation_enabled,
                ];
            });

        $upcomingEvents = Event::whereIn('status', ['active', 'scheduled'])
            ->with('organization')
            ->where(function ($query) use ($student) {
                $query->whereNull('organization_id')
                    ->orWhere('organization_id', $student->organization_id);
            })
            ->orderBy('event_date', 'asc')
            ->limit(5)
            ->get()
            ->map(function ($e) use ($student, $lunchBreakActive, $designatedEventIds) {
                $att = Attendance::where('event_id', $e->id)
                    ->where('student_id', $student->id)
                    ->first();
                $queueEntry = EventQueueEntry::query()
                    ->where('event_id', $e->id)
                    ->where('student_id', $student->id)
                    ->whereNull('invalidated_at')
                    ->first();
                $hasScanned = (bool) $att;
                $isQueued = $queueEntry !== null && $queueEntry->checked_in_at === null;
                $isDesignated = in_array($e->id, $designatedEventIds);

                return [
                    'id' => $e->id,
                    'name' => $e->name,
                    'event_date' => $e->event_date?->format('Y-m-d') ?? now()->toDateString(),
                    'start_time' => $e->start_time,
                    'end_time' => $e->end_time,
                    'venue' => $e->venue ?? 'Campus Grounds',
                    'status' => $e->status,
                    'scanning_enabled' => $e->scanning_enabled,
                    'attendance_mode' => $e->attendance_mode ?? 'Barcode + Student ID',
                    'organizer' => $e->organizer ?? 'Student Affairs Office',
                    'organization_id' => $e->organization_id,
                    'organization_name' => $e->organization?->name,
                    'verification_interval_minutes' => $e->verification_interval_minutes,
                    'radius_meters' => $e->radius_meters,
                    'has_scanned' => $hasScanned,
                    'is_queued' => $isQueued,
                    'queue_entered_at' => $queueEntry?->entered_at?->toIso8601String(),
                    'queue_available' => ! $hasScanned
                        && ! $isQueued
                        && $this->isQueueWindowOpen($e, now()),
                    'is_designated' => $isDesignated,
                    'evaluation_enabled' => $e->evaluation_enabled,
                    'can_confirm_geofence' => $hasScanned && ! $lunchBreakActive && ! $isDesignated,
                    'geofence_status' => $isDesignated
                        ? 'Designation - Geofence Exempt'
                        : (! $hasScanned
                            ? 'Entrance Scan Required'
                            : ($lunchBreakActive ? 'Lunch Break - Geofence Paused' : 'Scan Verified - Geofence Ready')),
                    'scanned_at' => $att?->scanned_at?->format('h:i A'),
                ];
            });

        $activeEvent = Event::where('status', 'active')
            ->where(function ($query) use ($student) {
                $query->whereNull('organization_id')
                    ->orWhere('organization_id', $student->organization_id);
            })
            ->orderBy('event_date')
            ->first();
        $activeAttendance = $activeEvent ? Attendance::where('event_id', $activeEvent->id)
            ->where('student_id', $student->id)
            ->first() : null;
        $hasScannedActive = (bool) $activeAttendance;
        $isDesignatedForActiveEvent = $activeEvent
            ? in_array($activeEvent->id, $designatedEventIds)
            : false;

        $eventsAttended = Attendance::where('student_id', $student->id)
            ->where('status', 'present')
            ->count();

        return response()->json([
            'success' => true,
            'lunch_break' => [
                'active' => $lunchBreakActive,
                'start_time' => '12:00',
                'end_time' => '13:00',
                'message' => $lunchBreakActive ? 'Geofence verification is paused for lunch.' : null,
            ],
            'student' => [
                'id' => $student->id,
                'student_id' => $student->student_id,
                'full_name' => $student->full_name,
                'program' => $student->program?->name ?: 'BSIT',
                'organization' => $student->organization?->name ?: 'DOIT',
                'year_level' => $student->year_level,
                'block' => $student->block,
                'section_block' => $student->block,
                'requires_block' => blank($student->block),
                'email' => $student->email ?: ($student->student_id.'@psu.edu.ph'),
                'phone' => $student->phone ?: '09171112222',
                'campus' => 'Pangasinan State University - Alaminos Campus',
            ],
            'stats' => [
                'events_attended' => $eventsAttended,
                'upcoming_events' => $upcomingEvents->count(),
                'standing' => 'Good',
                'standing_subtitle' => 'Compliant',
                'has_scanned' => $hasScannedActive,
                'can_confirm_geofence' => $hasScannedActive && ! $lunchBreakActive && ! $isDesignatedForActiveEvent,
                'geofence_status' => $isDesignatedForActiveEvent
                    ? 'Designation - Geofence Exempt'
                    : (! $hasScannedActive
                        ? 'Entrance Scan Required'
                        : ($lunchBreakActive ? 'Lunch Break - Geofence Paused' : 'Entrance Scan Verified')),
                'is_designated' => $isDesignatedForActiveEvent,
                'active_event_id' => $activeEvent?->id,
                'active_event_name' => $activeEvent?->name,
            ],
            'upcoming_events' => $upcomingEvents,
            'recent_attendance' => $recentAttendance,
        ]);
    }

    public function updateProfile(Request $request): JsonResponse
    {
        $studentId = trim((string) (
            $request->input('student_id')
            ?? $request->input('username')
            ?? $request->input('id')
            ?? ''
        ));
        if ($studentId === '') {
            return response()->json([
                'success' => false,
                'message' => 'Student ID is required to update a student profile.',
            ], 422);
        }

        $student = Student::where('student_id', $studentId)
            ->orWhere('email', $studentId)
            ->orWhere('email', $studentId.'@psu.edu.ph')
            ->first();
        if (! $student) {
            return response()->json(['success' => false, 'message' => 'Student record not found.'], 404);
        }

        if (! $request->has('block')) {
            foreach (['student_block', 'section_block'] as $blockField) {
                if ($request->has($blockField)) {
                    $request->merge(['block' => $request->input($blockField)]);
                    break;
                }
            }
        }

        $validated = $request->validate([
            'email' => ['sometimes', 'nullable', 'email', 'max:255'],
            'phone' => ['sometimes', 'nullable', 'string', 'max:50'],
            'year_level' => ['sometimes', 'nullable', 'string', 'max:50'],
            'block' => ['sometimes', 'required', 'string', 'max:20'],
        ]);

        if (! empty($validated['email'])) {
            $student->email = trim($validated['email']);
        }
        if (! empty($validated['phone'])) {
            $student->phone = trim($validated['phone']);
        }

        $academicDetails = Student::normalizeAcademicDetails(
            $validated['year_level'] ?? $student->year_level,
            $validated['block'] ?? $student->block
        );
        $student->year_level = $academicDetails['year_level'];
        $student->block = $academicDetails['block'];
        $student->save();

        ActivityLog::log($student->full_name, 'Profile Updated', 'Updated contact and academic details via mobile app');

        return response()->json([
            'success' => true,
            'message' => 'Profile details updated successfully!',
            'student' => [
                'id' => $student->id,
                'student_id' => $student->student_id,
                'full_name' => $student->full_name,
                'program' => $student->program?->name ?: 'BSIT',
                'organization' => $student->organization?->name ?: 'DOIT',
                'year_level' => $student->year_level,
                'block' => $student->block,
                'section_block' => $student->block,
                'requires_block' => blank($student->block),
                'email' => $student->email,
                'phone' => $student->phone,
                'campus' => 'Pangasinan State University - Alaminos Campus',
            ],
        ]);
    }

    public function submitEvaluation(Request $request): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $student = $this->resolveEvaluationStudent($request);
        if (! $student) {
            return response()->json(['success' => false, 'message' => 'Student record not found.']);
        }

        $eventId = (int) $request->input('event_id', 0);
        $event = Event::find($eventId);
        if (! $event) {
            return response()->json(['success' => false, 'message' => 'Invalid Event selected for evaluation.']);
        }
        $event->refresh();

        if (! $event->evaluation_enabled) {
            return response()->json([
                'success' => false,
                'message' => 'Event evaluation is not currently available.',
            ], 403);
        }

        $isPresent = Attendance::where('event_id', $event->id)
            ->where('student_id', $student->id)
            ->where('status', 'present')
            ->exists();
        if (! $isPresent) {
            return response()->json([
                'success' => false,
                'message' => 'Only students marked present for this event can submit an evaluation and receive an e-certificate.',
            ], 403);
        }

        if (strtolower((string) $event->status) !== 'completed') {
            return response()->json([
                'success' => false,
                'message' => 'Event evaluation is not yet open. You must wait until the event is COMPLETED before submitting an evaluation.',
            ], 403);
        }

        $ratingOverall = (int) $request->input('rating_overall', 5);
        $ratingSpeaker = (int) $request->input('rating_speaker', 5);
        $ratingVenue = (int) $request->input('rating_venue', 5);
        $feedback = trim((string) ($request->input('feedback') ?? $request->input('comments') ?? ''));

        EventEvaluation::updateOrCreate(
            ['event_id' => $event->id, 'student_id' => $student->id],
            [
                'rating_content' => $ratingOverall,
                'rating_speaker' => $ratingSpeaker,
                'rating_venue' => $ratingVenue,
                'rating_overall' => $ratingOverall,
                'comments' => $feedback,
                'submitted_at' => now(),
            ]
        );

        $certService = app(CertificateService::class);
        $cert = $certService->issueCertificate($event, $student);

        ActivityLog::log($student->full_name, 'Mobile Event Evaluation', "Evaluated {$event->name} and unlocked certificate {$cert->certificate_code}");

        return response()->json([
            'success' => true,
            'message' => 'Evaluation submitted successfully! Your official E-Certificate is ready.',
            'certificate_serial' => $cert->certificate_code,
        ]);
    }

    public function getCertificate(Request $request): JsonResponse
    {
        $student = $this->resolveEvaluationStudent($request);
        if (! $student) {
            return response()->json(['success' => false, 'message' => 'Student not found.'], 404);
        }

        $eventId = (int) $request->input('event_id', 0);
        $cert = IssuedCertificate::where('event_id', $eventId)
            ->where('student_id', $student->id)
            ->with(['event.certificate', 'student.program'])
            ->first();

        if (! $cert) {
            return response()->json(['success' => false, 'message' => 'Certificate not found.'], 404);
        }

        $event = $cert->event;
        $config = $event?->certificate;

        return response()->json([
            'success' => true,
            'certificate' => [
                'serial_number' => $cert->certificate_code,
                'student_name' => $cert->student_name,
                'student_id' => $student->student_id,
                'program' => $student->program?->name ?: 'BSIT',
                'year_level' => $student->year_level,
                'event_id' => $cert->event_id,
                'event_name' => $event?->name ?? 'Campus Event',
                'venue' => $event?->venue ?? 'Campus Grounds',
                'event_date' => $event?->event_date?->format('F d, Y') ?? date('F d, Y'),
                'issue_date' => $cert->issued_at?->format('F d, Y') ?? date('F d, Y'),
                'campus' => 'Pangasinan State University - Alaminos Campus',
                'signatory_1' => $event?->organizer ?: 'Event Committee Chair',
                'signatory_1_title' => 'Organizing Committee',
                'signatory_2' => $config?->signatory_name ?: 'Campus Executive Director',
                'signatory_2_title' => $config?->signatory_title ?: 'Pangasinan State University',
            ],
        ]);
    }

    private function resolveStudent(Request $request): ?Student
    {
        $input = trim((string) $request->input('student_id', ''));
        if ($input === '') {
            return null;
        }

        $student = Student::with(['program', 'organization'])
            ->where('student_id', $input)
            ->orWhere('email', $input)
            ->orWhere('email', $input.'@psu.edu.ph')
            ->first();

        if ($student) {
            return $student;
        }

        // Fallback to first student in database
        return null;
    }

    private function resolveEvaluationStudent(Request $request): ?Student
    {
        $input = trim((string) $request->input('student_id', ''));
        if ($input === '') {
            return null;
        }

        return Student::with(['program', 'organization'])
            ->where('student_id', $input)
            ->orWhere('email', $input)
            ->orWhere('email', $input.'@psu.edu.ph')
            ->first();
    }
}
