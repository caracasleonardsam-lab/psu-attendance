<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\Organization;
use App\Models\PresenceVerification;
use App\Models\Program;
use App\Models\Student;
use App\Services\EventAudienceService;
use App\Services\EventLifecycleService;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $totalStudents = Student::count();
        $totalPrograms = Program::count();
        $totalOrganizations = Organization::count();
        $activeEvents = Event::where('status', 'active')->count();
        $upcomingEvents = Event::whereIn('status', ['active', 'scheduled'])->orderBy('event_date', 'asc')->take(5)->get();
        
        $todayAttendance = Attendance::whereDate('scanned_at', now()->today())->count();
        $totalAttendance = Attendance::count();

        $recentAttendance = Auth::user()?->isAdmin()
            ? Attendance::with(['student.program', 'student.organization', 'event'])
                ->orderBy('scanned_at', 'desc')
                ->take(8)
                ->get()
            : collect();

        $recentLogs = Auth::user()?->isSuperAdmin()
            ? ActivityLog::orderBy('created_at', 'desc')->take(6)->get()
            : collect();

        $currentActiveEvent = Event::where('status', 'active')->orderBy('event_date', 'desc')->first();
        $eligibleStudentIds = $currentActiveEvent
            ? app(EventAudienceService::class)->eligibleStudentsQuery($currentActiveEvent)->pluck('id')
            : collect();
        $eligibleStudentCount = $eligibleStudentIds->count();
        $verifiedPresenceCount = $currentActiveEvent
            ? PresenceVerification::where('event_id', $currentActiveEvent->id)
                ->where('status', 'inside')
                ->whereIn('student_id', $eligibleStudentIds)
                ->distinct('student_id')
                ->count('student_id')
            : 0;
        $presenceRate = $eligibleStudentCount > 0
            ? round(($verifiedPresenceCount / $eligibleStudentCount) * 100, 1)
            : 0;

        $academicYear = \App\Models\SystemSetting::get('academic_year', '2025-2026');
        $academicSemester = \App\Models\SystemSetting::get('academic_semester', '1st Semester');

        return view('dashboard.index', compact(
            'totalStudents',
            'totalPrograms',
            'totalOrganizations',
            'activeEvents',
            'upcomingEvents',
            'todayAttendance',
            'totalAttendance',
            'recentAttendance',
            'recentLogs',
            'verifiedPresenceCount',
            'eligibleStudentCount',
            'presenceRate',
            'currentActiveEvent',
            'academicYear',
            'academicSemester'
        ));
    }
}
