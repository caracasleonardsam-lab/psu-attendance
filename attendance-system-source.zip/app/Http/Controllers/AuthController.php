<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class AuthController extends Controller
{
    public function showLogin(): View|RedirectResponse
    {
        if (Auth::check()) {
            $user = Auth::user();
            if ($user->role === 'student') {
                Auth::logout();
                return redirect()->route('login')->withErrors([
                    'username' => 'Student accounts must access the system using the Attendance Mobile App.',
                ]);
            }
            return redirect()->route('dashboard');
        }

        return view('auth.login');
    }

    public function login(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        $username = trim($credentials['username']);
        $password = $credentials['password'];

        // Find user by username or email
        $user = User::where('username', $username)
            ->orWhere('email', $username)
            ->first();

        // If not found in users table, check students registry
        if (!$user) {
            $student = \App\Models\Student::where('student_id', $username)
                ->orWhere('email', $username)
                ->orWhere('email', strtolower($username) . '@psu.edu.ph')
                ->first();

            if ($student && ($password === $student->student_id || $password === 'student')) {
                $user = User::create([
                    'name' => $student->full_name,
                    'username' => $student->student_id,
                    'email' => $student->email ?? ($student->student_id . '@psu.edu.ph'),
                    'password' => Hash::make($password),
                    'role' => 'student',
                ]);
            }
        }


        if ($user) {
            $valid = false;
            // Check password hash
            if (Hash::check($password, $user->password)) {
                $valid = true;
            } elseif (password_verify($password, $user->password)) {
                // If legacy hash was stored directly, re-hash with Laravel Hash
                $user->password = Hash::make($password);
                $user->save();
                $valid = true;
            }

            if ($valid) {
                if ($user->role === 'student') {
                    return back()->withErrors([
                        'username' => 'Student accounts must access the system using the Attendance Mobile App.',
                    ])->withInput($request->only('username'));
                }

                Auth::login($user, $request->boolean('remember'));
                $request->session()->regenerate();

                ActivityLog::log($user->name, 'User Logged In', "Logged in successfully as {$user->role}");

                return redirect()->intended(route('dashboard'));
            }
        }

        return back()->withErrors([
            'username' => 'Invalid username or password credentials.',
        ])->withInput($request->only('username'));
    }

    public function logout(Request $request): RedirectResponse
    {
        $userName = Auth::user()?->name ?? 'User';
        ActivityLog::log($userName, 'User Logged Out', 'Ended session');

        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('success', 'You have been logged out successfully.');
    }
}
