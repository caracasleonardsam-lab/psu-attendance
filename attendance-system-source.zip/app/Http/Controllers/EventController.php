<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventQueueEntry;
use App\Models\EventStudentDesignation;
use App\Models\Organization;
use App\Models\Program;
use App\Models\SystemSetting;
use App\Services\EventLifecycleService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class EventController extends Controller
{
    public function index(Request $request): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        app(EventLifecycleService::class)->completeExpiredEvents();

        $query = Event::with('creator');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('venue', 'like', "%{$search}%")
                    ->orWhere('organizer', 'like', "%{$search}%");
            });
        }

        $events = $query->orderBy('event_date', 'desc')->paginate(12)->withQueryString();
        $programs = Program::orderBy('name')->get();
        $organizations = Organization::orderBy('name')->get();

        return view('events.index', compact('events', 'programs', 'organizations'));
    }

    public function store(Request $request): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $canManageEvaluation = $this->canManageEvaluationSetting($request);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'event_date' => ['required', 'date'],
            'start_time' => ['nullable'],
            'end_time' => ['nullable'],
            'venue' => ['nullable', 'string', 'max:255'],
            'organizer' => ['nullable', 'string', 'max:255'],
            'organization_id' => ['nullable', 'integer', 'exists:organizations,id'],
            'attendance_mode' => ['nullable', 'string'],
            'latitude' => ['nullable', 'numeric'],
            'longitude' => ['nullable', 'numeric'],
            'radius_meters' => ['nullable', 'integer', 'min:10', 'max:5000'],
            'presence_verification' => ['nullable', 'boolean'],
            'verification_interval_minutes' => ['nullable', 'integer'],
            'minimum_required_presence' => ['nullable', 'integer'],
            'require_checkout' => ['nullable', 'boolean'],
            'evaluation_enabled' => ['nullable', 'boolean'],
        ]);

        $validated['status'] = 'scheduled';
        $validated['scanning_enabled'] = false;
        $validated['attendance_mode'] = $validated['attendance_mode'] ?? 'Barcode + Student ID';
        $validated['presence_verification'] = $request->boolean('presence_verification');
        $validated['require_checkout'] = $request->boolean('require_checkout');
        if ($canManageEvaluation) {
            $validated['evaluation_enabled'] = $request->boolean('evaluation_enabled');
        } else {
            unset($validated['evaluation_enabled']);
        }
        $validated['latitude'] = $validated['latitude'] ?? 16.115303;
        $validated['longitude'] = $validated['longitude'] ?? 119.967252;
        $validated['radius_meters'] = $validated['radius_meters'] ?? (int) SystemSetting::get('event_radius_meters', '100');
        $validated['verification_interval_minutes'] = $validated['verification_interval_minutes'] ?? (int) SystemSetting::get('verification_interval', '15');
        $validated['minimum_required_presence'] = $validated['minimum_required_presence'] ?? (int) SystemSetting::get('attendance_threshold', '80');
        $validated['created_by'] = Auth::id();

        $event = Event::create($validated);

        ActivityLog::log(
            Auth::user()->name,
            'Created Event',
            "Created event '{$event->name}' scheduled for {$event->event_date?->format('Y-m-d')}"
        );

        return redirect()->route('events.show', $event)->with('success', 'Event created successfully.');
    }

    public function updateScanning(Request $request, Event $event): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        abort_unless(Auth::user()?->isAdmin(), 403);

        $validated = $request->validate([
            'action' => ['required', 'in:start,pause'],
        ]);

        if ($validated['action'] === 'start') {
            if (in_array($event->status, ['completed', 'cancelled'], true)) {
                return back()->withErrors(['scanning' => 'Completed or cancelled events cannot be started.']);
            }

            $event->update([
                'status' => 'active',
                'scanning_enabled' => true,
            ]);
            $action = 'Started Event Scanning';
            $message = 'Scanning is now open for this event.';
        } else {
            if (! in_array($event->status, ['active', 'scheduled'], true)) {
                return back()->withErrors(['scanning' => 'Scanning can only be paused for an active or scheduled event.']);
            }

            $event->update(['scanning_enabled' => false]);
            $action = 'Paused Event Scanning';
            $message = 'Scanning is paused. The event will remain open until its scheduled end time.';
        }

        ActivityLog::log(
            Auth::user()->name ?? 'Administrator',
            $action,
            "Event scanning changed to '{$event->status}' for '{$event->name}'."
        );

        $redirect = $request->boolean('return_to_scanner')
            ? redirect()->route('attendance.scanner', ['event_id' => $event->id])
            : redirect()->route('events.show', $event);

        return $redirect->with('success', $message);
    }

    public function cancel(Request $request, Event $event): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        abort_unless(Auth::user()?->isAdmin(), 403);

        if (! in_array($event->status, ['scheduled', 'active'], true)) {
            return back()->withErrors(['event' => 'Only scheduled or active events can be cancelled.']);
        }

        $event->update([
            'status' => 'cancelled',
            'scanning_enabled' => false,
        ]);
        $this->invalidateQueueEntries($event);

        ActivityLog::log(
            Auth::user()->name,
            'Cancelled Event',
            "Cancelled event '{$event->name}' scheduled for {$event->event_date?->format('Y-m-d')}."
        );

        return redirect()->route('events.show', $event)->with('success', 'Event cancelled. Existing attendance records were kept.');
    }

    public function reschedule(Request $request, Event $event): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        abort_unless(Auth::user()?->isAdmin(), 403);

        if (! in_array($event->status, ['scheduled', 'active', 'cancelled'], true)) {
            return back()->withErrors(['event' => 'Completed events cannot be rescheduled.']);
        }

        $validated = $request->validate([
            'event_date' => [
                'required',
                'date',
                'after:today',
                Rule::notIn([$event->event_date?->format('Y-m-d')]),
            ],
        ]);

        $previousDate = $event->event_date?->format('Y-m-d');
        $event->update([
            'event_date' => $validated['event_date'],
            'status' => 'scheduled',
            'scanning_enabled' => false,
        ]);
        $this->invalidateQueueEntries($event);

        ActivityLog::log(
            Auth::user()->name,
            'Rescheduled Event',
            "Rescheduled event '{$event->name}' from {$previousDate} to {$event->event_date?->format('Y-m-d')}; scanning is off until restarted."
        );

        return redirect()->route('events.show', $event)->with('success', 'Event rescheduled. Existing attendance records were kept and scanning was turned off.');
    }

    public function show(Event $event): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        app(EventLifecycleService::class)->completeExpiredEvents();
        $event->refresh();

        $event->load([
            'attendances.student.program',
            'attendances.student.organization',
            'studentDesignations.student.program',
            'studentDesignations.student.organization',
            'creator',
        ]);

        $attendeesCount = $event->attendances->count();
        $presentCount = $event->attendances->where('status', 'present')->count();
        $lateCount = $event->attendances->where('status', 'late')->count();

        $organizations = Organization::orderBy('name')->get();

        return view('events.show', compact('event', 'attendeesCount', 'presentCount', 'lateCount', 'organizations'));
    }

    public function assignStudentDesignation(Request $request, Event $event): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $validated = $request->validate([
            'student_id' => ['required', 'integer', 'exists:students,id'],
            'designation' => ['required', 'string', 'max:150'],
        ]);

        $designation = $event->studentDesignations()->updateOrCreate(
            ['student_id' => $validated['student_id']],
            [
                'designation' => trim($validated['designation']),
                'assigned_by' => Auth::id(),
            ]
        );
        $designation->load('student');

        ActivityLog::log(
            Auth::user()->name,
            'Assigned Event Designation',
            "Assigned {$designation->student->full_name} as {$designation->designation} for '{$event->name}'"
        );

        return back()->with('success', "{$designation->student->full_name} was assigned as {$designation->designation}.");
    }

    public function removeStudentDesignation(Event $event, EventStudentDesignation $designation): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $designation = $event->studentDesignations()->with('student')->findOrFail($designation->id);
        $studentName = $designation->student?->full_name ?? 'Student';
        $role = $designation->designation;
        $designation->delete();

        ActivityLog::log(
            Auth::user()->name,
            'Removed Event Designation',
            "Removed {$role} designation for {$studentName} from '{$event->name}'"
        );

        return back()->with('success', "Removed {$studentName}'s event designation.");
    }

    public function update(Request $request, Event $event): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'event_date' => ['required', 'date'],
            'start_time' => ['nullable'],
            'end_time' => ['nullable'],
            'venue' => ['nullable', 'string', 'max:255'],
            'organizer' => ['nullable', 'string', 'max:255'],
            'organization_id' => ['sometimes', 'nullable', 'integer', 'exists:organizations,id'],
            'attendance_mode' => ['nullable', 'string'],
            'status' => ['required', 'in:active,scheduled,completed,cancelled'],
            'latitude' => ['nullable', 'numeric'],
            'longitude' => ['nullable', 'numeric'],
            'radius_meters' => ['nullable', 'integer', 'min:10', 'max:5000'],
            'presence_verification' => ['nullable', 'boolean'],
            'verification_interval_minutes' => ['nullable', 'integer'],
            'minimum_required_presence' => ['nullable', 'integer'],
            'require_checkout' => ['nullable', 'boolean'],
        ]);

        $validated['presence_verification'] = $request->boolean('presence_verification');
        $validated['require_checkout'] = $request->boolean('require_checkout');
        if ($validated['status'] === 'cancelled') {
            $validated['scanning_enabled'] = false;
        } elseif (
            $event->status === 'active'
            && $validated['event_date'] !== $event->event_date?->format('Y-m-d')
        ) {
            $validated['status'] = 'scheduled';
            $validated['scanning_enabled'] = false;
        }
        if (
            $validated['status'] !== 'active'
            || $validated['event_date'] !== $event->event_date?->format('Y-m-d')
            || (int) ($validated['organization_id'] ?? $event->organization_id ?? 0) !== (int) ($event->organization_id ?? 0)
        ) {
            $this->invalidateQueueEntries($event);
        }

        $event->update($validated);

        ActivityLog::log(
            Auth::user()->name,
            'Updated Event',
            "Updated event settings for '{$event->name}'"
        );

        return redirect()->route('events.show', $event)->with('success', 'Event updated successfully.');
    }

    private function invalidateQueueEntries(Event $event): void
    {
        EventQueueEntry::query()
            ->where('event_id', $event->id)
            ->whereNull('invalidated_at')
            ->update(['invalidated_at' => now()]);
    }

    public function toggleEvaluation(Request $request, Event $event): RedirectResponse
    {
        $user = Auth::user();
        if (! $user || ! in_array($user->role, ['admin', 'superadmin'], true)) {
            abort(403, 'Only administrators can change evaluation availability.');
        }

        $validated = $request->validate([
            'evaluation_enabled' => ['required', 'boolean'],
        ]);

        if ($validated['evaluation_enabled'] && $event->status !== 'completed') {
            return back()->withErrors([
                'evaluation_enabled' => 'Mark the event as completed before turning on its evaluation.',
            ]);
        }

        $event->update(['evaluation_enabled' => $validated['evaluation_enabled']]);

        ActivityLog::log(
            $user->name,
            $validated['evaluation_enabled'] ? 'Enabled Event Evaluation' : 'Disabled Event Evaluation',
            "Changed evaluation availability for '{$event->name}'"
        );

        return back()->with(
            'success',
            $validated['evaluation_enabled']
                ? 'Event evaluation is now open to present students.'
                : 'Event evaluation has been turned off.'
        );
    }

    public function toggleEvaluationReportVisibility(Request $request, Event $event): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'evaluation_results_visible' => ['required', 'boolean'],
        ]);
        $event->update(['evaluation_results_visible' => $validated['evaluation_results_visible']]);

        ActivityLog::log(
            Auth::user()->name,
            $validated['evaluation_results_visible'] ? 'Opened Evaluation Report' : 'Closed Evaluation Report',
            "Changed report visibility for '{$event->name}'."
        );

        return back()->with(
            'success',
            $validated['evaluation_results_visible']
                ? 'Evaluation report is now available to administrators and officers.'
                : 'Evaluation report access has been closed.'
        );
    }

    public function destroy(Event $event): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $name = $event->name;
        $event->delete();

        ActivityLog::log(
            Auth::user()->name,
            'Deleted Event',
            "Deleted event '{$name}'"
        );

        return redirect()->route('events.index')->with('success', "Event '{$name}' has been deleted.");
    }

    private function canManageEvaluationSetting(Request $request, ?Event $event = null): bool
    {
        if (in_array(Auth::user()?->role, ['admin', 'superadmin'], true)) {
            return true;
        }

        if (! $request->has('evaluation_enabled') || ! $request->boolean('evaluation_enabled')) {
            return false;
        }

        if ($event?->evaluation_enabled) {
            return false;
        }

        abort(403, 'Only administrators can enable event evaluation.');
    }

    public function exportAttendance(Event $event): StreamedResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $attendances = Attendance::with(['student.program', 'student.organization'])
            ->where('event_id', $event->id)
            ->orderByRaw('(SELECT LOWER(full_name) FROM students WHERE students.id = attendance.student_id)')
            ->orderBy('attendance.scanned_at')
            ->get();
        $designations = $event->studentDesignations()->get()->keyBy('student_id');

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"Attendance_{$event->id}_{$event->name}.csv\"",
        ];

        return response()->stream(function () use ($attendances, $event, $designations) {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, ['Event Name', $event->name]);
            fputcsv($handle, ['Event Date', $event->event_date?->format('Y-m-d')]);
            fputcsv($handle, ['Venue', $event->venue]);
            fputcsv($handle, []);
            fputcsv($handle, ['#', 'Student ID', 'Full Name', 'Program', 'Organization', 'Year Level', 'Block', 'Designation', 'Status', 'Time In', 'Verified By']);

            $index = 1;
            foreach ($attendances as $att) {
                fputcsv($handle, [
                    $index++,
                    $att->student?->student_id ?? 'N/A',
                    $att->student?->full_name ?? 'N/A',
                    $att->student?->program?->name ?? 'N/A',
                    $att->student?->organization?->name ?? 'N/A',
                    $att->student?->year_level ?? 'N/A',
                    $att->student?->block ?? 'N/A',
                    $designations->get($att->student_id)?->designation ?? 'N/A',
                    strtoupper($att->status),
                    $att->scanned_at?->format('Y-m-d H:i:s') ?? '',
                    $att->scanned_by ?? 'Barcode Scanner',
                ]);
            }

            fclose($handle);
        }, 200, $headers);
    }
}
