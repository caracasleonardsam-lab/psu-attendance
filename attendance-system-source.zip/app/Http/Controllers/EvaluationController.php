<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\EvaluationAnswer;
use App\Models\EvaluationForm;
use App\Models\EvaluationOption;
use App\Models\EvaluationQuestion;
use App\Models\EvaluationResponse;
use App\Models\Event;
use App\Models\EventEligibility;
use App\Models\Student;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class EvaluationController extends Controller
{
    private const QUESTION_TYPES = [
        'multiple_choice',
        'rating',
        'yes_no',
        'short_answer',
        'paragraph',
    ];

    public function index(): View
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);

        $forms = EvaluationForm::with('event')
            ->withCount('responses')
            ->latest()
            ->paginate(20);
        foreach ($forms as $form) {
            $eligibleCount = self::eligibleStudentsQuery($form)->count();
            $submittedCount = $form->responses()->distinct('student_id')->count('student_id');
            $form->setAttribute('eligible_students_count', $eligibleCount);
            $form->setAttribute('submitted_students_count', $submittedCount);
            $form->setAttribute('pending_students_count', max(0, $eligibleCount - $submittedCount));
        }

        return view('evaluations.index', compact('forms'));
    }

    public function create(): View
    {
        $this->authorizeManagement();

        $form = new EvaluationForm([
            'eligibility_mode' => 'attended',
            'allow_resubmission' => false,
        ]);
        $events = Event::orderByDesc('event_date')->get();

        return view('evaluations.form', compact('form', 'events'));
    }

    public function store(Request $request): RedirectResponse
    {
        $this->authorizeManagement();
        $validated = $this->validateForm($request);

        $form = DB::transaction(function () use ($validated): EvaluationForm {
            $form = EvaluationForm::create([
                'event_id' => $validated['event_id'],
                'created_by' => Auth::id(),
                'title' => $validated['title'],
                'description' => $validated['description'] ?? null,
                'deadline' => $validated['deadline'] ?? null,
                'eligibility_mode' => $validated['eligibility_mode'],
                'allow_resubmission' => (bool) ($validated['allow_resubmission'] ?? false),
            ]);
            $this->saveQuestions($form, $validated['questions'] ?? []);

            return $form;
        });

        ActivityLog::log(Auth::user()->name, 'Created Evaluation', "Created evaluation '{$form->title}'.");

        return redirect()->route('evaluations.edit', $form)->with('success', 'Evaluation form created.');
    }

    public function edit(EvaluationForm $evaluation): View|RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $this->authorizeFormManagement($evaluation);
        if ($evaluation->responses()->exists()) {
            return redirect()->route('evaluations.index')->withErrors([
                'evaluation' => 'This evaluation already has responses. Create a new evaluation to preserve submitted answers.',
            ]);
        }
        $evaluation->load('questions.options', 'event');
        $events = Event::orderByDesc('event_date')->get();
        $form = $evaluation;

        return view('evaluations.form', compact('form', 'events'));
    }

    public function update(Request $request, EvaluationForm $evaluation): RedirectResponse
    {
        $this->authorizeFormManagement($evaluation);
        if ($evaluation->responses()->exists()) {
            return redirect()->route('evaluations.index')->withErrors([
                'evaluation' => 'This evaluation already has responses. Create a new evaluation to preserve submitted answers.',
            ]);
        }
        $validated = $this->validateForm($request);

        DB::transaction(function () use ($evaluation, $validated): void {
            $evaluation->update([
                'event_id' => $validated['event_id'],
                'title' => $validated['title'],
                'description' => $validated['description'] ?? null,
                'deadline' => $validated['deadline'] ?? null,
                'eligibility_mode' => $validated['eligibility_mode'],
                'allow_resubmission' => (bool) ($validated['allow_resubmission'] ?? false),
            ]);
            $evaluation->questions()->delete();
            $this->saveQuestions($evaluation, $validated['questions'] ?? []);
        });

        ActivityLog::log(Auth::user()->name, 'Updated Evaluation', "Updated evaluation '{$evaluation->title}'.");

        return redirect()->route('evaluations.edit', $evaluation)->with('success', 'Evaluation form updated.');
    }

    public function togglePublish(EvaluationForm $evaluation): RedirectResponse
    {
        $this->authorizeFormManagement($evaluation);
        if (! $evaluation->is_published && $evaluation->questions()->count() === 0) {
            return back()->withErrors(['publish' => 'Add at least one question before publishing.']);
        }
        if (! $evaluation->is_published && $evaluation->deadline?->isPast()) {
            return back()->withErrors(['publish' => 'Set a future deadline before publishing.']);
        }

        $evaluation->update(['is_published' => ! $evaluation->is_published]);
        ActivityLog::log(
            Auth::user()->name,
            $evaluation->is_published ? 'Published Evaluation' : 'Unpublished Evaluation',
            "Evaluation '{$evaluation->title}' is now ".($evaluation->is_published ? 'published' : 'unpublished').'.'
        );

        return back()->with('success', $evaluation->is_published ? 'Evaluation published.' : 'Evaluation unpublished.');
    }

    public function results(Request $request): View
    {
        $user = Auth::user();
        abort_unless($user?->isAdmin() || $user?->isOfficer(), 403);
        $formsQuery = EvaluationForm::with('event');
        $eventsQuery = Event::query();
        $responsesQuery = EvaluationResponse::query();
        if (! $user->isSuperAdmin()) {
            $formsQuery->whereHas('event', fn (Builder $event) => $event->where('evaluation_results_visible', true));
            $eventsQuery->where('evaluation_results_visible', true);
            $responsesQuery->whereHas('form.event', fn (Builder $event) => $event->where('evaluation_results_visible', true));
        }
        $forms = $formsQuery->orderByDesc('created_at')->get();
        $events = $eventsQuery->orderByDesc('event_date')->get();
        $query = $responsesQuery->with([
            'student.program',
            'form.event',
            'answers.question',
            'answers.option',
        ])->latest('submitted_at');

        if ($request->filled('event_id')) {
            $query->whereHas('form', fn (Builder $form) => $form->where('event_id', $request->integer('event_id')));
        }
        if ($request->filled('evaluation_id')) {
            $query->where('evaluation_form_id', $request->integer('evaluation_id'));
        }

        $responses = $query->paginate(20)->withQueryString();
        $selectedForm = $request->filled('evaluation_id')
            ? $forms->firstWhere('id', $request->integer('evaluation_id'))
            : null;
        $ratingAverages = $selectedForm
            ? $this->ratingAverages($selectedForm)
            : collect();
        $canViewStudentIdentities = $user->isSuperAdmin();

        return view('evaluations.results', compact(
            'forms',
            'events',
            'responses',
            'selectedForm',
            'ratingAverages',
            'canViewStudentIdentities'
        ));
    }

    public function export(Request $request): StreamedResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $query = EvaluationResponse::with(['student', 'form.event', 'answers.question', 'answers.option'])
            ->latest('submitted_at');
        if ($request->filled('event_id')) {
            $query->whereHas('form', fn (Builder $form) => $form->where('event_id', $request->integer('event_id')));
        }
        if ($request->filled('evaluation_id')) {
            $query->where('evaluation_form_id', $request->integer('evaluation_id'));
        }

        return response()->streamDownload(function () use ($query): void {
            $output = fopen('php://output', 'w');
            fputcsv($output, ['Evaluation', 'Event', 'Student ID', 'Student Name', 'Submitted At', 'Question', 'Answer']);
            $query->chunk(200, function ($responses) use ($output): void {
                foreach ($responses as $response) {
                    foreach ($response->answers as $answer) {
                        fputcsv($output, [
                            $response->form?->title,
                            $response->form?->event?->name,
                            $response->student?->student_id,
                            $response->student?->full_name,
                            $response->submitted_at?->toDateTimeString(),
                            $answer->question?->question_text,
                            $answer->option?->option_text ?? $answer->answer_text,
                        ]);
                    }
                }
            });
            fclose($output);
        }, 'evaluation-results.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public static function eligibleStudentsQuery(EvaluationForm $form): Builder
    {
        $query = Student::query();
        if ($form->eligibility_mode === 'attended') {
            return $query->whereHas('attendances', fn (Builder $attendance) => $attendance
                ->where('event_id', $form->event_id)
                ->whereIn('status', ['present', 'late', 'checked_out']));
        }

        $designatedIds = $form->event->studentDesignations()->select('student_id');
        $rules = EventEligibility::where('event_id', $form->event_id)->get();
        if ($rules->isEmpty() && ! $designatedIds->exists()) {
            return $query;
        }

        return $query->where(function (Builder $participants) use ($form, $rules, $designatedIds): void {
            if ($designatedIds->exists()) {
                $participants->whereIn('id', $designatedIds);
            }
            foreach ($rules as $rule) {
                $participants->orWhere(function (Builder $student) use ($rule): void {
                    $hasCriteria = false;
                    foreach (['program_id', 'organization_id', 'year_level'] as $field) {
                        if ($rule->{$field} !== null) {
                            $student->where($field, $rule->{$field});
                            $hasCriteria = true;
                        }
                    }
                    if (! $hasCriteria) {
                        $student->whereRaw('1 = 0');
                    }
                });
            }
        });
    }

    private function validateForm(Request $request): array
    {
        $validated = $request->validate([
            'event_id' => ['required', 'integer', 'exists:events,id'],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:5000'],
            'deadline' => ['nullable', 'date'],
            'eligibility_mode' => ['required', Rule::in(['attended', 'participants'])],
            'allow_resubmission' => ['nullable', 'boolean'],
            'questions' => ['required', 'array', 'min:1', 'max:100'],
            'questions.*.text' => ['required', 'string', 'max:2000'],
            'questions.*.type' => ['required', Rule::in(self::QUESTION_TYPES)],
            'questions.*.required' => ['nullable', 'boolean'],
            'questions.*.options' => ['nullable', 'array', 'max:30'],
            'questions.*.options.*' => ['required', 'string', 'max:255'],
        ]);

        foreach ($validated['questions'] as $index => $question) {
            if ($question['type'] === 'multiple_choice' &&
                count(array_filter($question['options'] ?? [], fn ($option) => trim($option) !== '')) < 2) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    "questions.{$index}.options" => 'Multiple choice questions need at least two non-empty options.',
                ]);
            }
        }

        return $validated;
    }

    private function saveQuestions(EvaluationForm $form, array $questions): void
    {
        foreach (array_values($questions) as $position => $data) {
            $question = $form->questions()->create([
                'question_text' => trim($data['text']),
                'question_type' => $data['type'],
                'is_required' => (bool) ($data['required'] ?? false),
                'position' => $position,
            ]);
            if ($data['type'] === 'multiple_choice') {
                foreach (array_values(array_filter(
                    $data['options'] ?? [],
                    fn ($option) => trim($option) !== ''
                )) as $optionPosition => $option) {
                    $question->options()->create([
                        'option_text' => trim($option),
                        'position' => $optionPosition,
                    ]);
                }
            }
        }
    }

    private function ratingAverages(EvaluationForm $form): \Illuminate\Support\Collection
    {
        return $form->questions()
            ->where('question_type', 'rating')
            ->with(['options', 'form'])
            ->get()
            ->mapWithKeys(function (EvaluationQuestion $question) use ($form): array {
                $average = EvaluationAnswer::query()
                    ->join('evaluation_responses', 'evaluation_responses.id', '=', 'evaluation_answers.evaluation_response_id')
                    ->where('evaluation_responses.evaluation_form_id', $form->id)
                    ->where('evaluation_answers.evaluation_question_id', $question->id)
                    ->avg('evaluation_answers.answer_text');

                return [$question->id => round((float) $average, 2)];
            });
    }

    private function authorizeManagement(): void
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
    }

    private function authorizeFormManagement(EvaluationForm $evaluation): void
    {
        $this->authorizeManagement();
    }
}
