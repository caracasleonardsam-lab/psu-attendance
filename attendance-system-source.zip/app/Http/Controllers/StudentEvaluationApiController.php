<?php

namespace App\Http\Controllers;

use App\Models\EvaluationAnswer;
use App\Models\EvaluationForm;
use App\Models\EvaluationResponse;
use App\Models\Student;
use App\Models\StudentApiToken;
use App\Services\EventLifecycleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentEvaluationApiController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $student = $this->studentFromToken($request);
        if (! $student) {
            return response()->json(['success' => false, 'message' => 'Please sign in again.'], 401);
        }

        $forms = EvaluationForm::query()
            ->with(['event', 'questions.options'])
            ->where('is_published', true)
            ->where(fn ($query) => $query->whereNull('deadline')->orWhere('deadline', '>=', now()))
            ->whereHas('event', fn ($query) => $query->where('status', 'completed'))
            ->get()
            ->filter(fn (EvaluationForm $form) => EvaluationController::eligibleStudentsQuery($form)
                ->whereKey($student->id)
                ->exists())
            ->map(fn (EvaluationForm $form) => $this->formPayload($form, $student))
            ->values();

        return response()->json(['success' => true, 'evaluations' => $forms]);
    }

    public function show(Request $request, EvaluationForm $evaluation): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $student = $this->studentFromToken($request);
        if (! $student) {
            return response()->json(['success' => false, 'message' => 'Please sign in again.'], 401);
        }
        if (! $this->isAvailable($evaluation, $student)) {
            return response()->json(['success' => false, 'message' => 'This evaluation is not available to your account.'], 403);
        }

        return response()->json([
            'success' => true,
            'evaluation' => $this->formPayload($evaluation->load('event', 'questions.options'), $student),
        ]);
    }

    public function submit(Request $request, EvaluationForm $evaluation): JsonResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();

        $student = $this->studentFromToken($request);
        if (! $student) {
            return response()->json(['success' => false, 'message' => 'Please sign in again.'], 401);
        }
        if (! $this->isAvailable($evaluation, $student)) {
            return response()->json(['success' => false, 'message' => 'This evaluation is not available to your account.'], 403);
        }
        if (! $evaluation->allow_resubmission &&
            $evaluation->responses()->where('student_id', $student->id)->exists()) {
            return response()->json(['success' => false, 'message' => 'You have already submitted this evaluation.'], 409);
        }

        $answers = $request->input('answers');
        if (! is_array($answers)) {
            return response()->json(['success' => false, 'message' => 'Answers must be provided.'], 422);
        }

        $questions = $evaluation->questions()->with('options')->get()->keyBy('id');
        $normalized = [];
        foreach ($questions as $question) {
            $value = $answers[(string) $question->id] ?? $answers[$question->id] ?? null;
            if ($question->is_required && (
                $value === null ||
                $value === '' ||
                (is_string($value) && trim($value) === '')
            )) {
                return response()->json(['success' => false, 'message' => "Please answer: {$question->question_text}"], 422);
            }
            if ($value === null || $value === '') {
                continue;
            }

            $answerText = null;
            $optionId = null;
            switch ($question->question_type) {
                case 'multiple_choice':
                    $optionId = filter_var($value, FILTER_VALIDATE_INT);
                    if (! $optionId || ! $question->options->contains('id', $optionId)) {
                        return response()->json(['success' => false, 'message' => 'Choose a valid option for each multiple-choice question.'], 422);
                    }
                    break;
                case 'rating':
                    if (! is_numeric($value) || (int) $value < 1 || (int) $value > 5) {
                        return response()->json(['success' => false, 'message' => 'Ratings must be from 1 to 5.'], 422);
                    }
                    $answerText = (string) (int) $value;
                    break;
                case 'yes_no':
                    if (! in_array((string) $value, ['yes', 'no'], true)) {
                        return response()->json(['success' => false, 'message' => 'Choose Yes or No.'], 422);
                    }
                    $answerText = (string) $value;
                    break;
                case 'short_answer':
                case 'paragraph':
                    if (! is_string($value) || mb_strlen($value) > ($question->question_type === 'short_answer' ? 255 : 5000)) {
                        return response()->json(['success' => false, 'message' => 'One of the written answers is too long.'], 422);
                    }
                    $answerText = trim($value);
                    break;
                default:
                    return response()->json(['success' => false, 'message' => 'This evaluation contains an unsupported question type.'], 422);
            }
            $normalized[] = [
                'question_id' => $question->id,
                'option_id' => $optionId,
                'answer_text' => $answerText,
            ];
        }

        foreach (array_keys($answers) as $questionId) {
            if (! $questions->has((int) $questionId)) {
                return response()->json(['success' => false, 'message' => 'The submission contains an unknown question. Refresh the form and try again.'], 422);
            }
        }

        $response = DB::transaction(function () use ($evaluation, $student, $normalized): EvaluationResponse {
            $lockedForm = EvaluationForm::query()->whereKey($evaluation->id)->lockForUpdate()->firstOrFail();
            abort_unless($this->isAvailable($lockedForm, $student), 403);
            if (! $lockedForm->allow_resubmission &&
                $lockedForm->responses()->where('student_id', $student->id)->exists()) {
                abort(409, 'You have already submitted this evaluation.');
            }
            $response = $lockedForm->responses()->create([
                'student_id' => $student->id,
                'submitted_at' => now(),
            ]);
            foreach ($normalized as $answer) {
                $response->answers()->create([
                    'evaluation_question_id' => $answer['question_id'],
                    'evaluation_option_id' => $answer['option_id'],
                    'answer_text' => $answer['answer_text'],
                ]);
            }

            return $response;
        });

        return response()->json([
            'success' => true,
            'message' => 'Evaluation submitted. Thank you for your feedback.',
            'response_id' => $response->id,
        ]);
    }

    private function studentFromToken(Request $request): ?Student
    {
        $plainTextToken = $request->bearerToken();
        if (! $plainTextToken) {
            return null;
        }

        return StudentApiToken::query()
            ->with('student')
            ->where('token_hash', hash('sha256', $plainTextToken))
            ->where('expires_at', '>', now())
            ->first()
            ?->student;
    }

    private function isAvailable(EvaluationForm $form, Student $student): bool
    {
        return $form->is_published
            && $form->event?->status === 'completed'
            && (! $form->deadline || ! $form->deadline->isPast())
            && EvaluationController::eligibleStudentsQuery($form)->whereKey($student->id)->exists();
    }

    private function formPayload(EvaluationForm $form, Student $student): array
    {
        return [
            'id' => $form->id,
            'event_id' => $form->event_id,
            'event_name' => $form->event?->name,
            'title' => $form->title,
            'description' => $form->description,
            'deadline' => $form->deadline?->toIso8601String(),
            'allow_resubmission' => $form->allow_resubmission,
            'already_submitted' => $form->responses()->where('student_id', $student->id)->exists(),
            'questions' => $form->questions->map(fn ($question) => [
                'id' => $question->id,
                'text' => $question->question_text,
                'type' => $question->question_type,
                'required' => $question->is_required,
                'options' => $question->options->map(fn ($option) => [
                    'id' => $option->id,
                    'text' => $option->option_text,
                ])->values(),
            ])->values(),
        ];
    }
}
