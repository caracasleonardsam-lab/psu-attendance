<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\Organization;
use App\Models\Program;
use App\Models\Student;
use App\Services\EventAudienceService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportController extends Controller
{
    public function index(Request $request): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $events = Event::orderBy('event_date', 'desc')->get();
        $programs = Program::withCount('students')->orderBy('name')->get();
        $organizations = Organization::withCount('students')->orderBy('name')->get();
        $yearLevels = Student::query()
            ->whereNotNull('year_level')
            ->distinct()
            ->orderBy('year_level')
            ->pluck('year_level');
        $blocks = Student::query()
            ->whereNotNull('block')
            ->distinct()
            ->orderBy('block')
            ->pluck('block');

        // Total system statistics
        $totalStudents = Student::count();
        $totalAttendance = Attendance::count();
        $presentCount = Attendance::where('status', 'present')->count();
        $lateCount = Attendance::where('status', 'late')->count();

        // Measure cumulative turnout as attended student-event slots over eligible slots.
        $summaryEvents = Event::query()
            ->where(function ($query) {
                $query->where('status', 'completed')
                    ->orWhereHas('attendances');
            })
            ->get();
        $eventAudience = app(EventAudienceService::class);
        $programStats = Program::get()->map(function ($p) use ($summaryEvents, $eventAudience) {
            $totalInProg = Student::where('program_id', $p->id)->count();
            $expected = 0;
            $attended = 0;

            foreach ($summaryEvents as $event) {
                $eligibleStudentIds = $eventAudience->eligibleStudentsQuery($event)
                    ->where('program_id', $p->id)
                    ->pluck('id');
                $expected += $eligibleStudentIds->count();
                $attended += Attendance::query()
                    ->where('event_id', $event->id)
                    ->whereIn('status', ['present', 'late'])
                    ->whereIn('student_id', $eligibleStudentIds)
                    ->distinct('student_id')
                    ->count('student_id');
            }

            return [
                'name' => $p->name,
                'students' => $totalInProg,
                'expected' => $expected,
                'attendances' => $attended,
            ];
        });

        // Query preview according to selected filters
        $filteredQuery = $this->buildAttendanceQuery($request);
        $previewCount = (clone $filteredQuery)->count();
        $filteredPresent = (clone $filteredQuery)->where('status', 'present')->count();
        $filteredLate = (clone $filteredQuery)->where('status', 'late')->count();

        $previewRecords = $filteredQuery
            ->orderByRaw('LOWER(students.full_name)')
            ->orderBy('students.student_id')
            ->orderBy('attendance.scanned_at')
            ->paginate(15)
            ->withQueryString();

        return view('reports.index', compact(
            'events',
            'programs',
            'organizations',
            'yearLevels',
            'blocks',
            'totalStudents',
            'totalAttendance',
            'presentCount',
            'lateCount',
            'programStats',
            'previewRecords',
            'previewCount',
            'filteredPresent',
            'filteredLate'
        ));
    }

    public function export(Request $request): StreamedResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $attendances = $this->buildAttendanceQuery($request)
            ->orderByRaw('LOWER(students.full_name)')
            ->orderBy('students.student_id')
            ->orderBy('attendance.scanned_at')
            ->get();

        $scopeDesc = $this->getScopeDescription($request);
        $eventDesc = 'All Campus Events';
        if ($request->filled('event_id')) {
            $ev = Event::find($request->input('event_id'));
            if ($ev) {
                $eventDesc = $ev->name . ' (' . ($ev->event_date?->format('Y-m-d') ?? 'N/A') . ')';
            }
        }

        $safeScope = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $scopeDesc);
        $filename = "Attendance_Report_{$safeScope}_" . date('Ymd_His') . ".csv";

        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];

        ActivityLog::log(
            Auth::user()->name ?? 'Administrator',
            'Exported Attendance Report',
            "Downloaded CSV report for scope: {$scopeDesc}, Event: {$eventDesc}, Total Records: {$attendances->count()}"
        );

        $turnout = $this->calculateTurnout($request, $attendances);

        return response()->stream(function () use ($attendances, $scopeDesc, $eventDesc, $turnout) {
            $handle = fopen('php://output', 'w');

            // UTF-8 BOM for Microsoft Excel compatibility
            fprintf($handle, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // Institutional Report Header
            fputcsv($handle, ['PANGASINAN STATE UNIVERSITY - ALAMINOS CITY CAMPUS']);
            fputcsv($handle, ['OFFICIAL ATTENDANCE AND COMPLIANCE REPORT']);
            fputcsv($handle, ['Report Scope', $scopeDesc]);
            fputcsv($handle, ['Event / Session', $eventDesc]);
            fputcsv($handle, ['Generated Date', date('F d, Y h:i A')]);
            fputcsv($handle, ['Generated By', Auth::user()->name ?? 'Administrator']);
            fputcsv($handle, ['Total Records Found', $attendances->count()]);
            fputcsv($handle, []); // Blank separator

            // Column Headers
            fputcsv($handle, [
                '#',
                'Student ID',
                'Student Full Name',
                'Academic Program',
                'Student Organization',
                'Year Level',
                'Block',
                'Event Name',
                'Venue',
                'Attendance Status',
                'Check-in Timestamp',
                'Verified By'
            ]);

            $index = 1;
            $presentCount = 0;
            $lateCount = 0;

            foreach ($attendances as $att) {
                if ($att->status === 'present') $presentCount++;
                if ($att->status === 'late') $lateCount++;

                fputcsv($handle, [
                    $index++,
                    $att->student?->student_id ?? 'N/A',
                    $att->student?->full_name ?? 'N/A',
                    $att->student?->program?->name ?? 'N/A',
                    $att->student?->organization?->name ?? 'N/A',
                    $att->student?->year_level ?? 'N/A',
                    $att->student?->block ?? 'N/A',
                    $att->event?->name ?? 'Campus Event',
                    $att->event?->venue ?? 'Campus Grounds',
                    strtoupper($att->status),
                    $att->scanned_at ? $att->scanned_at->format('Y-m-d H:i:s') : 'N/A',
                    $att->scanned_by ?? 'Barcode Scanner',
                ]);
            }

            // Summary Footer
            fputcsv($handle, []);
            fputcsv($handle, ['SUMMARY COMPLIANCE STATISTICS']);
            fputcsv($handle, ['Total Attendees', $attendances->count()]);
            fputcsv($handle, ['Present (On-Time)', $presentCount]);
            fputcsv($handle, ['Late Check-in', $lateCount]);
            fputcsv($handle, ['Attended Student-Event Slots', $turnout['attended']]);
            fputcsv($handle, ['Eligible Student-Event Slots', $turnout['expected']]);
            fputcsv($handle, ['Turnout Among Eligible Students', $turnout['rate'] . '%']);

            fclose($handle);
        }, 200, $headers);
    }

    public function printReport(Request $request): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $attendances = $this->buildAttendanceQuery($request)
            ->orderByRaw('LOWER(students.full_name)')
            ->orderBy('students.student_id')
            ->orderBy('attendance.scanned_at')
            ->get();

        $scopeDesc = $this->getScopeDescription($request);
        $event = null;
        if ($request->filled('event_id')) {
            $event = Event::find($request->input('event_id'));
        }

        $presentCount = $attendances->where('status', 'present')->count();
        $lateCount = $attendances->where('status', 'late')->count();
        $turnout = $this->calculateTurnout($request, $attendances);

        ActivityLog::log(
            Auth::user()->name ?? 'Administrator',
            'Printed Attendance Document',
            "Generated printable attendance report for scope: {$scopeDesc}"
        );

        return view('reports.print', array_merge(compact(
            'attendances',
            'scopeDesc',
            'event',
            'presentCount',
            'lateCount'
        ), [
            'attendedStudentCount' => $turnout['attended'],
            'expectedStudentCount' => $turnout['expected'],
            'turnoutRate' => $turnout['rate'],
        ]));
    }

    private function calculateTurnout(Request $request, \Illuminate\Support\Collection $attendances): array
    {
        $attended = 0;
        $expected = 0;
        foreach ($this->reportEvents($request) as $event) {
            $eligibleStudentIds = $this->scopedEligibleStudentsQuery($event, $request)->pluck('id');
            $expected += $eligibleStudentIds->count();
            $attended += $attendances
                ->where('event_id', $event->id)
                ->whereIn('status', ['present', 'late'])
                ->whereIn('student_id', $eligibleStudentIds)
                ->pluck('student_id')
                ->unique()
                ->count();
        }

        return [
            'attended' => $attended,
            'expected' => $expected,
            'rate' => $expected > 0 ? round(($attended / $expected) * 100, 1) : 0,
        ];
    }

    private function reportEvents(Request $request)
    {
        $query = Event::query();

        if ($request->filled('event_id')) {
            $query->whereKey($request->input('event_id'));
        } else {
            $query->where(function ($events) {
                $events->where('status', 'completed')
                    ->orWhereHas('attendances');
            });
        }
        if ($request->filled('date_from')) {
            $query->whereDate('event_date', '>=', $request->input('date_from'));
        }
        if ($request->filled('date_to')) {
            $query->whereDate('event_date', '<=', $request->input('date_to'));
        }

        return $query->get();
    }

    private function scopedEligibleStudentsQuery(Event $event, Request $request)
    {
        $query = app(EventAudienceService::class)->eligibleStudentsQuery($event);
        $scope = $request->input('scope', 'all');

        if ($scope === 'organization' && $request->filled('organization_id')) {
            $query->where('organization_id', $request->input('organization_id'));
        } elseif ($scope === 'year_level' && $request->filled('year_level')) {
            $query->where('year_level', $request->input('year_level'));
            if ($request->filled('block')) {
                $query->where('block', $request->input('block'));
            }
        } elseif ($scope === 'block' && $request->filled('block')) {
            $query->where('block', $request->input('block'));
        } elseif ($scope === 'program' && $request->filled('program_id')) {
            $query->where('program_id', $request->input('program_id'));
        }

        return $query;
    }

    private function buildAttendanceQuery(Request $request)
    {
        $request->validate([
            'scope' => ['sometimes', 'in:all,organization,year_level,block,program'],
            'organization_id' => ['required_if:scope,organization', 'nullable', 'integer', 'exists:organizations,id'],
            'year_level' => ['required_if:scope,year_level', 'nullable', 'string', 'max:50'],
            'block' => ['required_if:scope,block', 'nullable', 'string', 'max:20'],
            'program_id' => ['required_if:scope,program', 'nullable', 'integer', 'exists:programs,id'],
            'event_id' => ['nullable', 'integer', 'exists:events,id'],
            'status' => ['nullable', 'in:present,late,checked_out,absent'],
            'date_from' => ['nullable', 'date_format:Y-m-d'],
            'date_to' => ['nullable', 'date_format:Y-m-d', 'after_or_equal:date_from'],
        ]);

        $query = Attendance::query()
            ->select('attendance.*')
            ->join('students', 'attendance.student_id', '=', 'students.id')
            ->with(['student.program', 'student.organization', 'event']);

        // Scope filter: all (campus-wide), organization, year/block, or program
        $scope = $request->input('scope', 'all');

        if ($scope === 'organization' && $request->filled('organization_id')) {
            $query->where('students.organization_id', $request->input('organization_id'));
        } elseif ($scope === 'year_level' && $request->filled('year_level')) {
            $query->where('students.year_level', $request->input('year_level'));
            if ($request->filled('block')) {
                $query->where('students.block', $request->input('block'));
            }
        } elseif ($scope === 'block' && $request->filled('block')) {
            $query->where('students.block', $request->input('block'));
        } elseif ($scope === 'program' && $request->filled('program_id')) {
            $query->where('students.program_id', $request->input('program_id'));
        }

        // Event filter
        if ($request->filled('event_id')) {
            $query->where('attendance.event_id', $request->input('event_id'));
        }

        // Status filter
        if ($request->filled('status')) {
            $query->where('attendance.status', $request->input('status'));
        }

        // Date range
        if ($request->filled('date_from')) {
            $query->whereDate('attendance.scanned_at', '>=', $request->input('date_from'));
        }
        if ($request->filled('date_to')) {
            $query->whereDate('attendance.scanned_at', '<=', $request->input('date_to'));
        }

        return $query;
    }

    private function getScopeDescription(Request $request): string
    {
        $scope = $request->input('scope', 'all');

        if ($scope === 'organization' && $request->filled('organization_id')) {
            $org = Organization::find($request->input('organization_id'));
            return $org ? "Student Organization - {$org->name}" : "Per Organization";
        }

        if ($scope === 'year_level' && $request->filled('year_level')) {
            $description = "Year Level - " . $request->input('year_level');
            if ($request->filled('block')) {
                $description .= " / Block " . $request->input('block');
            }

            return $description;
        }

        if ($scope === 'block' && $request->filled('block')) {
            return "Block - " . $request->input('block');
        }

        if ($scope === 'program' && $request->filled('program_id')) {
            $prog = Program::find($request->input('program_id'));
            return $prog ? "Academic Program - {$prog->name}" : "Per Academic Program";
        }

        return "Whole Campus (All Programs & Organizations)";
    }
}
