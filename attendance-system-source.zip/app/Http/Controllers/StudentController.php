<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Organization;
use App\Models\Program;
use App\Models\Student;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;

class StudentController extends Controller
{
    public function index(Request $request): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $students = $this->filteredStudents($request)->paginate(25)->withQueryString();
        $programs = Program::orderBy('name')->get();
        $organizations = Organization::orderBy('name')->get();
        $yearLevels = Student::query()->whereNotNull('year_level')->where('year_level', '!=', '')
            ->distinct()->orderBy('year_level')->pluck('year_level');
        $blocks = Student::query()->whereNotNull('block')->where('block', '!=', '')
            ->distinct()->orderBy('block')->pluck('block');

        return view('students.index', compact('students', 'programs', 'organizations', 'yearLevels', 'blocks'));
    }

    public function export(Request $request): StreamedResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $students = $this->filteredStudents($request)->get();
        $filename = 'students-' . now()->format('Ymd-His') . '.csv';

        return response()->streamDownload(function () use ($students) {
            $handle = fopen('php://output', 'w');
            fwrite($handle, "\xEF\xBB\xBF");
            fputcsv($handle, ['Student ID', 'Full Name', 'Program', 'Organization', 'Year Level', 'Block', 'Email', 'Phone']);

            foreach ($students as $student) {
                fputcsv($handle, [
                    $student->student_id,
                    $student->full_name,
                    $student->program?->name ?? 'N/A',
                    $student->organization?->name ?? 'N/A',
                    $student->year_level ?? 'N/A',
                    $student->block ?? 'N/A',
                    $student->email ?? '',
                    $student->phone ?? '',
                ]);
            }

            fclose($handle);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function template(): StreamedResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        return response()->streamDownload(function () {
            $handle = fopen('php://output', 'w');
            fwrite($handle, "\xEF\xBB\xBF");
            fputcsv($handle, ['Student Number', 'Full Name', 'Course', 'Year Level', 'Block', 'Organization', 'Email', 'Phone']);
            fclose($handle);
        }, 'student-roster-template.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function import(Request $request): RedirectResponse
    {
        $this->authorizeManagement();
        $validated = $request->validate([
            'student_file' => ['required', 'file', 'mimes:csv,txt', 'max:10240'],
        ]);

        $handle = fopen($validated['student_file']->getRealPath(), 'r');
        if ($handle === false) {
            throw ValidationException::withMessages(['student_file' => 'The uploaded file could not be read.']);
        }

        $headers = fgetcsv($handle, 0, ',', '"', '\\');
        if (!$headers) {
            fclose($handle);
            throw ValidationException::withMessages(['student_file' => 'The CSV file is empty or has no header row.']);
        }

        $headerMap = [];
        foreach ($headers as $index => $header) {
            $normalized = preg_replace('/[^a-z0-9]/', '', strtolower(trim((string) $header, "\xEF\xBB\xBF \t\n\r\0\x0B")));
            $field = match ($normalized) {
                'studentnumber', 'studentno', 'studentid', 'id' => 'student_id',
                'fullname', 'name' => 'full_name',
                'course', 'program' => 'course',
                'year', 'yearlevel', 'academicyear' => 'year_level',
                'block', 'section', 'sectionblock' => 'block',
                'organization', 'org' => 'organization',
                'email', 'emailaddress' => 'email',
                'phone', 'phonenumber', 'contact' => 'phone',
                default => null,
            };

            if ($field !== null) {
                $headerMap[$field] = $index;
            }
        }

        foreach (['student_id', 'full_name', 'course'] as $requiredHeader) {
            if (!array_key_exists($requiredHeader, $headerMap)) {
                fclose($handle);
                throw ValidationException::withMessages([
                    'student_file' => 'CSV headers must include Student Number, Full Name, and Course.',
                ]);
            }
        }

        $rows = [];
        $errors = [];
        $seenStudentIds = [];
        $lineNumber = 1;
        while (($cells = fgetcsv($handle, 0, ',', '"', '\\')) !== false) {
            $lineNumber++;
            if ($cells === [null] || count(array_filter($cells, fn ($cell) => trim((string) $cell) !== '')) === 0) {
                continue;
            }

            if (count($rows) >= 5000) {
                $errors[] = 'CSV imports are limited to 5,000 student rows.';
                break;
            }

            $row = [];
            foreach ($headerMap as $field => $column) {
                $value = isset($cells[$column]) ? trim((string) $cells[$column]) : '';
                $row[$field] = $value === '' && $field !== 'student_id' && $field !== 'full_name' && $field !== 'course'
                    ? null
                    : $value;
            }

            $rowValidator = Validator::make($row, [
                'student_id' => ['required', 'string', 'max:100'],
                'full_name' => ['required', 'string', 'max:255'],
                'course' => ['required', 'string', 'max:255'],
                'year_level' => ['nullable', 'string', 'max:50'],
                'block' => ['nullable', 'string', 'max:20'],
                'organization' => ['nullable', 'string', 'max:255'],
                'email' => ['nullable', 'email', 'max:255'],
                'phone' => ['nullable', 'string', 'max:50'],
            ]);

            if ($rowValidator->fails()) {
                foreach ($rowValidator->errors()->all() as $error) {
                    $errors[] = "CSV row {$lineNumber}: {$error}";
                }
                continue;
            }

            $studentIdKey = strtolower($row['student_id']);
            if (isset($seenStudentIds[$studentIdKey])) {
                $errors[] = "CSV row {$lineNumber}: Student Number duplicates row {$seenStudentIds[$studentIdKey]}.";
                continue;
            }
            $seenStudentIds[$studentIdKey] = $lineNumber;
            $rows[] = $row;
        }
        fclose($handle);

        if ($errors !== []) {
            throw ValidationException::withMessages(['student_file' => array_slice($errors, 0, 20)]);
        }
        if ($rows === []) {
            throw ValidationException::withMessages(['student_file' => 'The CSV contains no student rows to import.']);
        }

        $created = 0;
        $updated = 0;
        DB::transaction(function () use ($rows, $headerMap, &$created, &$updated): void {
            foreach ($rows as $row) {
                $program = Program::query()
                    ->whereRaw('LOWER(name) = ?', [mb_strtolower($row['course'])])
                    ->first();
                if (!$program) {
                    $program = Program::create(['name' => $row['course']]);
                }

                $student = Student::withTrashed()->where('student_id', $row['student_id'])->first();
                $attributes = [
                    'full_name' => $row['full_name'],
                    'program_id' => $program->id,
                ];
                foreach ([
                    'year_level' => 'year_level',
                    'block' => 'block',
                    'organization' => 'organization_id',
                    'email' => 'email',
                    'phone' => 'phone',
                ] as $csvField => $studentField) {
                    if (!array_key_exists($csvField, $headerMap)) {
                        continue;
                    }

                    if ($csvField === 'organization') {
                        $organization = empty($row[$csvField])
                            ? null
                            : Organization::firstOrCreate(['name' => $row[$csvField]]);
                        $attributes[$studentField] = $organization?->id;
                    } elseif (in_array($csvField, ['year_level', 'block'], true)) {
                        $attributes[$studentField] = $row[$csvField];
                    } else {
                        $attributes[$studentField] = $row[$csvField];
                    }
                }

                $yearLevel = array_key_exists('year_level', $attributes)
                    ? $attributes['year_level']
                    : $student?->year_level;
                $block = array_key_exists('block', $attributes)
                    ? $attributes['block']
                    : $student?->block;
                $attributes = array_merge($attributes, Student::normalizeAcademicDetails($yearLevel, $block));

                if ($student) {
                    $student->fill($attributes);
                    if ($student->trashed()) {
                        $student->restore();
                    }
                    $student->save();
                    $updated++;
                } else {
                    $attributes['student_id'] = $row['student_id'];
                    Student::create($attributes);
                    $created++;
                }
            }
        });

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Imported Student Roster',
            "Imported {$created} new and updated {$updated} student records from CSV"
        );

        return back()->with('success', "Student roster imported: {$created} added, {$updated} updated.");
    }

    private function filteredStudents(Request $request): Builder
    {
        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:100'],
            'program_id' => ['nullable', 'integer', 'exists:programs,id'],
            'organization_id' => ['nullable', 'integer', 'exists:organizations,id'],
            'year_level' => ['nullable', 'string', 'max:50'],
            'block' => ['nullable', 'string', 'max:20'],
        ]);
        $query = Student::with(['program', 'organization']);

        if (!empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function (Builder $q) use ($search) {
                $q->where('student_id', 'like', "%{$search}%")
                    ->orWhere('full_name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%");
            });
        }

        foreach (['program_id', 'organization_id', 'year_level', 'block'] as $filter) {
            if (!empty($filters[$filter])) {
                $query->where($filter, $filters[$filter]);
            }
        }

        return $query->orderBy('full_name')->orderBy('student_id');
    }

    public function store(Request $request): RedirectResponse
    {
        $this->authorizeManagement();
        $validated = $request->validate([
            'student_id' => ['required', 'string', 'max:100', Rule::unique('students', 'student_id')->whereNull('deleted_at')],
            'full_name' => ['required', 'string', 'max:255'],
            'program_id' => ['nullable', 'exists:programs,id'],
            'organization_id' => ['nullable', 'exists:organizations,id'],
            'year_level' => ['nullable', 'string', 'max:50'],
            'block' => ['nullable', 'string', 'max:20'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
        ]);
        $validated = array_merge($validated, Student::normalizeAcademicDetails(
            $validated['year_level'] ?? null,
            $validated['block'] ?? null
        ));

        $student = Student::withTrashed()->where('student_id', $validated['student_id'])->first();
        if ($student) {
            $student->fill($validated);
            if ($student->trashed()) {
                $student->restore();
            }
            $student->save();
            $action = 'Reactivated Student';
        } else {
            $student = Student::create($validated);
            $action = 'Added Student';
        }

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            $action,
            "Enrolled student {$student->full_name} ({$student->student_id})"
        );

        return back()->with('success', "Student {$student->full_name} added successfully.");
    }

    public function update(Request $request, Student $student): RedirectResponse
    {
        $this->authorizeManagement();
        $validated = $request->validate([
            'full_name' => ['required', 'string', 'max:255'],
            'program_id' => ['nullable', 'exists:programs,id'],
            'organization_id' => ['nullable', 'exists:organizations,id'],
            'year_level' => ['nullable', 'string', 'max:50'],
            'block' => ['nullable', 'string', 'max:20'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
        ]);
        $yearLevel = array_key_exists('year_level', $validated) ? $validated['year_level'] : $student->year_level;
        $block = array_key_exists('block', $validated) ? $validated['block'] : $student->block;
        $validated = array_merge($validated, Student::normalizeAcademicDetails($yearLevel, $block));

        $student->update($validated);

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Updated Student',
            "Updated student record for {$student->full_name} ({$student->student_id})"
        );

        return back()->with('success', "Student {$student->full_name} updated successfully.");
    }

    public function destroy(Student $student): RedirectResponse
    {
        $this->authorizeManagement();
        $name = $student->full_name;
        $student->delete();

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Archived Student',
            "Archived student {$name} from the active roster; linked history was preserved"
        );

        return back()->with('success', "Student {$name} removed successfully.");
    }

    private function authorizeManagement(): void
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
    }
}
