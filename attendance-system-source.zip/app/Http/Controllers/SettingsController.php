<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\SystemSetting;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class SettingsController extends Controller
{
    /**
     * Display the comprehensive system settings page.
     */
    public function index(Request $request): View
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $defaults = [
            'campus_name' => 'Pangasinan State University - Alaminos City Campus',
            'system_name' => 'Pangasinan State University Attendance & Presence Verification System',
            'campus_head' => 'Dr. Armando D. Junio',
            'contact_email' => 'alaminos@psu.edu.ph',
            'campus_address' => 'City of Alaminos, Pangasinan 2404',
            'academic_year' => '2025-2026',
            'academic_semester' => '1st Semester',
            'event_radius_meters' => '100',
            'verification_interval' => '15',
            'attendance_threshold' => '80',
            'session_timeout_minutes' => '30',
            'grace_period_minutes' => '15',
            'auto_checkout_enabled' => '1',
        ];

        $storedSettings = SystemSetting::all()->pluck('value_text', 'key_name')->toArray();
        $settings = array_merge($defaults, $storedSettings);

        $users = Auth::user()->isSuperAdmin()
            ? User::whereIn('role', ['superadmin', 'admin', 'officer'])
                ->orderByRaw("CASE role WHEN 'superadmin' THEN 0 WHEN 'admin' THEN 1 WHEN 'officer' THEN 2 ELSE 3 END")
                ->orderBy('name')
                ->get()
            : collect();

        $activeTab = $request->query('tab', 'institutional');
        if (!in_array($activeTab, ['institutional', 'users'])) {
            $activeTab = 'institutional';
        }
        if (! Auth::user()->isSuperAdmin() && $activeTab === 'users') {
            abort(403);
        }

        $totalAdmins = $users->whereIn('role', ['superadmin', 'admin'])->count();
        $totalOfficers = $users->where('role', 'officer')->count();

        return view('settings.index', compact('settings', 'users', 'activeTab', 'totalAdmins', 'totalOfficers'));
    }

    /**
     * Update institutional and academic term settings.
     */
    public function updateGeneral(Request $request): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'campus_name' => ['required', 'string', 'max:255'],
            'system_name' => ['required', 'string', 'max:255'],
            'campus_head' => ['nullable', 'string', 'max:255'],
            'contact_email' => ['nullable', 'email', 'max:255'],
            'campus_address' => ['nullable', 'string', 'max:255'],
            'academic_year' => ['required', 'string', 'max:50'],
            'academic_semester' => ['required', 'string', 'max:50'],
        ]);

        foreach ($validated as $key => $value) {
            SystemSetting::set($key, (string) $value);
        }

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Updated Institutional Settings',
            "Updated campus info ({$validated['campus_name']}) and academic term ({$validated['academic_year']} - {$validated['academic_semester']})"
        );

        return redirect()->route('settings.index', ['tab' => 'institutional'])
            ->with('success', 'Institutional identity and academic term settings saved successfully.');
    }

    /**
     * Update attendance and geofencing defaults.
     */
    public function updateAttendance(Request $request): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'event_radius_meters' => ['required', 'integer', 'min:10', 'max:5000'],
            'verification_interval' => ['required', 'integer', 'min:1', 'max:120'],
            'attendance_threshold' => ['required', 'integer', 'min:1', 'max:100'],
            'session_timeout_minutes' => ['required', 'integer', 'min:5', 'max:300'],
            'grace_period_minutes' => ['required', 'integer', 'min:0', 'max:60'],
            'auto_checkout_enabled' => ['nullable', 'boolean'],
        ]);

        foreach (['event_radius_meters', 'verification_interval', 'attendance_threshold', 'session_timeout_minutes', 'grace_period_minutes'] as $key) {
            SystemSetting::set($key, (string) $validated[$key]);
        }

        SystemSetting::set('auto_checkout_enabled', $request->boolean('auto_checkout_enabled') ? '1' : '0');

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Updated Attendance Rules',
            "Default radius set to {$validated['event_radius_meters']}m, interval {$validated['verification_interval']}m, threshold {$validated['attendance_threshold']}%"
        );

        return redirect()->route('settings.index', ['tab' => 'attendance'])
            ->with('success', 'Default attendance rules and geofencing thresholds saved successfully.');
    }

    /**
     * Backwards-compatible general updater.
     */
    public function update(Request $request): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $keys = [
            'campus_name',
            'system_name',
            'campus_head',
            'contact_email',
            'campus_address',
            'academic_year',
            'academic_semester',
            'attendance_threshold',
            'verification_interval',
            'event_radius_meters',
            'session_timeout_minutes',
            'grace_period_minutes',
            'auto_checkout_enabled',
        ];

        foreach ($keys as $key) {
            if ($request->has($key)) {
                SystemSetting::set($key, (string) $request->input($key));
            }
        }

        ActivityLog::log(Auth::user()?->name ?? 'Admin', 'Updated System Settings', 'Modified core system parameters');

        return back()->with('success', 'System settings saved successfully.');
    }

    /**
     * Create a new administrative or officer account.
     */
    public function storeUser(Request $request): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:50', 'alpha_dash', 'unique:users,username'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'role' => ['required', 'in:superadmin,admin,officer'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
        ]);

        $currentUser = Auth::user();
        if ($currentUser && $currentUser->role !== 'superadmin' && $validated['role'] === 'superadmin') {
            return redirect()->route('settings.index', ['tab' => 'users'])
                ->with('error', 'Only Super Administrators can create other Super Admin accounts.')
                ->withInput();
        }

        $user = User::create([
            'name' => $validated['name'],
            'username' => $validated['username'],
            'email' => $validated['email'],
            'role' => $validated['role'],
            'password' => Hash::make($validated['password']),
        ]);

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Created Staff Account',
            "Created {$user->role} account for {$user->name} (@{$user->username})"
        );

        return redirect()->route('settings.index', ['tab' => 'users'])
            ->with('success', "Account for '{$user->name}' was created successfully.");
    }

    /**
     * Update an existing administrative or officer account.
     */
    public function updateUser(Request $request, User $user): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:50', 'alpha_dash', 'unique:users,username,' . $user->id],
            'email' => ['required', 'email', 'max:255', 'unique:users,email,' . $user->id],
            'role' => ['required', 'in:superadmin,admin,officer'],
            'password' => ['nullable', 'string', 'min:6', 'confirmed'],
        ]);

        $currentUser = Auth::user();
        if ($currentUser && $currentUser->role !== 'superadmin') {
            if ($user->role === 'superadmin' || $validated['role'] === 'superadmin') {
                return redirect()->route('settings.index', ['tab' => 'users'])
                    ->with('error', 'Only Super Administrators can grant or modify Super Admin privileges.');
            }
        }

        if ($user->role === 'superadmin' && $validated['role'] !== 'superadmin') {
            $superadminCount = User::where('role', 'superadmin')->count();
            if ($superadminCount <= 1) {
                return redirect()->route('settings.index', ['tab' => 'users'])
                    ->with('error', 'Cannot demote the system\'s only Super Administrator account.');
            }
        }

        $user->name = $validated['name'];
        $user->username = $validated['username'];
        $user->email = $validated['email'];
        $user->role = $validated['role'];

        if ($request->filled('password')) {
            $user->password = Hash::make($request->password);
        }

        $user->save();

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Updated Staff Account',
            "Updated account details for {$user->name} (@{$user->username})"
        );

        return redirect()->route('settings.index', ['tab' => 'users'])
            ->with('success', "Account for '{$user->name}' was updated successfully.");
    }

    /**
     * Delete an administrative or officer account with security safeguards.
     */
    public function destroyUser(User $user): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        if (Auth::id() === $user->id) {
            return redirect()->route('settings.index', ['tab' => 'users'])
                ->with('error', 'Security Safeguard: You cannot delete your own account while logged in.');
        }

        if ($user->role === 'student') {
            return redirect()->route('settings.index', ['tab' => 'users'])
                ->with('error', 'Student accounts must be managed from the Student Roster, not System Settings.');
        }

        if ($user->role === 'superadmin') {
            $superadminCount = User::where('role', 'superadmin')->count();
            if ($superadminCount <= 1) {
                return redirect()->route('settings.index', ['tab' => 'users'])
                    ->with('error', 'Security Safeguard: Cannot delete the only Super Administrator account in the system.');
            }
        }

        $currentUser = Auth::user();
        if ($currentUser && $currentUser->role !== 'superadmin' && $user->role === 'superadmin') {
            return redirect()->route('settings.index', ['tab' => 'users'])
                ->with('error', 'Only Super Administrators can delete Super Admin accounts.');
        }

        $userName = $user->name;
        $userUsername = $user->username;
        $userRole = $user->role;

        $user->delete();

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Deleted Staff Account',
            "Deleted {$userRole} account for {$userName} (@{$userUsername})"
        );

        return redirect()->route('settings.index', ['tab' => 'users'])
            ->with('success', "Staff account for '{$userName}' has been deleted successfully.");
    }
}
