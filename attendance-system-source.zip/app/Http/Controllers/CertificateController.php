<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventCertificate;
use App\Models\EventEvaluation;
use App\Models\IssuedCertificate;
use App\Models\Student;
use App\Services\EventLifecycleService;
use App\Services\CertificateService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class CertificateController extends Controller
{
    protected CertificateService $certificateService;

    public function __construct(CertificateService $certificateService)
    {
        $this->certificateService = $certificateService;
    }

    /**
     * Admin: Configure certificate template for an event.
     */
    public function edit(Event $event): View
    {
        $user = Auth::user();
        if (! $user || ! in_array($user->role, ['admin', 'superadmin'], true)) {
            abort(403, 'Only administrators can manage certificate templates.');
        }

        $certificate = $event->certificate ?? new EventCertificate([
            'event_id' => $event->id,
            'title' => 'Certificate of Participation',
            'sub_title' => 'is proudly presented to',
            'signatory_name' => 'Campus Executive Director',
            'signatory_title' => 'Pangasinan State University - Alaminos City Campus',
            'name_y_position' => 48,
            'font_size' => 44,
            'font_color' => '#07152d',
            'is_active' => true,
        ]);

        return view('certificates.admin_setup', compact('event', 'certificate'));
    }

    /**
     * Admin: Store / update certificate template and coordinates.
     */
    public function update(Request $request, Event $event): RedirectResponse
    {
        $user = Auth::user();
        if (! $user || ! in_array($user->role, ['admin', 'superadmin'], true)) {
            abort(403, 'Only administrators can manage certificate templates.');
        }

        $validated = $request->validate([
            'template_image' => ['nullable', 'image', 'mimes:jpeg,jpg,png,webp', 'max:5120'],
            'title' => ['required', 'string', 'max:255'],
            'sub_title' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'signatory_name' => ['nullable', 'string', 'max:255'],
            'signatory_title' => ['nullable', 'string', 'max:255'],
            'name_y_position' => ['required', 'integer', 'min:10', 'max:90'],
            'font_size' => ['required', 'integer', 'min:16', 'max:80'],
            'font_color' => ['required', 'string', 'max:20'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $certificate = $event->certificate ?? new EventCertificate(['event_id' => $event->id]);
        $certificate->title = $validated['title'];
        $certificate->sub_title = $validated['sub_title'] ?? 'is proudly presented to';
        $certificate->description = $validated['description'] ?? null;
        $certificate->signatory_name = $validated['signatory_name'] ?? 'Campus Executive Director';
        $certificate->signatory_title = $validated['signatory_title'] ?? 'Pangasinan State University - Alaminos City Campus';
        $certificate->name_y_position = $validated['name_y_position'];
        $certificate->font_size = $validated['font_size'];
        $certificate->font_color = $validated['font_color'];
        $certificate->is_active = $request->boolean('is_active', true);

        $previousTemplatePath = $certificate->template_path;
        if ($request->hasFile('template_image')) {
            $path = $request->file('template_image')->store('certificates/templates', 'public');
            if ($path === false) {
                throw ValidationException::withMessages([
                    'template_image' => 'The uploaded template could not be saved. Please try again.',
                ]);
            }
            $certificate->template_path = $path;
        } elseif ($request->boolean('remove_custom_template')) {
            $certificate->template_path = null;
        }

        $certificate->save();

        if ($previousTemplatePath && $previousTemplatePath !== $certificate->template_path) {
            Storage::disk('public')->delete($previousTemplatePath);
        }

        ActivityLog::log(
            $user->name,
            'Updated Certificate Template',
            "Configured e-certificate template for event '{$event->name}'"
        );

        return redirect()->route('events.certificate.setup', $event)
            ->with('success', 'E-Certificate template & settings saved successfully!');
    }

    /**
     * Admin: Preview certificate with sample student name.
     */
    public function preview(Event $event): Response
    {
        $gdImage = $this->certificateService->renderImage($event, 'JUAN DELA CRUZ', 'PREVIEW-CERT-'.date('Y'));

        ob_start();
        imagepng($gdImage, null, 6, PNG_NO_FILTER);
        $imageData = ob_get_clean();
        imagedestroy($gdImage);

        return response($imageData, 200, [
            'Content-Type' => 'image/png',
            'Cache-Control' => 'no-cache, private',
        ]);
    }

    /**
     * Admin: Download the official Pangasinan State University certificate template.
     */
    public function downloadBlankTemplate(Event $event): Response
    {
        $gdImage = $this->certificateService->renderBlankTemplate($event);

        ob_start();
        imagepng($gdImage, null, 6, PNG_NO_FILTER);
        $imageData = ob_get_clean();
        imagedestroy($gdImage);

        return response($imageData, 200, [
            'Content-Type' => 'image/png',
            'Content-Disposition' => 'attachment; filename="Pangasinan-State-University-Blank-HD-Certificate-Template.png"',
            'Cache-Control' => 'no-cache, private',
        ]);
    }

    /**
     * Admin: View student evaluation results for an event.
     */
    public function evaluations(Event $event): View
    {
        $user = Auth::user();
        abort_unless($user?->isAdmin() || $user?->isOfficer(), 403);
        abort_unless($user->isSuperAdmin() || $event->evaluation_results_visible, 403);

        $evaluations = EventEvaluation::where('event_id', $event->id)
            ->with('student.program')
            ->orderBy('submitted_at', 'desc')
            ->paginate(20);

        $totalEvaluations = EventEvaluation::where('event_id', $event->id)->count();
        $avgContent = round((float) EventEvaluation::where('event_id', $event->id)->avg('rating_content'), 1);
        $avgSpeaker = round((float) EventEvaluation::where('event_id', $event->id)->avg('rating_speaker'), 1);
        $avgVenue = round((float) EventEvaluation::where('event_id', $event->id)->avg('rating_venue'), 1);
        $avgOverall = round((float) EventEvaluation::where('event_id', $event->id)->avg('rating_overall'), 1);

        $issuedCertificatesCount = IssuedCertificate::where('event_id', $event->id)->count();
        $canViewStudentIdentities = $user->isSuperAdmin();

        return view('certificates.evaluations_index', compact(
            'event',
            'evaluations',
            'totalEvaluations',
            'avgContent',
            'avgSpeaker',
            'avgVenue',
            'avgOverall',
            'issuedCertificatesCount',
            'canViewStudentIdentities'
        ));
    }

    /**
     * Student: Show Event Evaluation Form.
     */
    public function showEvaluation(Event $event): View|RedirectResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();
        $event->refresh();

        $student = $this->resolveCurrentStudent();
        if (! $student) {
            return redirect('/')->with('error', 'Student record not found.');
        }

        // Check if already evaluated and has certificate
        $existingCert = IssuedCertificate::where('event_id', $event->id)
            ->where('student_id', $student->id)
            ->first();

        if ($existingCert) {
            return redirect()->route('certificates.show', $existingCert->certificate_code)
                ->with('info', 'You have already completed the evaluation. Here is your official E-Certificate!');
        }

        if (! $this->canEvaluateEvent($event, $student)) {
            return redirect('/')->with('error', $this->evaluationUnavailableMessage($event, $student));
        }

        $alreadyEvaluated = EventEvaluation::where('event_id', $event->id)
            ->where('student_id', $student->id)
            ->exists();

        if ($alreadyEvaluated) {
            $cert = $this->certificateService->issueCertificate($event, $student);

            return redirect()->route('certificates.show', $cert->certificate_code);
        }

        return view('certificates.evaluate', compact('event', 'student'));
    }

    /**
     * Student: Submit Event Evaluation & automatically receive E-Certificate.
     */
    public function submitEvaluation(Request $request, Event $event): RedirectResponse
    {
        app(EventLifecycleService::class)->completeExpiredEvents();
        $event->refresh();

        $student = $this->resolveCurrentStudent();
        if (! $student) {
            return redirect('/')->with('error', 'Student record not found.');
        }

        if (! $this->canEvaluateEvent($event, $student)) {
            return redirect('/')->with('error', $this->evaluationUnavailableMessage($event, $student));
        }

        $validated = $request->validate([
            'rating_content' => ['required', 'integer', 'min:1', 'max:5'],
            'rating_speaker' => ['required', 'integer', 'min:1', 'max:5'],
            'rating_venue' => ['required', 'integer', 'min:1', 'max:5'],
            'rating_overall' => ['required', 'integer', 'min:1', 'max:5'],
            'comments' => ['nullable', 'string', 'max:1000'],
            'suggestions' => ['nullable', 'string', 'max:1000'],
        ]);

        // Record Evaluation
        EventEvaluation::updateOrCreate(
            ['event_id' => $event->id, 'student_id' => $student->id],
            [
                'rating_content' => $validated['rating_content'],
                'rating_speaker' => $validated['rating_speaker'],
                'rating_venue' => $validated['rating_venue'],
                'rating_overall' => $validated['rating_overall'],
                'comments' => $validated['comments'] ?? null,
                'suggestions' => $validated['suggestions'] ?? null,
                'submitted_at' => now(),
            ]
        );

        // Automatically generate & issue certificate with student name
        $certificate = $this->certificateService->issueCertificate($event, $student);

        ActivityLog::log(
            $student->full_name,
            'Submitted Event Evaluation',
            "Evaluated event '{$event->name}' and unlocked E-Certificate [{$certificate->certificate_code}]"
        );

        return redirect()->route('certificates.show', $certificate->certificate_code)
            ->with('success', 'Thank you! Your event evaluation has been submitted and your official E-Certificate is ready below.');
    }

    /**
     * Student/Recipient: View issued E-Certificate.
     */
    public function showCertificate(string $code): View
    {
        $certificate = IssuedCertificate::with(['event.certificate', 'student.program', 'student.organization'])
            ->where('certificate_code', $code)
            ->firstOrFail();

        $event = $certificate->event;
        $student = $certificate->student;
        $config = $event->certificate ?? new EventCertificate([
            'title' => 'Certificate of Participation',
            'sub_title' => 'is proudly presented to',
            'signatory_name' => 'Campus Executive Director',
            'signatory_title' => 'Pangasinan State University - Alaminos City Campus',
            'name_y_position' => 48,
            'font_size' => 44,
            'font_color' => '#07152d',
        ]);

        return view('certificates.show', compact('certificate', 'event', 'student', 'config'));
    }

    /**
     * Download or stream direct PNG rendered with student name.
     */
    public function downloadImage(string $code): Response
    {
        $certificate = IssuedCertificate::with(['event.certificate'])
            ->where('certificate_code', $code)
            ->firstOrFail();

        $gdImage = $this->certificateService->renderImage(
            $certificate->event,
            $certificate->student_name,
            $certificate->certificate_code
        );

        ob_start();
        imagepng($gdImage, null, 6, PNG_NO_FILTER);
        $imageData = ob_get_clean();
        imagedestroy($gdImage);

        return response($imageData, 200, [
            'Content-Type' => 'image/png',
            'Content-Disposition' => 'attachment; filename="Pangasinan-State-University-Certificate-'.$certificate->certificate_code.'.png"',
            'Cache-Control' => 'public, max-age=86400',
        ]);
    }

    /**
     * Public verification endpoint.
     */
    public function verify(string $code): View
    {
        $certificate = IssuedCertificate::with(['event', 'student.program'])
            ->where('certificate_code', $code)
            ->first();

        return view('certificates.verify', compact('certificate', 'code'));
    }

    /**
     * Helper to resolve current student model from session/user.
     */
    protected function resolveCurrentStudent(): ?Student
    {
        $user = Auth::user();
        if (! $user || $user->role !== 'student') {
            return null;
        }

        return Student::where('student_id', $user->username)
            ->orWhere('email', $user->email)
            ->first();
    }

    protected function canEvaluateEvent(Event $event, Student $student): bool
    {
        return $event->status === 'completed'
            && $event->evaluation_enabled
            && Attendance::where('event_id', $event->id)
                ->where('student_id', $student->id)
                ->where('status', 'present')
                ->exists();
    }

    protected function evaluationUnavailableMessage(Event $event, Student $student): string
    {
        if ($event->status !== 'completed' || ! $event->evaluation_enabled) {
            return 'Event evaluation is available only after an administrator marks the event completed and turns it on.';
        }

        return 'Only students marked present for this event can submit an evaluation and receive an e-certificate.';
    }
}
