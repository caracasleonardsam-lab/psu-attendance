<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Organization;
use App\Models\OrganizationOfficer;
use App\Models\Program;
use App\Models\Student;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class OrganizationController extends Controller
{
    public function index(): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $organizations = Organization::withCount('students')->orderBy('name')->get();

        return view('organizations.index', compact('organizations'));
    }

    public function show(Organization $organization): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $organization->load([
            'students' => fn ($query) => $query->with('program')->orderBy('full_name'),
            'officers.student',
        ]);
        $availableStudents = Student::query()
            ->whereNull('organization_id')
            ->orderBy('full_name')
            ->get();

        return view('organizations.show', compact('organization', 'availableStudents'));
    }

    public function storeProgram(Request $request): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:programs,name'],
        ]);

        Program::create($validated);
        ActivityLog::log(Auth::user()?->name ?? 'Admin', 'Created Program', "Added academic program '{$validated['name']}'");

        return back()->with('success', "Program '{$validated['name']}' created successfully.");
    }

    public function destroyProgram(Program $program): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $name = $program->name;
        $program->delete();
        ActivityLog::log(Auth::user()?->name ?? 'Admin', 'Deleted Program', "Deleted program '{$name}'");

        return back()->with('success', "Program '{$name}' deleted.");
    }

    public function storeOrganization(Request $request): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:organizations,name'],
        ]);

        Organization::create($validated);
        ActivityLog::log(Auth::user()?->name ?? 'Admin', 'Created Organization', "Added organization '{$validated['name']}'");

        return back()->with('success', "Organization '{$validated['name']}' created successfully.");
    }

    public function updateOrganization(Request $request, Organization $organization): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:organizations,name,'.$organization->id],
        ]);

        $organization->update($validated);
        ActivityLog::log(Auth::user()?->name ?? 'Admin', 'Updated Organization', "Renamed organization to '{$validated['name']}'");

        return back()->with('success', 'Organization name updated successfully.');
    }

    public function addMember(Request $request, Organization $organization): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'student_id' => ['required', 'integer', 'exists:students,id'],
        ]);

        $student = Student::findOrFail($validated['student_id']);
        if ($student->organization_id !== null) {
            return back()->withErrors([
                'student_id' => 'This student already belongs to an organization. Remove them from that organization before adding them here.',
            ]);
        }

        $student->update(['organization_id' => $organization->id]);
        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Added Organization Member',
            "Added '{$student->full_name}' to '{$organization->name}'."
        );

        return back()->with('success', "{$student->full_name} added to {$organization->name}.");
    }

    public function removeMember(Organization $organization, Student $student): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        abort_unless((int) $student->organization_id === (int) $organization->id, 404);

        DB::transaction(function () use ($organization, $student): void {
            OrganizationOfficer::query()
                ->where('organization_id', $organization->id)
                ->where('student_id', $student->id)
                ->delete();
            $student->update(['organization_id' => null]);
        });

        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Removed Organization Member',
            "Removed '{$student->full_name}' from '{$organization->name}'."
        );

        return back()->with('success', "{$student->full_name} removed from {$organization->name}.");
    }

    public function assignOfficer(Request $request, Organization $organization): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $validated = $request->validate([
            'position' => ['required', 'string', 'max:100'],
            'student_id' => ['required', 'string', 'max:100'],
        ]);
        $student = Student::query()
            ->where('student_id', trim($validated['student_id']))
            ->where('organization_id', $organization->id)
            ->first();

        if (! $student) {
            return back()->withErrors([
                'student_id' => 'Walang member sa organisasyong ito na may ganyang Student ID.',
            ]);
        }

        $officer = OrganizationOfficer::updateOrCreate(
            [
                'organization_id' => $organization->id,
                'position' => trim($validated['position']),
            ],
            ['student_id' => $student->id]
        );
        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Assigned Organization Officer',
            "Assigned '{$student->full_name}' as {$officer->position} of '{$organization->name}'."
        );

        return back()->with('success', "{$student->full_name} assigned as {$officer->position}.");
    }

    public function removeOfficer(Organization $organization, OrganizationOfficer $officer): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        abort_unless((int) $officer->organization_id === (int) $organization->id, 404);

        $position = $officer->position;
        $officer->delete();
        ActivityLog::log(
            Auth::user()?->name ?? 'Admin',
            'Removed Organization Officer',
            "Removed the {$position} officer assignment from '{$organization->name}'."
        );

        return back()->with('success', "{$position} officer assignment removed.");
    }

    public function destroyOrganization(Organization $organization): RedirectResponse
    {
        abort_unless(Auth::user()?->isSuperAdmin(), 403);
        $name = $organization->name;
        $organization->delete();
        ActivityLog::log(Auth::user()?->name ?? 'Admin', 'Deleted Organization', "Deleted organization '{$name}'");

        return back()->with('success', "Organization '{$name}' deleted.");
    }
}
