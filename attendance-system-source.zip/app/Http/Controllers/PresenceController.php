<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Event;
use App\Models\PresenceVerification;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class PresenceController extends Controller
{
    public function index(Request $request): View
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $events = Event::orderBy('event_date', 'desc')->get();
        
        $selectedEventId = $request->input('event_id');
        $selectedEvent = $selectedEventId
            ? $events->firstWhere('id', $selectedEventId)
            : null;

        $verifications = collect();
        $stats = [
            'total' => 0,
            'inside' => 0,
            'outside' => 0,
            'compliance_rate' => 100,
        ];

        if ($selectedEvent) {
            // Ensure default values if null
            if (!$selectedEvent->latitude || !$selectedEvent->longitude) {
                $selectedEvent->latitude = 16.115303;
                $selectedEvent->longitude = 119.967252;
            }
            if (!$selectedEvent->radius_meters) {
                $selectedEvent->radius_meters = 100;
            }

            $verificationsQuery = PresenceVerification::with([
                'student.program',
                'student.organization',
                'student.attendances' => function ($q) use ($selectedEvent) {
                    $q->where('event_id', $selectedEvent->id);
                }
            ])
                ->where('event_id', $selectedEvent->id)
                ->orderBy('verified_at', 'desc');

            $allPings = (clone $verificationsQuery)->get();
            $stats['total'] = $allPings->count();
            $stats['inside'] = $allPings->where('status', 'inside')->count();
            $stats['outside'] = $allPings->where('status', 'outside')->count();
            $stats['compliance_rate'] = $stats['total'] > 0 
                ? round(($stats['inside'] / $stats['total']) * 100, 1) 
                : 100;

            $verifications = $verificationsQuery->paginate(20)->withQueryString();

            // Prepare radar map pings for interactive Leaflet display
            $mapPings = [];
            foreach ($allPings->take(100) as $ping) {
                $lat = null;
                $lng = null;
                if (!empty($ping->notes) && preg_match('/GPS:\s*([-\d\.]+),\s*([-\d\.]+)/', $ping->notes, $matches)) {
                    $lat = (float) $matches[1];
                    $lng = (float) $matches[2];
                } else {
                    $angle = fmod(($ping->id * 137.508), 360) * (pi() / 180);
                    $dist = (float) ($ping->distance_meters ?: 10);
                    $centerLat = (float) $selectedEvent->latitude;
                    $latOffset = ($dist / 111111) * cos($angle);
                    $cosLat = cos(deg2rad($centerLat));
                    $lngOffset = ($dist / (111111 * ($cosLat != 0 ? $cosLat : 1))) * sin($angle);
                    $lat = round($centerLat + $latOffset, 6);
                    $lng = round((float) $selectedEvent->longitude + $lngOffset, 6);
                }

                $att = $ping->student?->attendances->first();

                $mapPings[] = [
                    'id' => $ping->id,
                    'student_name' => $ping->student?->full_name ?? 'Student #' . $ping->student_id,
                    'student_id' => $ping->student?->student_id ?? 'N/A',
                    'program' => $ping->student?->program?->name ?? 'General',
                    'organization' => $ping->student?->organization?->name ?? 'General Student',
                    'status' => $ping->status,
                    'distance_meters' => round((float) $ping->distance_meters, 1),
                    'verified_at' => $ping->verified_at?->format('h:i:s A, M d') ?? '',
                    'has_scanned' => (bool) $att,
                    'scanned_time' => $att?->scanned_at?->format('h:i A') ?? null,
                    'lat' => $lat,
                    'lng' => $lng,
                ];
            }
        } else {
            $mapPings = [];
        }

        return view('presence.index', compact('events', 'selectedEvent', 'verifications', 'stats', 'mapPings'));
    }

    public function updateGeofence(Request $request): RedirectResponse|JsonResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);
        $validated = $request->validate([
            'event_id' => ['required', 'exists:events,id'],
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'radius_meters' => ['required', 'integer', 'min:10', 'max:10000'],
            'presence_verification' => ['nullable'],
            'verification_interval_minutes' => ['nullable', 'integer', 'min:1', 'max:180'],
        ]);

        $event = Event::findOrFail($validated['event_id']);

        $event->latitude = $validated['latitude'];
        $event->longitude = $validated['longitude'];
        $event->radius_meters = $validated['radius_meters'];
        $event->presence_verification = $request->boolean('presence_verification');
        if (!empty($validated['verification_interval_minutes'])) {
            $event->verification_interval_minutes = $validated['verification_interval_minutes'];
        }
        $event->save();

        ActivityLog::log(
            Auth::user()->name ?? 'Administrator',
            'Calibrated Geofence',
            "Updated geofence for event '{$event->name}': Radius set to {$event->radius_meters}m at GPS coordinates ({$event->latitude}, {$event->longitude})"
        );

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => "Geofence radius updated to {$event->radius_meters}m for {$event->name}.",
                'event' => [
                    'id' => $event->id,
                    'name' => $event->name,
                    'latitude' => $event->latitude,
                    'longitude' => $event->longitude,
                    'radius_meters' => $event->radius_meters,
                    'presence_verification' => $event->presence_verification,
                ]
            ]);
        }

        return redirect()
            ->route('presence.index', ['event_id' => $event->id])
            ->with('success', "Geofence perimeter for '{$event->name}' calibrated successfully! Radius set to {$event->radius_meters} meters.");
    }

    public function updateVerification(Request $request, PresenceVerification $presenceVerification): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);

        $validated = $request->validate([
            'status' => ['required', 'in:inside,outside'],
            'distance_meters' => ['required', 'numeric', 'min:0', 'max:20000000'],
            'verified_at' => ['required', 'date'],
            'notes' => ['nullable', 'string', 'max:5000'],
        ]);

        $original = $presenceVerification->only(['status', 'distance_meters', 'verified_at', 'notes']);
        $presenceVerification->update($validated);

        $studentName = $presenceVerification->student?->full_name ?? "Student #{$presenceVerification->student_id}";
        $eventName = $presenceVerification->event?->name ?? "Event #{$presenceVerification->event_id}";

        ActivityLog::log(
            Auth::user()->name ?? 'Administrator',
            'Edited GPS Verification Log',
            sprintf(
                'Updated GPS verification #%d for %s (%s). Status: %s to %s; distance: %sm to %sm; verified time: %s to %s%s.',
                $presenceVerification->id,
                $studentName,
                $eventName,
                $original['status'],
                $presenceVerification->status,
                $original['distance_meters'],
                $presenceVerification->distance_meters,
                $original['verified_at'],
                $presenceVerification->verified_at?->toDateTimeString(),
                $original['notes'] !== $presenceVerification->notes ? '; notes updated' : ''
            )
        );

        return redirect()
            ->route('presence.index', ['event_id' => $presenceVerification->event_id])
            ->with('success', 'GPS verification log updated. Attendance records were not changed.');
    }

    public function destroyVerification(PresenceVerification $presenceVerification): RedirectResponse
    {
        abort_unless(Auth::user()?->isAdmin(), 403);

        $eventId = $presenceVerification->event_id;
        $studentName = $presenceVerification->student?->full_name ?? "Student #{$presenceVerification->student_id}";
        $eventName = $presenceVerification->event?->name ?? "Event #{$eventId}";

        ActivityLog::log(
            Auth::user()->name ?? 'Administrator',
            'Deleted GPS Verification Log',
            sprintf(
                'Deleted GPS verification #%d for %s (%s). Status: %s; distance: %sm; verified time: %s.',
                $presenceVerification->id,
                $studentName,
                $eventName,
                $presenceVerification->status,
                $presenceVerification->distance_meters,
                $presenceVerification->verified_at?->toDateTimeString()
            )
        );

        $presenceVerification->delete();

        return redirect()
            ->route('presence.index', ['event_id' => $eventId])
            ->with('success', 'GPS verification log deleted. Attendance records were not changed.');
    }
}
