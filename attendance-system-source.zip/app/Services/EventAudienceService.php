<?php

namespace App\Services;

use App\Models\Event;
use App\Models\EventEligibility;
use App\Models\EventStudentDesignation;
use App\Models\Student;
use Illuminate\Database\Eloquent\Builder;

class EventAudienceService
{
    public function eligibleStudentsQuery(Event $event): Builder
    {
        $query = Student::query();
        if ($event->organization_id !== null) {
            $query->where('organization_id', $event->organization_id);
        }

        $allRules = EventEligibility::query()->where('event_id', $event->id)->get();
        if ($allRules->isEmpty()) {
            return $query;
        }

        $rules = $allRules->filter(function (EventEligibility $rule) {
            return $rule->program_id !== null
                || $rule->organization_id !== null
                || $rule->year_level !== null;
        });
        $designatedStudentIds = EventStudentDesignation::query()
            ->where('event_id', $event->id)
            ->pluck('student_id');

        if ($rules->isEmpty() && $designatedStudentIds->isEmpty()) {
            return $query->whereRaw('1 = 0');
        }

        return $query->where(function ($eligible) use ($rules, $designatedStudentIds) {
            foreach ($rules as $rule) {
                $eligible->orWhere(function ($ruleQuery) use ($rule) {
                    foreach (['program_id', 'organization_id', 'year_level'] as $field) {
                        if ($rule->{$field} !== null) {
                            $ruleQuery->orWhere($field, $rule->{$field});
                        }
                    }
                });
            }

            if ($designatedStudentIds->isNotEmpty()) {
                $eligible->orWhereIn('id', $designatedStudentIds);
            }
        });
    }
}
