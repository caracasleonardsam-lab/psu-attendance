<?php

namespace App\Services;

use App\Models\Event;
use App\Models\EventCertificate;
use App\Models\IssuedCertificate;
use App\Models\Student;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class CertificateService
{
    /**
     * Issue a certificate for a student attending an event.
     */
    public function issueCertificate(Event $event, Student $student): IssuedCertificate
    {
        $existing = IssuedCertificate::where('event_id', $event->id)
            ->where('student_id', $student->id)
            ->first();

        if ($existing) {
            return $existing;
        }

        $code = 'PSU-' . strtoupper(Str::random(4)) . '-' . date('Y') . '-' . str_pad((string)$student->id, 4, '0', STR_PAD_LEFT);

        return IssuedCertificate::create([
            'certificate_code' => $code,
            'event_id' => $event->id,
            'student_id' => $student->id,
            'student_name' => $student->full_name,
            'issued_at' => now(),
        ]);
    }

    /**
     * Generate GD Image for an issued certificate or preview.
     * Automatically adjusts the template image (proportional cover, no distortion)
     * and intelligently enhances text readability (contrast halo, auto font-scale, text strictly in front).
     */
    /**
     * Generate GD Image for an issued certificate or preview.
     * Preserves 100% native resolution for HD templates (no downsampling blur)
     * and guarantees sharp, high-contrast readable text strictly in front.
     */
    public function renderImage(Event $event, string $studentName, ?string $certificateCode = null)
    {
        $config = $event->certificate ?? new EventCertificate([
            'title' => 'Certificate of Participation',
            'sub_title' => 'is proudly presented to',
            'signatory_name' => 'Campus Executive Director',
            'signatory_title' => 'Pangasinan State University - Alaminos City Campus',
            'name_y_position' => 48,
            'font_size' => 48,
            'font_color' => '#07152d',
        ]);

        // Default Ultra-High-Definition A4 Landscape canvas (1920x1358)
        $width = 1920;
        $height = 1358;

        $templatePath = $config->template_path ? storage_path('app/public/' . $config->template_path) : null;
        $image = null;
        $hasCustomTemplate = false;

        if ($templatePath && file_exists($templatePath)) {
            $info = @getimagesize($templatePath);
            $mime = $info['mime'] ?? '';
            $src = null;

            if ($mime === 'image/jpeg' || $mime === 'image/jpg') {
                $src = @imagecreatefromjpeg($templatePath);
            } elseif ($mime === 'image/png') {
                $src = @imagecreatefrompng($templatePath);
            } elseif ($mime === 'image/webp') {
                $src = @imagecreatefromwebp($templatePath);
            }

            if (!empty($src)) {
                $srcW = imagesx($src);
                $srcH = imagesy($src);

                // If uploaded template is already High Definition (>= 1200px width),
                // use 100% NATIVE RESOLUTION directly! Zero resampling, zero blur, zero pixel loss!
                if ($srcW >= 1200 && $srcH >= 600) {
                    $width = $srcW;
                    $height = $srcH;
                    $image = imagecreatetruecolor($width, $height);
                    imagealphablending($image, false);
                    imagesavealpha($image, true);
                    $white = imagecolorallocate($image, 255, 255, 255);
                    imagefilledrectangle($image, 0, 0, $width, $height, $white);
                    imagealphablending($image, true);
                    imagecopy($image, $src, 0, 0, 0, 0, $width, $height);
                } else {
                    // Lower resolution / thumbnail uploaded: upscale proportionally to standard HD width
                    $aspect = $srcW / max(1, $srcH);
                    $width = max(1920, $srcW);
                    $height = (int) round($width / $aspect);

                    $image = imagecreatetruecolor($width, $height);
                    imagealphablending($image, false);
                    imagesavealpha($image, true);
                    $white = imagecolorallocate($image, 255, 255, 255);
                    imagefilledrectangle($image, 0, 0, $width, $height, $white);
                    imagealphablending($image, true);

                    // High-quality bicubic resample
                    imagecopyresampled($image, $src, 0, 0, 0, 0, $width, $height, $srcW, $srcH);

                    // Apply edge sharpening convolution matrix to counter upscaling softness
                    $sharpenMatrix = [
                        [ 0, -1,  0],
                        [-1,  5, -1],
                        [ 0, -1,  0],
                    ];
                    @imageconvolution($image, $sharpenMatrix, 1, 0);
                }

                imagedestroy($src);
                $hasCustomTemplate = true;
            }
        }

        // Fallback to official PSU template if no template was uploaded
        if (!$image) {
            $image = $this->createDefaultTemplate($width, $height, $event, $config);
        }

        imagealphablending($image, true);
        imagesavealpha($image, true);
        if (function_exists('imageantialias')) {
            @imageantialias($image, true);
        }

        // Relative scaling factor based on 1920px standard width
        $scale = $width / 1920.0;

        // 1. Intelligent Luminance & Background Contrast Detection
        $sampleY = (int) (($height * ($config->name_y_position ?: 48)) / 100);
        $sampleLum = $this->calculateAreaLuminance($image, (int)($width * 0.2), max(50, $sampleY - (int)(80 * $scale)), (int)($width * 0.6), (int)(160 * $scale));
        $isDarkBackground = ($sampleLum < 128);

        // 2. Parse Font Color & Auto-Optimize for Guaranteed Readability
        $hex = ltrim($config->font_color ?: '#07152d', '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        }
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        $configuredLum = (0.299 * $r) + (0.587 * $g) + (0.114 * $b);

        // If user's font color conflicts with background luminance, auto-adjust to readable shade
        if ($isDarkBackground && $configuredLum < 100) {
            $r = 251; $g = 191; $b = 36; // Warm gold for dark background
        } elseif (!$isDarkBackground && $configuredLum > 210) {
            $r = 7; $g = 21; $b = 45; // Deep navy for light background
        }

        $nameColor = imagecolorallocate($image, $r, $g, $b);

        // Color definitions
        $navy = imagecolorallocate($image, 7, 21, 45);
        $royalBlue = imagecolorallocate($image, 18, 89, 195);
        $gold = imagecolorallocate($image, 217, 119, 6);
        $slate = imagecolorallocate($image, 71, 85, 105);

        // Crisp Anti-Aliased Text Shadow/Halo (hugs letters tightly, no blurry rectangle scrim!)
        $textHaloColor = $isDarkBackground 
            ? imagecolorallocatealpha($image, 7, 21, 45, 40)
            : imagecolorallocatealpha($image, 255, 255, 255, 30);

        // Resolve TTF fonts
        $boldFont = $this->resolveFont(['georgiab.ttf', 'timesbd.ttf', 'arialbd.ttf', 'georgia.ttf', 'times.ttf', 'arial.ttf']);
        $regularFont = $this->resolveFont(['georgia.ttf', 'times.ttf', 'arial.ttf']);

        // 3. Render All Text Elements - ALWAYS STRICTLY IN FRONT
        
        // A. If custom template: render Title and Subtitle at top if present
        if ($hasCustomTemplate && $boldFont && $regularFont) {
            // Certificate Title
            $titleText = strtoupper($config->title ?: 'CERTIFICATE OF PARTICIPATION');
            $titleSize = (int) round(32 * $scale);
            $bTitle = imagettfbbox($titleSize, 0, $boldFont, $titleText);
            $wTitle = abs($bTitle[4] - $bTitle[0]);
            $titleY = max((int)(140 * $scale), (int)($sampleY * 0.45));
            $this->drawTextWithHalo($image, $titleSize, 0, (int)(($width - $wTitle)/2), $titleY, $royalBlue, $textHaloColor, $boldFont, $titleText, max(1, (int)(2 * $scale)));

            // Subtitle
            $subText = $config->sub_title ?: 'is proudly presented to';
            $subSize = (int) round(18 * $scale);
            $bSub = imagettfbbox($subSize, 0, $regularFont, $subText);
            $wSub = abs($bSub[4] - $bSub[0]);
            $subY = $titleY + (int) round(48 * $scale);
            $this->drawTextWithHalo($image, $subSize, 0, (int)(($width - $wSub)/2), $subY, $slate, $textHaloColor, $regularFont, $subText, max(1, (int)(2 * $scale)));
        }

        // B. Student Name (Dynamic Auto-Fit Font Size & Scaled Proportionally)
        $nameText = strtoupper(trim($studentName));
        $baseFontSize = (int) ($config->font_size ?: 48);
        $fontSize = (int) round($baseFontSize * $scale);
        $maxNameWidth = (int) ($width * 0.78);
        $yPercent = (int) ($config->name_y_position ?: 48);
        $nameY = (int) (($height * $yPercent) / 100);

        if ($boldFont) {
            // Automatically downscale font size if name is very long so it fits gracefully
            do {
                $bbox = imagettfbbox($fontSize, 0, $boldFont, $nameText);
                $nameWidth = abs($bbox[4] - $bbox[0]);
                if ($nameWidth > $maxNameWidth && $fontSize > (int)(20 * $scale)) {
                    $fontSize -= max(1, (int)(2 * $scale));
                } else {
                    break;
                }
            } while ($fontSize > (int)(20 * $scale));

            $nameX = (int) (($width - $nameWidth) / 2);

            // Draw student name with anti-aliased high-contrast halo in front
            $haloRadius = max(2, (int) round(3 * $scale));
            $this->drawTextWithHalo($image, $fontSize, 0, $nameX, $nameY, $nameColor, $textHaloColor, $boldFont, $nameText, $haloRadius);

            // Elegant Underline Accent Bar
            $lineY = $nameY + (int) round(20 * $scale);
            $lineWidth = min((int)($width * 0.8), max($nameWidth + (int)(100 * $scale), (int)(550 * $scale)));
            $lineX1 = (int) (($width - $lineWidth) / 2);
            $lineX2 = $lineX1 + $lineWidth;
            $lineH = max(2, (int) round(4 * $scale));
            imagefilledrectangle($image, $lineX1, $lineY, $lineX2, $lineY + $lineH, $gold);

            // C. Event Citation Description
            $descLine1 = 'for outstanding participation and valuable contribution during the university activity';
            $eventName = '"' . strtoupper($event->name) . '"';
            $eventDateStr = $event->event_date ? $event->event_date->format('F d, Y') : date('F d, Y');
            $venueDate = 'Held at ' . ($event->venue ?: 'Pangasinan State University - Alaminos Campus') . ' on ' . $eventDateStr . '.';

            $descY = $lineY + (int) round(48 * $scale);
            $descSize = (int) round(16 * $scale);
            $bDesc1 = imagettfbbox($descSize, 0, $regularFont ?: $boldFont, $descLine1);
            $this->drawTextWithHalo($image, $descSize, 0, (int)(($width - abs($bDesc1[4]-$bDesc1[0]))/2), $descY, $slate, $textHaloColor, $regularFont ?: $boldFont, $descLine1, max(1, (int)(2 * $scale)));

            $evY = $descY + (int) round(44 * $scale);
            $evSize = (int) round(22 * $scale);
            $bEv = imagettfbbox($evSize, 0, $boldFont, $eventName);
            $this->drawTextWithHalo($image, $evSize, 0, (int)(($width - abs($bEv[4]-$bEv[0]))/2), $evY, $navy, $textHaloColor, $boldFont, $eventName, max(1, (int)(2 * $scale)));

            $vdY = $evY + (int) round(38 * $scale);
            $vdSize = (int) round(15 * $scale);
            $bVD = imagettfbbox($vdSize, 0, $regularFont ?: $boldFont, $venueDate);
            $this->drawTextWithHalo($image, $vdSize, 0, (int)(($width - abs($bVD[4]-$bVD[0]))/2), $vdY, $slate, $textHaloColor, $regularFont ?: $boldFont, $venueDate, max(1, (int)(2 * $scale)));

            // D. Signatories Section in Front
            $sigY = $height - (int) round(170 * $scale);
            $signName = $config->signatory_name ?: 'Campus Executive Director';
            $signTitle = $config->signatory_title ?: 'Pangasinan State University';
            $orgName = $event->organizer ?: 'Event Committee Chair';

            $sigLineWidth = (int) round(360 * $scale);
            $sigLineThickness = max(2, (int) round(2 * $scale));
            $sigFontSize = (int) round(15 * $scale);
            $sigSubSize = (int) round(12 * $scale);

            // Left: Organizing Committee
            $leftX = (int) round(160 * $scale);
            imagefilledrectangle($image, $leftX, $sigY - (int)(28 * $scale), $leftX + $sigLineWidth, $sigY - (int)(28 * $scale) + $sigLineThickness, $navy);
            $bOrg = imagettfbbox($sigFontSize, 0, $boldFont, $orgName);
            $this->drawTextWithHalo($image, $sigFontSize, 0, $leftX + (int)(($sigLineWidth - abs($bOrg[4]-$bOrg[0]))/2), $sigY, $navy, $textHaloColor, $boldFont, $orgName, max(1, (int)(2 * $scale)));
            $bOrgSub = imagettfbbox($sigSubSize, 0, $regularFont, 'Event Organizing Committee');
            $this->drawTextWithHalo($image, $sigSubSize, 0, $leftX + (int)(($sigLineWidth - abs($bOrgSub[4]-$bOrgSub[0]))/2), $sigY + (int)(26 * $scale), $slate, $textHaloColor, $regularFont, 'Event Organizing Committee', max(1, (int)(2 * $scale)));

            // Right: Campus Executive Director
            $rightX = $width - (int) round(160 * $scale) - $sigLineWidth;
            imagefilledrectangle($image, $rightX, $sigY - (int)(28 * $scale), $rightX + $sigLineWidth, $sigY - (int)(28 * $scale) + $sigLineThickness, $navy);
            $bSig = imagettfbbox($sigFontSize, 0, $boldFont, $signName);
            $this->drawTextWithHalo($image, $sigFontSize, 0, $rightX + (int)(($sigLineWidth - abs($bSig[4]-$bSig[0]))/2), $sigY, $navy, $textHaloColor, $boldFont, $signName, max(1, (int)(2 * $scale)));
            $bSigSub = imagettfbbox($sigSubSize, 0, $regularFont, $signTitle);
            $this->drawTextWithHalo($image, $sigSubSize, 0, $rightX + (int)(($sigLineWidth - abs($bSigSub[4]-$bSigSub[0]))/2), $sigY + (int)(26 * $scale), $slate, $textHaloColor, $regularFont, $signTitle, max(1, (int)(2 * $scale)));

        } else {
            // Built-in GD font fallback
            $nameX = (int) (($width - (strlen($nameText) * 14)) / 2);
            imagestring($image, 5, $nameX, $nameY - 20, $nameText, $nameColor);
        }

        // E. Security Verification Code & Issue Date at Bottom
        $code = $certificateCode ?: ('PREVIEW-CERT-' . date('Y'));
        $dateText = 'Issued on: ' . ($event->event_date ? $event->event_date->format('F d, Y') : date('F d, Y'));
        $verifyText = 'Digital Verification Serial: ' . $code;
        $footSize = (int) round(12 * $scale);
        $footX = (int) round(120 * $scale);

        if ($regularFont) {
            $this->drawTextWithHalo($image, $footSize, 0, $footX, $height - (int)(75 * $scale), $slate, $textHaloColor, $regularFont, $dateText, max(1, (int)(2 * $scale)));
            $this->drawTextWithHalo($image, $footSize, 0, $footX, $height - (int)(50 * $scale), $slate, $textHaloColor, $regularFont, $verifyText, max(1, (int)(2 * $scale)));
        } else {
            imagestring($image, 3, $footX, $height - (int)(75 * $scale), $dateText, $slate);
            imagestring($image, 3, $footX, $height - (int)(50 * $scale), $verifyText, $slate);
        }

        return $image;
    }

    /**
     * Render a blank high-definition PSU template (without student name/stamps) for download.
     */
    public function renderBlankTemplate(Event $event)
    {
        $config = $event->certificate ?? new EventCertificate();
        $width = 1920;
        $height = 1358;
        return $this->createDefaultTemplate($width, $height, $event, $config);
    }

    /**
     * Draw text with multi-directional halo / shadow so all text is 100% readable in front of any background.
     */
    protected function drawTextWithHalo($image, int $fontSize, int $angle, int $x, int $y, int $textColor, int $haloColor, string $font, string $text, int $radius = 2)
    {
        // Render halo offsets
        for ($dx = -$radius; $dx <= $radius; $dx++) {
            for ($dy = -$radius; $dy <= $radius; $dy++) {
                if ($dx !== 0 || $dy !== 0) {
                    imagettftext($image, $fontSize, $angle, $x + $dx, $y + $dy, $haloColor, $font, $text);
                }
            }
        }

        // Render main text on top
        imagettftext($image, $fontSize, $angle, $x, $y, $textColor, $font, $text);
    }

    /**
     * Compute average luminance of a specific image area to determine contrast.
     */
    protected function calculateAreaLuminance($image, int $x, int $y, int $w, int $h): float
    {
        $step = 12; // Sample interval for fast computation
        $total = 0;
        $count = 0;
        $maxX = min(imagesx($image), $x + $w);
        $maxY = min(imagesy($image), $y + $h);

        for ($py = max(0, $y); $py < $maxY; $py += $step) {
            for ($px = max(0, $x); $px < $maxX; $px += $step) {
                $rgb = imagecolorat($image, $px, $py);
                $r = ($rgb >> 16) & 0xFF;
                $g = ($rgb >> 8) & 0xFF;
                $b = $rgb & 0xFF;
                $lum = (0.299 * $r) + (0.587 * $g) + (0.114 * $b);
                $total += $lum;
                $count++;
            }
        }

        return $count > 0 ? ($total / $count) : 255.0;
    }

    /**
     * Create an elegant, high-resolution default PSU certificate background with official seal.
     */
    protected function createDefaultTemplate(int $width, int $height, Event $event, EventCertificate $config)
    {
        $im = imagecreatetruecolor($width, $height);
        imagealphablending($im, false);
        imagesavealpha($im, true);

        $bg = imagecolorallocate($im, 255, 255, 255);
        $navy = imagecolorallocate($im, 7, 21, 45);
        $royalBlue = imagecolorallocate($im, 18, 89, 195);
        $gold = imagecolorallocate($im, 217, 119, 6);
        $slate = imagecolorallocate($im, 71, 85, 105);

        // Fill clean white background
        imagefilledrectangle($im, 0, 0, $width, $height, $bg);
        imagealphablending($im, true);

        // Elegant navy borders
        imagefilledrectangle($im, 28, 28, $width - 28, 48, $navy);
        imagefilledrectangle($im, 28, $height - 48, $width - 28, $height - 28, $navy);
        imagefilledrectangle($im, 28, 28, 48, $height - 28, $navy);
        imagefilledrectangle($im, $width - 48, 28, $width - 28, $height - 28, $navy);

        // Inner gold border
        for ($i = 0; $i < 5; $i++) {
            imagerectangle($im, 56 + $i, 56 + $i, $width - 56 - $i, $height - 56 - $i, $gold);
        }

        // Corner accents
        imagefilledrectangle($im, 48, 48, 85, 85, $gold);
        imagefilledrectangle($im, $width - 85, 48, $width - 48, 85, $gold);
        imagefilledrectangle($im, 48, $height - 85, 85, $height - 48, $gold);
        imagefilledrectangle($im, $width - 85, $height - 85, $width - 48, $height - 48, $gold);

        // Stamp Transparent Official PSU Logo at top center if available
        $logoPath = public_path('images/logo.png');
        if (file_exists($logoPath)) {
            $logo = @imagecreatefrompng($logoPath);
            if ($logo) {
                $lw = imagesx($logo);
                $lh = imagesy($logo);
                $targetH = 100;
                $targetW = (int) round($lw * ($targetH / $lh));
                imagealphablending($im, true);
                imagecopyresampled($im, $logo, (int)(($width - $targetW) / 2), 65, 0, 0, $targetW, $targetH, $lw, $lh);
                imagedestroy($logo);
            }
        }

        $boldFont = $this->resolveFont(['georgiab.ttf', 'timesbd.ttf', 'arialbd.ttf']);
        $regularFont = $this->resolveFont(['georgia.ttf', 'times.ttf', 'arial.ttf']);

        // Institution Header
        $univ = 'PANGASINAN STATE UNIVERSITY';
        $campus = 'ALAMINOS CITY CAMPUS • CITY OF ALAMINOS, PANGASINAN';

        if ($boldFont && $regularFont) {
            $b1 = imagettfbbox(24, 0, $boldFont, $univ);
            $w1 = abs($b1[4] - $b1[0]);
            imagettftext($im, 24, 0, (int)(($width - $w1)/2), 195, $navy, $boldFont, $univ);

            $b2 = imagettfbbox(13, 0, $regularFont, $campus);
            $w2 = abs($b2[4] - $b2[0]);
            imagettftext($im, 13, 0, (int)(($width - $w2)/2), 230, $slate, $regularFont, $campus);
        }

        return $im;
    }

    /**
     * Resolve font path from candidate list.
     */
    protected function resolveFont(array $candidates): ?string
    {
        $dirs = [
            'C:/Windows/Fonts/',
            'C:\\Windows\\Fonts\\',
            public_path('fonts/'),
        ];

        foreach ($candidates as $cand) {
            foreach ($dirs as $dir) {
                $path = $dir . $cand;
                if (file_exists($path)) {
                    return $path;
                }
            }
        }

        return null;
    }
}
