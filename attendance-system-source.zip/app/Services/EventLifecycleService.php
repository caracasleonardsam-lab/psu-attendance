<?php

namespace App\Services;

use App\Models\ActivityLog;
use App\Models\Attendance;
use App\Models\Event;
use App\Models\EventQueueEntry;
use App\Models\SystemSetting;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class EventLifecycleService
{
    public function completeExpiredEvents(): int
    {
        $now = now();
        $this->startScheduledEvents($now);
        $expiredCount = 0;

        $events = Event::query()
            ->whereIn('status', ['active', 'scheduled'])
            ->whereNotNull('event_date')
            ->whereNotNull('end_time')
            ->whereDate('event_date', '<=', $now->toDateString())
            ->get();

        foreach ($events as $event) {
            $eventDate = $event->event_date->format('Y-m-d');
            $endsAt = Carbon::parse("{$eventDate} {$event->end_time}", $now->timezone);

            if ($event->start_time && $event->end_time < $event->start_time) {
                $endsAt->addDay();
            }

            if ($endsAt->isAfter($now)) {
                continue;
            }

            if ($this->completeEvent($event, $endsAt)) {
                $expiredCount++;
            }
        }

        return $expiredCount;
    }

    private function startScheduledEvents(Carbon $now): int
    {
        $startedCount = 0;
        $events = Event::query()
            ->where('status', 'scheduled')
            ->whereNotNull('event_date')
            ->whereNotNull('start_time')
            ->whereDate('event_date', '<=', $now->toDateString())
            ->get();

        foreach ($events as $event) {
            $eventDate = $event->event_date->format('Y-m-d');
            $startsAt = Carbon::parse("{$eventDate} {$event->start_time}", $now->timezone);
            if ($startsAt->isAfter($now)) {
                continue;
            }

            if ($event->end_time) {
                $endsAt = Carbon::parse("{$eventDate} {$event->end_time}", $now->timezone);
                if ($event->end_time < $event->start_time) {
                    $endsAt->addDay();
                }
                if (! $endsAt->isAfter($now)) {
                    continue;
                }
            }

            $started = Event::query()
                ->whereKey($event->id)
                ->where('status', 'scheduled')
                ->update([
                    'status' => 'active',
                    'scanning_enabled' => true,
                    'updated_at' => $now,
                ]);
            if ($started !== 1) {
                continue;
            }

            ActivityLog::log(
                'System',
                'Event Scanning Started',
                "Automatically started scanning for '{$event->name}' at its scheduled start time."
            );
            $startedCount++;
        }

        return $startedCount;
    }

    public function completeEvent(Event $event, ?Carbon $completedAt = null, bool $logActivity = true): bool
    {
        $completedAt ??= now();

        $checkout = DB::transaction(function () use ($event, $completedAt): ?array {
            $updated = Event::query()
                ->whereKey($event->id)
                ->whereIn('status', ['active', 'scheduled'])
                ->update([
                    'status' => 'completed',
                    'scanning_enabled' => false,
                    'evaluation_enabled' => true,
                    'updated_at' => $completedAt,
                ]);

            if ($updated !== 1) {
                return null;
            }

            EventQueueEntry::query()
                ->where('event_id', $event->id)
                ->whereNull('invalidated_at')
                ->update(['invalidated_at' => $completedAt]);

            if (SystemSetting::get('auto_checkout_enabled', '1') !== '1') {
                return ['count' => 0, 'enabled' => false];
            }

            $attendances = Attendance::query()
                ->where('event_id', $event->id)
                ->where(function ($query) {
                    $query->whereNull('notes')
                        ->orWhere('notes', 'not like', '%Checked out%');
                })
                ->get();

            foreach ($attendances as $attendance) {
                $attendance->notes = trim(
                    ($attendance->notes ? $attendance->notes.' | ' : '')
                    .'Checked out automatically at '.$completedAt->format('h:i:s A')
                );
                $attendance->save();
            }

            return ['count' => $attendances->count(), 'enabled' => true];
        });

        if ($checkout === null) {
            return false;
        }

        if ($logActivity) {
            $checkoutDetails = $checkout['enabled']
                ? "checked out {$checkout['count']} attendance record(s)"
                : 'automatic checkout is disabled';
            ActivityLog::log(
                'System',
                'Event Completed',
                "Automatically completed event '{$event->name}'; {$checkoutDetails}."
            );
        }

        return true;
    }
}
