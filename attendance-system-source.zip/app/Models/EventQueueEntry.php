<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EventQueueEntry extends Model
{
    protected $fillable = [
        'event_id',
        'student_id',
        'entered_at',
        'latitude',
        'longitude',
        'accuracy_meters',
        'distance_meters',
        'checked_in_at',
        'invalidated_at',
    ];

    protected $casts = [
        'entered_at' => 'datetime',
        'checked_in_at' => 'datetime',
        'invalidated_at' => 'datetime',
        'latitude' => 'float',
        'longitude' => 'float',
        'accuracy_meters' => 'float',
        'distance_meters' => 'float',
    ];

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class);
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }
}
