<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Student extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'student_id',
        'full_name',
        'program_id',
        'organization_id',
        'year_level',
        'block',
        'email',
        'phone',
    ];

    public static function normalizeAcademicDetails(?string $yearLevel, ?string $block): array
    {
        $yearNames = [
            '1' => 'First Year',
            '2' => 'Second Year',
            '3' => 'Third Year',
            '4' => 'Fourth Year',
            '5' => 'Fifth Year',
            '6' => 'Sixth Year',
        ];

        $yearLevel = trim((string) $yearLevel);
        $block = trim((string) $block);

        if (preg_match('/^([1-6])\s*[- ]?\s*([a-z])$/i', $yearLevel, $matches)) {
            $yearLevel = $yearNames[$matches[1]];
            $block = $block !== '' ? $block : $matches[2];
        } elseif (preg_match('/^([1-6])\s*[- ]?\s*([a-z])$/i', $block, $matches)) {
            $yearLevel = $yearLevel !== '' ? $yearLevel : $yearNames[$matches[1]];
            $block = $matches[2];
        } elseif (isset($yearNames[$yearLevel])) {
            $yearLevel = $yearNames[$yearLevel];
        } else {
            foreach ($yearNames as $yearName) {
                if (strcasecmp($yearLevel, $yearName) === 0) {
                    $yearLevel = $yearName;
                    break;
                }
            }
        }

        $block = preg_replace('/^block\s*/i', '', $block);

        return [
            'year_level' => $yearLevel !== '' ? $yearLevel : null,
            'block' => $block !== '' ? strtoupper($block) : null,
        ];
    }

    public function program(): BelongsTo
    {
        return $this->belongsTo(Program::class);
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function attendances(): HasMany
    {
        return $this->hasMany(Attendance::class);
    }

    public function presenceVerifications(): HasMany
    {
        return $this->hasMany(PresenceVerification::class);
    }

    public function evaluations(): HasMany
    {
        return $this->hasMany(EventEvaluation::class);
    }

    public function issuedCertificates(): HasMany
    {
        return $this->hasMany(IssuedCertificate::class);
    }
}
