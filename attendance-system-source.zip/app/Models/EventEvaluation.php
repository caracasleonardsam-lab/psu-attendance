<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EventEvaluation extends Model
{
    use HasFactory;

    protected $fillable = [
        'event_id',
        'student_id',
        'rating_content',
        'rating_speaker',
        'rating_venue',
        'rating_overall',
        'comments',
        'suggestions',
        'submitted_at',
    ];

    protected $casts = [
        'rating_content' => 'integer',
        'rating_speaker' => 'integer',
        'rating_venue' => 'integer',
        'rating_overall' => 'integer',
        'submitted_at' => 'datetime',
    ];

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class);
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class)->withTrashed();
    }

    public function averageRating(): float
    {
        $sum = $this->rating_content + $this->rating_speaker + $this->rating_venue + $this->rating_overall;
        return round($sum / 4, 1);
    }
}
