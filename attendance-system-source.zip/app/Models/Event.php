<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Event extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'event_date',
        'start_time',
        'end_time',
        'venue',
        'organizer',
        'organization_id',
        'attendance_mode',
        'status',
        'scanning_enabled',
        'latitude',
        'longitude',
        'radius_meters',
        'presence_verification',
        'verification_interval_minutes',
        'minimum_required_presence',
        'require_checkout',
        'evaluation_enabled',
        'evaluation_results_visible',
        'created_by',
    ];

    protected $casts = [
        'event_date' => 'date',
        'organization_id' => 'integer',
        'latitude' => 'float',
        'longitude' => 'float',
        'radius_meters' => 'integer',
        'presence_verification' => 'boolean',
        'verification_interval_minutes' => 'integer',
        'minimum_required_presence' => 'integer',
        'require_checkout' => 'boolean',
        'evaluation_enabled' => 'boolean',
        'evaluation_results_visible' => 'boolean',
        'scanning_enabled' => 'boolean',
    ];

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function attendances(): HasMany
    {
        return $this->hasMany(Attendance::class);
    }

    public function studentDesignations(): HasMany
    {
        return $this->hasMany(EventStudentDesignation::class);
    }

    public function eligibilities(): HasMany
    {
        return $this->hasMany(EventEligibility::class);
    }

    public function geofences(): HasMany
    {
        return $this->hasMany(EventGeofence::class);
    }

    public function presenceVerifications(): HasMany
    {
        return $this->hasMany(PresenceVerification::class);
    }

    public function certificate(): HasOne
    {
        return $this->hasOne(EventCertificate::class);
    }

    public function evaluations(): HasMany
    {
        return $this->hasMany(EventEvaluation::class);
    }

    public function issuedCertificates(): HasMany
    {
        return $this->hasMany(IssuedCertificate::class);
    }

}
