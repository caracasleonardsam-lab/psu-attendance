<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EventCertificate extends Model
{
    use HasFactory;

    protected $fillable = [
        'event_id',
        'template_path',
        'title',
        'sub_title',
        'description',
        'signatory_name',
        'signatory_title',
        'name_y_position',
        'font_size',
        'font_color',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'name_y_position' => 'integer',
        'font_size' => 'integer',
    ];

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class);
    }
}
