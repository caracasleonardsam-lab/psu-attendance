<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SystemSetting extends Model
{
    use HasFactory;

    protected $fillable = [
        'key_name',
        'value_text',
    ];

    public static function get(string $key, ?string $default = null): ?string
    {
        $setting = self::where('key_name', $key)->first();
        return $setting ? $setting->value_text : $default;
    }

    public static function set(string $key, ?string $value): void
    {
        self::updateOrCreate(
            ['key_name' => $key],
            ['value_text' => $value]
        );
    }
}
