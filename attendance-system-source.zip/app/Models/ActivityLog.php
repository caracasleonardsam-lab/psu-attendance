<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'actor',
        'action',
        'details',
    ];

    public static function log(string $actor, string $action, ?string $details = null): self
    {
        return self::create([
            'actor' => $actor,
            'action' => $action,
            'details' => $details,
        ]);
    }
}
