<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class EvaluationQuestion extends Model
{
    protected $fillable = [
        'evaluation_form_id',
        'question_text',
        'question_type',
        'is_required',
        'position',
    ];

    protected $casts = ['is_required' => 'boolean'];

    public function form(): BelongsTo
    {
        return $this->belongsTo(EvaluationForm::class, 'evaluation_form_id');
    }

    public function options(): HasMany
    {
        return $this->hasMany(EvaluationOption::class)->orderBy('position');
    }
}
