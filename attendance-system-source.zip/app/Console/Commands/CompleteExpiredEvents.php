<?php

namespace App\Console\Commands;

use App\Services\EventLifecycleService;
use Illuminate\Console\Command;

class CompleteExpiredEvents extends Command
{
    protected $signature = 'events:complete-expired';

    protected $description = 'Start events at their scheduled time and complete them after their end time';

    public function handle(EventLifecycleService $eventLifecycle): int
    {
        $completedCount = $eventLifecycle->completeExpiredEvents();

        $this->info("Completed {$completedCount} expired event(s).");

        return self::SUCCESS;
    }
}
