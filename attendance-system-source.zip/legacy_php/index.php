<?php
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL & ~E_DEPRECATED & ~E_WARNING);

session_set_cookie_params([
    'lifetime' => 1800,
    'path' => '/',
    'secure' => (!empty($_SERVER['HTTPS']) || (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443')),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedToken = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', (string) $submittedToken)) {
        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Your session has expired or the request is invalid. Please try again.'];
        $safePage = isset($_GET['page']) && is_string($_GET['page']) ? preg_replace('/[^a-zA-Z0-9_\-]/', '', $_GET['page']) : 'login';
        header('Location: ?page=' . $safePage);
        exit;
    }
}

if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > 1800) {
    session_destroy();
    header('Location: ?page=login');
    exit;
}
$_SESSION['last_activity'] = time();

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

initializeDatabase();

$db = getDatabaseConnection();

$superadminRows = $db->query('SELECT id, username, full_name FROM users WHERE role = "superadmin" ORDER BY id ASC')->fetchAll();
if (count($superadminRows) > 1) {
    $keepId = (int) ($superadminRows[0]['id'] ?? 0);
    foreach ($superadminRows as $row) {
        $rowId = (int) ($row['id'] ?? 0);
        if ($rowId > 0 && $rowId !== $keepId) {
            $db->prepare('DELETE FROM users WHERE id = :id AND role = "superadmin"')->execute([':id' => $rowId]);
        }
    }
}

if (isset($_GET['page']) && $_GET['page'] === 'logout') {
    session_destroy();
    redirect('?page=login');
}

if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $db->prepare('SELECT * FROM users WHERE username = :username LIMIT 1');
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'full_name' => $user['full_name'],
            'role' => $user['role'],
        ];
        $_SESSION['last_activity'] = time();
        logAction($user['username'], 'Logged in', 'Successful authentication for ' . $user['full_name']);
        redirect('?page=dashboard');
    }

    $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Invalid username or password.'];
    redirect('?page=login');
}

if (isset($_POST['action']) && $_POST['action'] === 'create_organization') {
    requireRole(['admin', 'superadmin']);
    $name = trim($_POST['name'] ?? '');
    if ($name !== '') {
        $stmt = $db->prepare('INSERT INTO organizations (name) VALUES (:name)');
        $stmt->execute([':name' => $name]);
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Organization created successfully.'];
        logAction($_SESSION['user']['username'], 'Organization created', 'Created organization ' . $name);
    }
    redirect('?page=organizations');
}

if (isset($_POST['action']) && $_POST['action'] === 'update_organization') {
    requireRole(['admin', 'superadmin']);
    $organizationId = (int) ($_POST['organization_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');

    if ($organizationId > 0 && $name !== '') {
        $stmt = $db->prepare('UPDATE organizations SET name = :name WHERE id = :id');
        $stmt->execute([':name' => $name, ':id' => $organizationId]);
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Organization updated successfully.'];
        logAction($_SESSION['user']['username'], 'Organization updated', 'Updated organization ' . $name);
    }

    redirect('?page=organizations');
}

if (isset($_POST['action']) && $_POST['action'] === 'delete_organization') {
    requireRole(['admin', 'superadmin']);
    $organizationId = (int) ($_POST['organization_id'] ?? 0);

    if ($organizationId > 0) {
        $db->beginTransaction();
        try {
            $db->prepare('UPDATE students SET organization_id = NULL WHERE organization_id = :id')->execute([':id' => $organizationId]);
            $db->prepare('UPDATE event_eligibility SET organization_id = NULL WHERE organization_id = :id')->execute([':id' => $organizationId]);
            $db->prepare('DELETE FROM organizations WHERE id = :id')->execute([':id' => $organizationId]);
            $db->commit();
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Organization deleted successfully.'];
            logAction($_SESSION['user']['username'], 'Organization deleted', 'Deleted organization ID ' . $organizationId);
        } catch (Throwable $e) {
            $db->rollBack();
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Unable to delete organization because it is still in use.'];
        }
    }

    redirect('?page=organizations');
}

if (isset($_POST['action']) && $_POST['action'] === 'delete_all_organizations') {
    requireRole(['admin', 'superadmin']);

    $db->beginTransaction();
    try {
        $db->prepare('UPDATE students SET organization_id = NULL')->execute();
        $db->prepare('UPDATE event_eligibility SET organization_id = NULL')->execute();
        $db->exec('DELETE FROM organizations');
        $db->commit();
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'All organizations deleted successfully.'];
        logAction($_SESSION['user']['username'], 'Organizations deleted', 'Deleted all organizations from the system');
    } catch (Throwable $e) {
        $db->rollBack();
        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Unable to delete all organizations.'];
    }

    redirect('?page=organizations');
}

if (isset($_POST['action']) && $_POST['action'] === 'create_event') {
    requireRole(['admin', 'superadmin']);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $eventDate = $_POST['event_date'] ?? date('Y-m-d');
    $start = $_POST['start_time'] ?? '08:00';
    $end = $_POST['end_time'] ?? '17:00';
    $venue = trim($_POST['venue'] ?? '');
    $organizer = trim($_POST['organizer'] ?? '');
    $mode = $_POST['attendance_mode'] ?? 'Barcode + Student ID';
    $status = in_array($_POST['status'] ?? 'active', ['active', 'draft', 'scheduled', 'completed'], true) ? $_POST['status'] : 'active';
    $latitude = (float) ($_POST['latitude'] ?? 16.1482);
    $longitude = (float) ($_POST['longitude'] ?? 119.9851);
    $radius = (int) ($_POST['radius_meters'] ?? 100);
    $verificationEnabled = isset($_POST['presence_verification']) ? 1 : 0;
    $verificationInterval = (int) ($_POST['verification_interval_minutes'] ?? 15);
    $minimumPresence = (int) ($_POST['minimum_required_presence'] ?? 80);
    $checkoutRequired = isset($_POST['require_checkout']) ? 1 : 0;

    if ($name !== '') {
        $stmt = $db->prepare('INSERT INTO events (name, description, event_date, start_time, end_time, venue, organizer, attendance_mode, status, latitude, longitude, radius_meters, presence_verification, verification_interval_minutes, minimum_required_presence, require_checkout, created_by) VALUES (:name, :description, :event_date, :start_time, :end_time, :venue, :organizer, :attendance_mode, :status, :latitude, :longitude, :radius_meters, :presence_verification, :verification_interval_minutes, :minimum_required_presence, :require_checkout, :created_by)');
        $stmt->execute([
            ':name' => $name,
            ':description' => $description,
            ':event_date' => $eventDate,
            ':start_time' => $start,
            ':end_time' => $end,
            ':venue' => $venue,
            ':organizer' => $organizer,
            ':attendance_mode' => $mode,
            ':status' => $status,
            ':latitude' => $latitude,
            ':longitude' => $longitude,
            ':radius_meters' => $radius,
            ':presence_verification' => $verificationEnabled,
            ':verification_interval_minutes' => $verificationInterval,
            ':minimum_required_presence' => $minimumPresence,
            ':require_checkout' => $checkoutRequired,
            ':created_by' => $_SESSION['user']['id'],
        ]);

        $eventId = $db->lastInsertId();
        $db->prepare('INSERT INTO event_geofences (event_id, latitude, longitude, radius_meters, enabled) VALUES (:event_id, :latitude, :longitude, :radius_meters, 1)')->execute([
            ':event_id' => $eventId,
            ':latitude' => $latitude,
            ':longitude' => $longitude,
            ':radius_meters' => $radius,
        ]);

        logAction($_SESSION['user']['username'], 'Created event', 'Created ' . $name . ' with ID ' . $eventId);
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Event created successfully.'];
    }

    redirect('?page=events');
}

if (isset($_POST['action']) && $_POST['action'] === 'update_event') {
    requireRole(['admin', 'superadmin']);
    $eventId = (int) ($_POST['event_id'] ?? 0);
    if ($eventId > 0) {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $eventDate = $_POST['event_date'] ?? date('Y-m-d');
        $start = $_POST['start_time'] ?? '08:00';
        $end = $_POST['end_time'] ?? '17:00';
        $venue = trim($_POST['venue'] ?? '');
        $organizer = trim($_POST['organizer'] ?? '');
        $mode = $_POST['attendance_mode'] ?? 'Barcode + Student ID';
        $status = in_array($_POST['status'] ?? 'active', ['active', 'draft', 'scheduled', 'completed'], true) ? $_POST['status'] : 'active';
        $latitude = (float) ($_POST['latitude'] ?? 16.1482);
        $longitude = (float) ($_POST['longitude'] ?? 119.9851);
        $radius = (int) ($_POST['radius_meters'] ?? 100);
        $verificationEnabled = isset($_POST['presence_verification']) ? 1 : 0;
        $verificationInterval = (int) ($_POST['verification_interval_minutes'] ?? 15);
        $minimumPresence = (int) ($_POST['minimum_required_presence'] ?? 80);
        $checkoutRequired = isset($_POST['require_checkout']) ? 1 : 0;

        if ($name !== '') {
            $db->prepare('UPDATE events SET name = :name, description = :description, event_date = :event_date, start_time = :start_time, end_time = :end_time, venue = :venue, organizer = :organizer, attendance_mode = :attendance_mode, status = :status, latitude = :latitude, longitude = :longitude, radius_meters = :radius_meters, presence_verification = :presence_verification, verification_interval_minutes = :verification_interval_minutes, minimum_required_presence = :minimum_required_presence, require_checkout = :require_checkout WHERE id = :event_id')->execute([
                ':name' => $name,
                ':description' => $description,
                ':event_date' => $eventDate,
                ':start_time' => $start,
                ':end_time' => $end,
                ':venue' => $venue,
                ':organizer' => $organizer,
                ':attendance_mode' => $mode,
                ':status' => $status,
                ':latitude' => $latitude,
                ':longitude' => $longitude,
                ':radius_meters' => $radius,
                ':presence_verification' => $verificationEnabled,
                ':verification_interval_minutes' => $verificationInterval,
                ':minimum_required_presence' => $minimumPresence,
                ':require_checkout' => $checkoutRequired,
                ':event_id' => $eventId,
            ]);

            $geofenceCheck = $db->prepare('SELECT id FROM event_geofences WHERE event_id = :event_id LIMIT 1');
            $geofenceCheck->execute([':event_id' => $eventId]);
            if ($geofenceCheck->fetchColumn() === false) {
                $db->prepare('INSERT INTO event_geofences (event_id, latitude, longitude, radius_meters, enabled) VALUES (:event_id, :latitude, :longitude, :radius_meters, 1)')->execute([
                    ':event_id' => $eventId,
                    ':latitude' => $latitude,
                    ':longitude' => $longitude,
                    ':radius_meters' => $radius,
                ]);
            } else {
                $db->prepare('UPDATE event_geofences SET latitude = :latitude, longitude = :longitude, radius_meters = :radius_meters, enabled = 1 WHERE event_id = :event_id')->execute([
                    ':latitude' => $latitude,
                    ':longitude' => $longitude,
                    ':radius_meters' => $radius,
                    ':event_id' => $eventId,
                ]);
            }

            logAction($_SESSION['user']['username'] ?? 'system', 'Updated event', 'Updated event ID ' . $eventId . ' (' . $name . ')');
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Event updated successfully.'];
        }
    }

    redirect('?page=events');
}

if (isset($_POST['action']) && $_POST['action'] === 'delete_event') {
    requireRole(['admin', 'superadmin']);
    $eventId = (int) ($_POST['event_id'] ?? 0);

    if ($eventId > 0) {
        $relatedTables = ['presence_verifications', 'attendance', 'event_geofences', 'event_eligibility'];

        if (isMysqlDatabase()) {
            $db->exec('SET FOREIGN_KEY_CHECKS = 0;');
        } else {
            $db->exec('PRAGMA foreign_keys = OFF;');
        }
        $db->beginTransaction();
        try {
            foreach ($relatedTables as $tableName) {
                $tableExists = isMysqlDatabase()
                    ? $db->query('SHOW TABLES LIKE \'' . $tableName . '\'')->fetchColumn()
                    : $db->query("SELECT name FROM sqlite_master WHERE type = 'table' AND name = '{$tableName}'")->fetchColumn();
                if ($tableExists) {
                    $db->prepare('DELETE FROM ' . $tableName . ' WHERE event_id = :event_id')->execute([':event_id' => $eventId]);
                }
            }

            $db->prepare('DELETE FROM events WHERE id = :event_id')->execute([':event_id' => $eventId]);
            $db->commit();

            $actor = $_SESSION['user']['username'] ?? 'system';
            logAction($actor, 'Deleted event', 'Deleted event ID ' . $eventId);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Event deleted successfully.'];
        } catch (Throwable $e) {
            $db->rollBack();
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Unable to delete event: ' . $e->getMessage()];
        } finally {
            if (isMysqlDatabase()) {
                $db->exec('SET FOREIGN_KEY_CHECKS = 1;');
            } else {
                $db->exec('PRAGMA foreign_keys = ON;');
            }
        }
    }

    redirect('?page=events');
}

if (isset($_POST['action']) && $_POST['action'] === 'save_geofence') {
    requireRole(['admin', 'superadmin']);
    $eventId = (int) ($_POST['event_id'] ?? 0);
    $latitude = (float) ($_POST['latitude'] ?? 0);
    $longitude = (float) ($_POST['longitude'] ?? 0);
    $radius = (int) ($_POST['radius_meters'] ?? 100);

    if ($eventId > 0) {
        $db->prepare('UPDATE events SET latitude = :latitude, longitude = :longitude, radius_meters = :radius_meters WHERE id = :event_id')->execute([
            ':latitude' => $latitude,
            ':longitude' => $longitude,
            ':radius_meters' => $radius,
            ':event_id' => $eventId,
        ]);
        $db->prepare('INSERT INTO event_geofences (event_id, latitude, longitude, radius_meters, enabled) VALUES (:event_id, :latitude, :longitude, :radius_meters, 1)')->execute([
            ':event_id' => $eventId,
            ':latitude' => $latitude,
            ':longitude' => $longitude,
            ':radius_meters' => $radius,
        ]);
        logAction($_SESSION['user']['username'], 'Updated geofence', 'Geofence updated for event ID ' . $eventId);
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Event geofence updated successfully.'];
    }

    redirect('?page=presence');
}

if (isset($_POST['action']) && $_POST['action'] === 'save_settings') {
    requireRole(['superadmin']);
    $settings = [
        'attendance_threshold' => $_POST['attendance_threshold'] ?? '80',
        'verification_interval' => $_POST['verification_interval'] ?? '15',
        'event_radius_meters' => $_POST['event_radius_meters'] ?? '100',
        'session_timeout_minutes' => $_POST['session_timeout_minutes'] ?? '30',
        'campus_name' => $_POST['campus_name'] ?? 'Pangasinan State University - Alaminos City Campus',
    ];

    foreach ($settings as $key => $value) {
        if (isMysqlDatabase()) {
            $stmt = $db->prepare('INSERT INTO system_settings (key_name, value_text) VALUES (:key_name, :value_text) ON DUPLICATE KEY UPDATE value_text = VALUES(value_text), updated_at = CURRENT_TIMESTAMP');
        } else {
            $stmt = $db->prepare('INSERT INTO system_settings (key_name, value_text) VALUES (:key_name, :value_text) ON CONFLICT(key_name) DO UPDATE SET value_text = excluded.value_text, updated_at = CURRENT_TIMESTAMP');
        }
        $stmt->execute([':key_name' => $key, ':value_text' => (string) $value]);
    }


    logAction($_SESSION['user']['username'], 'Updated system settings', 'System settings were updated.');
    $_SESSION['flash'] = ['type' => 'success', 'message' => 'System settings saved successfully.'];
    redirect('?page=settings');
}

if (isset($_POST['action']) && $_POST['action'] === 'create_admin_account') {
    requireRole(['superadmin']);

    $fullName = trim((string) ($_POST['full_name'] ?? ''));
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $role = in_array($_POST['role'] ?? 'admin', ['admin', 'superadmin'], true) ? $_POST['role'] : 'admin';

    if ($fullName === '' || $username === '' || strlen($password) < 6) {
        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Please provide a full name, username, and a password with at least 6 characters.'];
        redirect('?page=settings');
    }

    $existing = $db->prepare('SELECT id FROM users WHERE username = :username LIMIT 1');
    $existing->execute([':username' => $username]);
    if ($existing->fetch()) {
        $_SESSION['flash'] = ['type' => 'warning', 'message' => 'This username is already taken. Please choose another one.'];
        redirect('?page=settings');
    }

    if ($role === 'superadmin') {
        $superadminCount = (int) $db->query('SELECT COUNT(*) as count FROM users WHERE role = "superadmin"')->fetch()['count'];
        if ($superadminCount >= 1) {
            $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Only one super admin account is allowed. Please keep the existing super admin and create regular admin accounts instead.'];
            redirect('?page=settings');
        }
    }

    $stmt = $db->prepare('INSERT INTO users (username, password_hash, full_name, role) VALUES (:username, :password_hash, :full_name, :role)');
    $stmt->execute([
        ':username' => $username,
        ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ':full_name' => $fullName,
        ':role' => $role,
    ]);

    logAction($_SESSION['user']['username'], 'Created admin account', 'Created admin user ' . $fullName . ' (' . $username . ') as ' . $role);
    $_SESSION['flash'] = ['type' => 'success', 'message' => 'New admin account created successfully for ' . $fullName . '.'];
    redirect('?page=settings');
}

if (isset($_POST['action']) && $_POST['action'] === 'update_admin_account') {
    requireRole(['superadmin']);

    $adminId = (int) ($_POST['admin_id'] ?? 0);
    $fullName = trim((string) ($_POST['full_name'] ?? ''));
    $username = trim((string) ($_POST['username'] ?? ''));
    $role = in_array($_POST['role'] ?? 'admin', ['admin', 'superadmin'], true) ? $_POST['role'] : 'admin';
    $password = (string) ($_POST['password'] ?? '');

    if ($adminId <= 0 || $fullName === '' || $username === '') {
        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Please provide a valid admin profile to update.'];
        redirect('?page=settings');
    }

    $existing = $db->prepare('SELECT id, username, role FROM users WHERE username = :username AND id != :id LIMIT 1');
    $existing->execute([':username' => $username, ':id' => $adminId]);
    if ($existing->fetch()) {
        $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Another admin is already using that username.'];
        redirect('?page=settings');
    }

    if ($role === 'superadmin') {
        $otherSuperadmin = $db->prepare('SELECT id FROM users WHERE role = "superadmin" AND id != :id LIMIT 1');
        $otherSuperadmin->execute([':id' => $adminId]);
        if ($otherSuperadmin->fetch()) {
            $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Only one super admin account is allowed. Keep the current super admin and assign the rest as admin users.'];
            redirect('?page=settings');
        }
    }

    $updateSql = 'UPDATE users SET full_name = :full_name, username = :username, role = :role';
    $params = [
        ':full_name' => $fullName,
        ':username' => $username,
        ':role' => $role,
        ':id' => $adminId,
    ];

    if ($password !== '') {
        if (strlen($password) < 6) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Passwords must be at least 6 characters long.'];
            redirect('?page=settings');
        }
        $updateSql .= ', password_hash = :password_hash';
        $params[':password_hash'] = password_hash($password, PASSWORD_DEFAULT);
    }

    $updateSql .= ' WHERE id = :id';
    $stmt = $db->prepare($updateSql);
    $stmt->execute($params);

    logAction($_SESSION['user']['username'], 'Updated admin account', 'Updated admin ' . $fullName . ' (' . $username . ')');
    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Admin account updated successfully.'];
    redirect('?page=settings');
}

if (isset($_POST['action']) && $_POST['action'] === 'delete_admin_account') {
    requireRole(['superadmin']);

    $adminId = (int) ($_POST['admin_id'] ?? 0);
    if ($adminId <= 0) {
        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Invalid admin account selected for deletion.'];
        redirect('?page=settings');
    }

    $admin = $db->prepare('SELECT id, username, full_name, role FROM users WHERE id = :id AND role IN ("admin", "superadmin") LIMIT 1');
    $admin->execute([':id' => $adminId]);
    $target = $admin->fetch();

    if (!$target) {
        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Admin account not found.'];
        redirect('?page=settings');
    }

    if ($target['username'] === $_SESSION['user']['username']) {
        $_SESSION['flash'] = ['type' => 'warning', 'message' => 'You cannot delete the account you are currently using.'];
        redirect('?page=settings');
    }

    if ($target['role'] === 'superadmin') {
        $count = $db->query('SELECT COUNT(*) as count FROM users WHERE role = "superadmin"')->fetch()['count'];
        if ((int) $count <= 1) {
            $_SESSION['flash'] = ['type' => 'warning', 'message' => 'At least one superadmin account must remain in the system.'];
            redirect('?page=settings');
        }
    }

    $db->prepare('DELETE FROM users WHERE id = :id AND role IN ("admin", "superadmin")')->execute([':id' => $adminId]);
    logAction($_SESSION['user']['username'], 'Deleted admin account', 'Removed admin user ' . $target['full_name'] . ' (' . $target['username'] . ')');
    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Admin account deleted successfully.'];
    redirect('?page=settings');
}

if (isset($_POST['action']) && $_POST['action'] === 'scan_attendance') {
    requireLogin();

    $eventId = (int) ($_POST['event_id'] ?? 0);
    $studentIdEntry = trim($_POST['student_id'] ?? '');
    $student = $db->prepare('SELECT * FROM students WHERE student_id = :student_id LIMIT 1');
    $student->execute([':student_id' => $studentIdEntry]);
    $studentRecord = $student->fetch();

    if (!$studentRecord) {
        logAction($_SESSION['user']['username'], 'Rejected invalid attendance', 'Student ID ' . $studentIdEntry . ' not found.');
        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Student ID not found. Please verify the provided identifier.'];
        redirect('?page=scanner');
    }

    $duplicateCheck = $db->prepare('SELECT * FROM attendance WHERE event_id = :event_id AND student_id = :student_id LIMIT 1');
    $duplicateCheck->execute([':event_id' => $eventId, ':student_id' => $studentRecord['id']]);
    if ($duplicateCheck->fetch()) {
        $already = $db->prepare('SELECT scanned_at FROM attendance WHERE event_id = :event_id AND student_id = :student_id ORDER BY scanned_at DESC LIMIT 1');
        $already->execute([':event_id' => $eventId, ':student_id' => $studentRecord['id']]);
        $attendanceAt = $already->fetch();
        logAction($_SESSION['user']['username'], 'Duplicate attendance blocked', 'Duplicate attempt for student ' . $studentRecord['full_name']);
        $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Attendance already recorded for this student at ' . date('h:i:s A', strtotime($attendanceAt['scanned_at'])) . '.'];
        redirect('?page=scanner');
    }

    $ruleCount = $db->prepare('SELECT COUNT(*) as count FROM event_eligibility WHERE event_id = :event_id');
    $ruleCount->execute([':event_id' => $eventId]);
    $eligibilityCount = (int) $ruleCount->fetch()['count'];
    $eligible = true;

    if ($eligibilityCount > 0) {
        $candidate = $db->prepare('SELECT * FROM event_eligibility WHERE event_id = :event_id AND (program_id = :program_id OR organization_id = :organization_id OR year_level = :year_level) LIMIT 1');
        $candidate->execute([
            ':event_id' => $eventId,
            ':program_id' => $studentRecord['program_id'],
            ':organization_id' => $studentRecord['organization_id'],
            ':year_level' => $studentRecord['year_level'],
        ]);
        $eligible = (bool) $candidate->fetch();
    }

    if (!$eligible) {
        logAction($_SESSION['user']['username'], 'Student not eligible', 'Student ' . $studentRecord['full_name'] . ' attempted invalid event access.');
        $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Student is not eligible for this event. The account does not match the event eligibility rules.'];
        redirect('?page=scanner');
    }

    $insert = $db->prepare('INSERT INTO attendance (event_id, student_id, status, scanned_at, scanned_by, notes) VALUES (:event_id, :student_id, "present", CURRENT_TIMESTAMP, :scanned_by, :notes)');
    $insert->execute([
        ':event_id' => $eventId,
        ':student_id' => $studentRecord['id'],
        ':scanned_by' => $_SESSION['user']['username'],
        ':notes' => 'Manual scan',
    ]);

    logAction($_SESSION['user']['username'], 'Attendance recorded', 'Recorded attendance for ' . $studentRecord['full_name']);
    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Attendance recorded successfully for ' . $studentRecord['full_name'] . ' (' . htmlspecialchars($studentRecord['program_id'] ? 'BSIT' : 'Student') . ' / ' . $studentRecord['year_level'] . ') at ' . date('h:i:s A') . '.'];
    redirect('?page=scanner');
}

function renderSuperAdminDashboardPage(): string
{
    $db = getDatabaseConnection();
    $stats = getDashboardStats();
    $settings = getSystemSettings();
    $timeout = htmlspecialchars((string) ($settings['session_timeout_minutes'] ?? '30'));
    $orgs = getOrganizations();
    $auditCount = (int) $db->query('SELECT COUNT(*) as count FROM activity_logs')->fetch()['count'];
    $logs = $db->query('SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 8')->fetchAll();
    $activeEvt = activeEvent();
    $adminCount = (int) $db->query('SELECT COUNT(*) as count FROM users WHERE role IN ("admin", "superadmin")')->fetch()['count'];

    $logHtml = '';
    foreach ($logs as $log) {
        $actorRole = strtolower($log['actor'] ?? 'system');
        $actorBadgeClass = in_array($actorRole, ['superadmin', 'admin'], true) ? 'badge-role-admin' : 'badge-role-system';
        $logHtml .= '<li class="dash-audit-item">
            <div class="dash-audit-left">
                <span class="dash-actor-pill ' . $actorBadgeClass . '">' . htmlspecialchars(substr($log['actor'], 0, 2)) . '</span>
                <div>
                    <strong>' . htmlspecialchars($log['action']) . '</strong>
                    <span class="dash-audit-desc">' . htmlspecialchars($log['details'] ?: 'System event by ' . $log['actor']) . '</span>
                </div>
            </div>
            <time class="dash-audit-time">' . htmlspecialchars(date('M d, h:i A', strtotime($log['created_at']))) . '</time>
        </li>';
    }

    $orgHtml = '';
    foreach ($orgs as $org) {
        $orgStmt = $db->prepare('SELECT COUNT(*) FROM students WHERE organization_id = :id');
        $orgStmt->execute([':id' => $org['id']]);
        $orgCount = (int) $orgStmt->fetchColumn();

        $orgHtml .= '<div class="dash-org-chip">
            <div class="dash-org-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M3 7v14M21 7v14M6 7V3h12v4M9 11h2M9 15h2M13 11h2M13 15h2"/></svg></div>
            <div class="dash-org-info">
                <strong>' . htmlspecialchars($org['name']) . '</strong>
                <small>' . (int) $orgCount . ' Students</small>
            </div>
            <span class="dash-chip-status">ACTIVE</span>
        </div>';
    }

    $eventBanner = '';
    if ($activeEvt) {
        $eventSummary = getEventSummary((int) $activeEvt['id']);
        $presentRate = number_format((float) ($eventSummary['attendance_rate'] ?? 0), 1);
        $eventBanner = '<div class="dash-event-snapshot">
            <div class="dash-event-snap-meta">
                <span class="live-beacon"><span class="beacon-dot"></span>LIVE ON CAMPUS</span>
                <h3>' . htmlspecialchars($activeEvt['name']) . '</h3>
                <p><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg> ' . htmlspecialchars($activeEvt['venue']) . ' &bull; <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg> ' . htmlspecialchars($activeEvt['event_date']) . '</p>
            </div>
            <div class="dash-event-snap-stats">
                <div class="snap-stat">
                    <span>Present</span>
                    <strong>' . number_format((int) ($eventSummary['present'] ?? 0)) . '</strong>
                </div>
                <div class="snap-stat">
                    <span>Rate</span>
                    <strong>' . $presentRate . '%</strong>
                </div>
                <a class="button" href="?page=dashboard&view=operations">Live Operations &rarr;</a>
                <a class="button secondary" href="?page=scanner">Open Scanner</a>
            </div>
        </div>';
    } else {
        $eventBanner = '<div class="dash-event-snapshot standby">
            <div class="dash-event-snap-meta">
                <span class="standby-beacon"><span class="beacon-dot amber"></span>SYSTEM STANDBY</span>
                <h3>No active event currently running</h3>
                <p>Campus event monitors are primed. Create or activate an event to begin live attendee verification.</p>
            </div>
            <div class="dash-event-snap-stats">
                <a class="button" href="?page=events">+ Create New Event</a>
                <a class="button secondary" href="?page=dashboard&view=operations">View Operations</a>
            </div>
        </div>';
    }

    return '<div class="dash dash--superadmin">
        <div class="dash-view-tabs">
            <a class="dash-tab-btn active" href="?page=dashboard&view=governance">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                Institutional Governance
            </a>
            <a class="dash-tab-btn" href="?page=dashboard&view=operations">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
                Live Event Operations
            </a>
        </div>

        <section class="dash-hero">
            <div class="dash-hero-content">
                <div class="dash-hero-badge">
                    <span class="hero-dot"></span>
                    INSTITUTIONAL GOVERNANCE CONSOLE
                </div>
                <h1 class="dash-hero-title">Campus Security & Governance Hub</h1>
                <p class="dash-hero-subtitle">Institutional control center for student organizations, role-based campus access, security enforcement, and system audits.</p>
                <div class="dash-hero-actions">
                    <a class="button" href="?page=organizations">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M3 7v14M21 7v14M6 7V3h12v4M9 11h2M9 15h2M13 11h2M13 15h2"/></svg>
                        Manage Organizations
                    </a>
                    <a class="button secondary" href="?page=reports">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg>
                        System Reports
                    </a>
                    <a class="button secondary" href="?page=settings">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                        Security Settings
                    </a>
                </div>
            </div>
            <div class="dash-hero-stats">
                <div class="hero-metric-tile">
                    <span class="tile-label">ADMINISTRATORS</span>
                    <strong class="tile-val">' . $adminCount . ' Active</strong>
                    <small>Superadmin & Staff</small>
                </div>
                <div class="hero-metric-tile">
                    <span class="tile-label">SECURITY LEVEL</span>
                    <strong class="tile-val">Enterprise</strong>
                    <small>CSRF & Session Lock</small>
                </div>
            </div>
        </section>

        ' . $eventBanner . '

        <section class="dash-kpis" aria-label="Governance metrics">
            <article class="dash-kpi-card tone-primary">
                <div class="kpi-top">
                    <span class="kpi-label">Registered Students</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></span>
                </div>
                <div class="kpi-val">' . number_format((int) $stats['students']) . '</div>
                <div class="kpi-meta"><span class="kpi-pill success">&bull; Enrolled</span> Campus directory roster</div>
            </article>

            <article class="dash-kpi-card tone-live">
                <div class="kpi-top">
                    <span class="kpi-label">Active Events</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></span>
                </div>
                <div class="kpi-val">' . (int) $stats['active_events'] . '</div>
                <div class="kpi-meta"><span class="kpi-pill ' . ($stats['active_events'] > 0 ? 'success' : 'neutral') . '">' . ($stats['active_events'] > 0 ? 'Running' : 'Standby') . '</span> Scheduled & live sessions</div>
            </article>

            <article class="dash-kpi-card tone-accent">
                <div class="kpi-top">
                    <span class="kpi-label">Security Audit Logs</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></span>
                </div>
                <div class="kpi-val">' . number_format($auditCount) . '</div>
                <div class="kpi-meta"><span class="kpi-pill success">Verified</span> Immutable transaction log</div>
            </article>

            <article class="dash-kpi-card tone-gold">
                <div class="kpi-top">
                    <span class="kpi-label">Session Security</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></span>
                </div>
                <div class="kpi-val">' . $timeout . ' <small style="font-size: 1.1rem; font-weight: 600;">min</small></div>
                <div class="kpi-meta"><span class="kpi-pill warning">Protected</span> Auto-inactivity lock</div>
            </article>
        </section>

        <section class="dash-split dash-split--3">
            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">CAMPUS BODIES</span>
                        <h3>Student Organizations</h3>
                    </div>
                    <a class="dash-card-link" href="?page=organizations">View All &rarr;</a>
                </header>
                <div class="dash-org-list">
                    ' . ($orgHtml ?: '<div class="dash-empty">No organizations configured.</div>') . '
                </div>
            </article>

            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">POLICY ENFORCEMENT</span>
                        <h3>Security & Access Controls</h3>
                    </div>
                    <span class="dash-badge-secure">HEALTHY</span>
                </header>
                <ul class="dash-security-policies">
                    <li class="policy-item">
                        <div class="policy-icon green"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg></div>
                        <div class="policy-info">
                            <strong>Role-Based Access Control</strong>
                            <span>Superadmin, Admin, Student isolation</span>
                        </div>
                        <span class="policy-state on">ACTIVE</span>
                    </li>
                    <li class="policy-item">
                        <div class="policy-icon green"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg></div>
                        <div class="policy-info">
                            <strong>Anti-Duplicate Scan Guard</strong>
                            <span>Blocks replay and double check-ins</span>
                        </div>
                        <span class="policy-state on">ACTIVE</span>
                    </li>
                    <li class="policy-item">
                        <div class="policy-icon green"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg></div>
                        <div class="policy-info">
                            <strong>Eligibility Rule Engine</strong>
                            <span>Validates program & organization enrollment</span>
                        </div>
                        <span class="policy-state on">ACTIVE</span>
                    </li>
                    <li class="policy-item">
                        <div class="policy-icon gold"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
                        <div class="policy-info">
                            <strong>Session Security Lock</strong>
                            <span>' . $timeout . '-minute auto inactivity expiry</span>
                        </div>
                        <span class="policy-state locked">' . $timeout . 'm</span>
                    </li>
                </ul>
            </article>

            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">AUDIT TRAIL</span>
                        <h3>Security & Activity Log</h3>
                    </div>
                    <a class="dash-card-link" href="?page=activity_logs">Full Log &rarr;</a>
                </header>
                <ul class="dash-audit-stream">
                    ' . ($logHtml ?: '<li class="dash-empty">No activity logs recorded yet.</li>') . '
                </ul>
            </article>
        </section>
    </div>';
}

if (isset($_GET['page']) && $_GET['page'] === 'login') {
    if (isset($_SESSION['user'])) {
        redirect('?page=dashboard');
    }

    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    $flashMarkup = $flash ? '<div class="alert ' . htmlspecialchars($flash['type']) . '" style="margin: 0 0 18px;">' . htmlspecialchars($flash['message']) . '</div>' : '';

    $content = '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
        <meta http-equiv="Pragma" content="no-cache">
        <title>PSU Event Monitoring System</title>
        <link rel="stylesheet" href="assets/style.css?v=20261007a">
    </head>
    <body>
        <div class="login-page">
            <div class="login-shell">
                <div class="login-left-panel">
                    <div class="login-form-wrap">
                        <div class="login-kicker">Pangasinan State University - Alaminos City Campus</div>
                        <h1>Welcome Back</h1>
                        <p class="login-subtitle">Sign in to continue to the campus operations portal.</p>
                        ' . $flashMarkup . '
                        <form method="POST" class="login-form">
                            <input type="hidden" name="action" value="login">
                            ' . csrfField() . '
                            <label class="field">
                                <span>Username</span>
                                <input type="text" name="username" required autocomplete="username" placeholder="Enter username">
                            </label>
                            <label class="field">
                                <span>Password</span>
                                <input type="password" name="password" required autocomplete="current-password" placeholder="Enter password">
                            </label>
                            <button class="button" type="submit">Secure Login</button>
                        </form>
                    </div>
                </div>
                <div class="login-right-panel">
                    <div class="right-panel-inner">
                        <span class="right-panel-tag">Pangasinan State University</span>
                        <h2>Event Monitoring System</h2>
                        <p>Secure access for attendance, event operations, and campus verification.</p>
                        <div class="status-badges">
                            <span>Live</span>
                            <span>Verified</span>
                            <span>Protected</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>';
    echo $content;
    exit;
}

requireLogin();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$activePage = $_GET['page'] ?? 'dashboard';

if (in_array($activePage, ['events', 'presence', 'students', 'scanner', 'analytics', 'reports', 'activity_logs', 'settings'], true) && (!isset($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['admin', 'superadmin'], true))) {
    redirect('?page=dashboard');
}

function renderStudentDashboardPage(): string
{
    $db = getDatabaseConnection();
    $user = currentUser();
    $student = $db->prepare('SELECT * FROM students WHERE email = :email OR student_id = :student_id LIMIT 1');
    $student->execute([':email' => $user['username'] . '@psu.edu.ph', ':student_id' => $user['username']]);
    $record = $student->fetch();

    if (!$record && $user['username'] === 'student') {
        $db->prepare('INSERT OR IGNORE INTO students (student_id, full_name, program_id, organization_id, year_level, email, phone) VALUES (:student_id, :full_name, 1, 1, "2A", :email, "09171112222")')->execute([
            ':student_id' => 'student',
            ':full_name' => $user['full_name'],
            ':email' => 'student@psu.edu.ph',
        ]);
        $student = $db->prepare('SELECT * FROM students WHERE email = :email OR student_id = :student_id LIMIT 1');
        $student->execute([':email' => 'student@psu.edu.ph', ':student_id' => 'student']);
        $record = $student->fetch();
    }

    if (!$record) {
        return '<div class="dash dash--student"><div class="dash-card"><div class="dash-empty"><h3>Student account not linked</h3><p class="muted">Your student profile is not yet connected to the attendance system. Please contact the campus office.</p></div></div></div>';
    }

    $history = $db->prepare('SELECT e.name, a.status, a.scanned_at, e.venue FROM attendance a JOIN events e ON a.event_id = e.id WHERE a.student_id = :student_id ORDER BY a.scanned_at DESC LIMIT 6');
    $history->execute([':student_id' => $record['id']]);
    $rows = $history->fetchAll();

    $historyHtml = '';
    foreach ($rows as $row) {
        $status = strtoupper($row['status']);
        $historyHtml .= '<li class="dash-activity-item">
            <div class="dash-activity-avatar"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg></div>
            <div class="dash-activity-info">
                <strong>' . htmlspecialchars($row['name']) . '</strong>
                <span class="dash-activity-sub">' . htmlspecialchars($row['venue'] ?: 'Campus Venue') . ' &bull; ' . htmlspecialchars(date('M d, Y · h:i A', strtotime($row['scanned_at']))) . '</span>
            </div>
            <span class="badge success">VERIFIED ' . $status . '</span>
        </li>';
    }

    $upcoming = $db->query('SELECT * FROM events WHERE status IN ("active", "scheduled") ORDER BY event_date ASC LIMIT 4')->fetchAll();
    $upcomingHtml = '';
    foreach ($upcoming as $event) {
        $upcomingHtml .= '<li class="dash-activity-item">
            <div class="dash-activity-avatar event"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
            <div class="dash-activity-info">
                <strong>' . htmlspecialchars($event['name']) . '</strong>
                <span class="dash-activity-sub">' . htmlspecialchars($event['venue'] ?: 'Campus Venue') . ' &bull; ' . htmlspecialchars($event['event_date']) . '</span>
            </div>
            <span class="badge ' . ($event['status'] === 'active' ? 'success' : 'warning') . '">' . strtoupper(htmlspecialchars($event['status'])) . '</span>
        </li>';
    }

    $prog = $db->prepare('SELECT name FROM programs WHERE id = :id LIMIT 1');
    $prog->execute([':id' => $record['program_id']]);
    $progName = $prog->fetchColumn() ?: 'BSIT';

    return '<div class="dash dash--student">
        <section class="dash-hero">
            <div class="dash-hero-content">
                <div class="dash-hero-badge">
                    <span class="hero-dot"></span>
                    STUDENT ATTENDANCE PORTAL
                </div>
                <h1 class="dash-hero-title">Welcome, ' . htmlspecialchars($user['full_name']) . '</h1>
                <p class="dash-hero-subtitle">Student ID: <strong>' . htmlspecialchars($record['student_id']) . '</strong> &bull; Program: <strong>' . htmlspecialchars($progName) . ' (' . htmlspecialchars($record['year_level']) . ')</strong></p>
                <div class="dash-hero-actions">
                    <a class="button" href="?page=history">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        My Attendance Records
                    </a>
                    <a class="button secondary" href="?page=mobile_app">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
                        Digital Campus Pass
                    </a>
                </div>
            </div>
            <div class="dash-hero-stats">
                <div class="hero-metric-tile">
                    <span class="tile-label">ENROLLMENT STATUS</span>
                    <strong class="tile-val">Active</strong>
                    <small>PSU Alaminos Campus</small>
                </div>
                <div class="hero-metric-tile">
                    <span class="tile-label">VERIFIED CHECK-INS</span>
                    <strong class="tile-val">' . count($rows) . ' Events</strong>
                    <small>Official Presence Record</small>
                </div>
            </div>
        </section>

        <section class="dash-kpis" aria-label="Student attendance summary">
            <article class="dash-kpi-card tone-primary">
                <div class="kpi-top">
                    <span class="kpi-label">Events Attended</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg></span>
                </div>
                <div class="kpi-val">' . count($rows) . '</div>
                <div class="kpi-meta"><span class="kpi-pill success">Verified</span> Completed attendance</div>
            </article>

            <article class="dash-kpi-card tone-live">
                <div class="kpi-top">
                    <span class="kpi-label">Upcoming Events</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></span>
                </div>
                <div class="kpi-val">' . count($upcoming) . '</div>
                <div class="kpi-meta"><span class="kpi-pill warning">Scheduled</span> Campus events calendar</div>
            </article>

            <article class="dash-kpi-card tone-gold">
                <div class="kpi-top">
                    <span class="kpi-label">Standing</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></span>
                </div>
                <div class="kpi-val">Good</div>
                <div class="kpi-meta"><span class="kpi-pill success">Compliant</span> Attendance records verified</div>
            </article>
        </section>

        <section class="dash-split">
            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">CAMPUS CALENDAR</span>
                        <h3>Upcoming Events</h3>
                    </div>
                </header>
                <ul class="dash-activity-stream">
                    ' . ($upcomingHtml ?: '<li class="dash-empty">No upcoming events scheduled right now.</li>') . '
                </ul>
            </article>

            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">MY RECORDS</span>
                        <h3>Recent Verified Attendance</h3>
                    </div>
                    <a class="dash-card-link" href="?page=history">View Full History &rarr;</a>
                </header>
                <ul class="dash-activity-stream">
                    ' . ($historyHtml ?: '<li class="dash-empty">No attendance records yet. Attend an event to see check-ins here.</li>') . '
                </ul>
            </article>
        </section>
    </div>';
}

function renderDashboardPage(): string
{
    $db = getDatabaseConnection();
    $user = currentUser();
    $event = activeEvent();
    $summary = $event ? getEventSummary((int) $event['id']) : ['registered' => 0, 'present' => 0, 'absent' => 0, 'attendance_rate' => 0];
    $recent = getRecentAttendance();
    $presence = $event ? getPresenceStatusSummary((int) $event['id']) : ['inside' => 0, 'outside' => 0, 'pending' => 0];

    $eventName = htmlspecialchars($event['name'] ?? 'No active event');
    $eventVenue = htmlspecialchars($event['venue'] ?? 'Campus Main Grounds');
    $eventDate = htmlspecialchars($event['event_date'] ?? date('Y-m-d'));
    $eventOrganizer = htmlspecialchars($event['organizer'] ?? 'PSU Administration');
    $eventMode = htmlspecialchars($event['attendance_mode'] ?? 'Barcode + Student ID');

    $registeredNum = (int) ($summary['registered'] ?? 0);
    $presentNum = (int) ($summary['present'] ?? 0);
    $attendanceRateNum = (float) ($summary['attendance_rate'] ?? 0);

    $registered = number_format($registeredNum);
    $present = number_format($presentNum);
    $attendanceRate = number_format($attendanceRateNum, 1);

    $insideCount = (int) ($presence['inside'] ?? 0);
    $pendingCount = (int) ($presence['pending'] ?? 0);
    $outsideCount = (int) ($presence['outside'] ?? 0);
    $presenceTotal = $insideCount + $pendingCount + $outsideCount;

    $insidePct = $presenceTotal > 0 ? round(($insideCount / $presenceTotal) * 100) : 0;
    $pendingPct = $presenceTotal > 0 ? round(($pendingCount / $presenceTotal) * 100) : 0;
    $outsidePct = $presenceTotal > 0 ? max(0, 100 - $insidePct - $pendingPct) : 0;

    $liveLabel = $event ? 'LIVE EVENT RUNNING' : 'STANDBY / NO EVENT ACTIVE';

    $activityList = '';
    foreach (array_slice($recent, 0, 8) as $item) {
        $statusClass = 'verified';
        $statusGlyph = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>';
        $statusText = 'PRESENT';
        if (isset($item['status']) && $item['status'] === 'pending') {
            $statusClass = 'pending';
            $statusGlyph = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/></svg>';
            $statusText = 'VERIFYING';
        }

        $initials = strtoupper(substr($item['full_name'], 0, 2));

        $activityList .= '<li class="dash-activity-item">
            <div class="dash-activity-avatar">' . htmlspecialchars($initials) . '</div>
            <div class="dash-activity-info">
                <strong>' . htmlspecialchars($item['full_name']) . '</strong>
                <span class="dash-activity-sub">' . htmlspecialchars($item['event_name'] ?? 'Event') . ' &bull; ' . htmlspecialchars(date('h:i A', strtotime($item['scanned_at']))) . '</span>
            </div>
            <span class="badge ' . ($statusClass === 'verified' ? 'success' : 'warning') . '">' . $statusGlyph . ' ' . $statusText . '</span>
        </li>';
    }

    $peakWindowValue = 'Pending Scans';
    $peakWindowNote = 'Monitoring check-in arrival stream';
    $arrivalBars = '<div class="dash-bars-empty">No arrival traffic data recorded yet</div>';
    $programPulse = '<div class="dash-empty">No program participation data available</div>';

    if ($event) {
        $hourQuery = $db->prepare("SELECT strftime('%H', scanned_at) AS hour_label, COUNT(*) AS total FROM attendance WHERE event_id = :event_id GROUP BY strftime('%H', scanned_at) ORDER BY hour_label ASC");
        $hourQuery->execute([':event_id' => (int) $event['id']]);
        $hourData = [];
        foreach ($hourQuery->fetchAll() as $row) {
            $hourData[(int) $row['hour_label']] = (int) $row['total'];
        }

        $peakHour = null;
        $peakTotal = 0;
        foreach ($hourData as $hour => $total) {
            if ($total > $peakTotal) {
                $peakHour = $hour;
                $peakTotal = $total;
            }
        }

        $hourSeries = [];
        $maxSeries = 1;
        for ($hour = 7; $hour <= 20; $hour++) {
            $hourSeries[$hour] = $hourData[$hour] ?? 0;
            if ($hourSeries[$hour] > $maxSeries) {
                $maxSeries = $hourSeries[$hour];
            }
        }

        if ($peakHour !== null && $peakTotal > 0) {
            $ampm = ((int) $peakHour) >= 12 ? 'PM' : 'AM';
            $hour12 = ((int) $peakHour) % 12;
            if ($hour12 === 0) {
                $hour12 = 12;
            }
            $peakWindowValue = $hour12 . ':00 ' . $ampm;
            $peakWindowNote = 'Peak flow (' . $peakTotal . ' attendees)';
        }

        $barHtml = [];
        foreach ($hourSeries as $hour => $count) {
            $height = $count > 0 ? max(12, round(($count / $maxSeries) * 100)) : 6;
            $isPeak = ($peakHour !== null && $hour === (int) $peakHour && $count > 0);
            $hourFormatted = sprintf('%02d:00', $hour);
            $barHtml[] = '<div class="dash-bar-col ' . ($isPeak ? 'is-peak' : '') . '">
                <div class="dash-bar-track">
                    <div class="dash-bar-fill ' . ($count > 0 ? 'has-data' : '') . '" style="height: ' . $height . '%;" data-tooltip="' . $hourFormatted . ': ' . $count . ' check-ins"></div>
                </div>
                <span class="dash-bar-lbl">' . ($hour % 2 === 0 ? sprintf('%02d', $hour) : '') . '</span>
            </div>';
        }
        $arrivalBars = '<div class="dash-bars-container">' . implode('', $barHtml) . '</div>';

        $programQuery = $db->prepare('SELECT p.name, COUNT(DISTINCT a.student_id) AS total FROM attendance a JOIN students s ON s.id = a.student_id JOIN programs p ON p.id = s.program_id WHERE a.event_id = :event_id GROUP BY p.name ORDER BY total DESC LIMIT 5');
        $programQuery->execute([':event_id' => (int) $event['id']]);
        $programStats = $programQuery->fetchAll();

        if (!empty($programStats)) {
            $topProgramTotal = max(array_column($programStats, 'total')) ?: 1;
            $segments = [];
            foreach ($programStats as $program) {
                $percent = max(10, round(((int) $program['total'] / $topProgramTotal) * 100));
                $segments[] = '<div class="dash-program-row">
                    <div class="dash-program-info">
                        <strong>' . htmlspecialchars($program['name']) . '</strong>
                        <span>' . (int) $program['total'] . ' Students</span>
                    </div>
                    <div class="dash-program-bar-track">
                        <div class="dash-program-bar-fill" style="width: ' . $percent . '%;"></div>
                    </div>
                </div>';
            }
            $programPulse = '<div class="dash-programs-list">' . implode('', $segments) . '</div>';
        }
    }

    $c = 263.89; // 2 * PI * 42
    $dashInside = round(($insidePct / 100) * $c, 2);
    $dashPending = round(($pendingPct / 100) * $c, 2);
    $dashOutside = round(($outsidePct / 100) * $c, 2);

    $offsetPending = -$dashInside;
    $offsetOutside = -($dashInside + $dashPending);

    $superAdminTabs = '';
    if ($user && $user['role'] === 'superadmin') {
        $superAdminTabs = '<div class="dash-view-tabs">
            <a class="dash-tab-btn" href="?page=dashboard&view=governance">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                Institutional Governance
            </a>
            <a class="dash-tab-btn active" href="?page=dashboard&view=operations">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
                Live Event Operations
            </a>
        </div>';
    }

    return '<div class="dash dash--ops">
        ' . $superAdminTabs . '

        <section class="dash-hero">
            <div class="dash-hero-content">
                <div class="dash-hero-badge ' . ($event ? 'live' : 'standby') . '">
                    <span class="hero-dot ' . ($event ? '' : 'amber') . '"></span>
                    ' . $liveLabel . '
                </div>
                <h1 class="dash-hero-title">' . $eventName . '</h1>
                <p class="dash-hero-subtitle">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg> ' . $eventVenue . ' &bull;
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg> ' . $eventDate . ' &bull;
                    <span>Mode: ' . str_replace('QR', 'Barcode', $eventMode) . '</span>
                </p>
                <div class="dash-hero-actions">
                    <a class="button" href="?page=scanner">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2M7 12h10"/></svg>
                        Open Barcode Scanner
                    </a>
                    <a class="button secondary" href="?page=presence">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a8 8 0 0 0-8 8c0 5.25 8 12 8 12s8-6.75 8-12a8 8 0 0 0-8-8z"/><circle cx="12" cy="10" r="3"/></svg>
                        Presence Geofence
                    </a>
                    <a class="button secondary" href="?page=analytics">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                        Live Analytics
                    </a>
                    <a class="button secondary" href="?page=reports">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg>
                        Reports
                    </a>
                    <a class="button secondary" href="?page=events">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/></svg>
                        Manage Events
                    </a>
                </div>
            </div>
            <div class="dash-hero-stats">
                <div class="hero-metric-tile highlight">
                    <span class="tile-label">PEAK ARRIVAL WINDOW</span>
                    <strong class="tile-val">' . htmlspecialchars($peakWindowValue) . '</strong>
                    <small>' . htmlspecialchars($peakWindowNote) . '</small>
                </div>
                <div class="hero-metric-tile">
                    <span class="tile-label">ORGANIZER</span>
                    <strong class="tile-val">' . htmlspecialchars($eventOrganizer) . '</strong>
                    <small>Official Campus Host</small>
                </div>
            </div>
        </section>

        <section class="dash-kpis" aria-label="Event attendance metrics">
            <article class="dash-kpi-card tone-primary">
                <div class="kpi-top">
                    <span class="kpi-label">Verified Present</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg></span>
                </div>
                <div class="kpi-val">' . $present . '</div>
                <div class="kpi-meta"><span class="kpi-pill success">&bull; Present</span> ' . $attendanceRate . '% attendance rate</div>
            </article>

            <article class="dash-kpi-card tone-live">
                <div class="kpi-top">
                    <span class="kpi-label">Attendance Rate</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m10 15 5-3-5-3v6Z"/></svg></span>
                </div>
                <div class="kpi-val">' . $attendanceRate . '<small style="font-size: 1.2rem; font-weight:700;">%</small></div>
                <div class="kpi-meta"><span class="kpi-pill ' . ($attendanceRateNum >= 80 ? 'success' : 'warning') . '">' . ($attendanceRateNum >= 80 ? 'Goal Met' : 'Target: 80%') . '</span> Campus benchmark</div>
            </article>

            <article class="dash-kpi-card tone-accent">
                <div class="kpi-top">
                    <span class="kpi-label">Total Registered</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></span>
                </div>
                <div class="kpi-val">' . $registered . '</div>
                <div class="kpi-meta"><span class="kpi-pill neutral">Roster</span> Eligible student body</div>
            </article>

            <article class="dash-kpi-card tone-gold">
                <div class="kpi-top">
                    <span class="kpi-label">Inside Geofence Zone</span>
                    <span class="kpi-icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a8 8 0 0 0-8 8c0 5.25 8 12 8 12s8-6.75 8-12a8 8 0 0 0-8-8z"/><circle cx="12" cy="10" r="3"/></svg></span>
                </div>
                <div class="kpi-val">' . number_format($insideCount) . '</div>
                <div class="kpi-meta"><span class="kpi-pill success">Verified</span> ' . $insidePct . '% inside event perimeter</div>
            </article>
        </section>

        <section class="dash-split">
            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">GEOFENCE TELEMETRY</span>
                        <h3>Presence Verification Radar</h3>
                    </div>
                    <span class="dash-badge-secure">GEOFENCE ACTIVE</span>
                </header>
                <div class="dash-presence-body">
                    <div class="dash-donut-wrap">
                        <svg class="dash-donut-svg" viewBox="0 0 100 100">
                            <circle class="dash-donut-bg" cx="50" cy="50" r="42" fill="transparent" stroke-width="12"></circle>
                            ' . ($presenceTotal > 0 ? '
                            <circle class="dash-donut-segment seg-inside" cx="50" cy="50" r="42" fill="transparent" stroke-width="12" stroke-dasharray="' . $dashInside . ' ' . $c . '" stroke-dashoffset="0"></circle>
                            <circle class="dash-donut-segment seg-pending" cx="50" cy="50" r="42" fill="transparent" stroke-width="12" stroke-dasharray="' . $dashPending . ' ' . $c . '" stroke-dashoffset="' . $offsetPending . '"></circle>
                            <circle class="dash-donut-segment seg-outside" cx="50" cy="50" r="42" fill="transparent" stroke-width="12" stroke-dasharray="' . $dashOutside . ' ' . $c . '" stroke-dashoffset="' . $offsetOutside . '"></circle>
                            ' : '<circle class="dash-donut-segment seg-empty" cx="50" cy="50" r="42" fill="transparent" stroke-width="12" stroke-dasharray="' . $c . ' ' . $c . '" stroke-dashoffset="0"></circle>') . '
                        </svg>
                        <div class="dash-donut-center">
                            <strong>' . number_format($presenceTotal) . '</strong>
                            <span>CHECKS</span>
                        </div>
                    </div>
                    <div class="dash-presence-legend">
                        <div class="legend-card">
                            <div class="legend-header"><i class="dot inside"></i> Inside Zone</div>
                            <div class="legend-nums"><strong>' . number_format($insideCount) . '</strong><span>' . $insidePct . '%</span></div>
                        </div>
                        <div class="legend-card">
                            <div class="legend-header"><i class="dot pending"></i> Verifying</div>
                            <div class="legend-nums"><strong>' . number_format($pendingCount) . '</strong><span>' . $pendingPct . '%</span></div>
                        </div>
                        <div class="legend-card">
                            <div class="legend-header"><i class="dot outside"></i> Outside Boundary</div>
                            <div class="legend-nums"><strong>' . number_format($outsideCount) . '</strong><span>' . $outsidePct . '%</span></div>
                        </div>
                    </div>
                </div>
            </article>

            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">REAL-TIME STREAM</span>
                        <h3>Live Attendance Feed</h3>
                    </div>
                    <a class="dash-card-link" href="?page=presence">Presence Stream &rarr;</a>
                </header>
                <ul class="dash-activity-stream">
                    ' . ($activityList ?: '<li class="dash-empty">No attendee scans recorded yet. Attendees will appear here in real-time as they are scanned.</li>') . '
                </ul>
            </article>
        </section>

        <section class="dash-split">
            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">HOURLY VELOCITY</span>
                        <h3>Arrival Pattern & Velocity</h3>
                    </div>
                    <span class="dash-card-badge">7:00 AM &ndash; 8:00 PM</span>
                </header>
                <div class="dash-bars-wrap">
                    ' . $arrivalBars . '
                </div>
                <div class="dash-chart-footer">
                    <span><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> Peak check-in period: <strong>' . htmlspecialchars($peakWindowValue) . '</strong></span>
                </div>
            </article>

            <article class="dash-card">
                <header class="dash-card-header">
                    <div>
                        <span class="dash-card-kicker">ACADEMIC DEPARTMENTS</span>
                        <h3>Program Participation</h3>
                    </div>
                    <span class="dash-card-badge">Top Programs</span>
                </header>
                ' . $programPulse . '
            </article>
        </section>

        <section class="dash-card">
            <header class="dash-card-header">
                <div>
                    <span class="dash-card-kicker">SYSTEM LOGISTICS</span>
                    <h3>Event Overview & Policy Specifications</h3>
                </div>
                <span class="dash-badge-secure">VERIFIED</span>
            </header>
            <div class="dash-overview-grid">
                <div class="overview-item">
                    <span class="overview-label">EVENT TITLE</span>
                    <strong>' . $eventName . '</strong>
                </div>
                <div class="overview-item">
                    <span class="overview-label">SCHEDULE DATE</span>
                    <strong>' . $eventDate . '</strong>
                </div>
                <div class="overview-item">
                    <span class="overview-label">CAMPUS VENUE</span>
                    <strong>' . $eventVenue . '</strong>
                </div>
                <div class="overview-item">
                    <span class="overview-label">ORGANIZER</span>
                    <strong>' . $eventOrganizer . '</strong>
                </div>
                <div class="overview-item">
                    <span class="overview-label">ATTENDANCE MODE</span>
                    <strong>' . $eventMode . '</strong>
                </div>
                <div class="overview-item">
                    <span class="overview-label">SECURITY PROTOCOLS</span>
                    <strong class="status-positive">Anti-Duplicate & Geofence Active</strong>
                </div>
            </div>
        </section>
    </div>';
}

function renderOrganizationsPage(): string
{
    $db = getDatabaseConnection();
    $organizations = getOrganizations();
    $editId = isset($_GET['edit_organization']) ? (int) $_GET['edit_organization'] : 0;
    $editOrg = null;

    if ($editId > 0) {
        $stmt = $db->prepare('SELECT * FROM organizations WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $editId]);
        $editOrg = $stmt->fetch();
    }

    $rows = '';
    foreach ($organizations as $org) {
        $rows .= '<tr><td>' . htmlspecialchars($org['name']) . '</td><td>Active</td><td><div class="btn-row"><a class="button secondary" href="?page=organizations&edit_organization=' . (int) $org['id'] . '">Edit</a><form method="POST" style="display:inline; margin:0;">' . csrfField() . '<input type="hidden" name="action" value="delete_organization"><input type="hidden" name="organization_id" value="' . (int) $org['id'] . '"><button class="button" type="submit" style="background:#c53939; border-color:#c53939;">Delete</button></form></div></td></tr>';
    }

    $formAction = $editOrg ? 'update_organization' : 'create_organization';
    $hiddenField = $editOrg ? '<input type="hidden" name="organization_id" value="' . (int) $editOrg['id'] . '">' : '';
    $formTitle = $editOrg ? 'Edit Organization' : 'Create Organization';
    $submitText = $editOrg ? 'Update Organization' : 'Add Organization';
    $cancelLink = $editOrg ? '<a class="button secondary" href="?page=organizations">Cancel</a>' : '';
    $orgNameValue = $editOrg ? htmlspecialchars((string) $editOrg['name']) : '';

    $bulkDelete = '<form method="POST" style="margin-top: 18px;">' . csrfField() . '<input type="hidden" name="action" value="delete_all_organizations"><button class="button" type="submit" style="background:#c53939; border-color:#c53939;">Delete All Organizations</button></form>';

    return '<div class="grid-2"><div class="panel"><h3>' . $formTitle . '</h3><form method="POST" class="form-grid" style="margin-top: 18px;">' . csrfField() . '<input type="hidden" name="action" value="' . htmlspecialchars($formAction) . '">' . $hiddenField . '<label>Organization Name<input type="text" name="name" value="' . $orgNameValue . '" required placeholder="e.g. IT Society"></label><div class="btn-row"><button class="button" type="submit">' . $submitText . '</button>' . $cancelLink . '</div></form></div><div class="panel"><h3>Organization Directory</h3>' . ($organizations ? $bulkDelete : '') . '<table><thead><tr><th>Name</th><th>Status</th><th>Action</th></tr></thead><tbody>' . ($rows ?: '<tr><td colspan="3">No organizations created yet.</td></tr>') . '</tbody></table></div></div>';
}

function renderEventsPage(): string
{
    $db = getDatabaseConnection();
    $events = $db->query('SELECT * FROM events ORDER BY event_date DESC')->fetchAll();

    $rows = '';
    $editEventId = isset($_GET['edit_event']) ? (int) $_GET['edit_event'] : 0;
    $editData = null;

    if ($editEventId > 0) {
        $stmt = $db->prepare('SELECT * FROM events WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $editEventId]);
        $editData = $stmt->fetch();
    }

    foreach ($events as $event) {
        $summary = getEventSummary((int) $event['id']);
        $rows .= '<tr><td>' . htmlspecialchars($event['name']) . '</td><td>' . htmlspecialchars($event['event_date']) . '</td><td>' . htmlspecialchars($event['venue']) . '</td><td>' . (int) ($summary['present'] ?? 0) . '</td><td>' . number_format((float) ($summary['attendance_rate'] ?? 0), 2) . '%</td><td>' . statusBadge($event['status']) . '</td><td><div class="btn-row"><a class="button secondary" href="?page=events&edit_event=' . (int) $event['id'] . '">Edit</a><form method="POST" style="display:inline; margin:0;">' . csrfField() . '<input type="hidden" name="action" value="delete_event"><input type="hidden" name="event_id" value="' . (int) $event['id'] . '"><button class="button" type="submit" style="background:#c53939; border-color:#c53939;">Delete</button></form></div></td></tr>';
    }

    $selectedEvent = $editData ?: [
        'name' => '',
        'description' => '',
        'event_date' => date('Y-m-d'),
        'start_time' => '08:00',
        'end_time' => '17:00',
        'venue' => 'PSU ACC Gymnasium',
        'organizer' => 'Student Affairs Office',
        'attendance_mode' => 'Barcode + Student ID',
        'status' => 'active',
        'latitude' => 16.1482,
        'longitude' => 119.9851,
        'radius_meters' => 100,
        'presence_verification' => 1,
        'verification_interval_minutes' => 15,
        'minimum_required_presence' => 80,
        'require_checkout' => 1,
    ];

    $formAction = $editData ? 'update_event' : 'create_event';
    $eventIdField = $editData ? '<input type="hidden" name="event_id" value="' . (int) $editData['id'] . '">' : '';
    $formTitle = $editData ? 'Edit Event' : 'Create Event';
    $submitText = $editData ? 'Update Event' : 'Create Event';
    $cancelLink = $editData ? '<a class="button secondary" href="?page=events">Cancel</a>' : '';

    if (empty($events)) {
        $content = '<div class="grid-3"><div class="panel"><h3>' . $formTitle . '</h3><form method="POST" class="form-grid" style="grid-template-columns: 1fr 1fr; margin-top: 18px;">' . csrfField() . $eventIdField . '<input type="hidden" name="action" value="' . htmlspecialchars($formAction) . '"><label>Event Name<input type="text" name="name" value="' . htmlspecialchars((string) $selectedEvent['name']) . '" required></label><label>Event Date<input type="date" name="event_date" value="' . htmlspecialchars((string) $selectedEvent['event_date']) . '"></label><label>Start Time<input type="time" name="start_time" value="' . htmlspecialchars((string) $selectedEvent['start_time']) . '"></label><label>End Time<input type="time" name="end_time" value="' . htmlspecialchars((string) $selectedEvent['end_time']) . '"></label><label>Venue<input type="text" name="venue" value="' . htmlspecialchars((string) $selectedEvent['venue']) . '"></label><label>Organizer<input type="text" name="organizer" value="' . htmlspecialchars((string) $selectedEvent['organizer']) . '"></label><label style="grid-column: 1 / -1;">Description<textarea name="description">' . htmlspecialchars((string) $selectedEvent['description']) . '</textarea></label><label style="grid-column: 1 / -1;">Attendance Mode<select name="attendance_mode"><option ' . (($selectedEvent['attendance_mode'] ?? 'Barcode + Student ID') === 'Barcode + Student ID' ? 'selected' : '') . '>Barcode + Student ID</option><option ' . (($selectedEvent['attendance_mode'] ?? 'Barcode + Student ID') === 'Student ID only' ? 'selected' : '') . '>Student ID only</option></select></label><div style="grid-column: 1 / -1; display:flex; gap:12px; flex-wrap:wrap;"><button class="button" type="submit">' . $submitText . '</button>' . $cancelLink . '</div></form></div><div class="panel"><h3>No active event</h3><p class="muted">There are no events in the system yet. Create your first event to begin attendance tracking.</p></div><div class="panel"><h3>Event Modules</h3><p class="muted">The scanner, analytics, and presence tools will become available after an event is created.</p></div></div>';
        return $content;
    }

    $content = '<div class="grid-3"><div class="panel"><h3>' . $formTitle . '</h3><form method="POST" class="form-grid" style="grid-template-columns: 1fr 1fr; margin-top: 18px;">' . csrfField() . $eventIdField . '<input type="hidden" name="action" value="' . htmlspecialchars($formAction) . '"><label>Event Name<input type="text" name="name" value="' . htmlspecialchars((string) $selectedEvent['name']) . '" required></label><label>Event Date<input type="date" name="event_date" value="' . htmlspecialchars((string) $selectedEvent['event_date']) . '"></label><label>Start Time<input type="time" name="start_time" value="' . htmlspecialchars((string) $selectedEvent['start_time']) . '"></label><label>End Time<input type="time" name="end_time" value="' . htmlspecialchars((string) $selectedEvent['end_time']) . '"></label><label>Venue<input type="text" name="venue" value="' . htmlspecialchars((string) $selectedEvent['venue']) . '"></label><label>Organizer<input type="text" name="organizer" value="' . htmlspecialchars((string) $selectedEvent['organizer']) . '"></label><label style="grid-column: 1 / -1;">Description<textarea name="description">' . htmlspecialchars((string) $selectedEvent['description']) . '</textarea></label><label style="grid-column: 1 / -1;">Attendance Mode<select name="attendance_mode"><option ' . (($selectedEvent['attendance_mode'] ?? 'Barcode + Student ID') === 'Barcode + Student ID' ? 'selected' : '') . '>Barcode + Student ID</option><option ' . (($selectedEvent['attendance_mode'] ?? 'Barcode + Student ID') === 'Student ID only' ? 'selected' : '') . '>Student ID only</option></select></label><div style="grid-column: 1 / -1; display:flex; gap:12px; flex-wrap:wrap;"><button class="button" type="submit">' . $submitText . '</button>' . $cancelLink . '</div></form></div><div class="panel"><h3>Event Dashboard</h3><div class="stat-card success"><div class="label">Status</div><div class="value">ACTIVE</div></div><ul class="list" style="margin-top: 18px;"><li><span>Registered</span><strong>1,250</strong></li><li><span>Present</span><strong>1,087</strong></li><li><span>Absent</span><strong>163</strong></li><li><span>Attendance Rate</span><strong>86.96%</strong></li></ul></div><div class="panel"><h3>Event Modules</h3><div class="btn-row" style="margin-top: 12px;"><a class="button" href="?page=scanner">Open Scanner</a><a class="button secondary" href="?page=analytics">Live Monitor</a></div><div class="btn-row" style="margin-top: 12px;"><a class="button secondary" href="?page=reports">Generate Report</a></div></div></div><div class="panel" style="margin-top: 24px;"><h3>Event List</h3><table><thead><tr><th>Event</th><th>Date</th><th>Venue</th><th>Present</th><th>Rate</th><th>Status</th><th>Actions</th></tr></thead><tbody>' . $rows . '</tbody></table></div>';

    return $content;
}

function renderPresenceMonitoringPage(): string
{
    $db = getDatabaseConnection();
    $event = activeEvent();
    if (!$event) {
        return '<div class="panel"><h3>No active event</h3><p class="muted">Create or activate an event to begin presence verification monitoring.</p></div>';
    }

    $geofence = getEventGeofence((int) $event['id']);
    $presenceSummary = getPresenceStatusSummary((int) $event['id']);
    $stmt = $db->prepare('SELECT pv.*, s.full_name, s.student_id FROM presence_verifications pv JOIN students s ON pv.student_id = s.id WHERE pv.event_id = :event_id ORDER BY pv.verified_at DESC LIMIT 10');
    $stmt->execute([':event_id' => $event['id']]);
    $items = '';
    foreach ($stmt->fetchAll() as $row) {
        $badge = $row['status'] === 'inside' ? 'success' : ($row['status'] === 'outside' ? 'danger' : 'warning');
        $items .= '<li><span><strong>' . htmlspecialchars($row['full_name']) . '</strong><br><small>' . htmlspecialchars($row['student_id']) . '</small></span><span class="badge ' . $badge . '">' . strtoupper(htmlspecialchars($row['status'])) . '</span></li>';
    }

    $geofenceText = $geofence ? 'Lat ' . $geofence['latitude'] . ', Lng ' . $geofence['longitude'] . ', Radius ' . $geofence['radius_meters'] . 'm' : 'Geofence not configured';

    return '<div class="grid-3"><div class="panel"><h3>Presence Overview</h3><ul class="list"><li><span>Inside Event Zone</span><strong>' . (int) $presenceSummary['inside'] . '</strong></li><li><span>Outside Geofence</span><strong>' . (int) $presenceSummary['outside'] . '</strong></li><li><span>Pending Verification</span><strong>' . (int) $presenceSummary['pending'] . '</strong></li></ul></div><div class="panel"><h3>Event Geofence</h3><p class="muted">' . htmlspecialchars($event['name']) . '</p><ul class="list"><li><span>Location</span><strong>' . htmlspecialchars($event['venue']) . '</strong></li><li><span>Geofence</span><strong>' . htmlspecialchars($geofenceText) . '</strong></li><li><span>Verification Interval</span><strong>' . (int) ($event['verification_interval_minutes'] ?? 15) . ' mins</strong></li></ul></div><div class="panel"><h3>Monitor Controls</h3><form method="POST" class="form-grid">' . csrfField() . '<input type="hidden" name="action" value="save_geofence"><label>Event<select name="event_id"><option value="' . $event['id'] . '">' . htmlspecialchars($event['name']) . '</option></select></label><label>Latitude<input type="number" step="any" name="latitude" value="' . htmlspecialchars((string) ($geofence['latitude'] ?? $event['latitude'] ?? 16.1482)) . '"></label><label>Longitude<input type="number" step="any" name="longitude" value="' . htmlspecialchars((string) ($geofence['longitude'] ?? $event['longitude'] ?? 119.9851)) . '"></label><label>Radius (m)<input type="number" name="radius_meters" value="' . htmlspecialchars((string) ($geofence['radius_meters'] ?? $event['radius_meters'] ?? 100)) . '"></label><button class="button" type="submit">Update Geofence</button></form></div></div><div class="panel" style="margin-top: 24px;"><h3>Presence Timeline</h3><ul class="list">' . ($items ?: '<li><span>No presence verification entries yet.</span></li>') . '</ul></div>';
}

function renderStudentsPage(): string
{
    $db = getDatabaseConnection();
    $students = $db->query('SELECT s.*, p.name as program_name, o.name as organization_name FROM students s LEFT JOIN programs p ON s.program_id = p.id LEFT JOIN organizations o ON s.organization_id = o.id ORDER BY CASE o.name WHEN "DOIT" THEN 1 WHEN "SAHARA" THEN 2 WHEN "LAKBAY" THEN 3 WHEN "SYBA" THEN 4 WHEN "GEG" THEN 5 WHEN "CS" THEN 6 WHEN "TAGNAWA" THEN 7 WHEN "PRIME" THEN 8 ELSE 99 END, CASE s.year_level WHEN "First Year" THEN 1 WHEN "Second Year" THEN 2 WHEN "Third Year" THEN 3 WHEN "Fourth Year" THEN 4 ELSE 99 END, s.full_name ASC')->fetchAll();

    $rows = '';
    foreach ($students as $student) {
        $rows .= '<tr><td>' . htmlspecialchars($student['student_id']) . '</td><td>' . htmlspecialchars($student['full_name']) . '</td><td>' . htmlspecialchars($student['program_name'] ?? '-') . '</td><td>' . htmlspecialchars($student['year_level'] ?? '-') . '</td><td>' . htmlspecialchars($student['organization_name'] ?? '-') . '</td></tr>';
    }

    return '<div class="panel"><h3>Student Registry</h3><table><thead><tr><th>Student ID</th><th>Name</th><th>Program</th><th>Year</th><th>Organization</th></tr></thead><tbody>' . ($rows ?: '<tr><td colspan="5">No students configured yet.</td></tr>') . '</tbody></table></div>';
}

function renderActivityLogsPage(): string
{
    $db = getDatabaseConnection();
    $logs = $db->query('SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 30')->fetchAll();
    $rows = '';
    foreach ($logs as $log) {
        $rows .= '<tr><td>' . htmlspecialchars($log['actor']) . '</td><td>' . htmlspecialchars($log['action']) . '</td><td>' . htmlspecialchars($log['details']) . '</td><td>' . htmlspecialchars(date('M d, Y h:i A', strtotime($log['created_at']))) . '</td></tr>';
    }

    return '<div class="panel"><h3>Activity Logs</h3><table><thead><tr><th>Actor</th><th>Action</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>' . ($rows ?: '<tr><td colspan="4">No activity logs yet.</td></tr>') . '</tbody></table></div>';
}

function renderSettingsPage(): string
{
    $db = getDatabaseConnection();
    $settings = getSystemSettings();
    $campus = $settings['campus_name'] ?? 'Pangasinan State University - Alaminos City Campus';
    $threshold = $settings['attendance_threshold'] ?? '80';
    $interval = $settings['verification_interval'] ?? '15';
    $radius = $settings['event_radius_meters'] ?? '100';
    $timeout = $settings['session_timeout_minutes'] ?? '30';
    $editAdminId = isset($_GET['edit_admin']) ? (int) $_GET['edit_admin'] : 0;
    $editAdmin = null;
    if ($editAdminId > 0) {
        $stmt = $db->prepare('SELECT * FROM users WHERE id = :id AND role IN ("admin", "superadmin") LIMIT 1');
        $stmt->execute([':id' => $editAdminId]);
        $editAdmin = $stmt->fetch();
    }

    $adminUsers = $db->query("SELECT id, username, full_name, role, created_at FROM users WHERE role IN ('admin', 'superadmin') ORDER BY role ASC, full_name ASC")->fetchAll();
    $adminRows = '';
    foreach ($adminUsers as $admin) {
        $roleLabel = $admin['role'] === 'superadmin' ? 'Super Admin' : 'Admin';
        $adminRows .= '<tr><td>' . htmlspecialchars($admin['full_name']) . '</td><td>' . htmlspecialchars($admin['username']) . '</td><td>' . htmlspecialchars($roleLabel) . '</td><td>' . htmlspecialchars(date('M d, Y', strtotime($admin['created_at']))) . '</td><td><div class="btn-row"><a class="button secondary" href="?page=settings&edit_admin=' . (int) $admin['id'] . '">Edit</a><form method="POST" style="display:inline; margin:0;">' . csrfField() . '<input type="hidden" name="action" value="delete_admin_account"><input type="hidden" name="admin_id" value="' . (int) $admin['id'] . '"><button class="button" type="submit" style="background:#c53939; border-color:#c53939;">Delete</button></form></div></td></tr>';
    }

    $formAction = $editAdmin ? 'update_admin_account' : 'create_admin_account';
    $formTitle = $editAdmin ? 'Update Admin Account' : 'Create Admin Account';
    $formButton = $editAdmin ? 'Update Admin' : 'Create Admin';
    $fullNameValue = htmlspecialchars($editAdmin['full_name'] ?? '');
    $usernameValue = htmlspecialchars($editAdmin['username'] ?? '');
    $selectedRole = $editAdmin['role'] ?? 'admin';
    $passwordPlaceholder = $editAdmin ? 'Leave blank to keep current password' : 'Minimum 6 characters';
    $hiddenField = $editAdmin ? '<input type="hidden" name="admin_id" value="' . (int) $editAdmin['id'] . '">' : '';
    $cancelEdit = $editAdmin ? '<a class="button secondary" href="?page=settings">Cancel edit</a>' : '';

    return '<div class="grid-2"><div class="panel"><h3>System Settings</h3><form method="POST" class="form-grid" style="grid-template-columns: 1fr 1fr; margin-top: 18px;">' . csrfField() . '<input type="hidden" name="action" value="save_settings"><label>Campus Name<input type="text" name="campus_name" value="' . htmlspecialchars($campus) . '"></label><label>Attendance Threshold (%)<input type="number" name="attendance_threshold" value="' . htmlspecialchars($threshold) . '"></label><label>Verification Interval (min)<input type="number" name="verification_interval" value="' . htmlspecialchars($interval) . '"></label><label>Default Event Radius (m)<input type="number" name="event_radius_meters" value="' . htmlspecialchars($radius) . '"></label><label>Session Timeout (min)<input type="number" name="session_timeout_minutes" value="' . htmlspecialchars($timeout) . '"></label><div style="grid-column: 1 / -1;"><button class="button" type="submit">Save Settings</button></div></form></div><div class="panel"><h3>' . htmlspecialchars($formTitle) . '</h3><form method="POST" class="form-grid" style="margin-top: 18px;">' . csrfField() . '<input type="hidden" name="action" value="' . htmlspecialchars($formAction) . '">' . $hiddenField . '<label>Full Name<input type="text" name="full_name" value="' . $fullNameValue . '" placeholder="e.g. Juana Dela Cruz" required></label><label>Username<input type="text" name="username" value="' . $usernameValue . '" placeholder="e.g. juana.admin" required></label><label>Role<select name="role"><option value="admin" ' . ($selectedRole === 'admin' ? 'selected' : '') . '>Admin</option><option value="superadmin" ' . ($selectedRole === 'superadmin' ? 'selected' : '') . '>Super Admin</option></select></label><label>Password<input type="password" name="password" placeholder="' . htmlspecialchars($passwordPlaceholder) . '"></label><div class="btn-row">' . $cancelEdit . '<button class="button" type="submit">' . htmlspecialchars($formButton) . '</button></div></form><table style="margin-top: 18px;"><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Created</th><th>Action</th></tr></thead><tbody>' . ($adminRows ?: '<tr><td colspan="5">No admin accounts found.</td></tr>') . '</tbody></table></div></div>';
}

function renderScannerPage(): string
{
    $db = getDatabaseConnection();
    $events = $db->query('SELECT * FROM events ORDER BY event_date DESC')->fetchAll();
    $activeEvent = activeEvent();
    $selectedEventId = $_POST['event_id'] ?? ($activeEvent['id'] ?? 0);
    $eventTitle = $activeEvent['name'] ?? 'UNIVERSITY WEEK 2026';

    $eventOptions = '';
    foreach ($events as $event) {
        $selected = $event['id'] == $selectedEventId ? 'selected' : '';
        $eventOptions .= '<option value="' . htmlspecialchars((string) $event['id']) . '" ' . $selected . '>' . htmlspecialchars($event['name']) . '</option>';
    }
    $eventTitleLabel = strtoupper(htmlspecialchars($eventTitle));

    $content = <<<HTML
<div class="scanner-box">
    <div class="camera-sim">
        <div class="camera-sim-inner">
            <h3>{$eventTitleLabel}</h3>
            <p>BARCODE SCANNER</p>
            <div class="scan-line"></div>
            <video id="camera-preview" autoplay playsinline muted style="display:none; width:100%; height:100%; object-fit:cover; border-radius:12px;"></video>
        </div>
    </div>
    <div class="panel">
        <h3>Barcode Verification</h3>
        <div class="panel" id="scan-support" style="margin-bottom: 16px; padding: 12px 16px; background: #f8fbff; border: 1px solid #dfe9f7; border-radius: 12px;">
            <strong>Barcode-first attendance</strong>
            <p class="muted" style="margin: 8px 0 0;">Optimized for barcode scanning on phones, tablets, laptops, webcams, and USB barcode scanners.</p>
        </div>
        <div id="scan-status" data-tone="info" style="margin-bottom: 12px; font-size: 13px; color: #1d4ed8;">Waiting for barcode input...</div>
        <form method="POST" style="display: grid; gap: 16px; margin-top: 18px;">
            ' . csrfField() . '
            <input type="hidden" name="action" value="scan_attendance">
            <label>Event
                <select name="event_id">
                    {$eventOptions}
                </select>
            </label>
            <label>Student ID / Barcode Data
                <input id="barcode-input" type="text" name="student_id" placeholder="Scan barcode or type PSU ID" required>
            </label>
            <div class="btn-row">
                <button class="button" type="submit">Record Attendance</button>
                <button id="start-camera-scan" class="button secondary" type="button">Camera Scanner</button>
                <button class="button secondary" type="button" onclick="document.getElementById('barcode-input').focus(); return false;">Manual Entry</button>
            </div>
        </form>
    </div>
</div>
<script>
    (function () {
        const statusEl = document.getElementById('scan-status');
        const input = document.getElementById('barcode-input');
        const cameraButton = document.getElementById('start-camera-scan');
        const cameraView = document.getElementById('camera-preview');
        let stream = null;
        let detector = null;
        let scannerTimer = null;

        function setStatus(message, tone) {
            if (!statusEl) return;
            statusEl.textContent = message;
            statusEl.dataset.tone = tone || 'info';
            statusEl.style.color = tone === 'success' ? '#166534' : tone === 'warning' ? '#b45309' : '#1d4ed8';
        }

        function autoSubmit(value) {
            const cleaned = (value || '').trim();
            if (!cleaned) return;
            input.value = cleaned;
            setStatus('Barcode captured: ' + cleaned, 'success');
            setTimeout(function () {
                const form = input.closest('form');
                if (form) {
                    form.requestSubmit ? form.requestSubmit() : form.submit();
                }
            }, 250);
        }

        if (input) {
            const finalizeScan = function (force) {
                const value = input.value.trim();
                if (!value || (value.length < 6 && !force)) {
                    return;
                }
                autoSubmit(value);
            };

            input.addEventListener('keydown', function (event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    finalizeScan(true);
                    return;
                }

                if (event.key === 'Tab' || event.key === 'Shift') {
                    return;
                }

                if (event.key.length === 1) {
                    clearTimeout(scannerTimer);
                    scannerTimer = setTimeout(function () {
                        finalizeScan(false);
                    }, 120);
                }
            });

            input.addEventListener('input', function () {
                clearTimeout(scannerTimer);
                scannerTimer = setTimeout(function () {
                    finalizeScan(false);
                }, 120);
            });

            input.addEventListener('paste', function () {
                clearTimeout(scannerTimer);
                scannerTimer = setTimeout(function () {
                    finalizeScan(true);
                }, 100);
            });
        }

        if ('BarcodeDetector' in window && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            const support = document.getElementById('scan-support');
            if (support) {
                support.innerHTML = '<strong>Barcode-ready</strong><p class="muted" style="margin: 8px 0 0;">Live browser barcode detection is available for supported phone, tablet, laptop, and webcam devices.</p>';
            }
        }

        async function startCameraScanner() {
            if (!("BarcodeDetector" in window)) {
                setStatus('This browser does not support live barcode detection. Use a USB barcode scanner or manual input instead.', 'warning');
                return;
            }

            try {
                setStatus('Opening camera for barcode detection...', 'info');
                stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                if (cameraView) {
                    cameraView.srcObject = stream;
                    cameraView.style.display = 'block';
                    cameraView.play();
                }

                detector = new BarcodeDetector({ formats: ['code_128', 'code_39', 'code_93', 'ean_13', 'ean_8', 'itf', 'upc_a', 'upc_e', 'codabar'] });

                const scanFrame = async function () {
                    if (!detector || !cameraView || !cameraView.srcObject) {
                        return;
                    }

                    try {
                        const barcodes = await detector.detect(cameraView);
                        if (barcodes && barcodes.length > 0) {
                            const value = barcodes[0].rawValue;
                            if (value) {
                                autoSubmit(value);
                                if (stream) {
                                    stream.getTracks().forEach(function (track) { track.stop(); });
                                }
                                if (cameraView) {
                                    cameraView.srcObject = null;
                                    cameraView.style.display = 'none';
                                }
                                return;
                            }
                        }
                    } catch (error) {
                        setStatus('Barcode scan not detected yet. Keep camera steady.', 'warning');
                    }

                    requestAnimationFrame(scanFrame);
                };

                requestAnimationFrame(scanFrame);
            } catch (error) {
                setStatus('Camera access was blocked or unavailable. Please use manual or USB barcode entry.', 'warning');
            }
        }

        if (cameraButton) {
            cameraButton.addEventListener('click', startCameraScanner);
        }
    })();
</script>
HTML;

    return $content;
}

function renderAnalyticsPage(): string
{
    $db = getDatabaseConnection();
    $event = activeEvent();
    $eventId = $event['id'] ?? 1;

    $programStats = $db->query('SELECT p.name, COUNT(DISTINCT a.student_id) as total FROM attendance a JOIN students s ON a.student_id = s.id JOIN programs p ON s.program_id = p.id WHERE a.event_id = ' . (int) $eventId . ' GROUP BY p.name ORDER BY total DESC')->fetchAll();
    $orgStats = $db->query('SELECT o.name, COUNT(DISTINCT a.student_id) as total FROM attendance a JOIN students s ON a.student_id = s.id JOIN organizations o ON s.organization_id = o.id WHERE a.event_id = ' . (int) $eventId . ' GROUP BY o.name ORDER BY total DESC')->fetchAll();
    $yearStats = $db->query('SELECT s.year_level, COUNT(DISTINCT a.student_id) as total FROM attendance a JOIN students s ON a.student_id = s.id WHERE a.event_id = ' . (int) $eventId . ' GROUP BY s.year_level ORDER BY total DESC')->fetchAll();
    $insights = getAttendanceInsights($eventId);

    $maxProgram = 1; if ($programStats) { $maxProgram = max(array_column($programStats, 'total')); }
    $programChart = '';
    foreach ($programStats as $row) {
        $width = $maxProgram > 0 ? round(($row['total'] / $maxProgram) * 100) : 0;
        $programChart .= '<div class="chart-item"><strong>' . htmlspecialchars($row['name']) . '</strong><div class="bar" style="width: ' . $width . '%"></div><span>' . $row['total'] . '</span></div>';
    }

    $orgChart = '';
    $maxOrg = 1; if ($orgStats) { $maxOrg = max(array_column($orgStats, 'total')); }
    foreach ($orgStats as $row) {
        $width = $maxOrg > 0 ? round(($row['total'] / $maxOrg) * 100) : 0;
        $orgChart .= '<div class="chart-item"><strong>' . htmlspecialchars($row['name']) . '</strong><div class="bar" style="width: ' . $width . '%"></div><span>' . $row['total'] . '</span></div>';
    }

    $yearChart = '';
    $maxYear = 1; if ($yearStats) { $maxYear = max(array_column($yearStats, 'total')); }
    foreach ($yearStats as $row) {
        $width = $maxYear > 0 ? round(($row['total'] / $maxYear) * 100) : 0;
        $yearChart .= '<div class="chart-item"><strong>' . htmlspecialchars($row['year_level']) . '</strong><div class="bar" style="width: ' . $width . '%"></div><span>' . $row['total'] . '</span></div>';
    }

    $summary = getEventSummary($eventId);

    $insightHtml = '<div class="panel insights-panel"><h3>Automated Attendance Insights</h3><p><strong>' . htmlspecialchars($insights['event_name']) . '</strong></p><ul class="list"><li><span>Attendance rate</span><strong>' . number_format($insights['attendance_rate'], 2) . '%</strong></li><li><span>Peak attendance window</span><strong>' . htmlspecialchars($insights['peak_hour']) . ':00 - ' . htmlspecialchars((string) ((int) $insights['peak_hour'] + 1)) . ':00</strong></li><li><span>Top program</span><strong>' . htmlspecialchars($insights['top_program']) . '</strong></li><li><span>Top organization</span><strong>' . htmlspecialchars($insights['top_organization']) . '</strong></li><li><span>Duplicate attempts prevented</span><strong>' . (int) $insights['duplicate_attempts'] . '</strong></li></ul></div>';

    return '<div class="grid-4"><div class="stat-card primary"><div class="label">Overall Attendance</div><div class="value">' . number_format($summary['attendance_rate'], 2) . '%</div></div><div class="stat-card success"><div class="label">Peak Arrival Time</div><div class="value">' . htmlspecialchars($insights['peak_hour']) . ':00 - ' . htmlspecialchars((string) ((int) $insights['peak_hour'] + 1)) . ':00</div></div><div class="stat-card warning"><div class="label">Highest Attendance Program</div><div class="value">' . htmlspecialchars($insights['top_program']) . '</div></div><div class="stat-card danger"><div class="label">Highest Attendance Organization</div><div class="value">' . htmlspecialchars($insights['top_organization']) . '</div></div></div><div class="grid-3" style="margin-top: 24px;"><div class="panel"><h3>Attendance by Program</h3><div class="chart-row">' . $programChart . '</div></div><div class="panel"><h3>Attendance by Organization</h3><div class="chart-row">' . $orgChart . '</div></div><div class="panel"><h3>Attendance by Year Level</h3><div class="chart-row">' . $yearChart . '</div></div></div><div style="margin-top: 24px;">' . $insightHtml . '</div>';
}

function renderReportsPage(): string
{
    $db = getDatabaseConnection();
    $event = activeEvent();
    $summary = $event ? getEventSummary((int) $event['id']) : ['registered' => 0, 'present' => 0, 'absent' => 0, 'attendance_rate' => 0];

    if (!$event) {
        return '<div class="report-hero">
            <div>
                <span class="panel-kicker">Institutional Reporting</span>
                <h2>Event Attendance Report</h2>
            </div>
        </div>
        <div class="panel"><div style="padding: 26px; border: 1px solid var(--line); border-radius: 14px; background: #fafcff;">
            <h3>No active event</h3>
            <p class="muted">Create and activate an event before generating attendance reports. The system is intentionally showing no report data until there is a real event to monitor.</p>
        </div></div>';
    }

    return '<div class="report-hero">
        <div>
            <span class="panel-kicker">Institutional Reporting</span>
            <h2>Event Attendance Report</h2>
        </div>
        <div class="hero-actions">
            <a class="button" href="?page=reports&export=pdf">Export PDF</a>
            <a class="button secondary" href="?page=reports&export=excel">Export Excel</a>
            <a class="button secondary" href="?page=reports&export=print">Print</a>
        </div>
    </div>
    <div class="panel"><div style="padding: 26px; border: 1px solid var(--line); border-radius: 14px; background: #fafcff;">
        <h2>' . htmlspecialchars(strtoupper($event['name'] ?? 'EVENT')) . '</h2>
        <p class="muted">' . htmlspecialchars($event['venue'] ?? 'Venue not specified') . '</p>
        <h3>ATTENDANCE REPORT</h3>
        <p><strong>Event:</strong> ' . htmlspecialchars($event['name'] ?? 'Not available') . '</p>
        <p><strong>Date:</strong> ' . htmlspecialchars($event['event_date'] ?? 'Not available') . '</p>
        <p><strong>Venue:</strong> ' . htmlspecialchars($event['venue'] ?? 'Not available') . '</p>
        <hr>
        <ul class="list"><li><span>Registered</span><strong>' . (int) $summary['registered'] . '</strong></li><li><span>Present</span><strong>' . (int) $summary['present'] . '</strong></li><li><span>Absent</span><strong>' . (int) $summary['absent'] . '</strong></li><li><span>Attendance Rate</span><strong>' . number_format((float) $summary['attendance_rate'], 2) . '%</strong></li></ul>
    </div></div>';
}

function renderHistoryPage(): string
{
    $user = currentUser();
    $db = getDatabaseConnection();
    $student = $db->prepare('SELECT * FROM students WHERE email = :email OR student_id = :student_id LIMIT 1');
    $student->execute([':email' => $user['username'] . '@psu.edu.ph', ':student_id' => $user['username']]);
    $record = $student->fetch();

    if (!$record) {
        $fallback = $db->prepare('SELECT * FROM students WHERE full_name = :name LIMIT 1');
        $fallback->execute([':name' => $user['full_name']]);
        $record = $fallback->fetch();
    }

    if (!$record && $user['username'] === 'student') {
        $db->prepare('INSERT OR IGNORE INTO students (student_id, full_name, program_id, organization_id, year_level, email, phone) VALUES (:student_id, :full_name, 1, 1, "2A", :email, "09171112222")')->execute([
            ':student_id' => 'student',
            ':full_name' => $user['full_name'],
            ':email' => 'student@psu.edu.ph',
        ]);
        $student = $db->prepare('SELECT * FROM students WHERE email = :email OR student_id = :student_id LIMIT 1');
        $student->execute([':email' => 'student@psu.edu.ph', ':student_id' => 'student']);
        $record = $student->fetch();
    }

    if (!$record) {
        return '<div class="panel"><h3>No student record found</h3><p class="muted">Student attendance history cannot be displayed until a verified student profile is linked.</p></div>';
    }

    $history = $db->prepare('SELECT e.name, a.status, a.scanned_at FROM attendance a JOIN events e ON a.event_id = e.id WHERE a.student_id = :student_id ORDER BY a.scanned_at DESC');
    $history->execute([':student_id' => $record['id']]);
    $rows = $history->fetchAll();

    $items = '';
    foreach ($rows as $row) {
        $badge = $row['status'] === 'present' ? 'success' : 'warning';
        $items .= '<li><span><strong>' . htmlspecialchars($row['name']) . '</strong><br><small>' . htmlspecialchars(date('M d, Y', strtotime($row['scanned_at']))) . '</small></span><span class="badge ' . $badge . '">' . strtoupper($row['status']) . '</span></li>';
    }

    if ($items === '') {
        $items = '<li><span>No attendance history available.</span></li>';
    }

    return '<div class="report-hero"><div><span class="panel-kicker">Student Records</span><h2>My Attendance</h2></div></div><div class="panel"><ul class="list">' . $items . '</ul></div>';
}

function renderStudentMobileAppPage(): string
{
    $db = getDatabaseConnection();
    $user = currentUser();
    $student = $db->prepare('SELECT * FROM students WHERE email = :email OR student_id = :student_id LIMIT 1');
    $student->execute([':email' => $user['username'] . '@psu.edu.ph', ':student_id' => $user['username']]);
    $record = $student->fetch();

    if (!$record && $user['username'] === 'student') {
        $db->prepare('INSERT OR IGNORE INTO students (student_id, full_name, program_id, organization_id, year_level, email, phone) VALUES (:student_id, :full_name, 1, 1, "2A", :email, "09171112222")')->execute([
            ':student_id' => 'student',
            ':full_name' => $user['full_name'],
            ':email' => 'student@psu.edu.ph',
        ]);
        $student = $db->prepare('SELECT * FROM students WHERE email = :email OR student_id = :student_id LIMIT 1');
        $student->execute([':email' => 'student@psu.edu.ph', ':student_id' => 'student']);
        $record = $student->fetch();
    }

    if (!$record) {
        return '<div class="panel"><h3>Student account not linked</h3><p class="muted">Your profile must be linked before the student mobile app can display your attendance access.</p></div>';
    }

    $events = $db->query('SELECT * FROM events ORDER BY event_date DESC LIMIT 3')->fetchAll();
    $history = $db->prepare('SELECT e.name, a.status, a.scanned_at FROM attendance a JOIN events e ON a.event_id = e.id WHERE a.student_id = :student_id ORDER BY a.scanned_at DESC LIMIT 4');
    $history->execute([':student_id' => $record['id']]);
    $historyRows = $history->fetchAll();

    $eventCards = '';
    foreach ($events as $event) {
        $eventCards .= '<div class="mini-card"><strong>' . htmlspecialchars($event['name']) . '</strong><small>' . htmlspecialchars($event['event_date']) . '</small><span class="badge neutral">' . htmlspecialchars(strtoupper($event['status'])) . '</span></div>';
    }

    $attendanceCards = '';
    foreach ($historyRows as $row) {
        $attendanceCards .= '<li><span><strong>' . htmlspecialchars($row['name']) . '</strong><br><small>' . htmlspecialchars(date('M d, Y', strtotime($row['scanned_at']))) . '</small></span><span class="badge success">' . strtoupper(htmlspecialchars($row['status'])) . '</span></li>';
    }

    return '<div class="student-app-shell"><div class="student-app-phone"><div class="student-app-header"><div><span class="panel-kicker">PSU Mobile</span><h2>Student App</h2></div><div class="avatar-pill">' . htmlspecialchars(substr($record['full_name'], 0, 1)) . '</div></div><div class="student-app-profile"><strong>' . htmlspecialchars($record['full_name']) . '</strong><small>' . htmlspecialchars($record['student_id']) . '</small></div><div class="student-metrics"><div class="mini-stat"><span>Events</span><strong>' . count($events) . '</strong></div><div class="mini-stat"><span>Checked-in</span><strong>' . count($historyRows) . '</strong></div><div class="mini-stat"><span>Profile</span><strong>Active</strong></div></div><div class="student-section"><h3>Upcoming events</h3>' . ($eventCards ?: '<p class="muted">No events available.</p>') . '</div><div class="student-section"><h3>Recent attendance</h3><ul class="list">' . ($attendanceCards ?: '<li><span>No attendance history yet.</span></li>') . '</ul></div></div></div>';
}

if (isset($_GET['export'])) {
    $event = activeEvent();
    $summary = $event ? getEventSummary((int) $event['id']) : ['present' => 0, 'absent' => 0, 'registered' => 0, 'attendance_rate' => 0];
    $rows = getRecentAttendance();

    if ($_GET['export'] === 'csv' || $_GET['export'] === 'excel') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="attendance_report_' . $_GET['export'] . '.csv"');
        if (!$event) {
            echo "Event,Student Name,Scanned At\nNo active event,,\n";
            exit;
        }
        echo "Event,Student Name,Scanned At\n";
        foreach ($rows as $row) {
            echo htmlspecialchars_decode($event['name'] ?? 'No active event') . ',' . $row['full_name'] . ',' . $row['scanned_at'] . "\n";
        }
        exit;
    }

    if ($_GET['export'] === 'pdf') {
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="attendance_report.pdf"');
        if (!$event) {
            echo "%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n4 0 obj\n<< /Length 96 >>\nstream\nBT\n/F1 16 Tf\n72 740 Td\nNo active event\n0 -24 Td\n72 720 Td\nCreate an event to generate attendance data.\nET\nendstream\nendobj\n5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\nxref\n0 6\n0000000000 65535 f \n0000000010 00000 n \n0000000062 00000 n \n0000000127 00000 n \n0000000411 00000 n \n0000000715 00000 n \ntrailer\n<< /Root 1 0 R /Size 6 >>\nstartxref\n807\n%%EOF";
            exit;
        }
        echo "%PDF-1.4\n1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n4 0 obj\n<< /Length 160 >>\nstream\nBT\n/F1 18 Tf\n72 740 Td\n" . addslashes($event['name'] ?? 'Event') . "\n0 -24 Td\n/F1 12 Tf\n72 720 Td\nPresent: " . (int) ($summary['present'] ?? 0) . "\n0 -24 Td\n72 700 Td\nAttendance Rate: " . number_format((float) ($summary['attendance_rate'] ?? 0), 2) . "%\nET\nendstream\nendobj\n5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\nxref\n0 6\n0000000000 65535 f \n0000000010 00000 n \n0000000062 00000 n \n0000000127 00000 n \n0000000499 00000 n \n0000000800 00000 n \ntrailer\n<< /Root 1 0 R /Size 6 >>\nstartxref\n892\n%%EOF";
        exit;
    }

    if ($_GET['export'] === 'print') {
        echo renderReportsPage();
        exit;
    }
}

$pageContent = '';

switch ($activePage) {
    case 'dashboard':
        $role = currentUser()['role'] ?? 'admin';
        $view = $_GET['view'] ?? '';
        if ($role === 'student') {
            $pageContent = renderStudentDashboardPage();
        } elseif ($role === 'superadmin') {
            $pageContent = $view === 'operations' ? renderDashboardPage() : renderSuperAdminDashboardPage();
        } else {
            $pageContent = renderDashboardPage();
        }
        break;
    case 'organizations':
        requireRole(['admin', 'superadmin']);
        $pageContent = renderOrganizationsPage();
        break;
    case 'events':
        requireRole(['admin', 'superadmin']);
        $pageContent = renderEventsPage();
        break;
    case 'scanner':
        requireRole(['admin', 'superadmin']);
        $pageContent = renderScannerPage();
        break;
    case 'analytics':
        requireRole(['admin', 'superadmin']);
        $pageContent = renderAnalyticsPage();
        break;
    case 'presence':
        requireRole(['admin', 'superadmin']);
        $pageContent = renderPresenceMonitoringPage();
        break;
    case 'students':
        requireRole(['admin', 'superadmin']);
        $pageContent = renderStudentsPage();
        break;
    case 'activity_logs':
        requireRole(['admin', 'superadmin']);
        $pageContent = renderActivityLogsPage();
        break;
    case 'settings':
        requireRole(['superadmin']);
        $pageContent = renderSettingsPage();
        break;
    case 'reports':
        requireRole(['admin', 'superadmin']);
        $pageContent = renderReportsPage();
        break;
    case 'history':
        $pageContent = renderHistoryPage();
        break;
    case 'mobile_app':
        requireRole(['student']);
        $pageContent = renderStudentMobileAppPage();
        break;
    default:
        $role = currentUser()['role'] ?? 'admin';
        $view = $_GET['view'] ?? '';
        if ($role === 'student') {
            $pageContent = renderStudentDashboardPage();
        } elseif ($role === 'superadmin') {
            $pageContent = $view === 'operations' ? renderDashboardPage() : renderSuperAdminDashboardPage();
        } else {
            $pageContent = renderDashboardPage();
        }
        break;
}

if ($flash) {
    $flashType = htmlspecialchars($flash['type'] ?? 'info');
    $flashMsg = htmlspecialchars($flash['message'] ?? '');
    $alertIcon = match ($flashType) {
        'success' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>',
        'danger' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
        'warning' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
        default => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    };
    $pageContent = '<div class="alert alert-' . $flashType . '"><span class="alert-icon">' . $alertIcon . '</span><div class="alert-body">' . $flashMsg . '</div></div>' . $pageContent;
}

$html = renderLayout('PSU Event Monitoring System', $pageContent, ['System', ucfirst($activePage)]);
echo $html;
