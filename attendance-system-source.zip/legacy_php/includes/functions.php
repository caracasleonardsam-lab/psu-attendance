<?php
date_default_timezone_set('Asia/Manila');

if (!function_exists('csrfToken')) {
    function csrfToken(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('csrfField')) {
    function csrfField(): string
    {
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrfToken()) . '">';
    }
}

if (!function_exists('requireLogin')) {
    function requireLogin(): void
    {
        if (!isset($_SESSION['user'])) {
            header('Location: ?page=login');
            exit;
        }
    }
}

if (!function_exists('currentUser')) {
    function currentUser(): ?array
    {
        return $_SESSION['user'] ?? null;
    }
}

if (!function_exists('redirect')) {
    function redirect(string $location): void
    {
        header('Location: ' . $location);
        exit;
    }
}


function userCan(string $role): bool
{
    $user = currentUser();
    if (!$user) {
        return false;
    }

    return $user['role'] === $role || $user['role'] === 'superadmin';
}

function requireRole(array $roles): void
{
    $user = currentUser();
    if (!$user || !in_array($user['role'], $roles, true)) {
        header('Location: ?page=dashboard');
        exit;
    }
}

function logAction(string $actor, string $action, string $details = ''): void
{
    $db = getDatabaseConnection();
    $stmt = $db->prepare('INSERT INTO activity_logs (actor, action, details) VALUES (:actor, :action, :details)');
    $stmt->execute([
        ':actor' => $actor,
        ':action' => $action,
        ':details' => $details,
    ]);
}

function getPrograms(): array
{
    $db = getDatabaseConnection();
    return $db->query('SELECT * FROM programs ORDER BY name')->fetchAll();
}

function getOrganizations(): array
{
    $db = getDatabaseConnection();
    return $db->query('SELECT * FROM organizations ORDER BY name')->fetchAll();
}

function getStudents(): array
{
    $db = getDatabaseConnection();
    return $db->query('SELECT s.*, p.name as program_name, o.name as organization_name FROM students s LEFT JOIN programs p ON s.program_id = p.id LEFT JOIN organizations o ON s.organization_id = o.id ORDER BY CASE s.year_level WHEN "First Year" THEN 1 WHEN "Second Year" THEN 2 WHEN "Third Year" THEN 3 WHEN "Fourth Year" THEN 4 ELSE 99 END, p.name ASC, s.full_name ASC')->fetchAll();
}

function getLatestEvents(): array
{
    $db = getDatabaseConnection();
    return $db->query('SELECT e.*, COUNT(a.id) as attendance_count FROM events e LEFT JOIN attendance a ON a.event_id = e.id GROUP BY e.id ORDER BY e.event_date DESC')->fetchAll();
}

function getEventSummary(int $eventId): array
{
    $db = getDatabaseConnection();
    $stmt = $db->prepare('SELECT COUNT(DISTINCT student_id) as registered, COUNT(DISTINCT CASE WHEN status = "present" THEN student_id END) as present, COUNT(DISTINCT CASE WHEN status = "absent" THEN student_id END) as absent FROM attendance WHERE event_id = :event_id');
    $stmt->execute([':event_id' => $eventId]);
    $summary = $stmt->fetch() ?: ['registered' => 0, 'present' => 0, 'absent' => 0];

    $summary['registered'] = (int) ($summary['registered'] ?? 0);
    $summary['present'] = (int) ($summary['present'] ?? 0);
    $summary['absent'] = (int) ($summary['absent'] ?? 0);
    $summary['attendance_rate'] = $summary['registered'] > 0 ? round(($summary['present'] / $summary['registered']) * 100, 2) : 0;

    return $summary;
}

function getRecentAttendance(): array
{
    $db = getDatabaseConnection();
    return $db->query('SELECT a.*, s.full_name, e.name as event_name FROM attendance a JOIN students s ON a.student_id = s.id JOIN events e ON a.event_id = e.id ORDER BY a.scanned_at DESC LIMIT 10')->fetchAll();
}

function getDashboardStats(): array
{
    $db = getDatabaseConnection();
    $stats = [];
    $stats['students'] = $db->query('SELECT COUNT(*) as count FROM students')->fetch()['count'];
    $stats['events'] = $db->query('SELECT COUNT(*) as count FROM events')->fetch()['count'];
    $todayClause = isMysqlDatabase() ? 'DATE(scanned_at) = CURDATE()' : "date(scanned_at) = date('now')";
    $stats['attendance_today'] = $db->query("SELECT COUNT(*) as count FROM attendance WHERE {$todayClause}")->fetch()['count'];
    $stats['duplicate_attempts'] = $db->query('SELECT COUNT(*) as count FROM activity_logs WHERE action LIKE "%Duplicate%"')->fetch()['count'];
    $stats['active_events'] = $db->query("SELECT COUNT(*) as count FROM events WHERE status = 'active'")->fetch()['count'];


    return $stats;
}

function getEventGeofence(int $eventId): ?array
{
    $db = getDatabaseConnection();
    $stmt = $db->prepare('SELECT * FROM event_geofences WHERE event_id = :event_id ORDER BY id DESC LIMIT 1');
    $stmt->execute([':event_id' => $eventId]);
    $geofence = $stmt->fetch();

    return $geofence ?: null;
}

function getPresenceStatusSummary(int $eventId): array
{
    $db = getDatabaseConnection();
    $summary = [
        'inside' => 0,
        'outside' => 0,
        'pending' => 0,
    ];

    $rows = $db->prepare('SELECT status, COUNT(*) as total FROM presence_verifications WHERE event_id = :event_id GROUP BY status');
    $rows->execute([':event_id' => $eventId]);

    foreach ($rows->fetchAll() as $row) {
        $status = strtolower((string) $row['status']);
        if (isset($summary[$status])) {
            $summary[$status] = (int) $row['total'];
        }
    }

    return $summary;
}

function getLatestNotifications(): array
{
    $db = getDatabaseConnection();
    return $db->query('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5')->fetchAll();
}

function getSystemSettings(): array
{
    $db = getDatabaseConnection();
    $settings = [];
    foreach ($db->query('SELECT key_name, value_text FROM system_settings')->fetchAll() as $row) {
        $settings[$row['key_name']] = $row['value_text'];
    }
    return $settings;
}

function formatDateTime(string $value): string
{
    return date('M d, Y h:i A', strtotime($value));
}

function activeEvent(): ?array
{
    $db = getDatabaseConnection();
    $stmt = $db->query('SELECT * FROM events WHERE status = "active" ORDER BY event_date DESC LIMIT 1');
    $event = $stmt->fetch();

    return $event ?: null;
}

function getAttendanceInsights(int $eventId): array
{
    $db = getDatabaseConnection();
    $event = $db->prepare('SELECT * FROM events WHERE id = :id LIMIT 1');
    $event->execute([':id' => $eventId]);
    $eventData = $event->fetch();

    $summary = getEventSummary($eventId);
    $duplicateAttempts = (int) $db->query('SELECT COUNT(*) as count FROM activity_logs WHERE action LIKE "%Duplicate%"')->fetch()['count'];
    $hourExpr = isMysqlDatabase() ? "DATE_FORMAT(scanned_at, '%H:00')" : 'strftime("%H:00", scanned_at)';
    $peakHour = $db->query("SELECT {$hourExpr} as hour, COUNT(*) as total FROM attendance WHERE event_id = " . (int) $eventId . " GROUP BY hour ORDER BY total DESC LIMIT 1")->fetch();
    $program = $db->query('SELECT p.name, COUNT(DISTINCT a.student_id) as total FROM attendance a JOIN students s ON a.student_id = s.id JOIN programs p ON s.program_id = p.id WHERE a.event_id = ' . (int) $eventId . ' GROUP BY p.name ORDER BY total DESC LIMIT 1')->fetch();

    $organization = $db->query('SELECT o.name, COUNT(DISTINCT a.student_id) as total FROM attendance a JOIN students s ON a.student_id = s.id JOIN organizations o ON s.organization_id = o.id WHERE a.event_id = ' . (int) $eventId . ' GROUP BY o.name ORDER BY total DESC LIMIT 1')->fetch();

    $insights = [
        'event_name' => $eventData['name'] ?? 'No active event',
        'attendance_rate' => $summary['attendance_rate'] ?? 0,
        'duplicate_attempts' => $duplicateAttempts,
        'peak_hour' => $peakHour ? $peakHour['hour'] : 'No data',
        'top_program' => $program['name'] ?? 'No data',
        'top_organization' => $organization['name'] ?? 'No data',
    ];

    return $insights;
}

function renderLayout(string $title, string $content, array $breadcrumbs = []): string
{
    $user = currentUser();
    $roleLabel = strtoupper($user['role'] ?? 'guest');
    $currentPage = $_GET['page'] ?? 'dashboard';

    $icons = [
        'dashboard' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/></svg>',
        'organizations' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M3 7v14M21 7v14M6 7V3h12v4M9 11h2M9 15h2M13 11h2M13 15h2"/></svg>',
        'events' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
        'presence' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a8 8 0 0 0-8 8c0 5.25 8 12 8 12s8-6.75 8-12a8 8 0 0 0-8-8z"/><circle cx="12" cy="10" r="3"/></svg>',
        'students' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
        'scanner' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2M7 12h10"/></svg>',
        'analytics' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
        'reports' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
        'activity_logs' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
        'settings' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
        'mobile_app' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>',
        'history' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
        'logout' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
    ];

    $menu = [
        'dashboard' => ['Dashboard', 'dashboard'],
    ];

    if ($user && in_array($user['role'], ['admin', 'superadmin'], true)) {
        $menu['organizations'] = ['Organizations', 'organizations'];
        $menu['events'] = ['Events', 'events'];
        $menu['presence'] = ['Presence', 'presence'];
        $menu['students'] = ['Students', 'students'];
        $menu['scanner'] = ['Scanner', 'scanner'];
        $menu['analytics'] = ['Analytics', 'analytics'];
        $menu['reports'] = ['Reports', 'reports'];
        $menu['activity_logs'] = ['Activity Logs', 'activity_logs'];
        if ($user['role'] === 'superadmin') {
            $menu['settings'] = ['Settings', 'settings'];
        }
    }

    if ($user && $user['role'] === 'student') {
        $menu['mobile_app'] = ['Student App', 'mobile_app'];
    }

    $menu['history'] = ['My Attendance', 'history'];

    $nav = '';
    foreach ($menu as $key => $item) {
        $isActive = $currentPage === $key ? 'active' : '';
        $iconSvg = $icons[$key] ?? '';
        $nav .= '<a class="nav-item ' . $isActive . '" href="?page=' . $key . '"><span class="nav-icon">' . $iconSvg . '</span><span class="nav-label">' . $item[0] . '</span></a>';
    }

    $logoutLink = '';
    if ($user) {
        $logoutSvg = $icons['logout'] ?? '';
        $logoutLink = '<a class="nav-item logout" href="?page=logout"><span class="nav-icon">' . $logoutSvg . '</span><span class="nav-label">Sign Out</span></a>';
    }

    $userRoleLabel = $user['role'] ?? 'guest';
    $topbarRole = $userRoleLabel === 'superadmin' ? 'Super Admin' : ($userRoleLabel === 'admin' ? 'Admin' : ($userRoleLabel === 'student' ? 'Student' : 'Guest'));
    $userName = $user['full_name'] ?? 'Guest User';
    $userInitials = strtoupper(substr(trim($userName), 0, 2));

    $breadcrumbHtml = '<a href="?page=dashboard" class="bc-home"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg></a>';
    foreach ($breadcrumbs as $bc) {
        $breadcrumbHtml .= '<span class="bc-sep">/</span><span class="bc-item">' . htmlspecialchars((string) $bc) . '</span>';
    }

    return '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="PSU attendance monitoring and event operations platform">
        <title>' . htmlspecialchars($title) . '</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="assets/style.css?v=' . time() . '">
    </head>
    <body>
        <div class="app-shell" id="appShell">
            <aside class="sidebar" id="sidebar">
                <div class="brand-box">
                    <div class="brand-logo-frame">
                        <img src="PSU%20logo.jpg" alt="PSU Seal">
                    </div>
                    <div class="brand-text">
                        <span class="brand-kicker">Pangasinan State Univ</span>
                        <strong>Event Ops</strong>
                        <small class="brand-campus">Alaminos City Campus</small>
                    </div>
                </div>

                <div class="nav-section-title">NAVIGATION</div>
                <nav class="nav">
                    ' . $nav . '
                </nav>

                <div class="sidebar-footer">
                    ' . $logoutLink . '
                    <div class="sidebar-user-card">
                        <div class="sidebar-avatar">' . htmlspecialchars($userInitials) . '</div>
                        <div class="sidebar-user-meta">
                            <strong>' . htmlspecialchars($userName) . '</strong>
                            <span class="user-role-badge role-' . htmlspecialchars(strtolower($userRoleLabel)) . '">' . htmlspecialchars($topbarRole) . '</span>
                        </div>
                    </div>
                </div>
            </aside>

            <main class="main-panel">
                <header class="topbar">
                    <div class="topbar-left">
                        <button class="menu-toggle-btn" id="menuToggle" aria-label="Toggle navigation">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
                        </button>
                        <nav class="breadcrumbs" aria-label="Breadcrumb">
                            ' . $breadcrumbHtml . '
                        </nav>
                    </div>

                    <div class="topbar-right">
                        <div class="system-online" title="All campus systems operational">
                            <span class="status-dot"></span>
                            <span class="status-text">System Online</span>
                        </div>

                        <div class="live-clock-card">
                            <div class="live-date" id="live-date">-- --, ----</div>
                            <div class="live-clock" id="live-clock">--:--:-- --</div>
                        </div>

                        <div class="topbar-user-pill">
                            <div class="topbar-avatar">' . htmlspecialchars($userInitials) . '</div>
                            <div class="topbar-user-info">
                                <span class="topbar-user-name">' . htmlspecialchars($userName) . '</span>
                                <span class="topbar-user-role role-' . htmlspecialchars(strtolower($userRoleLabel)) . '">' . htmlspecialchars($topbarRole) . '</span>
                            </div>
                        </div>
                    </div>
                </header>

                <div class="page-content">
                    ' . $content . '
                </div>
            </main>
        </div>

        <script>
            function updateLiveClock() {
                const clock = document.getElementById("live-clock");
                const dateEl = document.getElementById("live-date");
                const now = new Date();
                if (clock) {
                    clock.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true });
                }
                if (dateEl) {
                    dateEl.textContent = now.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric", year: "numeric" });
                }
            }
            updateLiveClock();
            setInterval(updateLiveClock, 1000);

            const toggle = document.getElementById("menuToggle");
            const shell = document.getElementById("appShell");
            if (toggle && shell) {
                toggle.addEventListener("click", () => {
                    shell.classList.toggle("nav-open");
                });
            }
        </script>
    </body>
    </html>';
}

function statusBadge(?string $status): string
{
    $status = strtolower(trim((string) ($status ?? 'active')));
    $status = $status === '' ? 'active' : $status;

    $map = [
        'present' => 'success',
        'duplicate' => 'warning',
        'invalid' => 'danger',
        'not_eligible' => 'warning',
        'active' => 'success',
        'draft' => 'neutral',
        'scheduled' => 'warning',
        'completed' => 'neutral',
    ];

    $label = strtoupper($status);
    return '<span class="badge ' . ($map[$status] ?? 'neutral') . '">' . htmlspecialchars($label) . '</span>';
}

function smallStat(string $title, string $value, string $tone = 'primary'): string
{
    return '<div class="stat-card ' . $tone . '"><div class="label">' . htmlspecialchars($title) . '</div><div class="value">' . htmlspecialchars($value) . '</div></div>';
}
