<?php

function getDatabaseConfig(): array
{
    $envDriver = getenv('DB_DRIVER');
    $driver = strtolower((string) ($_ENV['DB_DRIVER'] ?? ($envDriver !== false && $envDriver !== '' ? $envDriver : 'sqlite')));

    if ($driver === 'mysql') {
        $envHost = getenv('DB_HOST');
        $host = (string) ($_ENV['DB_HOST'] ?? ($envHost !== false && $envHost !== '' ? $envHost : '127.0.0.1'));
        $envPort = getenv('DB_PORT');
        $port = (string) ($_ENV['DB_PORT'] ?? ($envPort !== false && $envPort !== '' ? $envPort : '3306'));
        $envDb = getenv('DB_NAME') ?: getenv('DB_DATABASE');
        $database = (string) ($_ENV['DB_NAME'] ?? $_ENV['DB_DATABASE'] ?? ($envDb !== false && $envDb !== '' ? $envDb : 'attendance_system'));
        $envUser = getenv('DB_USERNAME');
        $username = (string) ($_ENV['DB_USERNAME'] ?? ($envUser !== false && $envUser !== '' ? $envUser : 'root'));
        $envPass = getenv('DB_PASSWORD');
        $password = (string) ($_ENV['DB_PASSWORD'] ?? ($envPass !== false ? $envPass : ''));


        return [
            'driver' => 'mysql',
            'dsn' => 'mysql:host=' . $host . ';port=' . $port . ';dbname=' . $database . ';charset=utf8mb4',
            'username' => $username,
            'password' => $password,
        ];
    }

    $dbFile = __DIR__ . '/../storage/attendance_system.sqlite';

    if (!is_dir(dirname($dbFile))) {
        mkdir(dirname($dbFile), 0777, true);
    }

    return [
        'driver' => 'sqlite',
        'dsn' => 'sqlite:' . $dbFile,
        'username' => null,
        'password' => null,
    ];
}

function isMysqlDatabase(): bool
{
    return getDatabaseConfig()['driver'] === 'mysql';
}

function getDatabaseConnection(): PDO
{
    $config = getDatabaseConfig();
    $pdo = new PDO($config['dsn'], $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    if ($config['driver'] === 'sqlite') {
        $pdo->exec('PRAGMA journal_mode=WAL;');
        $pdo->exec('PRAGMA synchronous=NORMAL;');
        $pdo->exec('PRAGMA foreign_keys = ON;');
        $pdo->exec('PRAGMA busy_timeout = 5000;');
    } else {
        $pdo->exec('SET NAMES utf8mb4;');
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 1;');
    }

    return $pdo;
}

function databaseTableColumns(string $tableName): array
{
    $db = getDatabaseConnection();
    if (isMysqlDatabase()) {
        $columns = $db->query('SHOW COLUMNS FROM `' . str_replace('`', '', $tableName) . '`')->fetchAll();
        return array_map(static fn ($column) => $column['Field'], $columns);
    }

    $columns = $db->query('PRAGMA table_info(' . $tableName . ')')->fetchAll();
    return array_map(static fn ($column) => $column['name'], $columns);
}

function normalizeDatabaseSql(string $sql): string
{
    if (isMysqlDatabase()) {
        return str_replace('ON CONFLICT(', 'ON DUPLICATE KEY UPDATE ', $sql);
    }

    return $sql;
}

function resolveOrganizationNameFromProgram(string $programName): ?string
{
    $normalized = strtoupper(trim($programName));
    $rules = [
        'BSIT' => 'DOIT',
        'IT' => 'DOIT',
        'BSHM' => 'SAHARA',
        'HM' => 'SAHARA',
        'BSTM' => 'LAKBAY',
        'TOURISM' => 'LAKBAY',
        'BSBA' => 'SYBA',
        'BUSINESS ADMINISTRATION' => 'SYBA',
        'BUSINESS AD' => 'SYBA',
        'BEED' => 'GEG',
        'BSED' => 'CS',
        'BSE ENG' => 'CS',
        'ENGLISH' => 'CS',
        'BSE FIL' => 'TAGNAWA',
        'FILIPINO' => 'TAGNAWA',
        'BSE MATH' => 'PRIME',
        'MATH' => 'PRIME',
        'MATHEMATICS' => 'PRIME',
    ];

    foreach ($rules as $pattern => $organizationName) {
        if ($normalized === strtoupper((string) $pattern) || str_contains($normalized, strtoupper((string) $pattern))) {
            return $organizationName;
        }
    }

    return null;
}

function ensureOrganizationCatalog(): void
{
    $db = getDatabaseConnection();
    $desired = ['DOIT', 'SAHARA', 'LAKBAY', 'SYBA', 'GEG', 'CS', 'TAGNAWA', 'PRIME'];

    foreach ($desired as $name) {
        $existing = $db->prepare('SELECT id FROM organizations WHERE name = :name LIMIT 1');
        $existing->execute([':name' => $name]);
        if ($existing->fetchColumn() === false) {
            $db->prepare('INSERT INTO organizations (name) VALUES (:name)')->execute([':name' => $name]);
        }
    }
}

function assignOrganizationsToStudents(): void
{
    $db = getDatabaseConnection();
    ensureOrganizationCatalog();

    $students = $db->query('SELECT s.id, s.program_id, p.name AS program_name FROM students s LEFT JOIN programs p ON s.program_id = p.id ORDER BY s.id')->fetchAll();
    foreach ($students as $student) {
        $programName = $student['program_name'] ?? '';
        $organizationName = resolveOrganizationNameFromProgram((string) $programName);

        if ($organizationName === null) {
            continue;
        }

        $organizationId = $db->prepare('SELECT id FROM organizations WHERE name = :name LIMIT 1');
        $organizationId->execute([':name' => $organizationName]);
        $id = $organizationId->fetchColumn();

        if ($id !== false) {
            $db->prepare('UPDATE students SET organization_id = :organization_id WHERE id = :id')->execute([
                ':organization_id' => (int) $id,
                ':id' => (int) $student['id'],
            ]);
        }
    }
}

function initializeDatabase(): void
{
    $db = getDatabaseConnection();
    $isMysql = isMysqlDatabase();

    if ($isMysql) {
        $db->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(100) NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                full_name VARCHAR(255) NOT NULL,
                role VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS programs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS organizations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS students (
                id INT AUTO_INCREMENT PRIMARY KEY,
                student_id VARCHAR(100) NOT NULL UNIQUE,
                full_name VARCHAR(255) NOT NULL,
                program_id INT,
                organization_id INT,
                year_level VARCHAR(50),
                email VARCHAR(255),
                phone VARCHAR(50),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_students_program FOREIGN KEY (program_id) REFERENCES programs(id),
                CONSTRAINT fk_students_org FOREIGN KEY (organization_id) REFERENCES organizations(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS events (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                description TEXT,
                event_date DATE,
                start_time TIME,
                end_time TIME,
                venue VARCHAR(255),
                organizer VARCHAR(255),
                attendance_mode VARCHAR(100) DEFAULT 'Barcode + Student ID',
                status VARCHAR(50) DEFAULT 'active',
                latitude DOUBLE DEFAULT 16.1482,
                longitude DOUBLE DEFAULT 119.9851,
                radius_meters INT DEFAULT 100,
                presence_verification TINYINT(1) DEFAULT 1,
                verification_interval_minutes INT DEFAULT 15,
                minimum_required_presence INT DEFAULT 80,
                require_checkout TINYINT(1) DEFAULT 1,
                created_by INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_events_creator FOREIGN KEY (created_by) REFERENCES users(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS event_eligibility (
                id INT AUTO_INCREMENT PRIMARY KEY,
                event_id INT NOT NULL,
                program_id INT,
                organization_id INT,
                year_level VARCHAR(50),
                CONSTRAINT fk_event_eligibility_event FOREIGN KEY (event_id) REFERENCES events(id),
                CONSTRAINT fk_event_eligibility_program FOREIGN KEY (program_id) REFERENCES programs(id),
                CONSTRAINT fk_event_eligibility_org FOREIGN KEY (organization_id) REFERENCES organizations(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS attendance (
                id INT AUTO_INCREMENT PRIMARY KEY,
                event_id INT NOT NULL,
                student_id INT NOT NULL,
                status VARCHAR(50) NOT NULL DEFAULT 'present',
                scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                scanned_by VARCHAR(100),
                notes TEXT,
                CONSTRAINT fk_attendance_event FOREIGN KEY (event_id) REFERENCES events(id),
                CONSTRAINT fk_attendance_student FOREIGN KEY (student_id) REFERENCES students(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS activity_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                actor VARCHAR(100) NOT NULL,
                action VARCHAR(255) NOT NULL,
                details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS presence_verifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                event_id INT NOT NULL,
                student_id INT NOT NULL,
                status VARCHAR(50) NOT NULL DEFAULT 'inside',
                distance_meters DOUBLE DEFAULT 0,
                verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                notes TEXT,
                CONSTRAINT fk_presence_event FOREIGN KEY (event_id) REFERENCES events(id),
                CONSTRAINT fk_presence_student FOREIGN KEY (student_id) REFERENCES students(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS notifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                type VARCHAR(50) NOT NULL,
                title VARCHAR(255) NOT NULL,
                message TEXT NOT NULL,
                is_read TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS event_geofences (
                id INT AUTO_INCREMENT PRIMARY KEY,
                event_id INT NOT NULL,
                latitude DOUBLE NOT NULL,
                longitude DOUBLE NOT NULL,
                radius_meters INT NOT NULL DEFAULT 100,
                enabled TINYINT(1) NOT NULL DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_geofence_event FOREIGN KEY (event_id) REFERENCES events(id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS system_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                key_name VARCHAR(100) NOT NULL UNIQUE,
                value_text TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    } else {
        $db->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                full_name TEXT NOT NULL,
                role TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS programs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS organizations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT UNIQUE NOT NULL,
                full_name TEXT NOT NULL,
                program_id INTEGER,
                organization_id INTEGER,
                year_level TEXT,
                section_block TEXT DEFAULT '4A',
                email TEXT,
                phone TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (program_id) REFERENCES programs(id),
                FOREIGN KEY (organization_id) REFERENCES organizations(id)
            );
        ");

        try {
            $db->exec("ALTER TABLE students ADD COLUMN section_block TEXT DEFAULT '4A'");
        } catch (Exception $e) {}

        $db->exec("
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                event_date TEXT,
                start_time TEXT,
                end_time TEXT,
                venue TEXT,
                organizer TEXT,
                attendance_mode TEXT DEFAULT 'Barcode + Student ID',
                status TEXT DEFAULT 'active',
                latitude REAL DEFAULT 16.1482,
                longitude REAL DEFAULT 119.9851,
                radius_meters INTEGER DEFAULT 100,
                presence_verification INTEGER DEFAULT 1,
                verification_interval_minutes INTEGER DEFAULT 15,
                minimum_required_presence INTEGER DEFAULT 80,
                require_checkout INTEGER DEFAULT 1,
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users(id)
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS event_eligibility (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL,
                program_id INTEGER,
                organization_id INTEGER,
                year_level TEXT,
                FOREIGN KEY (event_id) REFERENCES events(id),
                FOREIGN KEY (program_id) REFERENCES programs(id),
                FOREIGN KEY (organization_id) REFERENCES organizations(id)
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'present',
                scanned_at TEXT DEFAULT CURRENT_TIMESTAMP,
                scanned_by TEXT,
                notes TEXT,
                FOREIGN KEY (event_id) REFERENCES events(id),
                FOREIGN KEY (student_id) REFERENCES students(id)
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                details TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS presence_verifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'inside',
                distance_meters REAL DEFAULT 0,
                verified_at TEXT DEFAULT CURRENT_TIMESTAMP,
                notes TEXT,
                FOREIGN KEY (event_id) REFERENCES events(id),
                FOREIGN KEY (student_id) REFERENCES students(id)
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT NOT NULL,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                is_read INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS event_evaluations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL,
                student_id INTEGER NOT NULL,
                rating_overall INTEGER DEFAULT 5,
                rating_speaker INTEGER DEFAULT 5,
                rating_venue INTEGER DEFAULT 5,
                feedback TEXT,
                certificate_serial TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (event_id) REFERENCES events(id),
                FOREIGN KEY (student_id) REFERENCES students(id)
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS event_geofences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                radius_meters INTEGER NOT NULL DEFAULT 100,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (event_id) REFERENCES events(id)
            );
        ");

        $db->exec("
            CREATE TABLE IF NOT EXISTS system_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_name TEXT UNIQUE NOT NULL,
                value_text TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
        ");

        $eventColumns = $db->query('PRAGMA table_info(events)')->fetchAll();
        $eventFields = array_map(static fn ($column) => $column['name'], $eventColumns);
        foreach (['latitude', 'longitude', 'radius_meters', 'presence_verification', 'verification_interval_minutes', 'minimum_required_presence', 'require_checkout'] as $field) {
            if (!in_array($field, $eventFields, true)) {
                $db->exec("ALTER TABLE events ADD COLUMN {$field} " . (
                    $field === 'latitude' || $field === 'longitude' ? 'REAL DEFAULT 0' :
                    ($field === 'radius_meters' || $field === 'verification_interval_minutes' || $field === 'minimum_required_presence' ? 'INTEGER DEFAULT 0' :
                    'INTEGER DEFAULT 1')
                ));
            }
        }
    }

    $existingUsers = $db->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
    if ((int) $existingUsers === 0) {
        $passwordHashes = [
            'superadmin' => password_hash('admin123', PASSWORD_DEFAULT),
            'admin' => password_hash('admin123', PASSWORD_DEFAULT),
            'student' => password_hash('student123', PASSWORD_DEFAULT),
        ];

        $db->exec("INSERT INTO users (username, password_hash, full_name, role) VALUES
            ('superadmin', '{$passwordHashes['superadmin']}', 'System Super Admin', 'superadmin'),
            ('admin', '{$passwordHashes['admin']}', 'Campus Admin', 'admin'),
            ('student', '{$passwordHashes['student']}', 'Juan Dela Cruz', 'student')");
    }

    $programCount = $db->query("SELECT COUNT(*) as count FROM programs")->fetch()['count'];
    if ((int) $programCount === 0) {
        $db->exec("INSERT INTO programs (name) VALUES ('BSIT'), ('BSED'), ('BSBA'), ('BSHM')");
    }

    $desiredOrganizations = [
        'DOIT' => 'DOIT',
        'SAHARA' => 'SAHARA',
        'LAKBAY' => 'LAKBAY',
        'SYBA' => 'SYBA',
        'GEG' => 'GEG',
        'CS' => 'CS',
        'TAGNAWA' => 'TAGNAWA',
        'PRIME' => 'PRIME',
    ];

    $existingOrganizations = $db->query("SELECT id, name FROM organizations ORDER BY id")->fetchAll();
    $existingMap = [];
    foreach ($existingOrganizations as $organization) {
        $existingMap[strtoupper(trim($organization['name']))] = $organization['id'];
    }

    foreach ($desiredOrganizations as $shortCode => $fullName) {
        $key = strtoupper($shortCode);
        if (isset($existingMap[$key])) {
            $db->prepare('UPDATE organizations SET name = :name WHERE id = :id')->execute([
                ':name' => $fullName,
                ':id' => $existingMap[$key],
            ]);
        } else {
            $db->prepare('INSERT INTO organizations (name) VALUES (:name)')->execute([':name' => $fullName]);
        }
    }

    foreach ($existingOrganizations as $organization) {
        $normalizedName = strtoupper(trim($organization['name']));
        $matchingDesired = array_search($organization['name'], $desiredOrganizations, true);
        if ($matchingDesired === false && in_array($normalizedName, array_map('strtoupper', array_keys($desiredOrganizations)), true)) {
            $db->prepare('UPDATE organizations SET name = :name WHERE id = :id')->execute([
                ':name' => $desiredOrganizations[array_search($normalizedName, array_map('strtoupper', array_keys($desiredOrganizations)), true)],
                ':id' => $organization['id'],
            ]);
        }
    }

    $studentCount = $db->query("SELECT COUNT(*) as count FROM students")->fetch()['count'];
    if ((int) $studentCount === 0) {
        $db->exec("INSERT INTO students (student_id, full_name, program_id, organization_id, year_level, email, phone)
            VALUES
            ('student', 'Juan Dela Cruz', 1, 1, '2A', 'student@psu.edu.ph', '09171112222'),
            ('2024001', 'Juan Dela Cruz', 1, 2, '2A', 'juan.delacruz@psu.edu.ph', '09171112222'),
            ('2024002', 'Maria Santos', 1, 3, '2A', 'maria.santos@psu.edu.ph', '09171113333'),
            ('2024003', 'Mark Garcia', 2, 4, '1B', 'mark.garcia@psu.edu.ph', '09171114444'),
            ('2024004', 'Ana Reyes', 3, 5, '3A', 'ana.reyes@psu.edu.ph', '09171115555'),
            ('2024005', 'Carlo Cruz', 4, 8, '1A', 'carlo.cruz@psu.edu.ph', '09171116666')");
    }

    assignOrganizationsToStudents();

    $eventCount = $db->query("SELECT COUNT(*) as count FROM events")->fetch()['count'];
    if ((int) $eventCount === 0) {
        // Keep the application in a blank event state until the admin creates event data.
    }

    $attendanceCount = $db->query("SELECT COUNT(*) as count FROM attendance")->fetch()['count'];
    if ((int) $attendanceCount === 0) {
        // No automatic sample attendance is created for an empty event list.
    }

    $logCount = $db->query("SELECT COUNT(*) as count FROM activity_logs")->fetch()['count'];
    if ((int) $logCount === 0) {
        $db->exec("INSERT INTO activity_logs (actor, action, details) VALUES
            ('system', 'System Initialized', 'Attendance system database created.'),
            ('admin', 'Created event', 'University Week 2026 was created.'),
            ('system', 'Duplicate blocked', 'Duplicate attendance attempt prevented for a student.')");
    }

    $settingsCount = $db->query("SELECT COUNT(*) as count FROM system_settings")->fetch()['count'];
    if ((int) $settingsCount === 0) {
        $db->exec("INSERT INTO system_settings (key_name, value_text) VALUES
            ('attendance_threshold', '80'),
            ('verification_interval', '15'),
            ('event_radius_meters', '100'),
            ('session_timeout_minutes', '30'),
            ('campus_name', 'Pangasinan State University - Alaminos City Campus')");
    }

    $notificationsCount = $db->query("SELECT COUNT(*) as count FROM notifications")->fetch()['count'];
    if ((int) $notificationsCount === 0) {
        $db->exec("INSERT INTO notifications (user_id, type, title, message) VALUES
            (1, 'info', 'Attendance Open', 'University Week 2026 is now accepting attendance.'),
            (1, 'warning', 'Presence Verification Required', 'Please remain within the event geofence during the event.'),
            (1, 'success', 'Attendance Successfully Completed', 'The attendance session has been verified and recorded.')");
    }
}
