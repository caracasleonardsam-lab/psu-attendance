<?php
require __DIR__ . '/../../vendor/autoload.php';
$app = require_once __DIR__ . '/../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

// 1. Delete all sample events and sample attendances
\App\Models\Attendance::query()->delete();
\App\Models\PresenceVerification::query()->delete();
\App\Models\EventEligibility::query()->delete();
\App\Models\EventGeofence::query()->delete();
\App\Models\Event::query()->delete();

// 2. Delete mock student
\App\Models\Student::where('student_id', 'student')->delete();
\App\Models\User::where('username', 'student')->delete();

// Log activity
\App\Models\ActivityLog::log('system', 'Database Purge', 'Purged all demo events and dummy student accounts. System set to production mode.');

echo "TOTAL REAL STUDENTS: " . \App\Models\Student::count() . PHP_EOL;
echo "TOTAL EVENTS: " . \App\Models\Event::count() . PHP_EOL;
echo "TOTAL ATTENDANCE RECORDS: " . \App\Models\Attendance::count() . PHP_EOL;
echo "FIRST 3 REAL STUDENTS IN DB:" . PHP_EOL;
foreach (\App\Models\Student::take(3)->get() as $s) {
    echo " - " . $s->student_id . " : " . $s->full_name . " (" . ($s->program?->name ?? 'N/A') . ")" . PHP_EOL;
}
