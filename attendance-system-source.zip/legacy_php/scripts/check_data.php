<?php
require __DIR__ . '/../../vendor/autoload.php';
$app = require_once __DIR__ . '/../../bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

echo "STUDENTS SAMPLE:" . PHP_EOL;
$sample = App\Models\Student::take(10)->get();
foreach ($sample as $s) {
    echo $s->student_id . " | " . $s->full_name . " | " . $s->year_level . PHP_EOL;
}

echo PHP_EOL . "SAMPLE / DUMMY ACCOUNTS IN DB:" . PHP_EOL;
$dummy = App\Models\Student::whereIn('student_id', ['student', '2024001', '2024002', '2024003', '2024004', '2024005'])->get();
foreach ($dummy as $d) {
    echo "Found dummy: " . $d->student_id . " - " . $d->full_name . PHP_EOL;
}

echo PHP_EOL . "EVENTS IN DB:" . PHP_EOL;
$events = App\Models\Event::all();
foreach ($events as $e) {
    echo "Event ID " . $e->id . ": " . $e->name . " (" . $e->status . ")" . PHP_EOL;
}
