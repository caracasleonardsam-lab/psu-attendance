<?php

require __DIR__ . '/../includes/db.php';

$defaultSource = __DIR__ . '/../EnrollmentListing_PSU_ALAM_RRamos_20260818151337-1.htm';
$arguments = array_slice($argv, 1);
$apply = in_array('--apply', $arguments, true);
$sourceArguments = array_values(array_filter(
    $arguments,
    static fn (string $argument): bool => $argument !== '--apply'
));
$sourceFile = $sourceArguments[0] ?? $defaultSource;

if (!file_exists($sourceFile)) {
    fwrite(STDERR, "Enrollment file not found: {$sourceFile}\n");
    exit(1);
}

$html = file_get_contents($sourceFile);
if ($html === false) {
    fwrite(STDERR, "Unable to read enrollment file.\n");
    exit(1);
}

$programOrganizations = [
    'BEED' => 'GEG',
    'BSBA FM' => 'SYBA',
    'BSBA OM' => 'SYBA',
    'BSE ENG' => 'CS',
    'BSE FIL' => 'TAGNAWA',
    'BSE MATH' => 'PRIME',
    'BSHM' => 'SAHARA',
    'BSIT' => 'DOIT',
    'BSTM' => 'LAKBAY',
];

$dom = new DOMDocument();
libxml_use_internal_errors(true);
$loaded = $dom->loadHTML($html);
libxml_clear_errors();

if (! $loaded) {
    fwrite(STDERR, "Unable to parse the enrollment file.\n");
    exit(1);
}

$records = [];
$seenStudentIds = [];
$rowNumber = 0;

foreach ($dom->getElementsByTagName('tr') as $row) {
    $rowNumber++;
    $cells = [];

    foreach ($row->getElementsByTagName('td') as $td) {
        $cells[] = trim(preg_replace(
            '/\s+/u',
            ' ',
            html_entity_decode($td->textContent, ENT_QUOTES | ENT_HTML5, 'UTF-8')
        ));
    }

    if (count($cells) < 14 || ($cells[1] ?? '') === 'ID No.') {
        continue;
    }

    $studentId = trim($cells[1] ?? '');
    $fullName = trim(preg_replace('/\s+/u', ' ', str_replace(' , ', ', ', $cells[2] ?? '')));
    $courseCode = trim($cells[9] ?? '');

    if ($studentId === '' || $fullName === '') {
        fwrite(STDERR, "Enrollment row {$rowNumber} is missing a student ID or name.\n");
        exit(1);
    }

    if (isset($seenStudentIds[$studentId])) {
        fwrite(STDERR, "Duplicate student ID found on enrollment row {$rowNumber}.\n");
        exit(1);
    }
    $seenStudentIds[$studentId] = true;

    if (! preg_match('/^ALM_(BSE MATH|BSE ENG|BSE FIL|BSBA FM|BSBA OM|BSTM|BSHM|BSIT|BEED)(?=\s|[0-9]|$)/u', $courseCode, $matches)) {
        fwrite(STDERR, "Unrecognized program code on enrollment row {$rowNumber}.\n");
        exit(1);
    }

    $program = $matches[1];
    $email = null;
    foreach (array_slice($cells, 12) as $candidate) {
        if (filter_var($candidate, FILTER_VALIDATE_EMAIL)) {
            $email = $candidate;
            break;
        }
    }

    $records[] = [
        'student_id' => $studentId,
        'full_name' => $fullName,
        'program' => $program,
        'organization' => $programOrganizations[$program],
        'year_level' => trim($cells[10] ?? ''),
        'email' => $email,
    ];
}

if ($records === []) {
    fwrite(STDERR, "No enrollment records were found.\n");
    exit(1);
}

$db = getDatabaseConnection();
$programLookup = [];
foreach ($db->query('SELECT id, name FROM programs') as $program) {
    $programLookup[$program['name']] = (int) $program['id'];
}

$organizationLookup = [];
foreach ($db->query('SELECT id, name FROM organizations') as $organization) {
    $organizationLookup[$organization['name']] = (int) $organization['id'];
}

$findStudent = $db->prepare(
    'SELECT full_name, program_id, organization_id, year_level, email
     FROM students
     WHERE student_id = :student_id'
);
$plan = [];
$changes = [
    'new_students' => 0,
    'names' => 0,
    'programs' => 0,
    'organizations' => 0,
    'year_levels' => 0,
    'emails' => 0,
];

foreach ($records as $record) {
    if (!isset($programLookup[$record['program']], $organizationLookup[$record['organization']])) {
        fwrite(STDERR, "A required program or organization is missing from the database.\n");
        exit(1);
    }

    $record['program_id'] = $programLookup[$record['program']];
    $record['organization_id'] = $organizationLookup[$record['organization']];
    $findStudent->execute([':student_id' => $record['student_id']]);
    $existing = $findStudent->fetch();
    $findStudent->closeCursor();

    if ($existing === false) {
        $changes['new_students']++;
    } else {
        $changes['names'] += (int) ($existing['full_name'] !== $record['full_name']);
        $changes['programs'] += (int) ((int) $existing['program_id'] !== $record['program_id']);
        $changes['organizations'] += (int) ((int) $existing['organization_id'] !== $record['organization_id']);
        $changes['year_levels'] += (int) ((string) $existing['year_level'] !== $record['year_level']);
        if ($record['email'] !== null) {
            $changes['emails'] += (int) (strcasecmp((string) $existing['email'], $record['email']) !== 0);
        }
    }

    $plan[] = $record;
}

$driver = getDatabaseConfig()['driver'];
echo 'Database: ' . $driver . PHP_EOL;
echo 'Enrollment rows validated: ' . count($plan) . PHP_EOL;
echo 'Changes: ' . json_encode($changes, JSON_UNESCAPED_SLASHES) . PHP_EOL;

if (!$apply) {
    echo "Dry run only. Re-run with --apply to save these changes.\n";
    exit(0);
}

$updateStudent = $db->prepare(
    'UPDATE students SET
        full_name = :full_name,
        program_id = :program_id,
        organization_id = :organization_id,
        year_level = :year_level,
        email = COALESCE(:email, email)
     WHERE student_id = :student_id'
);
$insertStudent = $db->prepare(
    'INSERT INTO students (student_id, full_name, program_id, organization_id, year_level, email)
     VALUES (:student_id, :full_name, :program_id, :organization_id, :year_level, :email)'
);

$db->beginTransaction();

try {
    foreach ($plan as $record) {
        $findStudent->execute([':student_id' => $record['student_id']]);
        $existing = $findStudent->fetch();
        $findStudent->closeCursor();

        $values = [
            ':student_id' => $record['student_id'],
            ':full_name' => $record['full_name'],
            ':program_id' => $record['program_id'],
            ':organization_id' => $record['organization_id'],
            ':year_level' => $record['year_level'],
            ':email' => $record['email'],
        ];

        if ($existing === false) {
            $insertStudent->execute($values);
        } else {
            $updateStudent->execute($values);
        }
    }

    $log = $db->prepare(
        'INSERT INTO activity_logs (actor, action, details)
         VALUES (:actor, :action, :details)'
    );
    $log->execute([
        ':actor' => 'system',
        ':action' => 'Enrollment imported',
        ':details' => sprintf(
            'Imported/updated %d PSU Alaminos student records from %s with verified program and organization assignments.',
            count($plan),
            basename($sourceFile)
        ),
    ]);

    $db->commit();
} catch (Throwable $exception) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    throw $exception;
}

echo 'Imported/updated ' . count($plan) . " PSU Alaminos student records.\n";
