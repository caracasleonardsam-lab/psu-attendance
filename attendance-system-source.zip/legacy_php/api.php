<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_DEPRECATED & ~E_WARNING);

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

function haversineMeters($lat1, $lon1, $lat2, $lon2) {
    $earthRadius = 6371000;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $earthRadius * $c;
}

try {
    initializeDatabase();
    $db = getDatabaseConnection();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'get_student_dashboard';
$studentIdInput = trim($_GET['student_id'] ?? $_POST['student_id'] ?? $_POST['username'] ?? '23-AC-0453');

// Handle Student Login Action
if ($action === 'login') {
    $username = trim($_POST['username'] ?? $_POST['student_id'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        echo json_encode(['success' => false, 'message' => 'Please enter both Student ID and Password.']);
        exit;
    }

    // Look for student strictly in real students table
    $stmt = $db->prepare('SELECT s.*, p.name as program_name, o.name as organization_name FROM students s LEFT JOIN programs p ON s.program_id = p.id LEFT JOIN organizations o ON s.organization_id = o.id WHERE UPPER(s.student_id) = UPPER(:id) OR LOWER(s.email) = LOWER(:email) LIMIT 1');
    $stmt->execute([':id' => $username, ':email' => strtolower($username) . '@psu.edu.ph']);
    $student = $stmt->fetch();

    if (!$student && $username === 'student') {
        $db->prepare('INSERT OR IGNORE INTO students (student_id, full_name, program_id, organization_id, year_level, section_block, email, phone) VALUES ("student", "Juan Dela Cruz", 1, 1, "Fourth Year", "4A", "student@psu.edu.ph", "09171112222")')->execute();
        $stmt->execute([':id' => 'student', ':email' => 'student@psu.edu.ph']);
        $student = $stmt->fetch();
    }

    if (!$student) {
        echo json_encode(['success' => false, 'message' => 'Student ID "' . htmlspecialchars($username) . '" not found in university registry.']);
        exit;
    }

    // Check user account in users table
    $uStmt = $db->prepare('SELECT * FROM users WHERE UPPER(username) = UPPER(:username) LIMIT 1');
    $uStmt->execute([':username' => $student['student_id']]);
    $user = $uStmt->fetch();

    if (!$user) {
        // Auto-create user account with default password = student_id
        $passCol = in_array('password_hash', databaseTableColumns('users'), true) ? 'password_hash' : 'password';
        $defaultHash = password_hash($student['student_id'], PASSWORD_DEFAULT);
        $ins = $db->prepare("INSERT INTO users (username, {$passCol}, full_name, role) VALUES (:username, :hash, :name, 'student')");
        $ins->execute([
            ':username' => $student['student_id'],
            ':hash' => $defaultHash,
            ':name' => $student['full_name']
        ]);
        $uStmt->execute([':username' => $student['student_id']]);
        $user = $uStmt->fetch();
    }

    // Verify Password against users table or default student_id
    $isValid = false;
    $storedHash = $user['password_hash'] ?? $user['password'] ?? '';
    if ($user && password_verify($password, $storedHash)) {
        $isValid = true;
    } elseif ($password === $student['student_id']) {
        $isValid = true;
    }

    if (!$isValid) {
        echo json_encode(['success' => false, 'message' => 'Invalid Password for Student ID ' . htmlspecialchars($student['student_id']) . '.']);
        exit;
    }

    $requiresPasswordChange = ($password === $student['student_id']) || password_verify($student['student_id'], $storedHash);

    echo json_encode([
        'success' => true,
        'message' => 'Login successful!',
        'requires_password_change' => $requiresPasswordChange,
        'student' => [
            'id' => $student['id'],
            'student_id' => $student['student_id'],
            'full_name' => $student['full_name'],
            'program' => $student['program_name'] ?: 'BSIT',
            'organization' => $student['organization_name'] ?: 'DOIT',
            'year_level' => $student['year_level'] ?: 'Fourth Year',
            'section_block' => $student['section_block'] ?: '4A',
            'email' => $student['email'] ?: 'student@psu.edu.ph',
            'phone' => $student['phone'] ?: '09171112222',
            'campus' => 'PSU Alaminos Campus'
        ]
    ]);
    exit;
}

// Handle Change Password Action
if ($action === 'change_password') {
    $username = trim($_POST['student_id'] ?? $_POST['username'] ?? '');
    $currentPassword = trim($_POST['current_password'] ?? '');
    $newPassword = trim($_POST['new_password'] ?? '');

    if ($username === '' || $currentPassword === '' || $newPassword === '') {
        echo json_encode(['success' => false, 'message' => 'Please fill in all required password fields.']);
        exit;
    }

    if (strlen($newPassword) < 6) {
        echo json_encode(['success' => false, 'message' => 'New password must be at least 6 characters long.']);
        exit;
    }

    if ($newPassword === $username) {
        echo json_encode(['success' => false, 'message' => 'New password cannot be your Student ID default password.']);
        exit;
    }

    $uStmt = $db->prepare('SELECT * FROM users WHERE UPPER(username) = UPPER(:username) LIMIT 1');
    $uStmt->execute([':username' => $username]);
    $user = $uStmt->fetch();

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User account not found.']);
        exit;
    }

    $storedHash = $user['password_hash'] ?? $user['password'] ?? '';
    $isValid = password_verify($currentPassword, $storedHash) || ($currentPassword === $username);
    if (!$isValid) {
        echo json_encode(['success' => false, 'message' => 'Current password is incorrect.']);
        exit;
    }

    $passCol = in_array('password_hash', databaseTableColumns('users'), true) ? 'password_hash' : 'password';
    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $upd = $db->prepare("UPDATE users SET {$passCol} = :hash WHERE id = :id");
    $upd->execute([':hash' => $newHash, ':id' => $user['id']]);

    echo json_encode([
        'success' => true,
        'message' => 'Password updated successfully! You can now access your dashboard.'
    ]);
    exit;
}

// Handle Reset Password Request Action
if ($action === 'reset_password') {
    $studentId = trim($_POST['student_id'] ?? $_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($studentId === '' || $email === '') {
        echo json_encode(['success' => false, 'message' => 'Please enter both your Student ID and registered Email.']);
        exit;
    }

    $stCheck = $db->prepare('SELECT * FROM students WHERE UPPER(student_id) = UPPER(:id) AND (LOWER(email) = LOWER(:email) OR LOWER(email) = LOWER(:email_domain)) LIMIT 1');
    $stCheck->execute([
        ':id' => $studentId,
        ':email' => $email,
        ':email_domain' => strtolower($studentId) . '@psu.edu.ph'
    ]);
    $stRecord = $stCheck->fetch();

    if (!$stRecord) {
        echo json_encode(['success' => false, 'message' => 'Student ID or Email does not match university registry records.']);
        exit;
    }

    $uStmt = $db->prepare('SELECT * FROM users WHERE UPPER(username) = UPPER(:username) LIMIT 1');
    $uStmt->execute([':username' => $stRecord['student_id']]);
    $user = $uStmt->fetch();

    $defaultHash = password_hash($stRecord['student_id'], PASSWORD_DEFAULT);
    $passCol = in_array('password_hash', databaseTableColumns('users'), true) ? 'password_hash' : 'password';

    if ($user) {
        $upd = $db->prepare("UPDATE users SET {$passCol} = :hash WHERE id = :id");
        $upd->execute([':hash' => $defaultHash, ':id' => $user['id']]);
    } else {
        $ins = $db->prepare("INSERT INTO users (username, {$passCol}, full_name, role) VALUES (:username, :hash, :name, 'student')");
        $ins->execute([
            ':username' => $stRecord['student_id'],
            ':hash' => $defaultHash,
            ':name' => $stRecord['full_name']
        ]);
    }

    logAction($stRecord['full_name'], 'Password Reset', 'Password reset back to default Student ID');

    echo json_encode([
        'success' => true,
        'message' => 'Your password has been reset to your default Student ID. Log in with your Student ID as password to create your new password.'
    ]);
    exit;
}

// Find student strictly by student_id or email
$stmt = $db->prepare('SELECT s.*, p.name as program_name, o.name as organization_name FROM students s LEFT JOIN programs p ON s.program_id = p.id LEFT JOIN organizations o ON s.organization_id = o.id WHERE UPPER(s.student_id) = UPPER(:id) OR LOWER(s.email) = LOWER(:email) LIMIT 1');
$stmt->execute([':id' => $studentIdInput, ':email' => strtolower($studentIdInput) . '@psu.edu.ph']);
$student = $stmt->fetch();

if (!$student && ($studentIdInput === 'student' || $studentIdInput === '')) {
    $db->prepare('INSERT OR IGNORE INTO students (student_id, full_name, program_id, organization_id, year_level, section_block, email, phone) VALUES ("student", "Juan Dela Cruz", 1, 1, "Fourth Year", "4A", "student@psu.edu.ph", "09171112222")')->execute();
    $stmt->execute([':id' => 'student', ':email' => 'student@psu.edu.ph']);
    $student = $stmt->fetch();
}

if (!$student) {
    echo json_encode(['success' => false, 'error' => 'No student profile found for ID: ' . $studentIdInput]);
    exit;
}

// Handle Student Profile & Section Block Update
if ($action === 'update_profile') {
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $sectionBlock = trim($_POST['section_block'] ?? $_POST['block'] ?? '');

    if ($email === '') {
        echo json_encode(['success' => false, 'message' => 'Email address cannot be empty.']);
        exit;
    }

    if ($sectionBlock !== '') {
        $upd = $db->prepare('UPDATE students SET email = :email, phone = :phone, section_block = :block WHERE id = :id');
        $upd->execute([
            ':email' => $email,
            ':phone' => $phone,
            ':block' => $sectionBlock,
            ':id' => $student['id'],
        ]);
    } else {
        $upd = $db->prepare('UPDATE students SET email = :email, phone = :phone WHERE id = :id');
        $upd->execute([
            ':email' => $email,
            ':phone' => $phone,
            ':id' => $student['id'],
        ]);
    }

    // Refetch updated record
    $stmt->execute([':id' => $student['student_id'], ':email' => $email]);
    $student = $stmt->fetch();

    logAction($student['full_name'], 'Update Profile', 'Updated email to ' . $email . ', phone to ' . $phone . ', section block to ' . ($student['section_block'] ?? '4A'));

    echo json_encode([
        'success' => true,
        'message' => 'Profile & Academic Section Block updated successfully!',
        'student' => [
            'id' => $student['id'],
            'student_id' => $student['student_id'],
            'full_name' => $student['full_name'],
            'program' => $student['program_name'] ?: 'BSIT',
            'organization' => $student['organization_name'] ?: 'DOIT',
            'year_level' => $student['year_level'] ?: 'Fourth Year',
            'section_block' => $student['section_block'] ?: '4A',
            'email' => $student['email'] ?: $email,
            'phone' => $student['phone'] ?: '09171112222',
            'campus' => 'PSU Alaminos Campus'
        ]
    ]);
    exit;
}

// Handle Event Evaluation Submission (STRICT PER-EVENT ENTRANCE SCAN REQUIRED)
if ($action === 'submit_evaluation') {
    $eventId = (int) ($_POST['event_id'] ?? 0);
    $ratingOverall = (int) ($_POST['rating_overall'] ?? 5);
    $ratingSpeaker = (int) ($_POST['rating_speaker'] ?? 5);
    $ratingVenue = (int) ($_POST['rating_venue'] ?? 5);
    $feedback = trim($_POST['feedback'] ?? '');

    if ($eventId <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid Event selected for evaluation.']);
        exit;
    }

    // MANDATORY STRICT PER-EVENT SCAN CHECK: Student MUST be scanned for THIS SPECIFIC event!
    $attCheck = $db->prepare('SELECT status FROM attendance WHERE event_id = :event_id AND student_id = :student_id LIMIT 1');
    $attCheck->execute([':event_id' => $eventId, ':student_id' => $student['id']]);
    $attRecord = $attCheck->fetch();

    if (!$attRecord || strtolower($attRecord['status']) === 'absent') {
        echo json_encode([
            'success' => false,
            'message' => 'Entrance Scan Required: You have not been scanned in at the entrance for this specific event. Attendance must be scanned for each individual event before evaluating or unlocking an E-Certificate.'
        ]);
        exit;
    }

    $evStmt = $db->prepare('SELECT * FROM events WHERE id = :id LIMIT 1');
    $evStmt->execute([':id' => $eventId]);
    $event = $evStmt->fetch();

    if ($event && strtolower($event['status']) !== 'completed' && strtotime($event['event_date']) > time()) {
        echo json_encode([
            'success' => false,
            'message' => 'Event evaluation is not yet open. You must wait until the event is COMPLETED before submitting an evaluation.'
        ]);
        exit;
    }

    // Check if already evaluated
    $evalCheck = $db->prepare('SELECT certificate_serial FROM event_evaluations WHERE event_id = :event_id AND student_id = :student_id LIMIT 1');
    $evalCheck->execute([':event_id' => $eventId, ':student_id' => $student['id']]);
    $existing = $evalCheck->fetch();

    if ($existing) {
        $serial = $existing['certificate_serial'];
    } else {
        $serial = 'CERT-' . date('Y') . '-PSU-' . sprintf('%04d', $student['id']) . '-' . sprintf('%03d', $eventId);
        $insEval = $db->prepare('INSERT INTO event_evaluations (event_id, student_id, rating_overall, rating_speaker, rating_venue, feedback, certificate_serial) VALUES (:event_id, :student_id, :ro, :rs, :rv, :fb, :serial)');
        $insEval->execute([
            ':event_id' => $eventId,
            ':student_id' => $student['id'],
            ':ro' => $ratingOverall,
            ':rs' => $ratingSpeaker,
            ':rv' => $ratingVenue,
            ':fb' => $feedback,
            ':serial' => $serial,
        ]);
        logAction($student['full_name'], 'Event Evaluation', 'Submitted evaluation & generated E-Certificate serial ' . $serial);
    }

    echo json_encode([
        'success' => true,
        'message' => 'Evaluation submitted successfully! Your E-Certificate is ready.',
        'certificate_serial' => $serial,
        'has_evaluated' => true,
    ]);
    exit;
}

// Handle Geofence Check & Out-of-Range 3-Warning Absence System
if ($action === 'verify_geofence') {
    $eventId = (int) ($_POST['event_id'] ?? 0);
    $studentLat = (float) ($_POST['latitude'] ?? 16.1482);
    $studentLng = (float) ($_POST['longitude'] ?? 119.9851);

    if ($eventId <= 0) {
        $activeEv = $db->query('SELECT id FROM events WHERE status = "active" LIMIT 1')->fetch();
        $eventId = $activeEv ? (int) $activeEv['id'] : 1;
    }

    // MANDATORY PREREQUISITE: Check if student has been scanned/checked-in first for THIS SPECIFIC event!
    $attCheck = $db->prepare('SELECT status FROM attendance WHERE event_id = :event_id AND student_id = :student_id LIMIT 1');
    $attCheck->execute([':event_id' => $eventId, ':student_id' => $student['id']]);
    $attRecord = $attCheck->fetch();

    if (!$attRecord) {
        echo json_encode([
            'success' => false,
            'has_scanned' => false,
            'message' => 'Entrance Scan Required: Present your Barcode Campus Pass to the scanners at the event entrance before Geofence Location Tracking activates for this specific event.'
        ]);
        exit;
    }

    // MANDATORY LUNCH BREAK EXEMPTION CHECK (12:00 PM - 1:00 PM)
    $currentHour = (int) date('H');
    if ($currentHour === 12) {
        echo json_encode([
            'success' => true,
            'has_scanned' => true,
            'is_lunch_break' => true,
            'in_range' => true,
            'distance_meters' => 0,
            'radius_meters' => 100,
            'warning_count' => 0,
            'status' => 'present',
            'message' => 'University Lunch Break (12:00 PM - 1:00 PM): Geofence location check exempted during lunch break. Attendance status: PRESENT.'
        ]);
        exit;
    }

    $evStmt = $db->prepare('SELECT * FROM events WHERE id = :id LIMIT 1');
    $evStmt->execute([':id' => $eventId]);
    $event = $evStmt->fetch();

    $eventLat = (float) ($event['latitude'] ?? 16.1482);
    $eventLng = (float) ($event['longitude'] ?? 119.9851);
    $radiusMeters = (int) ($event['radius_meters'] ?? 100);

    $distanceMeters = haversineMeters($studentLat, $studentLng, $eventLat, $eventLng);

    // Get current presence verification record
    $pvStmt = $db->prepare('SELECT * FROM presence_verifications WHERE event_id = :event_id AND student_id = :student_id ORDER BY id DESC LIMIT 1');
    $pvStmt->execute([':event_id' => $eventId, ':student_id' => $student['id']]);
    $lastVer = $pvStmt->fetch();

    $currentWarnings = $lastVer ? (int) ($lastVer['notes'] ?? 0) : 0;

    if ($distanceMeters <= $radiusMeters) {
        // STUDENT IS IN RANGE -> Mark Present, reset warnings
        $db->prepare('INSERT INTO presence_verifications (event_id, student_id, status, distance_meters, notes) VALUES (:event_id, :student_id, "inside", :dist, "0")')
           ->execute([':event_id' => $eventId, ':student_id' => $student['id'], ':dist' => $distanceMeters]);

        $db->prepare('UPDATE attendance SET status = "present" WHERE event_id = :event_id AND student_id = :student_id')
           ->execute([':event_id' => $eventId, ':student_id' => $student['id']]);

        echo json_encode([
            'success' => true,
            'has_scanned' => true,
            'in_range' => true,
            'distance_meters' => round($distanceMeters, 1),
            'radius_meters' => $radiusMeters,
            'warning_count' => 0,
            'status' => 'present',
            'message' => 'Location verified! You are within venue geofence (' . round($distanceMeters) . 'm). Attendance status: PRESENT.'
        ]);
        exit;
    } else {
        // STUDENT IS OUT OF RANGE -> Increment warning count (1 to 3)
        $newWarnings = $currentWarnings + 1;
        $db->prepare('INSERT INTO presence_verifications (event_id, student_id, status, distance_meters, notes) VALUES (:event_id, :student_id, "outside", :dist, :warn)')
           ->execute([':event_id' => $eventId, ':student_id' => $student['id'], ':dist' => $distanceMeters, ':warn' => (string) $newWarnings]);

        if ($newWarnings >= 3) {
            // EXCEEDED 3 WARNINGS -> MARK ABSENT
            $db->prepare('UPDATE attendance SET status = "absent" WHERE event_id = :event_id AND student_id = :student_id')
               ->execute([':event_id' => $eventId, ':student_id' => $student['id']]);

            echo json_encode([
                'success' => true,
                'has_scanned' => true,
                'in_range' => false,
                'distance_meters' => round($distanceMeters, 1),
                'radius_meters' => $radiusMeters,
                'warning_count' => 3,
                'status' => 'absent',
                'message' => 'ABSENT WARNING EXCEEDED (3/3): You stayed out of venue range (' . round($distanceMeters) . 'm away). Attendance status marked ABSENT.'
            ]);
            exit;
        } else {
            // WARNING 1 or 2
            echo json_encode([
                'success' => true,
                'has_scanned' => true,
                'in_range' => false,
                'distance_meters' => round($distanceMeters, 1),
                'radius_meters' => $radiusMeters,
                'warning_count' => $newWarnings,
                'status' => 'warning',
                'message' => 'GEOFENCE WARNING ' . $newWarnings . '/3: You are ' . round($distanceMeters) . 'm away from event venue (Max: ' . $radiusMeters . 'm). Return to venue bounds to remain marked PRESENT!'
            ]);
            exit;
        }
    }
}

// Handle E-Certificate Fetching (INELIGIBLE IF ABSENT OR NOT SCANNED)
if ($action === 'get_certificate') {
    $eventId = (int) ($_GET['event_id'] ?? $_POST['event_id'] ?? 0);
    if ($eventId <= 0) {
        $activeEv = $db->query('SELECT id FROM events ORDER BY id DESC LIMIT 1')->fetch();
        $eventId = $activeEv ? (int) $activeEv['id'] : 1;
    }

    // MANDATORY STRICT PER-EVENT SCAN & ABSENT INELIGIBILITY CHECK:
    $attCheck = $db->prepare('SELECT status FROM attendance WHERE event_id = :event_id AND student_id = :student_id LIMIT 1');
    $attCheck->execute([':event_id' => $eventId, ':student_id' => $student['id']]);
    $attRecord = $attCheck->fetch();

    if (!$attRecord || strtolower($attRecord['status']) === 'absent') {
        echo json_encode([
            'success' => false,
            'message' => 'E-Certificate Ineligible: You have not been scanned for this specific event or were marked ABSENT. E-Certificates are only issued to students with verified PRESENT attendance records.'
        ]);
        exit;
    }

    $evStmt = $db->prepare('SELECT * FROM events WHERE id = :id LIMIT 1');
    $evStmt->execute([':id' => $eventId]);
    $event = $evStmt->fetch();

    if (!$event) {
        echo json_encode(['success' => false, 'message' => 'Event record not found.']);
        exit;
    }

    $evalCheck = $db->prepare('SELECT * FROM event_evaluations WHERE event_id = :event_id AND student_id = :student_id LIMIT 1');
    $evalCheck->execute([':event_id' => $eventId, ':student_id' => $student['id']]);
    $eval = $evalCheck->fetch();

    $serial = $eval ? $eval['certificate_serial'] : 'CERT-' . date('Y') . '-PSU-' . sprintf('%04d', $student['id']) . '-' . sprintf('%03d', $eventId);

    echo json_encode([
        'success' => true,
        'has_evaluated' => (bool) $eval,
        'certificate' => [
            'serial_number' => $serial,
            'student_name' => $student['full_name'],
            'student_id' => $student['student_id'],
            'program' => $student['program_name'] ?: 'BSIT',
            'year_level' => $student['year_level'] ?: 'Fourth Year',
            'event_id' => $event['id'],
            'event_name' => $event['name'],
            'venue' => $event['venue'] ?: 'Campus Grounds',
            'event_date' => $event['event_date'],
            'issue_date' => date('F j, Y'),
            'campus' => 'Pangasinan State University - Alaminos Campus',
            'signatory_1' => 'Prof. Mark Aron Nadal',
            'signatory_1_title' => 'Student Affairs Coordinator',
            'signatory_2' => 'Dr. Liza L. Quimson',
            'signatory_2_title' => 'Campus Executive Director'
        ]
    ]);
    exit;
}

if ($action === 'get_students') {
    $students = $db->query('SELECT s.*, p.name as program_name, o.name as organization_name FROM students s LEFT JOIN programs p ON s.program_id = p.id LEFT JOIN organizations o ON s.organization_id = o.id ORDER BY s.full_name ASC')->fetchAll();
    echo json_encode(['success' => true, 'students' => $students]);
    exit;
}

if ($action === 'get_events') {
    $rawEvents = $db->query('SELECT * FROM events ORDER BY id DESC')->fetchAll();
    $events = array_map(function($ev) use ($db, $student) {
        $scCheck = $db->prepare('SELECT id, status FROM attendance WHERE event_id = :event_id AND student_id = :student_id LIMIT 1');
        $scCheck->execute([':event_id' => $ev['id'], ':student_id' => $student['id']]);
        $scRecord = $scCheck->fetch();
        return [
            'id' => $ev['id'],
            'name' => $ev['name'],
            'event_date' => $ev['event_date'],
            'venue' => $ev['venue'],
            'status' => $ev['status'] ?: 'scheduled',
            'attendance_mode' => $ev['attendance_mode'] ?: 'Barcode + Student ID',
            'organizer' => $ev['organizer'] ?: 'Student Affairs Office',
            'verification_interval_minutes' => (int) ($ev['verification_interval_minutes'] ?? 15),
            'radius_meters' => (int) ($ev['radius_meters'] ?? 100),
            'has_scanned' => ($scRecord && strtolower($scRecord['status']) === 'present'),
        ];
    }, $rawEvents);

    echo json_encode(['success' => true, 'events' => $events]);
    exit;
}

if ($action === 'get_history') {
    $historyStmt = $db->prepare('SELECT a.id, a.event_id, e.name as event_name, e.venue, e.status as event_status, a.status, a.scanned_at, ev.certificate_serial FROM attendance a JOIN events e ON a.event_id = e.id LEFT JOIN event_evaluations ev ON (ev.event_id = a.event_id AND ev.student_id = a.student_id) WHERE a.student_id = :student_id ORDER BY a.scanned_at DESC');
    $historyStmt->execute([':student_id' => $student['id']]);
    $historyRows = $historyStmt->fetchAll();

    $history = array_map(function($row) {
        return [
            'id' => $row['id'],
            'event_id' => $row['event_id'],
            'event_name' => $row['event_name'],
            'venue' => $row['venue'],
            'event_status' => $row['event_status'] ?: 'active',
            'status' => $row['status'],
            'scanned_at' => $row['scanned_at'],
            'has_evaluated' => !empty($row['certificate_serial']),
            'certificate_serial' => $row['certificate_serial'] ?: null,
        ];
    }, $historyRows);

    echo json_encode(['success' => true, 'history' => $history]);
    exit;
}

if ($action === 'self_checkin') {
    $eventId = (int) ($_POST['event_id'] ?? 0);
    if ($eventId <= 0) {
        $activeEv = $db->query('SELECT id FROM events WHERE status = "active" LIMIT 1')->fetch();
        $eventId = $activeEv ? (int) $activeEv['id'] : 0;
    }

    if ($eventId <= 0) {
        echo json_encode(['success' => false, 'message' => 'No active event currently available for check-in.']);
        exit;
    }

    // Check duplicate
    $dup = $db->prepare('SELECT id, scanned_at FROM attendance WHERE event_id = :event_id AND student_id = :student_id');
    $dup->execute([':event_id' => $eventId, ':student_id' => $student['id']]);
    if ($dup->fetch()) {
        echo json_encode(['success' => true, 'already_checked_in' => true, 'message' => 'Attendance already recorded for this event.']);
        exit;
    }

    $ins = $db->prepare('INSERT INTO attendance (event_id, student_id, status, scanned_at, scanned_by) VALUES (:event_id, :student_id, "present", CURRENT_TIMESTAMP, "Student App")');
    $ins->execute([':event_id' => $eventId, ':student_id' => $student['id']]);

    logAction($student['full_name'], 'Self Check-in', 'Recorded attendance via Student App for event ID ' . $eventId);

    echo json_encode(['success' => true, 'message' => 'Self check-in recorded successfully!']);
    exit;
}

// Default: get_student_dashboard
$historyStmt = $db->prepare('SELECT a.id, a.event_id, e.name as event_name, e.venue, e.status as event_status, a.status, a.scanned_at, ev.certificate_serial FROM attendance a JOIN events e ON a.event_id = e.id LEFT JOIN event_evaluations ev ON (ev.event_id = a.event_id AND ev.student_id = a.student_id) WHERE a.student_id = :student_id ORDER BY a.scanned_at DESC LIMIT 6');
$historyStmt->execute([':student_id' => $student['id']]);
$recentRows = $historyStmt->fetchAll();

$recentHistory = array_map(function($row) {
    return [
        'id' => $row['id'],
        'event_id' => $row['event_id'],
        'event_name' => $row['event_name'],
        'venue' => $row['venue'],
        'event_status' => $row['event_status'] ?: 'active',
        'status' => $row['status'],
        'scanned_at' => $row['scanned_at'],
        'has_evaluated' => !empty($row['certificate_serial']),
        'certificate_serial' => $row['certificate_serial'] ?: null,
    ];
}, $recentRows);

// Robust Event Query: Fetch ALL active/scheduled/new events created by admin
$rawUpcoming = $db->query('SELECT * FROM events WHERE LOWER(status) != "completed" ORDER BY id DESC LIMIT 5')->fetchAll();
if (empty($rawUpcoming)) {
    $rawUpcoming = $db->query('SELECT * FROM events ORDER BY id DESC LIMIT 5')->fetchAll();
}

$upcomingEvents = array_map(function($ev) use ($db, $student) {
    $scCheck = $db->prepare('SELECT id, status FROM attendance WHERE event_id = :event_id AND student_id = :student_id LIMIT 1');
    $scCheck->execute([':event_id' => $ev['id'], ':student_id' => $student['id']]);
    $scRecord = $scCheck->fetch();
    return [
        'id' => $ev['id'],
        'name' => $ev['name'],
        'event_date' => $ev['event_date'],
        'venue' => $ev['venue'],
        'status' => $ev['status'] ?: 'scheduled',
        'attendance_mode' => $ev['attendance_mode'] ?: 'Barcode + Student ID',
        'organizer' => $ev['organizer'] ?: 'Student Affairs Office',
        'verification_interval_minutes' => (int) ($ev['verification_interval_minutes'] ?? 15),
        'radius_meters' => (int) ($ev['radius_meters'] ?? 100),
        'has_scanned' => ($scRecord && strtolower($scRecord['status']) === 'present'),
    ];
}, $rawUpcoming);

$activeEv = $db->query('SELECT id FROM events WHERE status = "active" LIMIT 1')->fetch();
$activeEventId = $activeEv ? (int) $activeEv['id'] : 1;

$scannedCheck = $db->prepare('SELECT id FROM attendance WHERE event_id = :event_id AND student_id = :student_id AND status = "present" LIMIT 1');
$scannedCheck->execute([':event_id' => $activeEventId, ':student_id' => $student['id']]);
$hasScannedActive = (bool) $scannedCheck->fetch();

$totalAttendedStmt = $db->prepare('SELECT COUNT(*) FROM attendance WHERE student_id = :student_id AND status = "present"');
$totalAttendedStmt->execute([':student_id' => $student['id']]);
$eventsAttended = (int) $totalAttendedStmt->fetchColumn();

echo json_encode([
    'success' => true,
    'student' => [
        'id' => $student['id'],
        'student_id' => $student['student_id'],
        'full_name' => $student['full_name'],
        'program' => $student['program_name'] ?: 'BSIT',
        'organization' => $student['organization_name'] ?: 'DOIT',
        'year_level' => $student['year_level'] ?: 'Fourth Year',
        'section_block' => $student['section_block'] ?: '4A',
        'email' => $student['email'] ?: 'student@psu.edu.ph',
        'phone' => $student['phone'] ?: '09171112222',
        'campus' => 'PSU Alaminos Campus'
    ],
    'stats' => [
        'events_attended' => $eventsAttended,
        'upcoming_events' => count($upcomingEvents),
        'standing' => 'Good',
        'standing_subtitle' => 'Compliant',
        'has_scanned' => $hasScannedActive
    ],
    'upcoming_events' => $upcomingEvents,
    'recent_attendance' => $recentHistory
]);
